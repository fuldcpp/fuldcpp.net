/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <api/UpdateApi.h>

#include <airdcpp/core/update/UpdateDownloader.h>
#include <airdcpp/core/update/UpdateManager.h>
#include <airdcpp/core/version.h>

namespace webserver {
	UpdateApi::UpdateApi(Session* aSession) : SubscribableApiModule(aSession, Access::ADMIN) {
		createSubscriptions({
			"update_available",
			"update_bad_version",
			"update_failed",
			"update_downloaded"
		});

		METHOD_HANDLER(Access::ADMIN,	METHOD_GET,		(EXACT_PARAM("info")),		UpdateApi::handleGetInfo);
		METHOD_HANDLER(Access::ADMIN,	METHOD_POST,	(EXACT_PARAM("check")),		UpdateApi::handleCheck);
		METHOD_HANDLER(Access::ADMIN,	METHOD_POST,	(EXACT_PARAM("download")),	UpdateApi::handleDownload);

		UpdateManager::getInstance()->addListener(this);
	}

	UpdateApi::~UpdateApi() {
		UpdateManager::getInstance()->removeListener(this);
	}

	json UpdateApi::serializeVersionInfo() const noexcept {
		json latest = nullptr;
		{
			RLock l(cs);
			if (latestVersion) {
				latest = {
					{ "title", latestTitle },
					{ "version", latestVersion->versionStr },
					{ "build", latestVersion->build },
					{ "info_url", latestVersion->infoUrl },
					{ "auto_update", latestVersion->autoUpdate },
				};
			}
		}

		json ret = {
			{ "current_version", VERSIONSTRING },
			{ "current_build", BUILD_NUMBER },
			{ "latest", latest },
		};

#ifndef NO_CLIENT_UPDATER
		auto um = UpdateManager::getInstance();
		if (um->isUpdaterInitialized()) {
			ret["downloading"] = um->getUpdater().isUpdating();
			ret["downloaded_build"] = um->getUpdater().getInstalledUpdate();
		}
#endif

		return ret;
	}

	api_return UpdateApi::handleGetInfo(ApiRequest& aRequest) {
		aRequest.setResponseBody(serializeVersionInfo());
		return http::status::ok;
	}

	api_return UpdateApi::handleCheck(ApiRequest& aRequest) {
		auto um = UpdateManager::getInstance();
		if (!um->isUpdaterInitialized()) {
			aRequest.setResponseErrorStr("The updater has not been initialized by the application");
			return http::status::precondition_failed;
		}

		// The version check state is not synchronized for concurrent callers; use the task queue
		addAsyncTask([] {
			UpdateManager::getInstance()->checkVersion(true);
		});

		return http::status::no_content;
	}

	api_return UpdateApi::handleDownload(ApiRequest& aRequest) {
#ifdef NO_CLIENT_UPDATER
		aRequest.setResponseErrorStr("Client updating is not supported on this platform");
		return http::status::precondition_failed;
#else
		auto um = UpdateManager::getInstance();
		if (!um->isUpdaterInitialized()) {
			aRequest.setResponseErrorStr("The updater has not been initialized by the application");
			return http::status::precondition_failed;
		}

		optional<UpdateVersion> version;
		{
			RLock l(cs);
			version = latestVersion;
		}

		if (!version) {
			aRequest.setResponseErrorStr("No update is available (run a version check first)");
			return http::status::conflict;
		}

		if (version->build <= BUILD_NUMBER) {
			aRequest.setResponseErrorStr("The running version is up to date");
			return http::status::conflict;
		}

		if (!version->autoUpdate) {
			aRequest.setResponseErrorStr("The available update can't be installed automatically; download it manually from " + version->infoUrl);
			return http::status::conflict;
		}

		if (um->getUpdater().isUpdating()) {
			aRequest.setResponseErrorStr("An update is being downloaded already");
			return http::status::conflict;
		}

		um->getUpdater().downloadUpdate(*version, true);
		return http::status::no_content;
#endif
	}

	void UpdateApi::on(UpdateManagerListener::UpdateAvailable, const string& aTitle, const string& aMessage, const UpdateVersion& aVersion) noexcept {
		{
			WLock l(cs);
			latestVersion = aVersion;
			latestTitle = aTitle;
		}

		maybeSend("update_available", [&] {
			return json({
				{ "title", aTitle },
				{ "message", aMessage },
				{ "version", aVersion.versionStr },
				{ "build", aVersion.build },
				{ "info_url", aVersion.infoUrl },
				{ "auto_update", aVersion.autoUpdate },
			});
		});
	}

	void UpdateApi::on(UpdateManagerListener::BadVersion, const string& aMessage, const UpdateVersion& aVersion) noexcept {
		// Cache the mandatory update so that it can be downloaded as well
		{
			WLock l(cs);
			latestVersion = aVersion;
			latestTitle = aMessage;
		}

		maybeSend("update_bad_version", [&] {
			return json({
				{ "message", aMessage },
				{ "version", aVersion.versionStr },
				{ "build", aVersion.build },
				{ "info_url", aVersion.infoUrl },
				{ "auto_update", aVersion.autoUpdate },
			});
		});
	}

	void UpdateApi::on(UpdateManagerListener::UpdateFailed, const string& aMessage) noexcept {
		maybeSend("update_failed", [&] {
			return json({ { "message", aMessage } });
		});
	}

	void UpdateApi::on(UpdateManagerListener::UpdateComplete, const string&) noexcept {
		maybeSend("update_downloaded", [] {
			return json({
				{ "message", "The update has been downloaded; it will be installed when the application is restarted" },
			});
		});
	}
}
