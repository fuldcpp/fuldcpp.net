/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#ifdef HAVE_CORE_MODULES

#include <api/HublistApi.h>

#include <api/common/Serializer.h>

#include <web-server/JsonUtil.h>

#include <airdcpp/core/thread/CriticalSection.h>
#include <airdcpp/modules/HublistManager.h>

namespace webserver {

	// The manager assumes single-threaded (desktop UI) usage and the web server task pool
	// runs multiple threads; serialize all API-triggered operations. Note that concurrent
	// desktop usage of the manager remains unsynchronized (accepted residual risk).
	static CriticalSection hublistCs;

	HublistApi::HublistApi(Session* aSession) : SubscribableApiModule(aSession, Access::HUBS_VIEW) {
		createSubscriptions({
			"hublist_download_started",
			"hublist_download_failed",
			"hublist_download_finished",
			"hublist_loaded_from_cache",
			"hublist_corrupted"
		});

		METHOD_HANDLER(Access::HUBS_VIEW,	METHOD_GET,		(EXACT_PARAM("status")),	HublistApi::handleGetStatus);
		METHOD_HANDLER(Access::HUBS_VIEW,	METHOD_GET,		(EXACT_PARAM("entries")),	HublistApi::handleGetEntries);
		METHOD_HANDLER(Access::HUBS_VIEW,	METHOD_POST,	(EXACT_PARAM("select")),	HublistApi::handleSelect);
		METHOD_HANDLER(Access::HUBS_VIEW,	METHOD_POST,	(EXACT_PARAM("refresh")),	HublistApi::handleRefresh);

		HublistManager::getInstance()->addListener(this);
	}

	HublistApi::~HublistApi() {
		HublistManager::getInstance()->removeListener(this);
	}

	json HublistApi::serializeEntry(const HublistEntry& aEntry) noexcept {
		return {
			{ "name", aEntry.getName() },
			{ "server", aEntry.getServer() },
			{ "description", aEntry.getDescription() },
			{ "country", aEntry.getCountry() },
			{ "rating", aEntry.getRating() },
			{ "reliability", aEntry.getReliability() },
			{ "shared", aEntry.getShared() },
			{ "min_share", aEntry.getMinShare() },
			{ "users", aEntry.getUsers() },
			{ "min_slots", aEntry.getMinSlots() },
			{ "max_hubs", aEntry.getMaxHubs() },
			{ "max_users", aEntry.getMaxUsers() },
		};
	}

	api_return HublistApi::handleGetStatus(ApiRequest& aRequest) {
		auto hm = HublistManager::getInstance();
		auto servers = hm->getHubLists();

		// The manager increments the index past the end on download failures
		auto selected = hm->getSelectedHubList();
		if (!servers.empty()) {
			selected = selected % static_cast<int>(servers.size());
		}

		aRequest.setResponseBody({
			{ "servers", servers },
			{ "selected", selected },
			{ "downloading", hm->isDownloading() },
		});

		return http::status::ok;
	}

	api_return HublistApi::handleGetEntries(ApiRequest& aRequest) {
		auto entries = HublistManager::getInstance()->getPublicHubs();
		aRequest.setResponseBody(Serializer::serializeList(entries, serializeEntry));
		return http::status::ok;
	}

	api_return HublistApi::handleSelect(ApiRequest& aRequest) {
		auto index = JsonUtil::getField<int>("index", aRequest.getRequestBody(), false);

		auto servers = HublistManager::getInstance()->getHubLists();
		if (index < 0 || static_cast<size_t>(index) >= servers.size()) {
			aRequest.setResponseErrorStr("Hublist index out of range");
			return http::status::bad_request;
		}

		addAsyncTask([index] {
			Lock l(hublistCs);
			HublistManager::getInstance()->setHubList(index);
		});

		return http::status::no_content;
	}

	api_return HublistApi::handleRefresh(ApiRequest& aRequest) {
		auto force = JsonUtil::getOptionalFieldDefault<bool>("force", aRequest.getRequestBody(), false);

		addAsyncTask([force] {
			Lock l(hublistCs);
			HublistManager::getInstance()->refresh(force);
		});

		return http::status::no_content;
	}

	void HublistApi::on(HublistManagerListener::DownloadStarting, const string& aServer) noexcept {
		maybeSend("hublist_download_started", [&] {
			return json({ { "server", aServer } });
		});
	}

	void HublistApi::on(HublistManagerListener::DownloadFailed, const string& aError) noexcept {
		// The listener argument is the HTTP error line, not the server URL
		maybeSend("hublist_download_failed", [&] {
			return json({ { "message", aError } });
		});
	}

	void HublistApi::on(HublistManagerListener::DownloadFinished, const string& aServer) noexcept {
		maybeSend("hublist_download_finished", [&] {
			return json({ { "server", aServer } });
		});
	}

	void HublistApi::on(HublistManagerListener::LoadedFromCache, const string& aServer, const string& aDate) noexcept {
		maybeSend("hublist_loaded_from_cache", [&] {
			return json({
				{ "server", aServer },
				{ "cache_date", aDate },
			});
		});
	}

	void HublistApi::on(HublistManagerListener::Corrupted, const string& aServer) noexcept {
		maybeSend("hublist_corrupted", [&] {
			return json({ { "server", aServer } });
		});
	}
}

#endif // HAVE_CORE_MODULES
