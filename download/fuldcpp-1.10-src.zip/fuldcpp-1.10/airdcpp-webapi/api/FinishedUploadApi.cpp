/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#ifdef HAVE_CORE_MODULES

#include <api/FinishedUploadApi.h>

#include <api/common/Serializer.h>

#include <airdcpp/modules/FinishedManager.h>
#include <airdcpp/util/PathUtil.h>

namespace webserver {
	FinishedUploadApi::FinishedUploadApi(Session* aSession) : SubscribableApiModule(aSession, Access::TRANSFERS) {
		createSubscriptions({
			"finished_upload_added",
			"finished_upload_removed",
			"finished_uploads_cleared"
		});

		METHOD_HANDLER(Access::TRANSFERS,	METHOD_GET,		(),							FinishedUploadApi::handleGetItems);
		METHOD_HANDLER(Access::TRANSFERS,	METHOD_DELETE,	(TOKEN_PARAM),				FinishedUploadApi::handleRemoveItem);
		METHOD_HANDLER(Access::TRANSFERS,	METHOD_POST,	(EXACT_PARAM("clear")),		FinishedUploadApi::handleClear);

		FinishedManager::getInstance()->addListener(this);
	}

	FinishedUploadApi::~FinishedUploadApi() {
		FinishedManager::getInstance()->removeListener(this);
	}

	json FinishedUploadApi::serializeFinishedItem(const FinishedItemPtr& aItem) noexcept {
		return {
			{ "id", aItem->getToken() },
			{ "user", Serializer::serializeHintedUser(aItem->getUser()) },
			{ "name", PathUtil::getFileName(aItem->getTarget()) },
			{ "path", PathUtil::getFilePath(aItem->getTarget()) },
			{ "size", aItem->getSize() },
			{ "speed", aItem->getAvgSpeed() },
			{ "time", aItem->getTime() },
			{ "tth", aItem->getTTH() == TTHValue() ? Util::emptyString : aItem->getTTH().toBase32() },
		};
	}

	FinishedItemPtr FinishedUploadApi::parseItemToken(ApiRequest& aRequest) {
		auto token = aRequest.getTokenParam();

		FinishedItemPtr ret = nullptr;
		{
			auto fm = FinishedManager::getInstance();
			for (const auto& item: fm->lockList()) {
				if (item->getToken() == token) {
					ret = item;
					break;
				}
			}

			fm->unlockList();
		}

		return ret;
	}

	api_return FinishedUploadApi::handleGetItems(ApiRequest& aRequest) {
		FinishedItemList items;
		{
			auto fm = FinishedManager::getInstance();
			items = fm->lockList();
			fm->unlockList();
		}

		aRequest.setResponseBody(Serializer::serializeList(items, serializeFinishedItem));
		return http::status::ok;
	}

	api_return FinishedUploadApi::handleRemoveItem(ApiRequest& aRequest) {
		auto item = parseItemToken(aRequest);
		if (!item) {
			aRequest.setResponseErrorStr("Finished upload not found");
			return http::status::not_found;
		}

		FinishedManager::getInstance()->remove(item);
		return http::status::no_content;
	}

	api_return FinishedUploadApi::handleClear(ApiRequest&) {
		FinishedManager::getInstance()->removeAll();
		return http::status::no_content;
	}

	void FinishedUploadApi::on(FinishedManagerListener::AddedUl, const FinishedItemPtr& aItem) noexcept {
		maybeSend("finished_upload_added", [&] {
			return serializeFinishedItem(aItem);
		});
	}

	void FinishedUploadApi::on(FinishedManagerListener::RemovedUl, const FinishedItemPtr& aItem) noexcept {
		maybeSend("finished_upload_removed", [&] {
			return serializeFinishedItem(aItem);
		});
	}

	void FinishedUploadApi::on(FinishedManagerListener::RemovedAllUl) noexcept {
		maybeSend("finished_uploads_cleared", [] {
			return json::object();
		});
	}
}

#endif // HAVE_CORE_MODULES
