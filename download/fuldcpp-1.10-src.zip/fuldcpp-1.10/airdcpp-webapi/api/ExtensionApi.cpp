/*
* Copyright (C) 2011-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <api/ExtensionApi.h>
#include <api/common/Serializer.h>

#include <web-server/JsonUtil.h>
#include <web-server/Extension.h>
#include <web-server/ExtensionManager.h>
#include <web-server/Session.h>
#include <web-server/WebServerManager.h>

#include <airdcpp/core/classes/Exception.h>
#include <airdcpp/core/io/File.h>
#include <airdcpp/util/LinkUtil.h>
#include <airdcpp/util/NetworkUtil.h>
#include <airdcpp/util/text/Text.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/Util.h>

#include <web-server/WebUser.h>

#include <boost/asio/ip/address.hpp>


#define EXTENSION_PARAM_ID "extension"
#define EXTENSION_PARAM (ApiModule::RequestHandler::Param(EXTENSION_PARAM_ID, regex(R"(^airdcpp-.+$)")))
namespace webserver {
	StringList ExtensionApi::subscriptionList = {
		"extension_added",
		"extension_removed",
		"extension_installation_started",
		"extension_installation_succeeded",
		"extension_installation_failed",
	};

	ExtensionApi::ExtensionApi(Session* aSession) : 
		ParentApiModule(EXTENSION_PARAM, Access::SETTINGS_VIEW, Access::ADMIN, aSession,
			[](const string& aId) { return aId; },
			[](const ExtensionInfo& aInfo) { return ExtensionInfo::serializeExtension(aInfo.getExtension()); }
		),
		em(aSession->getServer()->getExtensionManager())
	{
		em.addListener(this);

		createSubscriptions(subscriptionList, ExtensionInfo::subscriptionList);

		METHOD_HANDLER(Access::ADMIN, METHOD_POST, (), ExtensionApi::handlePostExtension);
		METHOD_HANDLER(Access::ADMIN, METHOD_POST, (EXACT_PARAM("download")), ExtensionApi::handleDownloadExtension);
		METHOD_HANDLER(Access::ADMIN, METHOD_POST, (EXACT_PARAM("install_local")), ExtensionApi::handleInstallLocalExtension);

		METHOD_HANDLER(Access::SETTINGS_VIEW, METHOD_GET, (EXACT_PARAM("engines"), EXACT_PARAM("status")), ExtensionApi::handleGetEngineStatuses);
		// TODO
		//METHOD_HANDLER(Access::ADMIN, METHOD_PUT, (EXACT_PARAM("engines")), ExtensionApi::handlePutEngines);
		//METHOD_HANDLER(Access::SETTINGS_VIEW, METHOD_GET, (EXACT_PARAM("engines")), ExtensionApi::handleGetEngines);

		for (const auto& ext: em.getExtensions()) {
			addExtension(ext);
		}
	}

	ExtensionApi::~ExtensionApi() {
		em.removeListener(this);
	}

	void ExtensionApi::addExtension(const ExtensionPtr& aExtension) noexcept {
		addSubModule(aExtension->getName(), std::make_shared<ExtensionInfo>(this, aExtension));
	}

	api_return ExtensionApi::handlePostExtension(ApiRequest& aRequest) {
		const auto& reqJson = aRequest.getRequestBody();

		try {
			auto ext = em.registerRemoteExtensionThrow(aRequest.getSession(), reqJson);
			aRequest.setResponseBody(ExtensionInfo::serializeExtension(ext));
		} catch (const Exception& e) {
			aRequest.setResponseErrorStr(e.getError());
			return http::status::bad_request;
		}

		return http::status::ok;
	}



	// Validates that the URL is an http(s) URL and does not target a private/loopback host.
	// Hostname (non-literal) targets cannot be safely resolved here without TOCTOU, so only
	// literal IP destinations and the obvious localhost alias are rejected.
	static void validateDownloadUrlThrow(const string& aUrl) {
		if (Util::findSubString(aUrl, "http://") != 0 && Util::findSubString(aUrl, "https://") != 0) {
			JsonUtil::throwError("url", JsonException::ERROR_INVALID, "Invalid URL");
		}

		string protocol, host, port, path, query, fragment;
		LinkUtil::decodeUrl(aUrl, protocol, host, port, path, query, fragment);

		if (host.empty()) {
			JsonUtil::throwError("url", JsonException::ERROR_INVALID, "Invalid URL");
		}

		// One implementation, in the core, shared with the address proxy and re-applied on every
		// redirect hop underneath this request (HttpOptions::publicDestinationsOnly). Keeping a
		// second copy here is what let the two drift apart in the first place.
		if (NetworkUtil::isBlockedDestinationHost(host)) {
			JsonUtil::throwError("url", JsonException::ERROR_INVALID, "Destination address is not allowed");
		}
	}

	api_return ExtensionApi::handleDownloadExtension(ApiRequest& aRequest) {
		const auto& reqJson = aRequest.getRequestBody();

		auto installId = JsonUtil::getField<string>("install_id", reqJson, false);
		auto url = JsonUtil::getField<string>("url", reqJson, false);
		auto sha = JsonUtil::getOptionalFieldDefault<string>("shasum", reqJson, Util::emptyString);
		// The catalogue publishes this beside the shasum; a caller that has one must be able to
		// pass it on, or installing through the API would be weaker than installing directly.
		auto integrity = JsonUtil::getOptionalFieldDefault<string>("integrity", reqJson, Util::emptyString);

		validateDownloadUrlThrow(url);

		if (!em.downloadExtension(installId, url, sha, integrity)) {
			aRequest.setResponseErrorStr("Extension is being download already");
			return http::status::conflict;
		}

		return http::status::no_content;
	}

	// Catches the outcome of one installation while it runs inside the request. The manager
	// fires its events on the installing thread, so by the time the call returns the result
	// is known and can be answered directly instead of leaving the caller to chase events
	// that were sent before the response
	class InstallOutcomeListener : private ExtensionManagerListener {
	public:
		InstallOutcomeListener(ExtensionManager& aEm, const string& aInstallId) : em(aEm), installId(aInstallId) {
			em.addListener(this);
		}

		~InstallOutcomeListener() {
			em.removeListener(this);
		}

		ExtensionPtr extension;
		string error;
	private:
		void on(ExtensionManagerListener::InstallationSucceeded, const string& aInstallId, const ExtensionPtr& aExtension, bool) noexcept override {
			if (aInstallId == installId) {
				extension = aExtension;
			}
		}

		void on(ExtensionManagerListener::InstallationFailed, const string& aInstallId, const string& aError) noexcept override {
			if (aInstallId == installId) {
				error = aError;
			}
		}

		ExtensionManager& em;
		const string installId;
	};

	// Installs a package file that is on the server's own disk. Administrators only, like a
	// download: either way the caller chooses what code gets installed. The file is only ever
	// read as a tarball, and the events carry the install id but never the path. The
	// installation runs to completion inside the request (as the uninstall below does), so
	// the response carries the outcome: the installed extension, or the failure
	api_return ExtensionApi::handleInstallLocalExtension(ApiRequest& aRequest) {
		const auto& reqJson = aRequest.getRequestBody();

		auto path = JsonUtil::getField<string>("path", reqJson, false);
		if (!File::isAbsolutePath(path)) {
			JsonUtil::throwError("path", JsonException::ERROR_INVALID, "Absolute path required");
		}

		auto installId = JsonUtil::getOptionalFieldDefault<string>("install_id", reqJson, Util::emptyString);
		if (installId.empty()) {
			installId = ExtensionManager::getPackageFileName(path);
		}

		if (installId.empty()) {
			JsonUtil::throwError("path", JsonException::ERROR_INVALID, "File name required");
		}

		InstallOutcomeListener outcome(em, installId);
		if (!em.installExtensionFromFile(installId, path)) {
			aRequest.setResponseErrorStr("Extension is being installed already");
			return http::status::conflict;
		}

		if (!outcome.extension) {
			aRequest.setResponseErrorStr(outcome.error);
			return http::status::bad_request;
		}

		aRequest.setResponseBody(ExtensionInfo::serializeExtension(outcome.extension));
		return http::status::ok;
	}

	api_return ExtensionApi::handleDeleteSubmodule(ApiRequest& aRequest) {
		// Uninstalling deletes the extension's files from disk, so it belongs with the
		// module's other administrative endpoints. The inherited DELETE route is registered
		// with the parent module's access instead, which is SETTINGS_VIEW here - a read-only
		// account could uninstall any extension while being unable to change a setting.
		if (!aRequest.getSession()->getUser()->hasPermission(Access::ADMIN)) {
			aRequest.setResponseErrorStr("Administrator permissions are required to remove extensions");
			return http::status::forbidden;
		}

		auto extensionInfo = getSubModule(aRequest);
		try {
			if (extensionInfo->getExtension()->isManaged()) {
				em.uninstallLocalExtensionThrow(extensionInfo->getExtension());
			} else {
				em.unregisterRemoteExtension(extensionInfo->getExtension());
			}
		} catch (const Exception& e) {
			aRequest.setResponseErrorStr(e.getError());
			return http::status::internal_server_error;
		}

		return http::status::no_content;
	}

	api_return ExtensionApi::handleGetEngineStatuses(ApiRequest& aRequest) {
		// Absolute executable paths are sensitive (they disclose the local filesystem layout).
		// Only administrators may see the resolved command; read-only callers get the basename.
		const auto disclosePaths = aRequest.getSession()->getUser()->hasPermission(Access::ADMIN);

		auto ret = json::object();
		for (const auto& e: em.getEngines()) {
			// The engine's configured command, not its name: the name is a label ("node"),
			// while the command is the "command1;command2;..." list that is actually searched
			// for, exactly as starting an extension does. Probing the name instead reported a
			// perfectly good engine as missing whenever it had been pointed somewhere specific,
			// and ignored the fallbacks the default command carries.
			auto command = ExtensionManager::selectEngineCommand(e.command);
			if (!command.empty()) {
				if (!disclosePaths && File::isAbsolutePath(command)) {
					ret[e.name] = PathUtil::getFileName(command);
				} else {
					ret[e.name] = command;
				}
			} else {
				ret[e.name] = nullptr;
			}
		}

		aRequest.setResponseBody(ret);
		return http::status::ok;
	}

	void ExtensionApi::on(ExtensionManagerListener::ExtensionAdded, const ExtensionPtr& aExtension) noexcept {
		addExtension(aExtension);

		maybeSend("extension_added", [&] {
			return ExtensionInfo::serializeExtension(aExtension);
		});
	}

	void ExtensionApi::on(ExtensionManagerListener::ExtensionRemoved, const ExtensionPtr& aExtension) noexcept {
		removeSubModule(aExtension->getName());
		maybeSend("extension_removed", [&] {
			return ExtensionInfo::serializeExtension(aExtension);
		});
	}

	void ExtensionApi::on(ExtensionManagerListener::InstallationStarted, const string& aInstallId) noexcept {
		maybeSend("extension_installation_started", [&] {
			return json({
				{ "install_id", aInstallId },
			});
		});
	}

	void ExtensionApi::on(ExtensionManagerListener::InstallationSucceeded, const string& aInstallId, const ExtensionPtr&, bool) noexcept {
		maybeSend("extension_installation_succeeded", [&] {
			return json({
				{ "install_id", aInstallId },
			});
		});
	}

	void ExtensionApi::on(ExtensionManagerListener::InstallationFailed, const string& aInstallId, const string& aError) noexcept {
		maybeSend("extension_installation_failed", [&] {
			return json({
				{ "install_id", aInstallId },
				{ "error", aError },
			});
		});
	}
}