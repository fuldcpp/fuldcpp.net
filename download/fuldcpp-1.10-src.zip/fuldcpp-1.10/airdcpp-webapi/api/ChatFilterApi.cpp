/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <api/ChatFilterApi.h>

#include <web-server/JsonUtil.h>

namespace webserver {

	// Validate the pattern with the same engine the filter actually runs on (StringMatch),
	// so a pattern that validates here behaves identically once stored. A plain boost::regex
	// check would diverge from the ICU/std::regex fallback the matcher uses.
	static void validatePattern(const string& aFieldName, const string& aPattern, StringMatch::Method aMethod) {
		if (aPattern.empty()) {
			return;
		}

		StringMatch matcher;
		matcher.setMethod(aMethod);
		matcher.pattern = aPattern;
		if (!matcher.prepare()) {
			JsonUtil::throwError(aFieldName, JsonException::ERROR_INVALID, "Invalid pattern");
		}
	}

	static const map<StringMatch::Method, string> matcherNames = {
		{ StringMatch::PARTIAL, "partial" },
		{ StringMatch::REGEX, "regex" },
		{ StringMatch::WILDCARD, "wildcard" },
		{ StringMatch::EXACT, "exact" },
	};

	static string methodToString(StringMatch::Method aMethod) noexcept {
		auto i = matcherNames.find(aMethod);
		return i != matcherNames.end() ? i->second : "partial";
	}

	static StringMatch::Method methodFromString(const string& aFieldName, const string& aValue) {
		for (const auto& [method, name]: matcherNames) {
			if (name == aValue) {
				return method;
			}
		}

		JsonUtil::throwError(aFieldName, JsonException::ERROR_INVALID, "Invalid matcher type: " + aValue);
		return StringMatch::PARTIAL;
	}

	ChatFilterApi::ChatFilterApi(Session* aSession) : ApiModule(aSession) {
		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(EXACT_PARAM("items")),		ChatFilterApi::handleGetItems);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_PUT,		(EXACT_PARAM("items")),		ChatFilterApi::handleSetItems);
	}

	json ChatFilterApi::serializeItem(const ChatFilterItem& aItem) noexcept {
		return {
			{ "nick_pattern", aItem.getNickPattern() },
			{ "nick_method", methodToString(aItem.getNickMethod()) },
			{ "text_pattern", aItem.getTextPattern() },
			{ "text_method", methodToString(aItem.getTextMethod()) },
			{ "main_chat", aItem.matchMainchat },
			{ "private_chat", aItem.matchPM },
			{ "enabled", aItem.getEnabled() },
		};
	}

	ChatFilterItem ChatFilterApi::deserializeItem(const json& aJson) {
		auto nickPattern = JsonUtil::getOptionalFieldDefault<string>("nick_pattern", aJson, Util::emptyString);
		auto textPattern = JsonUtil::getOptionalFieldDefault<string>("text_pattern", aJson, Util::emptyString);

		if (nickPattern.empty() && textPattern.empty()) {
			JsonUtil::throwError("nick_pattern", JsonException::ERROR_INVALID, "A nick or text pattern is required");
		}

		auto nickMethod = methodFromString("nick_method", JsonUtil::getOptionalFieldDefault<string>("nick_method", aJson, "partial"));
		auto textMethod = methodFromString("text_method", JsonUtil::getOptionalFieldDefault<string>("text_method", aJson, "partial"));

		// Validate the patterns up front so a bad pattern is a clean 400 rather than a
		// silently-broken filter (the ChatFilterItem ctor prepares but discards the result)
		validatePattern("nick_pattern", nickPattern, nickMethod);
		validatePattern("text_pattern", textPattern, textMethod);

		auto mainChat = JsonUtil::getOptionalFieldDefault<bool>("main_chat", aJson, true);
		auto privateChat = JsonUtil::getOptionalFieldDefault<bool>("private_chat", aJson, true);

		if (!mainChat && !privateChat) {
			JsonUtil::throwError("main_chat", JsonException::ERROR_INVALID, "At least one of main chat or private chat is required");
		}

		auto enabled = JsonUtil::getOptionalFieldDefault<bool>("enabled", aJson, true);

		return ChatFilterItem(nickPattern, textPattern, nickMethod, textMethod, mainChat, privateChat, enabled);
	}

	api_return ChatFilterApi::handleGetItems(ApiRequest& aRequest) {
		auto items = IgnoreManager::getInstance()->getChatFilters();

		auto ret = json::array();
		for (const auto& item: items) {
			ret.push_back(serializeItem(item));
		}

		aRequest.setResponseBody(ret);
		return http::status::ok;
	}

	api_return ChatFilterApi::handleSetItems(ApiRequest& aRequest) {
		const auto& itemsJson = aRequest.getRequestBody();
		if (!itemsJson.is_array()) {
			JsonUtil::throwError("items", JsonException::ERROR_INVALID, "An array of filters is required");
		}

		IgnoreManager::ChatFilterItemList items;
		for (const auto& itemJson: itemsJson) {
			items.push_back(deserializeItem(itemJson));
		}

		IgnoreManager::getInstance()->setChatFilters(items);

		auto ret = json::array();
		for (const auto& item: IgnoreManager::getInstance()->getChatFilters()) {
			ret.push_back(serializeItem(item));
		}

		aRequest.setResponseBody(ret);
		return http::status::ok;
	}
}
