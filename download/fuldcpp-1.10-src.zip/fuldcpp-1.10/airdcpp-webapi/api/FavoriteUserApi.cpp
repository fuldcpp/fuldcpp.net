/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <api/FavoriteUserApi.h>

#include <api/common/Deserializer.h>
#include <api/common/Serializer.h>

#include <web-server/JsonUtil.h>

#include <airdcpp/favorites/FavoriteUserManager.h>

namespace webserver {
	FavoriteUserApi::FavoriteUserApi(Session* aSession) : SubscribableApiModule(aSession, Access::FAVORITE_HUBS_VIEW) {
		createSubscriptions({
			"favorite_user_added",
			"favorite_user_removed",
			"favorite_user_updated"
		});

		METHOD_HANDLER(Access::FAVORITE_HUBS_VIEW,	METHOD_GET,		(),				FavoriteUserApi::handleGetUsers);
		METHOD_HANDLER(Access::FAVORITE_HUBS_EDIT,	METHOD_POST,	(),				FavoriteUserApi::handleAddUser);
		METHOD_HANDLER(Access::FAVORITE_HUBS_EDIT,	METHOD_PATCH,	(CID_PARAM),	FavoriteUserApi::handleUpdateUser);
		METHOD_HANDLER(Access::FAVORITE_HUBS_EDIT,	METHOD_DELETE,	(CID_PARAM),	FavoriteUserApi::handleRemoveUser);

		FavoriteUserManager::getInstance()->addListener(this);
	}

	FavoriteUserApi::~FavoriteUserApi() {
		FavoriteUserManager::getInstance()->removeListener(this);
	}

	UserPtr FavoriteUserApi::getUser(ApiRequest& aRequest) {
		return Deserializer::getUser(aRequest.getCIDParam(), false);
	}

	json FavoriteUserApi::serializeFavoriteUser(const FavoriteUser& aUser) noexcept {
		return {
			{ "user", Serializer::serializeUser(aUser.getUser()) },
			{ "nick", aUser.getNick() },
			{ "hub_url", aUser.getUrl() },
			{ "description", aUser.getDescription() },
			{ "last_seen", aUser.getLastSeen() },
			{ "online", aUser.getUser()->isOnline() },
			{ "auto_grant_slot", aUser.isSet(FavoriteUser::FLAG_GRANTSLOT) },
			{ "limiter_override", aUser.isSet(FavoriteUser::FLAG_SUPERUSER) },
		};
	}

	api_return FavoriteUserApi::handleGetUsers(ApiRequest& aRequest) {
		auto users = FavoriteUserManager::getInstance()->getFavoriteUsers();
		aRequest.setResponseBody(Serializer::serializeList(users, serializeFavoriteUser));
		return http::status::ok;
	}

	api_return FavoriteUserApi::handleAddUser(ApiRequest& aRequest) {
		auto user = Deserializer::deserializeHintedUser(aRequest.getRequestBody(), false);

		auto fum = FavoriteUserManager::getInstance();
		if (fum->getFavoriteUser(user.user)) {
			aRequest.setResponseErrorStr("The user is favorite already");
			return http::status::conflict;
		}

		fum->addFavoriteUser(user);

		auto fu = fum->getFavoriteUser(user.user);
		if (!fu) {
			aRequest.setResponseErrorStr("Adding the favorite user failed");
			return http::status::internal_server_error;
		}

		aRequest.setResponseBody(serializeFavoriteUser(*fu));
		return http::status::ok;
	}

	api_return FavoriteUserApi::handleUpdateUser(ApiRequest& aRequest) {
		const auto& reqJson = aRequest.getRequestBody();
		auto user = getUser(aRequest);

		auto fum = FavoriteUserManager::getInstance();
		if (!fum->getFavoriteUser(user)) {
			aRequest.setResponseErrorStr("The user is not favorite");
			return http::status::not_found;
		}

		// Raw field so that the description can also be cleared with an empty string
		auto descriptionJson = JsonUtil::getOptionalRawField("description", reqJson, false);
		if (!descriptionJson.is_null()) {
			fum->setUserDescription(user, JsonUtil::parseValue<string>("description", descriptionJson, true));
		}

		auto autoGrant = JsonUtil::getOptionalField<bool>("auto_grant_slot", reqJson);
		if (autoGrant) {
			fum->setAutoGrant(user, *autoGrant);
		}

		auto limiterOverride = JsonUtil::getOptionalField<bool>("limiter_override", reqJson);
		if (limiterOverride) {
			fum->setSuperUser(user, *limiterOverride);
		}

		auto fu = fum->getFavoriteUser(user);
		if (!fu) {
			return http::status::not_found;
		}

		aRequest.setResponseBody(serializeFavoriteUser(*fu));
		return http::status::ok;
	}

	api_return FavoriteUserApi::handleRemoveUser(ApiRequest& aRequest) {
		auto user = getUser(aRequest);

		auto fum = FavoriteUserManager::getInstance();
		if (!fum->getFavoriteUser(user)) {
			aRequest.setResponseErrorStr("The user is not favorite");
			return http::status::not_found;
		}

		fum->removeFavoriteUser(user);
		return http::status::no_content;
	}

	void FavoriteUserApi::on(FavoriteUserManagerListener::FavoriteUserAdded, const FavoriteUser& aUser) noexcept {
		maybeSend("favorite_user_added", [&] {
			return serializeFavoriteUser(aUser);
		});
	}

	void FavoriteUserApi::on(FavoriteUserManagerListener::FavoriteUserRemoved, const FavoriteUser& aUser) noexcept {
		maybeSend("favorite_user_removed", [&] {
			return serializeFavoriteUser(aUser);
		});
	}

	void FavoriteUserApi::sendUpdated(const UserPtr& aUser) noexcept {
		if (!subscriptionActive("favorite_user_updated")) {
			return;
		}

		auto fu = FavoriteUserManager::getInstance()->getFavoriteUser(aUser);
		if (!fu) {
			return;
		}

		send("favorite_user_updated", serializeFavoriteUser(*fu));
	}

	void FavoriteUserApi::on(FavoriteUserManagerListener::FavoriteUserUpdated, const UserPtr& aUser) noexcept {
		sendUpdated(aUser);
	}

	void FavoriteUserApi::on(FavoriteUserManagerListener::SlotsUpdated, const UserPtr& aUser) noexcept {
		sendUpdated(aUser);
	}
}
