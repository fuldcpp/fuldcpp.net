/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_UPDATE_API_H
#define DCPLUSPLUS_DCPP_UPDATE_API_H

#include <api/base/SubscribableApiModule.h>

#include <airdcpp/core/header/typedefs.h>
#include <airdcpp/core/thread/CriticalSection.h>

#include <airdcpp/core/update/UpdateManagerListener.h>
#include <airdcpp/core/update/UpdateVersion.h>

namespace webserver {
	class UpdateApi : public SubscribableApiModule, private UpdateManagerListener {
	public:
		UpdateApi(Session* aSession);
		~UpdateApi();
	private:
		json serializeVersionInfo() const noexcept;

		api_return handleGetInfo(ApiRequest& aRequest);
		api_return handleCheck(ApiRequest& aRequest);
		api_return handleDownload(ApiRequest& aRequest);

		void on(UpdateManagerListener::UpdateAvailable, const string& aTitle, const string& aMessage, const UpdateVersion& aVersion) noexcept override;
		void on(UpdateManagerListener::BadVersion, const string& aMessage, const UpdateVersion& aVersion) noexcept override;
		void on(UpdateManagerListener::UpdateFailed, const string& aMessage) noexcept override;
		void on(UpdateManagerListener::UpdateComplete, const string& aUpdater) noexcept override;

		// The latest version info exists only transiently in the listener events; cache it for the info endpoint
		mutable SharedMutex cs;
		optional<UpdateVersion> latestVersion;
		string latestTitle;
	};
}

#endif
