/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_ADL_SEARCH_API_H
#define DCPLUSPLUS_DCPP_ADL_SEARCH_API_H

#ifdef HAVE_CORE_MODULES

#include <api/base/ApiModule.h>

#include <airdcpp/core/header/typedefs.h>

#include <airdcpp/modules/ADLSearch.h>

namespace webserver {
	class AdlSearchApi : public ApiModule {
	public:
		AdlSearchApi(Session* aSession);
	private:
		static json serializeRule(const ADLSearch& aRule, size_t aIndex) noexcept;
		static ADLSearch deserializeRule(const json& aJson, const ADLSearch& aBase);

		api_return handleGetRules(ApiRequest& aRequest);
		api_return handleAddRule(ApiRequest& aRequest);
		api_return handleUpdateRule(ApiRequest& aRequest);
		api_return handleRemoveRule(ApiRequest& aRequest);
		api_return handleMoveRule(ApiRequest& aRequest);

		size_t parseRuleIndex(ApiRequest& aRequest) const;
	};
}

#endif // HAVE_CORE_MODULES

#endif
