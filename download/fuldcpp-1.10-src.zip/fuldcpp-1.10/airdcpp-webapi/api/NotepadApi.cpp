/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <api/NotepadApi.h>

#include <web-server/JsonUtil.h>

#include <airdcpp/core/classes/Exception.h>
#include <airdcpp/core/io/File.h>
#include <airdcpp/util/AppUtil.h>
#include <airdcpp/util/text/Text.h>

namespace webserver {
	// Shares the same file as the desktop notepad frame so notes are common to both
	string NotepadApi::getNotepadPath() noexcept {
		return AppUtil::getPath(AppUtil::PATH_USER_CONFIG) + "Notepad.txt";
	}

	NotepadApi::NotepadApi(Session* aSession) : ApiModule(aSession) {
		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(),		NotepadApi::handleGetNotepad);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(),		NotepadApi::handleSetNotepad);
	}

	api_return NotepadApi::handleGetNotepad(ApiRequest& aRequest) {
		string text;
		try {
			text = File(getNotepadPath(), File::READ, File::OPEN).read();
		} catch (const FileException&) {
			// No notepad file yet; return empty
		}

		// The file is shared with the desktop notepad and legacy files may hold non-UTF-8
		// bytes; those would make the JSON serializer throw. Repair to valid UTF-8 first.
		aRequest.setResponseBody({
			{ "text", Text::sanitizeUtf8(text) },
		});

		return http::status::ok;
	}

	api_return NotepadApi::handleSetNotepad(ApiRequest& aRequest) {
		auto text = JsonUtil::getField<string>("text", aRequest.getRequestBody(), true);

		try {
			// Written to a temporary and swapped in, like the desktop notepad frame does with the
			// same file. Truncating in place means that between the truncate and the write the
			// notes do not exist, so a crash, a power loss or a full disk in that window destroyed
			// them -- and this endpoint and the desktop frame write to the SAME file, so the window
			// is reachable from either. The desktop side was fixed; its sibling here was not.
			const auto path = getNotepadPath();
			File(path + ".tmp", File::WRITE, File::CREATE | File::TRUNCATE).write(text);
			File::replaceAtomic(path + ".tmp", path);
		} catch (const FileException& e) {
			aRequest.setResponseErrorStr("Failed to save the notepad: " + e.getError());
			return http::status::internal_server_error;
		}

		aRequest.setResponseBody({
			{ "text", text },
		});

		return http::status::ok;
	}
}
