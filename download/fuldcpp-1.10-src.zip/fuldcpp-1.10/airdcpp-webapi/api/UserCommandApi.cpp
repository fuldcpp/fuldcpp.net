/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <api/UserCommandApi.h>

#include <web-server/JsonUtil.h>

#include <airdcpp/hub/user_command/UserCommandManager.h>

namespace webserver {

	// Only the user-creatable types are exposed (the remove/clear types are protocol-internal)
	static const map<int, string> typeNames = {
		{ UserCommand::TYPE_SEPARATOR, "separator" },
		{ UserCommand::TYPE_RAW, "raw" },
		{ UserCommand::TYPE_RAW_ONCE, "raw_once" },
		{ UserCommand::TYPE_CHAT, "chat" },
		{ UserCommand::TYPE_CHAT_ONCE, "chat_once" },
	};

	static const map<int, string> contextNames = {
		{ UserCommand::CONTEXT_HUB, "hub" },
		{ UserCommand::CONTEXT_USER, "user" },
		{ UserCommand::CONTEXT_SEARCH, "search" },
		{ UserCommand::CONTEXT_FILELIST, "filelist" },
	};

	UserCommandApi::UserCommandApi(Session* aSession) : ApiModule(aSession) {
		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(),									UserCommandApi::handleGetCommands);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(),									UserCommandApi::handleAddCommand);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_DELETE,	(TOKEN_PARAM),						UserCommandApi::handleRemoveCommand);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(TOKEN_PARAM, EXACT_PARAM("move")),	UserCommandApi::handleMoveCommand);
	}

	string UserCommandApi::serializeType(int aType) noexcept {
		auto i = typeNames.find(aType);
		return i != typeNames.end() ? i->second : "raw";
	}

	int UserCommandApi::parseType(const string& aValue) {
		for (const auto& [type, name]: typeNames) {
			if (name == aValue) {
				return type;
			}
		}

		JsonUtil::throwError("type", JsonException::ERROR_INVALID, "Invalid user command type");
		return UserCommand::TYPE_RAW;
	}

	json UserCommandApi::serializeContexts(int aCtx) noexcept {
		auto ret = json::array();
		for (const auto& [flag, name]: contextNames) {
			if (aCtx & flag) {
				ret.push_back(name);
			}
		}

		return ret;
	}

	int UserCommandApi::parseContexts(const json& aJson) {
		auto contexts = JsonUtil::getOptionalFieldDefault<StringList>("contexts", aJson, StringList());

		int ctx = 0;
		for (const auto& name: contexts) {
			bool found = false;
			for (const auto& [flag, flagName]: contextNames) {
				if (flagName == name) {
					ctx |= flag;
					found = true;
					break;
				}
			}

			if (!found) {
				JsonUtil::throwError("contexts", JsonException::ERROR_INVALID, "Invalid context: " + name);
			}
		}

		return ctx;
	}

	json UserCommandApi::serializeCommand(const UserCommand& aCommand) noexcept {
		return {
			{ "id", aCommand.getId() },
			{ "type", serializeType(aCommand.getType()) },
			{ "contexts", serializeContexts(aCommand.getCtx()) },
			{ "name", aCommand.getName() },
			{ "command", aCommand.getCommand() },
			{ "to", aCommand.getTo() },
			{ "hub", aCommand.getHub() },
		};
	}

	api_return UserCommandApi::handleGetCommands(ApiRequest& aRequest) {
		auto ret = json::array();

		// Only the user's own (saved) commands; hub-provided ones are transient (FLAG_NOSAVE)
		for (const auto& uc: UserCommandManager::getInstance()->getUserCommands()) {
			if (!uc.isSet(UserCommand::FLAG_NOSAVE)) {
				ret.push_back(serializeCommand(uc));
			}
		}

		aRequest.setResponseBody(ret);
		return http::status::ok;
	}

	api_return UserCommandApi::handleAddCommand(ApiRequest& aRequest) {
		const auto& reqJson = aRequest.getRequestBody();

		auto type = parseType(JsonUtil::getField<string>("type", reqJson, false));
		auto ctx = parseContexts(reqJson);
		auto name = JsonUtil::getOptionalFieldDefault<string>("name", reqJson, Util::emptyString);
		auto command = JsonUtil::getOptionalFieldDefault<string>("command", reqJson, Util::emptyString);
		auto to = JsonUtil::getOptionalFieldDefault<string>("to", reqJson, Util::emptyString);
		auto hub = JsonUtil::getOptionalFieldDefault<string>("hub", reqJson, Util::emptyString);

		if (type != UserCommand::TYPE_SEPARATOR) {
			if (command.empty()) {
				JsonUtil::throwError("command", JsonException::ERROR_MISSING, "A command is required");
			}
			if (ctx == 0) {
				JsonUtil::throwError("contexts", JsonException::ERROR_INVALID, "At least one context is required");
			}
		}

		// flags 0 = a saved (persistent) user command
		auto uc = UserCommandManager::getInstance()->addUserCommand(type, ctx, 0, name, command, to, hub);

		aRequest.setResponseBody(serializeCommand(uc));
		return http::status::ok;
	}

	// This module manages the user's own saved commands only, so hub-provided (transient)
	// commands are treated as not found even if their id is known
	static bool findSavedCommand(int aId, UserCommand& uc_) noexcept {
		return UserCommandManager::getInstance()->getUserCommand(aId, uc_) && !uc_.isSet(UserCommand::FLAG_NOSAVE);
	}

	api_return UserCommandApi::handleRemoveCommand(ApiRequest& aRequest) {
		auto id = static_cast<int>(aRequest.getTokenParam());

		UserCommand uc;
		if (!findSavedCommand(id, uc)) {
			aRequest.setResponseErrorStr("User command not found");
			return http::status::not_found;
		}

		UserCommandManager::getInstance()->removeUserCommand(id);
		return http::status::no_content;
	}

	api_return UserCommandApi::handleMoveCommand(ApiRequest& aRequest) {
		auto id = static_cast<int>(aRequest.getTokenParam());
		auto position = JsonUtil::getField<int>("position", aRequest.getRequestBody(), false);

		if (position != -1 && position != 1) {
			JsonUtil::throwError("position", JsonException::ERROR_INVALID, "Position must be -1 (up) or 1 (down)");
		}

		UserCommand uc;
		if (!findSavedCommand(id, uc)) {
			aRequest.setResponseErrorStr("User command not found");
			return http::status::not_found;
		}

		if (!UserCommandManager::getInstance()->moveUserCommand(id, position)) {
			aRequest.setResponseErrorStr("The command is already at the boundary");
			return http::status::conflict;
		}

		return http::status::no_content;
	}
}
