/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_FAVORITE_USER_API_H
#define DCPLUSPLUS_DCPP_FAVORITE_USER_API_H

#include <api/base/SubscribableApiModule.h>

#include <airdcpp/core/header/typedefs.h>

#include <airdcpp/favorites/FavoriteUser.h>
#include <airdcpp/favorites/FavoriteUserManagerListener.h>

namespace webserver {
	class FavoriteUserApi : public SubscribableApiModule, private FavoriteUserManagerListener {
	public:
		FavoriteUserApi(Session* aSession);
		~FavoriteUserApi();
	private:
		static UserPtr getUser(ApiRequest& aRequest);
		static json serializeFavoriteUser(const FavoriteUser& aUser) noexcept;

		api_return handleGetUsers(ApiRequest& aRequest);
		api_return handleAddUser(ApiRequest& aRequest);
		api_return handleUpdateUser(ApiRequest& aRequest);
		api_return handleRemoveUser(ApiRequest& aRequest);

		void sendUpdated(const UserPtr& aUser) noexcept;

		void on(FavoriteUserManagerListener::FavoriteUserAdded, const FavoriteUser& aUser) noexcept override;
		void on(FavoriteUserManagerListener::FavoriteUserRemoved, const FavoriteUser& aUser) noexcept override;
		void on(FavoriteUserManagerListener::FavoriteUserUpdated, const UserPtr& aUser) noexcept override;
		void on(FavoriteUserManagerListener::SlotsUpdated, const UserPtr& aUser) noexcept override;
	};
}

#endif
