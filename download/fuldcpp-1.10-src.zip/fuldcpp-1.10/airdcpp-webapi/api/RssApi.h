/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_RSS_API_H
#define DCPLUSPLUS_DCPP_RSS_API_H

#ifdef HAVE_CORE_MODULES

#include <api/base/SubscribableApiModule.h>

#include <airdcpp/core/header/typedefs.h>

#include <airdcpp/modules/RSSManager.h>

namespace webserver {
	class RssApi : public SubscribableApiModule, private RSSManagerListener {
	public:
		RssApi(Session* aSession);
		~RssApi();
	private:
		// Serializers use only plain getters (may be called from listener events)
		static json serializeFeed(const RSSPtr& aFeed) noexcept;
		static json serializeFeedData(const RSSDataPtr& aData) noexcept;
		static json serializeFilter(const RSSFilter& aFilter) noexcept;
		static RSSFilter deserializeFilter(const json& aJson);

		RSSPtr parseFeedToken(ApiRequest& aRequest);

		api_return handleGetFeeds(ApiRequest& aRequest);
		api_return handleGetFeed(ApiRequest& aRequest);
		api_return handleAddFeed(ApiRequest& aRequest);
		api_return handleUpdateFeed(ApiRequest& aRequest);
		api_return handleRemoveFeed(ApiRequest& aRequest);
		api_return handleRefreshFeed(ApiRequest& aRequest);
		api_return handleMatchFilters(ApiRequest& aRequest);
		api_return handleClearData(ApiRequest& aRequest);
		api_return handleGetFeedData(ApiRequest& aRequest);
		api_return handleGetFilters(ApiRequest& aRequest);
		api_return handleSetFilters(ApiRequest& aRequest);

		void on(RSSManagerListener::RSSFeedAdded, const RSSPtr& aFeed) noexcept override;
		void on(RSSManagerListener::RSSFeedChanged, const RSSPtr& aFeed) noexcept override;
		void on(RSSManagerListener::RSSFeedRemoved, const RSSPtr& aFeed) noexcept override;
		void on(RSSManagerListener::RSSFeedUpdated, const RSSPtr& aFeed) noexcept override;
		void on(RSSManagerListener::RSSDataAdded, const RSSDataPtr& aData) noexcept override;
		void on(RSSManagerListener::RSSDataRemoved, const RSSDataPtr& aData) noexcept override;
		void on(RSSManagerListener::RSSDataCleared, const RSSPtr& aFeed) noexcept override;
	};
}

#endif // HAVE_CORE_MODULES

#endif
