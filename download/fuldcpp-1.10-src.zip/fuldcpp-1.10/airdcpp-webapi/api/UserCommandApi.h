/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_USER_COMMAND_API_H
#define DCPLUSPLUS_DCPP_USER_COMMAND_API_H

#include <api/base/ApiModule.h>

#include <airdcpp/core/header/typedefs.h>

#include <airdcpp/hub/user_command/UserCommand.h>

namespace webserver {
	class UserCommandApi : public ApiModule {
	public:
		UserCommandApi(Session* aSession);
	private:
		static json serializeCommand(const UserCommand& aCommand) noexcept;
		static int parseType(const string& aValue);
		static string serializeType(int aType) noexcept;
		static int parseContexts(const json& aJson);
		static json serializeContexts(int aCtx) noexcept;

		api_return handleGetCommands(ApiRequest& aRequest);
		api_return handleAddCommand(ApiRequest& aRequest);
		api_return handleRemoveCommand(ApiRequest& aRequest);
		api_return handleMoveCommand(ApiRequest& aRequest);
	};
}

#endif
