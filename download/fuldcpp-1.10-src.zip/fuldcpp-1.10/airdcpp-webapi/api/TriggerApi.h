/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_TRIGGERAPI_H
#define DCPLUSPLUS_DCPP_TRIGGERAPI_H

#include <api/base/SubscribableApiModule.h>

#include <airdcpp/core/header/typedefs.h>
#include <airdcpp/user/trigger/TriggerManager.h>
#include <airdcpp/user/trigger/TriggerManagerListener.h>

namespace webserver {
	class TriggerApi : public SubscribableApiModule, private TriggerManagerListener {
	public:
		TriggerApi(Session* aSession);
		~TriggerApi();
	private:
		static json serializeTriggers() noexcept;
		static json serializeTrigger(const TriggerItem& aTrigger) noexcept;
		static json serializeMuted() noexcept;

		api_return handleGetTriggers(ApiRequest& aRequest);
		api_return handleAddTrigger(ApiRequest& aRequest);
		api_return handleUpdateTrigger(ApiRequest& aRequest);
		api_return handleRemoveTrigger(ApiRequest& aRequest);

		api_return handleGetMuted(ApiRequest& aRequest);
		api_return handleSetMuted(ApiRequest& aRequest);

		api_return handleResetStats(ApiRequest& aRequest);

		// Applies the fields present in the request JSON on the item
		// (with defaults being set for all fields of new items)
		static void parseTrigger(TriggerItem& aTrigger, const json& aRequestJson, bool aNewTrigger);

		// Throws ArgumentException for items that TriggerManager::replaceList would drop silently
		static void validateTrigger(const TriggerItem& aTrigger);

		static uint8_t parseMatchMode(const string& aValue) noexcept;
		static uint8_t parseUserClass(const string& aValue) noexcept;
		static uint8_t parseSelectionStrategy(const string& aValue) noexcept;

		static string serializeMatchMode(uint8_t aMode) noexcept;
		static string serializeUserClass(uint8_t aUserClass) noexcept;
		static string serializeSelectionStrategy(uint8_t aStrategy) noexcept;

		static uint32_t parseTriggerIdParam(const ApiRequest& aRequest);
		static TriggerManager::TriggerItemList::iterator findTrigger(TriggerManager::TriggerItemList& aTriggers, uint32_t aId) noexcept;

		void on(TriggerManagerListener::TriggersUpdated) noexcept override;
		void on(TriggerManagerListener::MutedUpdated, bool aMuted) noexcept override;
		void on(TriggerManagerListener::TriggerFired, uint32_t aId, uint32_t aFireCount, time_t aLastFired) noexcept override;
	};
}

#endif