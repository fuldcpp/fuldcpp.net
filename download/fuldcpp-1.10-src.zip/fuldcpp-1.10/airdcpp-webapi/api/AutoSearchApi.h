/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_AUTO_SEARCH_API_H
#define DCPLUSPLUS_DCPP_AUTO_SEARCH_API_H

#ifdef HAVE_CORE_MODULES

#include <api/base/SubscribableApiModule.h>

#include <airdcpp/core/header/typedefs.h>

#include <airdcpp/modules/AutoSearch.h>
#include <airdcpp/modules/AutoSearchManagerListener.h>

namespace webserver {
	class AutoSearchApi : public SubscribableApiModule, private AutoSearchManagerListener {
	public:
		AutoSearchApi(Session* aSession);
		~AutoSearchApi();
	private:
		static json serializeItem(const AutoSearchPtr& aItem) noexcept;
		static void updateItemProperties(AutoSearchPtr& aItem, const json& aJson);

		AutoSearchPtr parseItemToken(ApiRequest& aRequest);

		api_return handleGetItems(ApiRequest& aRequest);
		api_return handleGetItem(ApiRequest& aRequest);
		api_return handleAddItem(ApiRequest& aRequest);
		api_return handleUpdateItem(ApiRequest& aRequest);
		api_return handleRemoveItem(ApiRequest& aRequest);
		api_return handleSearchItem(ApiRequest& aRequest);
		api_return handleGetGroups(ApiRequest& aRequest);

		void on(AutoSearchManagerListener::ItemAdded, const AutoSearchPtr& aItem) noexcept override;
		void on(AutoSearchManagerListener::ItemRemoved, const AutoSearchPtr& aItem) noexcept override;
		void on(AutoSearchManagerListener::ItemUpdated, const AutoSearchPtr& aItem, bool aSetTabDirty) noexcept override;
	};
}

#endif // HAVE_CORE_MODULES

#endif
