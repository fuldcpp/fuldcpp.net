/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <api/UploadQueueApi.h>

#include <api/common/Deserializer.h>
#include <api/common/Serializer.h>

#include <airdcpp/transfer/upload/UploadManager.h>
#include <airdcpp/transfer/upload/UploadQueueManager.h>
#include <airdcpp/util/PathUtil.h>

namespace webserver {
	UploadQueueApi::UploadQueueApi(Session* aSession) : SubscribableApiModule(aSession, Access::TRANSFERS) {
		createSubscriptions({
			"upload_queue_item_added",
			"upload_queue_item_removed",
			"upload_queue_user_removed"
		});

		METHOD_HANDLER(Access::TRANSFERS,	METHOD_GET,		(),				UploadQueueApi::handleGetQueue);
		METHOD_HANDLER(Access::TRANSFERS,	METHOD_DELETE,	(CID_PARAM),	UploadQueueApi::handleRemoveUser);

		UploadManager::getInstance()->getQueue().addListener(this);
	}

	UploadQueueApi::~UploadQueueApi() {
		UploadManager::getInstance()->getQueue().removeListener(this);
	}

	json UploadQueueApi::serializeQueueItem(const UploadQueueItemPtr& aItem) noexcept {
		return {
			{ "id", aItem->getToken() },
			{ "user", Serializer::serializeHintedUser(aItem->getHintedUser()) },
			{ "name", PathUtil::getFileName(aItem->getFile()) },
			{ "path", PathUtil::getFilePath(aItem->getFile()) },
			{ "size", aItem->getSize() },
			{ "position", aItem->getPos() },
			{ "time", aItem->getTime() },
		};
	}

	api_return UploadQueueApi::handleGetQueue(ApiRequest& aRequest) {
		auto queue = UploadManager::getInstance()->getQueue().getUploadQueue();

		auto j = json::array();
		for (const auto& waitingUser: queue) {
			j.push_back({
				{ "user", Serializer::serializeHintedUser(waitingUser.user) },
				{ "files", Serializer::serializeList(waitingUser.files, serializeQueueItem) },
			});
		}

		aRequest.setResponseBody(j);
		return http::status::ok;
	}

	api_return UploadQueueApi::handleRemoveUser(ApiRequest& aRequest) {
		auto user = Deserializer::getUser(aRequest.getCIDParam(), false);
		UploadManager::getInstance()->getQueue().clearUserFiles(user);
		return http::status::no_content;
	}

	// The queue events are fired while the manager lock is held; move serialization
	// and socket work off the core thread (the desktop frame defers these as well)
	void UploadQueueApi::on(UploadQueueManagerListener::QueueAdd, const UploadQueueItemPtr& aItem) noexcept {
		if (!subscriptionActive("upload_queue_item_added")) {
			return;
		}

		addAsyncTask([this, aItem] {
			send("upload_queue_item_added", serializeQueueItem(aItem));
		});
	}

	void UploadQueueApi::on(UploadQueueManagerListener::QueueItemRemove, const UploadQueueItemPtr& aItem) noexcept {
		if (!subscriptionActive("upload_queue_item_removed")) {
			return;
		}

		addAsyncTask([this, aItem] {
			send("upload_queue_item_removed", serializeQueueItem(aItem));
		});
	}

	void UploadQueueApi::on(UploadQueueManagerListener::QueueUserRemove, const UserPtr& aUser) noexcept {
		if (!subscriptionActive("upload_queue_user_removed")) {
			return;
		}

		addAsyncTask([this, aUser] {
			send("upload_queue_user_removed", json({
				{ "user", Serializer::serializeUser(aUser) },
			}));
		});
	}
}
