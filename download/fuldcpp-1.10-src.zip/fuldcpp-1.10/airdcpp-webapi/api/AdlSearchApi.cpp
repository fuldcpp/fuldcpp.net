/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#ifdef HAVE_CORE_MODULES

#include <api/AdlSearchApi.h>

#include <web-server/JsonUtil.h>

#include <airdcpp/core/thread/CriticalSection.h>
#include <airdcpp/core/thread/Thread.h>

#include <boost/regex.hpp>

namespace webserver {

	// The rule collection has no locking of its own (the desktop accesses it from the UI
	// thread only); serialize all API access so that concurrent web requests can't race
	static CriticalSection adlCs;

	AdlSearchApi::AdlSearchApi(Session* aSession) : ApiModule(aSession) {
		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(EXACT_PARAM("rules")),								AdlSearchApi::handleGetRules);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(EXACT_PARAM("rules")),								AdlSearchApi::handleAddRule);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_PATCH,	(EXACT_PARAM("rules"), TOKEN_PARAM),				AdlSearchApi::handleUpdateRule);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_DELETE,	(EXACT_PARAM("rules"), TOKEN_PARAM),				AdlSearchApi::handleRemoveRule);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(EXACT_PARAM("rules"), TOKEN_PARAM, EXACT_PARAM("move")),	AdlSearchApi::handleMoveRule);
	}

	json AdlSearchApi::serializeRule(const ADLSearch& aRule, size_t aIndex) noexcept {
		// The string conversions are non-const members; work on a copy
		auto rule = aRule;
		return {
			{ "index", aIndex },
			{ "pattern", rule.getPattern() },
			{ "regex", rule.isRegEx() },
			{ "source_type", rule.SourceTypeToString(rule.sourceType) },
			{ "dest_dir", rule.getDestDir() },
			{ "min_size", rule.minFileSize },
			{ "max_size", rule.maxFileSize },
			{ "size_type", rule.SizeTypeToString(rule.typeFileSize) },
			{ "active", rule.isActive },
			{ "auto_queue", rule.isAutoQueue },
			{ "comment", rule.adlsComment },
			{ "group", rule.group },
		};
	}

	ADLSearch AdlSearchApi::deserializeRule(const json& aJson, const ADLSearch& aBase) {
		auto rule = aBase;

		auto regEx = JsonUtil::getOptionalField<bool>("regex", aJson);
		if (regEx) {
			rule.setRegEx(*regEx);
		}

		auto pattern = JsonUtil::getOptionalField<string>("pattern", aJson);
		if (pattern) {
			rule.setPattern(*pattern);
		}

		if (rule.isRegEx()) {
			try {
				boost::regex reg(rule.getPattern());
			} catch (const std::exception&) {
				JsonUtil::throwError("pattern", JsonException::ERROR_INVALID, "Invalid regular expression");
			}
		}

		// Both enum fields are checked by round-trip. The StringTo* helpers coerce anything they do
		// not recognise to a default -- Filename and bytes -- so a typo, or a client written
		// against a different spelling, silently produced a rule that matched something else while
		// the API reported success. TriggerApi validates its enums the same way.
		auto sourceType = JsonUtil::getOptionalField<string>("source_type", aJson);
		if (sourceType) {
			auto parsed = rule.StringToSourceType(*sourceType);
			if (Util::stricmp(rule.SourceTypeToString(parsed), *sourceType) != 0) {
				JsonUtil::throwError("source_type", JsonException::ERROR_INVALID, "Unknown value: " + *sourceType);
			}

			rule.sourceType = parsed;
		}

		auto sizeType = JsonUtil::getOptionalField<string>("size_type", aJson);
		if (sizeType) {
			auto parsed = rule.StringToSizeType(*sizeType);
			if (Util::stricmp(rule.SizeTypeToString(parsed), *sizeType) != 0) {
				JsonUtil::throwError("size_type", JsonException::ERROR_INVALID, "Unknown value: " + *sizeType);
			}

			rule.typeFileSize = parsed;
		}

		auto minSize = JsonUtil::getOptionalField<int64_t>("min_size", aJson);
		if (minSize) {
			rule.minFileSize = *minSize;
		}

		auto maxSize = JsonUtil::getOptionalField<int64_t>("max_size", aJson);
		if (maxSize) {
			rule.maxFileSize = *maxSize;
		}

		auto destDir = JsonUtil::getOptionalField<string>("dest_dir", aJson);
		if (destDir) {
			rule.setDestDir(*destDir);
		}

		auto active = JsonUtil::getOptionalField<bool>("active", aJson);
		if (active) {
			rule.isActive = *active;
		}

		auto autoQueue = JsonUtil::getOptionalField<bool>("auto_queue", aJson);
		if (autoQueue) {
			rule.isAutoQueue = *autoQueue;
		}

		// Raw fields so that the values can also be cleared
		auto commentJson = JsonUtil::getOptionalRawField("comment", aJson, false);
		if (!commentJson.is_null()) {
			rule.adlsComment = JsonUtil::parseValue<string>("comment", commentJson, true);
		}

		auto groupJson = JsonUtil::getOptionalRawField("group", aJson, false);
		if (!groupJson.is_null()) {
			rule.group = JsonUtil::parseValue<string>("group", groupJson, true);
		}

		return rule;
	}

	size_t AdlSearchApi::parseRuleIndex(ApiRequest& aRequest) const {
		auto index = aRequest.getTokenParam();
		if (index >= ADLSearchManager::getInstance()->getCollectionSize()) {
			throw RequestException(http::status::not_found, "Rule index out of range");
		}

		return index;
	}

	api_return AdlSearchApi::handleGetRules(ApiRequest& aRequest) {
		auto ret = json::array();

		{
			Lock l(adlCs);
			// Snapshot: serializing straight off the live vector raced matchListing and the
			// mutators.
			const auto collection = ADLSearchManager::getInstance()->getCollection();
			for (size_t i = 0; i < collection.size(); ++i) {
				ret.push_back(serializeRule(collection[i], i));
			}
		}

		aRequest.setResponseBody(ret);
		return http::status::ok;
	}

	api_return AdlSearchApi::handleAddRule(ApiRequest& aRequest) {
		const auto& reqJson = aRequest.getRequestBody();

		auto rule = deserializeRule(reqJson, ADLSearch());
		if (rule.getPattern().empty()) {
			JsonUtil::throwError("pattern", JsonException::ERROR_MISSING, "Search pattern required");
		}

		Lock l(adlCs);
		auto am = ADLSearchManager::getInstance();
		auto size = am->getCollectionSize();
		auto index = JsonUtil::getOptionalFieldDefault<size_t>("index", reqJson, size);
		if (index > size) {
			index = size;
		}

		if (!am->addCollection(rule, static_cast<int>(index))) {
			aRequest.setResponseErrorStr("Adding the rule failed (a match may be running)");
			return http::status::conflict;
		}

		am->save();

		auto added = am->getSearch(index);
		if (!added) {
			return http::status::no_content;
		}

		aRequest.setResponseBody(serializeRule(*added, index));
		return http::status::ok;
	}

	api_return AdlSearchApi::handleUpdateRule(ApiRequest& aRequest) {
		Lock l(adlCs);
		auto am = ADLSearchManager::getInstance();
		auto index = parseRuleIndex(aRequest);

		auto existing = am->getSearch(index);
		if (!existing) {
			throw RequestException(http::status::not_found, "Rule index out of range");
		}

		auto rule = deserializeRule(aRequest.getRequestBody(), *existing);
		if (!am->updateCollection(rule, static_cast<int>(index))) {
			aRequest.setResponseErrorStr("Updating the rule failed (a match may be running)");
			return http::status::conflict;
		}

		am->save();

		auto updated = am->getSearch(index);
		if (!updated) {
			return http::status::no_content;
		}

		aRequest.setResponseBody(serializeRule(*updated, index));
		return http::status::ok;
	}

	api_return AdlSearchApi::handleRemoveRule(ApiRequest& aRequest) {
		Lock l(adlCs);
		auto am = ADLSearchManager::getInstance();
		auto index = parseRuleIndex(aRequest);

		if (!am->removeCollection(static_cast<int>(index))) {
			aRequest.setResponseErrorStr("Removing the rule failed (a match may be running)");
			return http::status::conflict;
		}

		am->save();
		return http::status::no_content;
	}

	api_return AdlSearchApi::handleMoveRule(ApiRequest& aRequest) {
		Lock l(adlCs);
		auto am = ADLSearchManager::getInstance();
		auto index = parseRuleIndex(aRequest);

		auto size = am->getCollectionSize();
		auto target = JsonUtil::getField<size_t>("target_index", aRequest.getRequestBody(), false);
		if (size == 0) {
			return http::status::no_content;
		}

		if (target >= size) {
			target = size - 1;
		}

		if (index == target) {
			return http::status::no_content;
		}

		// Mirrors the desktop reordering: remove and re-insert at the target position
		auto existing = am->getSearch(index);
		if (!existing) {
			throw RequestException(http::status::not_found, "Rule index out of range");
		}

		auto rule = *existing;
		if (!am->removeCollection(static_cast<int>(index))) {
			aRequest.setResponseErrorStr("Moving the rule failed (a match may be running)");
			return http::status::conflict;
		}

		if (!am->addCollection(rule, static_cast<int>(target))) {
			// The rule has been removed already; retry the restore so that a running
			// match (which blocks all mutations for its duration) can't drop it entirely
			auto restored = false;
			for (auto i = 0; i < 25 && !restored; ++i) {
				restored = am->addCollection(rule, static_cast<int>(index));
				if (!restored) {
					Thread::sleep(20);
				}
			}

			aRequest.setResponseErrorStr(restored ? "Moving the rule failed" : "Moving the rule failed and the rule could not be restored");
			return http::status::conflict;
		}

		am->save();
		return http::status::no_content;
	}
}

#endif // HAVE_CORE_MODULES
