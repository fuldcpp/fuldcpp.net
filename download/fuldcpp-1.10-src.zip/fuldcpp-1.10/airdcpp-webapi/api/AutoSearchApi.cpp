/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#ifdef HAVE_CORE_MODULES

#include <api/AutoSearchApi.h>

#include <web-server/JsonUtil.h>

#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/modules/AutoSearchManager.h>

#include <boost/regex.hpp>

namespace webserver {

	static const map<AutoSearch::ActionType, string> actionNames = {
		{ AutoSearch::ACTION_DOWNLOAD, "download" },
		{ AutoSearch::ACTION_QUEUE, "queue" },
		{ AutoSearch::ACTION_REPORT, "report" },
	};

	static const map<StringMatch::Method, string> matcherNames = {
		{ StringMatch::PARTIAL, "partial" },
		{ StringMatch::REGEX, "regex" },
		{ StringMatch::WILDCARD, "wildcard" },
		{ StringMatch::EXACT, "exact" },
	};

	static const map<AutoSearch::Status, string> statusNames = {
		{ AutoSearch::STATUS_DISABLED, "disabled" },
		{ AutoSearch::STATUS_EXPIRED, "expired" },
		{ AutoSearch::STATUS_MANUAL, "manual" },
		{ AutoSearch::STATUS_SEARCHING, "searching" },
		{ AutoSearch::STATUS_COLLECTING, "collecting" },
		{ AutoSearch::STATUS_WAITING, "waiting" },
		{ AutoSearch::STATUS_POSTSEARCH, "postsearch" },
		{ AutoSearch::STATUS_QUEUED_OK, "queued" },
		{ AutoSearch::STATUS_FAILED_MISSING, "failed_missing" },
		{ AutoSearch::STATUS_FAILED_EXTRAS, "failed_extras" },
	};

	template<typename EnumT>
	static string enumToString(const map<EnumT, string>& aMap, EnumT aValue, const string& aDefault) noexcept {
		auto i = aMap.find(aValue);
		return i != aMap.end() ? i->second : aDefault;
	}

	template<typename EnumT>
	static optional<EnumT> stringToEnum(const map<EnumT, string>& aMap, const string& aValue) noexcept {
		for (const auto& [key, name]: aMap) {
			if (name == aValue) {
				return key;
			}
		}

		return nullopt;
	}

	AutoSearchApi::AutoSearchApi(Session* aSession) : SubscribableApiModule(aSession, Access::SETTINGS_VIEW) {
		createSubscriptions({
			"auto_search_item_added",
			"auto_search_item_removed",
			"auto_search_item_updated"
		});

		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(EXACT_PARAM("items")),								AutoSearchApi::handleGetItems);
		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(EXACT_PARAM("items"), TOKEN_PARAM),				AutoSearchApi::handleGetItem);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(EXACT_PARAM("items")),								AutoSearchApi::handleAddItem);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_PATCH,	(EXACT_PARAM("items"), TOKEN_PARAM),				AutoSearchApi::handleUpdateItem);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_DELETE,	(EXACT_PARAM("items"), TOKEN_PARAM),				AutoSearchApi::handleRemoveItem);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(EXACT_PARAM("items"), TOKEN_PARAM, EXACT_PARAM("search")),	AutoSearchApi::handleSearchItem);
		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(EXACT_PARAM("groups")),							AutoSearchApi::handleGetGroups);

		AutoSearchManager::getInstance()->addListener(this);
	}

	AutoSearchApi::~AutoSearchApi() {
		AutoSearchManager::getInstance()->removeListener(this);
	}

	// Uses only plain AutoSearch getters: this may be called from a listener event that
	// is fired while the manager lock is held, so it must not re-enter the manager
	json AutoSearchApi::serializeItem(const AutoSearchPtr& aItem) noexcept {
		json searchDays = json::array();
		for (size_t i = 0; i < 7; ++i) {
			searchDays.push_back(aItem->searchDays.test(i));
		}

		return {
			{ "id", aItem->getToken() },
			{ "search_string", aItem->getSearchString() },
			{ "excluded_string", aItem->getExcludedString() },
			{ "matcher_string", aItem->getMatcherString() },
			{ "matcher_type", enumToString(matcherNames, aItem->getMethod(), "partial") },
			{ "action", enumToString(actionNames, aItem->getAction(), "download") },
			{ "file_type", aItem->getFileType() },
			{ "target", aItem->getTarget() },
			{ "expire_time", aItem->getExpireTime() },
			{ "match_full_path", aItem->getMatchFullPath() },
			{ "enabled", aItem->getEnabled() },
			{ "remove_after_hit", aItem->getRemove() },
			{ "check_already_queued", aItem->getCheckAlreadyQueued() },
			{ "check_already_shared", aItem->getCheckAlreadyShared() },
			{ "user_match", aItem->getNickPattern() },
			{ "user_match_exclude", aItem->getUserMatcherExclude() },
			{ "group", aItem->getGroup() },
			{ "min_size", aItem->getMinSize() },
			{ "use_params", aItem->getUseParams() },
			{ "cur_number", aItem->getCurNumber() },
			{ "max_number", aItem->getMaxNumber() },
			{ "number_length", aItem->getNumberLen() },
			{ "search_days", searchDays },
			{ "start_time", aItem->startTime.toString() },
			{ "end_time", aItem->endTime.toString() },
			// Runtime state (read-only)
			{ "status", enumToString(statusNames, aItem->getStatus(), "searching") },
			{ "status_string", aItem->getSearchingStatus() },
			{ "last_search", aItem->getLastSearch() },
			{ "time_added", aItem->getTimeAdded() },
			{ "last_error", aItem->getLastError() },
		};
	}

	void AutoSearchApi::updateItemProperties(AutoSearchPtr& aItem, const json& aJson) {
		auto searchString = JsonUtil::getOptionalField<string>("search_string", aJson);
		if (searchString) {
			aItem->setSearchString(*searchString);
		}

		auto excluded = JsonUtil::getOptionalField<string>("excluded_string", aJson);
		if (excluded) {
			aItem->setExcludedString(*excluded);
		}

		auto matcherString = JsonUtil::getOptionalField<string>("matcher_string", aJson);
		if (matcherString) {
			aItem->setMatcherString(*matcherString);
		}

		auto matcherType = JsonUtil::getOptionalField<string>("matcher_type", aJson);
		if (matcherType) {
			auto method = stringToEnum(matcherNames, *matcherType);
			if (!method) {
				JsonUtil::throwError("matcher_type", JsonException::ERROR_INVALID, "Invalid matcher type");
			}
			aItem->setMethod(*method);
		}

		// Validate a custom regex matcher before it is silently accepted and then never matches
		if (aItem->getMethod() == StringMatch::REGEX) {
			const auto& pattern = aItem->getMatcherString().empty() ? aItem->getSearchString() : aItem->getMatcherString();
			if (!pattern.empty()) {
				try {
					boost::regex reg(pattern);
				} catch (const std::exception&) {
					JsonUtil::throwError("matcher_string", JsonException::ERROR_INVALID, "Invalid regular expression");
				}
			}
		}

		auto action = JsonUtil::getOptionalField<string>("action", aJson);
		if (action) {
			auto actionType = stringToEnum(actionNames, *action);
			if (!actionType) {
				JsonUtil::throwError("action", JsonException::ERROR_INVALID, "Invalid action");
			}
			aItem->setAction(*actionType);
		}

		auto fileType = JsonUtil::getOptionalField<string>("file_type", aJson);
		if (fileType) {
			aItem->setFileType(*fileType);
		}

		auto target = JsonUtil::getOptionalField<string>("target", aJson);
		if (target) {
			aItem->setTarget(*target);
		}

		auto expireTime = JsonUtil::getOptionalField<time_t>("expire_time", aJson);
		if (expireTime) {
			aItem->setExpireTime(*expireTime);
		}

		auto matchFullPath = JsonUtil::getOptionalField<bool>("match_full_path", aJson);
		if (matchFullPath) {
			aItem->setMatchFullPath(*matchFullPath);
		}

		auto enabled = JsonUtil::getOptionalField<bool>("enabled", aJson);
		if (enabled) {
			aItem->setEnabled(*enabled);
		}

		auto removeAfterHit = JsonUtil::getOptionalField<bool>("remove_after_hit", aJson);
		if (removeAfterHit) {
			aItem->setRemove(*removeAfterHit);
		}

		auto checkQueued = JsonUtil::getOptionalField<bool>("check_already_queued", aJson);
		if (checkQueued) {
			aItem->setCheckAlreadyQueued(*checkQueued);
		}

		auto checkShared = JsonUtil::getOptionalField<bool>("check_already_shared", aJson);
		if (checkShared) {
			aItem->setCheckAlreadyShared(*checkShared);
		}

		auto userMatch = JsonUtil::getOptionalField<string>("user_match", aJson);
		if (userMatch) {
			aItem->setUserMatcher(*userMatch);
		}

		auto userMatchExclude = JsonUtil::getOptionalField<bool>("user_match_exclude", aJson);
		if (userMatchExclude) {
			aItem->setUserMatcherExclude(*userMatchExclude);
		}

		auto group = JsonUtil::getOptionalField<string>("group", aJson);
		if (group) {
			aItem->setGroup(*group);
		}

		auto minSize = JsonUtil::getOptionalField<int64_t>("min_size", aJson);
		if (minSize) {
			aItem->setMinSize(*minSize);
		}

		auto useParams = JsonUtil::getOptionalField<bool>("use_params", aJson);
		if (useParams) {
			aItem->setUseParams(*useParams);
		}

		auto curNumber = JsonUtil::getOptionalField<int>("cur_number", aJson);
		if (curNumber) {
			aItem->setCurNumber(*curNumber);
		}

		auto maxNumber = JsonUtil::getOptionalField<int>("max_number", aJson);
		if (maxNumber) {
			aItem->setMaxNumber(*maxNumber);
		}

		auto numberLength = JsonUtil::getOptionalField<int>("number_length", aJson);
		if (numberLength) {
			aItem->setNumberLen(*numberLength);
		}

		auto searchDays = JsonUtil::getOptionalField<vector<bool>>("search_days", aJson);
		if (searchDays && searchDays->size() == 7) {
			for (size_t i = 0; i < 7; ++i) {
				aItem->searchDays.set(i, (*searchDays)[i]);
			}
		}

		auto startTime = JsonUtil::getOptionalField<string>("start_time", aJson);
		if (startTime && startTime->size() == 4) {
			aItem->startTime = SearchTime(*startTime);
		}

		auto endTime = JsonUtil::getOptionalField<string>("end_time", aJson);
		if (endTime && endTime->size() == 4) {
			aItem->endTime = SearchTime(*endTime);
		}
	}

	AutoSearchPtr AutoSearchApi::parseItemToken(ApiRequest& aRequest) {
		auto item = AutoSearchManager::getInstance()->getSearchByToken(static_cast<ProfileToken>(aRequest.getTokenParam()));
		if (!item) {
			throw RequestException(http::status::not_found, "Auto search item not found");
		}

		return item;
	}

	api_return AutoSearchApi::handleGetItems(ApiRequest& aRequest) {
		auto am = AutoSearchManager::getInstance();

		auto ret = json::array();
		{
			RLock l(am->getCS());
			for (const auto& as: am->getSearchItems() | views::values) {
				ret.push_back(serializeItem(as));
			}
		}

		aRequest.setResponseBody(ret);
		return http::status::ok;
	}

	api_return AutoSearchApi::handleGetItem(ApiRequest& aRequest) {
		auto item = parseItemToken(aRequest);
		aRequest.setResponseBody(serializeItem(item));
		return http::status::ok;
	}

	api_return AutoSearchApi::handleAddItem(ApiRequest& aRequest) {
		const auto& reqJson = aRequest.getRequestBody();

		auto searchString = JsonUtil::getField<string>("search_string", reqJson, false);

		auto am = AutoSearchManager::getInstance();
		if (!am->validateAutoSearchStr(searchString)) {
			aRequest.setResponseErrorStr("The search string is too short or an item with the same string exists already");
			return http::status::conflict;
		}

		auto item = std::make_shared<AutoSearch>();
		item->setSearchString(searchString);
		item->setTimeAdded(GET_TIME()); // The default constructor leaves this unset (needed for recent-item handling)

		// Match the desktop's single-threaded field access: hold the manager lock while mutating
		{
			WLock l(am->getCS());
			updateItemProperties(item, reqJson);
		}

		am->addAutoSearch(item, false);

		aRequest.setResponseBody(serializeItem(item));
		return http::status::ok;
	}

	api_return AutoSearchApi::handleUpdateItem(ApiRequest& aRequest) {
		auto am = AutoSearchManager::getInstance();
		auto item = parseItemToken(aRequest);

		{
			WLock l(am->getCS());
			updateItemProperties(item, aRequest.getRequestBody());
		}

		am->updateAutoSearch(item);

		aRequest.setResponseBody(serializeItem(item));
		return http::status::ok;
	}

	api_return AutoSearchApi::handleRemoveItem(ApiRequest& aRequest) {
		auto item = parseItemToken(aRequest);
		AutoSearchManager::getInstance()->removeAutoSearch(item);
		return http::status::no_content;
	}

	api_return AutoSearchApi::handleSearchItem(ApiRequest& aRequest) {
		auto item = parseItemToken(aRequest);
		if (!AutoSearchManager::getInstance()->searchItem(item, AutoSearchManager::TYPE_MANUAL_BG)) {
			aRequest.setResponseErrorStr("Searching failed (no hubs are online)");
			return http::status::conflict;
		}

		return http::status::no_content;
	}

	api_return AutoSearchApi::handleGetGroups(ApiRequest& aRequest) {
		aRequest.setResponseBody(AutoSearchManager::getInstance()->getGroups());
		return http::status::ok;
	}

	void AutoSearchApi::on(AutoSearchManagerListener::ItemAdded, const AutoSearchPtr& aItem) noexcept {
		maybeSend("auto_search_item_added", [&] {
			return serializeItem(aItem);
		});
	}

	void AutoSearchApi::on(AutoSearchManagerListener::ItemRemoved, const AutoSearchPtr& aItem) noexcept {
		maybeSend("auto_search_item_removed", [&] {
			return serializeItem(aItem);
		});
	}

	void AutoSearchApi::on(AutoSearchManagerListener::ItemUpdated, const AutoSearchPtr& aItem, bool) noexcept {
		maybeSend("auto_search_item_updated", [&] {
			return serializeItem(aItem);
		});
	}
}

#endif // HAVE_CORE_MODULES
