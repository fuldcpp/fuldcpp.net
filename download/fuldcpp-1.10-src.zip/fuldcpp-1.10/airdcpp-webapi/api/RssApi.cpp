/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#ifdef HAVE_CORE_MODULES

#include <api/RssApi.h>

#include <api/common/Serializer.h>

#include <web-server/JsonUtil.h>

namespace webserver {

	static const map<int, string> filterActionNames = {
		{ RSSFilter::DOWNLOAD, "download" },
		{ RSSFilter::REMOVE, "remove" },
		{ RSSFilter::ADD_AUTOSEARCH, "add_autosearch" },
	};

	static const map<StringMatch::Method, string> matcherNames = {
		{ StringMatch::PARTIAL, "partial" },
		{ StringMatch::REGEX, "regex" },
		{ StringMatch::WILDCARD, "wildcard" },
		{ StringMatch::EXACT, "exact" },
	};

	template<typename EnumT>
	static string enumToString(const map<EnumT, string>& aMap, EnumT aValue, const string& aDefault) noexcept {
		auto i = aMap.find(aValue);
		return i != aMap.end() ? i->second : aDefault;
	}

	template<typename EnumT>
	static optional<EnumT> stringToEnum(const map<EnumT, string>& aMap, const string& aValue) noexcept {
		for (const auto& [key, name]: aMap) {
			if (name == aValue) {
				return key;
			}
		}

		return nullopt;
	}

	RssApi::RssApi(Session* aSession) : SubscribableApiModule(aSession, Access::SETTINGS_VIEW) {
		createSubscriptions({
			"rss_feed_added",
			"rss_feed_changed",
			"rss_feed_removed",
			"rss_feed_updated",
			"rss_data_added",
			"rss_data_removed",
			"rss_data_cleared"
		});

		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(EXACT_PARAM("feeds")),											RssApi::handleGetFeeds);
		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(EXACT_PARAM("feeds"), TOKEN_PARAM),							RssApi::handleGetFeed);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(EXACT_PARAM("feeds")),											RssApi::handleAddFeed);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_PATCH,	(EXACT_PARAM("feeds"), TOKEN_PARAM),							RssApi::handleUpdateFeed);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_DELETE,	(EXACT_PARAM("feeds"), TOKEN_PARAM),							RssApi::handleRemoveFeed);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(EXACT_PARAM("feeds"), TOKEN_PARAM, EXACT_PARAM("refresh")),		RssApi::handleRefreshFeed);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(EXACT_PARAM("feeds"), TOKEN_PARAM, EXACT_PARAM("match_filters")),	RssApi::handleMatchFilters);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(EXACT_PARAM("feeds"), TOKEN_PARAM, EXACT_PARAM("clear")),		RssApi::handleClearData);
		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(EXACT_PARAM("feeds"), TOKEN_PARAM, EXACT_PARAM("items")),		RssApi::handleGetFeedData);
		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(EXACT_PARAM("feeds"), TOKEN_PARAM, EXACT_PARAM("filters")),		RssApi::handleGetFilters);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_PUT,		(EXACT_PARAM("feeds"), TOKEN_PARAM, EXACT_PARAM("filters")),		RssApi::handleSetFilters);

		RSSManager::getInstance()->addListener(this);
	}

	RssApi::~RssApi() {
		RSSManager::getInstance()->removeListener(this);
	}

	json RssApi::serializeFeed(const RSSPtr& aFeed) noexcept {
		return {
			{ "id", aFeed->getToken() },
			{ "url", aFeed->getUrl() },
			{ "name", aFeed->getFeedName() },
			{ "update_interval", aFeed->getUpdateInterval() },
			{ "last_update", aFeed->getLastUpdate() },
			{ "enabled", aFeed->getEnable() },
		};
	}

	json RssApi::serializeFeedData(const RSSDataPtr& aData) noexcept {
		return {
			{ "title", aData->getTitle() },
			{ "link", aData->getLink() },
			{ "pub_date", aData->getPubDate() },
			{ "date_added", aData->getDateAdded() },
		};
	}

	json RssApi::serializeFilter(const RSSFilter& aFilter) noexcept {
		// getMethod() is non-const; work on a copy
		auto filter = aFilter;
		return {
			{ "pattern", filter.getFilterPattern() },
			{ "download_target", filter.getDownloadTarget() },
			{ "autosearch_group", filter.getAutosearchGroup() },
			{ "action", enumToString(filterActionNames, filter.getFilterAction(), "download") },
			{ "matcher_type", enumToString(matcherNames, filter.getMethod(), "partial") },
			{ "expire_days", filter.getExpireDays() },
			{ "format_time", filter.getFormatTimeParams() },
			{ "exact_match", filter.getAsExactMatch() },
			{ "skip_dupes", filter.skipDupes },
		};
	}

	RSSFilter RssApi::deserializeFilter(const json& aJson) {
		auto pattern = JsonUtil::getField<string>("pattern", aJson, false);
		auto downloadTarget = JsonUtil::getOptionalFieldDefault<string>("download_target", aJson, Util::emptyString);
		auto group = JsonUtil::getOptionalFieldDefault<string>("autosearch_group", aJson, Util::emptyString);

		auto actionStr = JsonUtil::getOptionalFieldDefault<string>("action", aJson, "download");
		auto action = stringToEnum(filterActionNames, actionStr);
		if (!action) {
			JsonUtil::throwError("action", JsonException::ERROR_INVALID, "Invalid filter action");
		}

		auto matcherStr = JsonUtil::getOptionalFieldDefault<string>("matcher_type", aJson, "partial");
		auto method = stringToEnum(matcherNames, matcherStr);
		if (!method) {
			JsonUtil::throwError("matcher_type", JsonException::ERROR_INVALID, "Invalid matcher type");
		}

		auto expireDays = JsonUtil::getOptionalFieldDefault<int>("expire_days", aJson, 3);
		auto formatTime = JsonUtil::getOptionalFieldDefault<bool>("format_time", aJson, false);
		auto exactMatch = JsonUtil::getOptionalFieldDefault<bool>("exact_match", aJson, true);
		auto skipDupes = JsonUtil::getOptionalFieldDefault<bool>("skip_dupes", aJson, true);

		return RSSFilter(pattern, downloadTarget, static_cast<int>(*method), group, skipDupes, *action, expireDays, formatTime, exactMatch);
	}

	RSSPtr RssApi::parseFeedToken(ApiRequest& aRequest) {
		auto feed = RSSManager::getInstance()->getFeedByToken(static_cast<int>(aRequest.getTokenParam()));
		if (!feed) {
			throw RequestException(http::status::not_found, "Feed not found");
		}

		return feed;
	}

	api_return RssApi::handleGetFeeds(ApiRequest& aRequest) {
		auto rm = RSSManager::getInstance();

		auto ret = json::array();
		{
			Lock l(rm->getCS());
			for (const auto& feed: rm->getRss()) {
				ret.push_back(serializeFeed(feed));
			}
		}

		aRequest.setResponseBody(ret);
		return http::status::ok;
	}

	api_return RssApi::handleGetFeed(ApiRequest& aRequest) {
		auto feed = parseFeedToken(aRequest);
		aRequest.setResponseBody(serializeFeed(feed));
		return http::status::ok;
	}

	api_return RssApi::handleAddFeed(ApiRequest& aRequest) {
		const auto& reqJson = aRequest.getRequestBody();

		auto url = JsonUtil::getField<string>("url", reqJson, false);
		auto name = JsonUtil::getField<string>("name", reqJson, false);
		auto interval = JsonUtil::getOptionalFieldDefault<int>("update_interval", reqJson, 60);
		auto enabled = JsonUtil::getOptionalFieldDefault<bool>("enabled", reqJson, true);

		auto rm = RSSManager::getInstance();
		if (rm->getFeedByUrl(url)) {
			aRequest.setResponseErrorStr("A feed with the same URL exists already");
			return http::status::conflict;
		}
		if (rm->getFeedByName(name)) {
			aRequest.setResponseErrorStr("A feed with the same name exists already");
			return http::status::conflict;
		}

		RSSPtr feed = std::make_shared<RSS>(url, name, enabled, 0, interval);
		rm->updateFeedItem(feed, url, name, interval, enabled);

		aRequest.setResponseBody(serializeFeed(feed));
		return http::status::ok;
	}

	api_return RssApi::handleUpdateFeed(ApiRequest& aRequest) {
		auto feed = parseFeedToken(aRequest);
		const auto& reqJson = aRequest.getRequestBody();

		auto url = JsonUtil::getOptionalFieldDefault<string>("url", reqJson, feed->getUrl());
		auto name = JsonUtil::getOptionalFieldDefault<string>("name", reqJson, feed->getFeedName());
		auto interval = JsonUtil::getOptionalFieldDefault<int>("update_interval", reqJson, feed->getUpdateInterval());
		auto enabled = JsonUtil::getOptionalFieldDefault<bool>("enabled", reqJson, feed->getEnable());

		auto rm = RSSManager::getInstance();

		// Guard against colliding with a different feed
		auto byUrl = rm->getFeedByUrl(url);
		if (byUrl && byUrl->getToken() != feed->getToken()) {
			aRequest.setResponseErrorStr("A feed with the same URL exists already");
			return http::status::conflict;
		}
		auto byName = rm->getFeedByName(name);
		if (byName && byName->getToken() != feed->getToken()) {
			aRequest.setResponseErrorStr("A feed with the same name exists already");
			return http::status::conflict;
		}

		rm->updateFeedItem(feed, url, name, interval, enabled);

		aRequest.setResponseBody(serializeFeed(feed));
		return http::status::ok;
	}

	api_return RssApi::handleRemoveFeed(ApiRequest& aRequest) {
		auto feed = parseFeedToken(aRequest);

		auto rm = RSSManager::getInstance();
		rm->removeFeedItem(feed);
		rm->save();

		return http::status::no_content;
	}

	api_return RssApi::handleRefreshFeed(ApiRequest& aRequest) {
		auto feed = parseFeedToken(aRequest);
		RSSManager::getInstance()->downloadFeed(feed, true);
		return http::status::no_content;
	}

	api_return RssApi::handleMatchFilters(ApiRequest& aRequest) {
		auto feed = parseFeedToken(aRequest);
		RSSManager::getInstance()->matchFilters(feed);
		return http::status::no_content;
	}

	api_return RssApi::handleClearData(ApiRequest& aRequest) {
		auto feed = parseFeedToken(aRequest);
		RSSManager::getInstance()->clearRSSData(feed);
		return http::status::no_content;
	}

	api_return RssApi::handleGetFeedData(ApiRequest& aRequest) {
		auto feed = parseFeedToken(aRequest);

		auto ret = json::array();
		{
			Lock l(RSSManager::getInstance()->getCS());
			for (const auto& data: feed->getFeedData() | views::values) {
				ret.push_back(serializeFeedData(data));
			}
		}

		aRequest.setResponseBody(ret);
		return http::status::ok;
	}

	api_return RssApi::handleGetFilters(ApiRequest& aRequest) {
		auto feed = parseFeedToken(aRequest);

		auto ret = json::array();
		{
			Lock l(RSSManager::getInstance()->getCS());
			for (const auto& filter: feed->getRssFilterList()) {
				ret.push_back(serializeFilter(filter));
			}
		}

		aRequest.setResponseBody(ret);
		return http::status::ok;
	}

	api_return RssApi::handleSetFilters(ApiRequest& aRequest) {
		auto feed = parseFeedToken(aRequest);

		const auto& filtersJson = aRequest.getRequestBody();
		if (!filtersJson.is_array()) {
			JsonUtil::throwError("filters", JsonException::ERROR_INVALID, "An array of filters is required");
		}

		vector<RSSFilter> filters;
		for (const auto& filterJson: filtersJson) {
			filters.push_back(deserializeFilter(filterJson));
		}

		auto rm = RSSManager::getInstance();
		rm->updateFilterList(feed, filters);
		rm->save();

		auto ret = json::array();
		{
			Lock l(rm->getCS());
			for (const auto& filter: feed->getRssFilterList()) {
				ret.push_back(serializeFilter(filter));
			}
		}

		aRequest.setResponseBody(ret);
		return http::status::ok;
	}

	void RssApi::on(RSSManagerListener::RSSFeedAdded, const RSSPtr& aFeed) noexcept {
		maybeSend("rss_feed_added", [&] { return serializeFeed(aFeed); });
	}

	void RssApi::on(RSSManagerListener::RSSFeedChanged, const RSSPtr& aFeed) noexcept {
		maybeSend("rss_feed_changed", [&] { return serializeFeed(aFeed); });
	}

	void RssApi::on(RSSManagerListener::RSSFeedRemoved, const RSSPtr& aFeed) noexcept {
		maybeSend("rss_feed_removed", [&] { return serializeFeed(aFeed); });
	}

	void RssApi::on(RSSManagerListener::RSSFeedUpdated, const RSSPtr& aFeed) noexcept {
		maybeSend("rss_feed_updated", [&] { return serializeFeed(aFeed); });
	}

	void RssApi::on(RSSManagerListener::RSSDataAdded, const RSSDataPtr& aData) noexcept {
		maybeSend("rss_data_added", [&] { return serializeFeedData(aData); });
	}

	void RssApi::on(RSSManagerListener::RSSDataRemoved, const RSSDataPtr& aData) noexcept {
		maybeSend("rss_data_removed", [&] { return serializeFeedData(aData); });
	}

	void RssApi::on(RSSManagerListener::RSSDataCleared, const RSSPtr& aFeed) noexcept {
		maybeSend("rss_data_cleared", [&] {
			return json({ { "id", aFeed->getToken() } });
		});
	}
}

#endif // HAVE_CORE_MODULES
