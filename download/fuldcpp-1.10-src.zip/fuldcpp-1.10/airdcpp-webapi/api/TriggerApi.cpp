/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <api/TriggerApi.h>

#include <api/common/Serializer.h>

#include <web-server/JsonUtil.h>

#include <regex>

namespace webserver {
	TriggerApi::TriggerApi(Session* aSession) : SubscribableApiModule(aSession, Access::SETTINGS_VIEW) {
		createSubscriptions({
			"triggers_updated",
			"trigger_muted",
			"trigger_fired"
		});

		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(EXACT_PARAM("triggers")),					TriggerApi::handleGetTriggers);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(EXACT_PARAM("triggers")),					TriggerApi::handleAddTrigger);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_PATCH,	(EXACT_PARAM("triggers"), TOKEN_PARAM),		TriggerApi::handleUpdateTrigger);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_DELETE,	(EXACT_PARAM("triggers"), TOKEN_PARAM),		TriggerApi::handleRemoveTrigger);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(EXACT_PARAM("triggers"), TOKEN_PARAM, EXACT_PARAM("reset_stats")),	TriggerApi::handleResetStats);

		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(EXACT_PARAM("muted")),						TriggerApi::handleGetMuted);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_POST,	(EXACT_PARAM("muted")),						TriggerApi::handleSetMuted);

		TriggerManager::getInstance()->addListener(this);
	}

	TriggerApi::~TriggerApi() {
		TriggerManager::getInstance()->removeListener(this);
	}

	string TriggerApi::serializeMatchMode(uint8_t aMode) noexcept {
		return TriggerManager::matchModeToString(aMode);
	}

	string TriggerApi::serializeUserClass(uint8_t aUserClass) noexcept {
		return TriggerManager::userClassToString(aUserClass);
	}

	string TriggerApi::serializeSelectionStrategy(uint8_t aStrategy) noexcept {
		return TriggerManager::selectionStrategyToString(aStrategy);
	}

	// The *FromString helpers coerce unknown tokens to a default; reject them instead so
	// that a typo is a 400 rather than a silently-wrong setting. A token is valid if it
	// round-trips (except the documented legacy "round-robin" alias for the strategy).
	uint8_t TriggerApi::parseMatchMode(const string& aValue) noexcept {
		return TriggerManager::matchModeFromString(aValue);
	}

	uint8_t TriggerApi::parseUserClass(const string& aValue) noexcept {
		return TriggerManager::userClassFromString(aValue);
	}

	uint8_t TriggerApi::parseSelectionStrategy(const string& aValue) noexcept {
		return TriggerManager::selectionStrategyFromString(aValue);
	}

	// aAllowLegacyAlias covers "round-robin", which is a documented legacy spelling for ONE value
	// of the selection strategy. It was exempted for every field, so match_mode and
	// min_user_class accepted it too and fell back to their default -- precisely the
	// silently-wrong setting this function exists to turn into a 400.
	static uint8_t parseEnumField(const string& aFieldName, const string& aValue, uint8_t aParsed, const string& aRoundTrip, bool aAllowLegacyAlias = false) {
		if (aRoundTrip != aValue && !(aAllowLegacyAlias && aValue == "round-robin")) {
			JsonUtil::throwError(aFieldName, JsonException::ERROR_INVALID, "Unknown value: " + aValue);
		}

		return aParsed;
	}

	json TriggerApi::serializeTrigger(const TriggerItem& aTrigger) noexcept {
		return {
			{ "id", aTrigger.getId() },
			{ "trigger_text", aTrigger.getTriggerText() },
			{ "responses", aTrigger.getResponses() },
			{ "match_main_chat", aTrigger.getMatchMainChat() },
			{ "match_pm", aTrigger.getMatchPM() },
			{ "match_join", aTrigger.getMatchJoin() },
			{ "match_hub_connect", aTrigger.getMatchHubConnect() },
			{ "enabled", aTrigger.getEnabled() },
			{ "cooldown", aTrigger.getCooldownSecs() },
			{ "match_mode", serializeMatchMode(aTrigger.getMatchMode()) },
			{ "min_user_class", serializeUserClass(aTrigger.getMinUserClass()) },
			{ "hub_urls", aTrigger.getHubUrls() },
			{ "regex_case_sensitive", aTrigger.getRegexCaseSensitive() },
			{ "stop_on_match", aTrigger.getStopOnMatch() },
			{ "selection_strategy", serializeSelectionStrategy(aTrigger.getSelectionStrategy()) },
			{ "reply_in_pm", aTrigger.getReplyInPM() },
			{ "reply_as_action", aTrigger.getReplyAsAction() },
			{ "max_delay", aTrigger.getMaxDelaySecs() },
			{ "only_when_away", aTrigger.getOnlyWhenAway() },

			// Read-only fire statistics
			{ "fire_count", aTrigger.getFireCount() },
			{ "last_fired", static_cast<int64_t>(aTrigger.getLastFired()) },
		};
	}

	json TriggerApi::serializeTriggers() noexcept {
		return Serializer::serializeList(TriggerManager::getInstance()->getTriggers(), serializeTrigger);
	}

	json TriggerApi::serializeMuted() noexcept {
		return {
			{ "muted", TriggerManager::getInstance()->getMuted() },
		};
	}

	void TriggerApi::parseTrigger(TriggerItem& aTrigger, const json& aRequestJson, bool aNewTrigger) {
		auto triggerText = JsonUtil::getOptionalField<string>("trigger_text", aRequestJson);
		if (triggerText) {
			aTrigger.setTriggerText(*triggerText);
		}

		auto responses = JsonUtil::getOptionalField<StringList>("responses", aRequestJson);
		if (responses) {
			aTrigger.setResponses(*responses);
		}

		auto matchMainChat = JsonUtil::getOptionalField<bool>("match_main_chat", aRequestJson);
		if (matchMainChat) {
			aTrigger.setMatchMainChat(*matchMainChat);
		}

		auto matchPM = JsonUtil::getOptionalField<bool>("match_pm", aRequestJson);
		if (matchPM) {
			aTrigger.setMatchPM(*matchPM);
		}

		auto matchJoin = JsonUtil::getOptionalField<bool>("match_join", aRequestJson);
		if (matchJoin) {
			aTrigger.setMatchJoin(*matchJoin);
		}

		auto matchHubConnect = JsonUtil::getOptionalField<bool>("match_hub_connect", aRequestJson);
		if (matchHubConnect) {
			aTrigger.setMatchHubConnect(*matchHubConnect);
		}

		auto enabled = JsonUtil::getOptionalField<bool>("enabled", aRequestJson);
		if (enabled) {
			aTrigger.setEnabled(*enabled);
		}

		auto cooldown = JsonUtil::getOptionalField<uint32_t>("cooldown", aRequestJson);
		if (cooldown) {
			aTrigger.setCooldownSecs(*cooldown);
		}

		auto matchMode = JsonUtil::getOptionalField<string>("match_mode", aRequestJson);
		if (matchMode) {
			auto parsed = parseMatchMode(*matchMode);
			aTrigger.setMatchMode(parseEnumField("match_mode", *matchMode, parsed, serializeMatchMode(parsed)));
		}

		auto minUserClass = JsonUtil::getOptionalField<string>("min_user_class", aRequestJson);
		if (minUserClass) {
			auto parsed = parseUserClass(*minUserClass);
			aTrigger.setMinUserClass(parseEnumField("min_user_class", *minUserClass, parsed, serializeUserClass(parsed)));
		}

		auto hubUrls = JsonUtil::getOptionalField<StringList>("hub_urls", aRequestJson);
		if (hubUrls) {
			aTrigger.setHubUrls(*hubUrls);
		}

		auto regexCaseSensitive = JsonUtil::getOptionalField<bool>("regex_case_sensitive", aRequestJson);
		if (regexCaseSensitive) {
			aTrigger.setRegexCaseSensitive(*regexCaseSensitive);
		}

		auto stopOnMatch = JsonUtil::getOptionalField<bool>("stop_on_match", aRequestJson);
		if (stopOnMatch) {
			aTrigger.setStopOnMatch(*stopOnMatch);
		}

		auto selectionStrategy = JsonUtil::getOptionalField<string>("selection_strategy", aRequestJson);
		if (selectionStrategy) {
			auto parsed = parseSelectionStrategy(*selectionStrategy);
			aTrigger.setSelectionStrategy(parseEnumField("selection_strategy", *selectionStrategy, parsed, serializeSelectionStrategy(parsed), true));
		}

		auto replyInPM = JsonUtil::getOptionalField<bool>("reply_in_pm", aRequestJson);
		if (replyInPM) {
			aTrigger.setReplyInPM(*replyInPM);
		}

		auto replyAsAction = JsonUtil::getOptionalField<bool>("reply_as_action", aRequestJson);
		if (replyAsAction) {
			aTrigger.setReplyAsAction(*replyAsAction);
		}

		auto maxDelay = JsonUtil::getOptionalField<uint32_t>("max_delay", aRequestJson);
		if (maxDelay) {
			aTrigger.setMaxDelaySecs(*maxDelay);
		}

		auto onlyWhenAway = JsonUtil::getOptionalField<bool>("only_when_away", aRequestJson);
		if (onlyWhenAway) {
			aTrigger.setOnlyWhenAway(*onlyWhenAway);
		}

		// fire_count/last_fired are read-only; TriggerManager::replaceList preserves
		// the stored statistics for surviving ids regardless of what is passed here.

		(void)aNewTrigger;
	}

	void TriggerApi::validateTrigger(const TriggerItem& aTrigger) {
		// Reject up front exactly what TriggerManager::replaceList would drop silently:
		// it sanitizes (trims text, drops empty responses, clamps caps) and then validates,
		// so check a sanitized copy rather than the raw parsed item.
		auto sanitized = aTrigger;
		TriggerManager::sanitize(sanitized);

		if (!TriggerManager::isValidItem(sanitized)) {
			JsonUtil::throwError("responses", JsonException::ERROR_INVALID, "A trigger needs at least one response and a pattern (unless it is a join/connect trigger)");
		}

		if (sanitized.getMatchMode() == TriggerItem::MATCH_REGEX && !sanitized.getTriggerText().empty()) {
			try {
				// Compile with the same engine and flags the matcher uses so that validation
				// exactly mirrors runtime (see TriggerManager::rebuildMatchStates)
				auto flags = std::regex::ECMAScript;
				if (!sanitized.getRegexCaseSensitive()) {
					flags |= std::regex::icase;
				}
				std::regex reg(sanitized.getTriggerText(), flags);
			} catch (const std::regex_error&) {
				JsonUtil::throwError("trigger_text", JsonException::ERROR_INVALID, "Invalid regular expression");
			}
		}
	}

	uint32_t TriggerApi::parseTriggerIdParam(const ApiRequest& aRequest) {
		return static_cast<uint32_t>(aRequest.getTokenParam());
	}

	TriggerManager::TriggerItemList::iterator TriggerApi::findTrigger(TriggerManager::TriggerItemList& aTriggers, uint32_t aId) noexcept {
		return ranges::find_if(aTriggers, [aId](const TriggerItem& aItem) { return aItem.getId() == aId; });
	}

	api_return TriggerApi::handleGetTriggers(ApiRequest& aRequest) {
		aRequest.setResponseBody(serializeTriggers());
		return http::status::ok;
	}

	api_return TriggerApi::handleAddTrigger(ApiRequest& aRequest) {
		TriggerItem item;
		parseTrigger(item, aRequest.getRequestBody(), true);
		validateTrigger(item);

		auto tm = TriggerManager::getInstance();

		// The list uses a whole-list-replace model; append the new (id 0) item and let the
		// manager assign an id. Identify it afterwards as the id that wasn't present before.
		auto list = tm->getTriggers();

		std::set<uint32_t> existingIds;
		for (const auto& t: list) {
			existingIds.insert(t.getId());
		}

		list.push_back(item);
		tm->replaceList(list);

		json responseItem = nullptr;
		for (const auto& t: tm->getTriggers()) {
			if (existingIds.find(t.getId()) == existingIds.end()) {
				responseItem = serializeTrigger(t);
				break;
			}
		}

		aRequest.setResponseBody(responseItem);
		return http::status::ok;
	}

	api_return TriggerApi::handleUpdateTrigger(ApiRequest& aRequest) {
		auto id = parseTriggerIdParam(aRequest);

		auto tm = TriggerManager::getInstance();
		auto list = tm->getTriggers();

		auto i = findTrigger(list, id);
		if (i == list.end()) {
			aRequest.setResponseErrorStr("Trigger not found");
			return http::status::not_found;
		}

		parseTrigger(*i, aRequest.getRequestBody(), false);
		validateTrigger(*i);

		tm->replaceList(list);

		// Return the stored item (post-sanitize/clamp) rather than the parsed input
		json responseItem = nullptr;
		for (const auto& t: tm->getTriggers()) {
			if (t.getId() == id) {
				responseItem = serializeTrigger(t);
				break;
			}
		}

		aRequest.setResponseBody(responseItem);
		return http::status::ok;
	}

	api_return TriggerApi::handleRemoveTrigger(ApiRequest& aRequest) {
		auto id = parseTriggerIdParam(aRequest);

		auto tm = TriggerManager::getInstance();
		auto list = tm->getTriggers();

		auto i = findTrigger(list, id);
		if (i == list.end()) {
			aRequest.setResponseErrorStr("Trigger not found");
			return http::status::not_found;
		}

		list.erase(i);
		tm->replaceList(list);

		return http::status::no_content;
	}

	api_return TriggerApi::handleResetStats(ApiRequest& aRequest) {
		auto id = parseTriggerIdParam(aRequest);

		if (!TriggerManager::getInstance()->resetStats(id)) {
			aRequest.setResponseErrorStr("Trigger not found");
			return http::status::not_found;
		}

		return http::status::no_content;
	}

	api_return TriggerApi::handleGetMuted(ApiRequest& aRequest) {
		aRequest.setResponseBody(serializeMuted());
		return http::status::ok;
	}

	api_return TriggerApi::handleSetMuted(ApiRequest& aRequest) {
		auto muted = JsonUtil::getField<bool>("muted", aRequest.getRequestBody(), false);
		TriggerManager::getInstance()->setMuted(muted);

		aRequest.setResponseBody(serializeMuted());
		return http::status::ok;
	}

	void TriggerApi::on(TriggerManagerListener::TriggersUpdated) noexcept {
		maybeSend("triggers_updated", [] {
			return serializeTriggers();
		});
	}

	void TriggerApi::on(TriggerManagerListener::MutedUpdated, bool aMuted) noexcept {
		maybeSend("trigger_muted", [aMuted] {
			return json({ { "muted", aMuted } });
		});
	}

	void TriggerApi::on(TriggerManagerListener::TriggerFired, uint32_t aId, uint32_t aFireCount, time_t aLastFired) noexcept {
		maybeSend("trigger_fired", [=] {
			return json({
				{ "id", aId },
				{ "fire_count", aFireCount },
				{ "last_fired", static_cast<int64_t>(aLastFired) },
			});
		});
	}
}
