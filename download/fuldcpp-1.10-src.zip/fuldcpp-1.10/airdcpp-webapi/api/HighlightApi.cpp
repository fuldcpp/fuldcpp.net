/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <api/HighlightApi.h>

#ifdef HAVE_CORE_MODULES

#include <web-server/JsonUtil.h>

#include <airdcpp/util/text/Text.h>

namespace webserver {

	// getMatchType(): 0 begins, 1 contains, 2 ends, 3 equals (see RichTextBox.cpp match logic)
	static const map<int, string> matchTypeNames = {
		{ 0, "begins" },
		{ 1, "contains" },
		{ 2, "ends" },
		{ 3, "equals" },
	};

	// getContext(): HighlightManager::CONTEXT_* enum
	static const map<uint8_t, string> contextNames = {
		{ HighlightManager::CONTEXT_CHAT, "chat" },
		{ HighlightManager::CONTEXT_NICKLIST, "nicklist" },
		{ HighlightManager::CONTEXT_FILELIST, "filelist" },
		{ HighlightManager::CONTEXT_SEARCH, "search" },
	};

	template<typename KeyT>
	static string enumToString(const map<KeyT, string>& aMap, KeyT aKey, const string& aDefault) noexcept {
		auto i = aMap.find(aKey);
		return i != aMap.end() ? i->second : aDefault;
	}

	template<typename KeyT>
	static KeyT enumFromString(const map<KeyT, string>& aMap, const string& aFieldName, const string& aValue) {
		for (const auto& [key, name]: aMap) {
			if (name == aValue) {
				return key;
			}
		}

		JsonUtil::throwError(aFieldName, JsonException::ERROR_INVALID, "Invalid value: " + aValue);
		return aMap.begin()->first;
	}

	// The colors are stored as COLORREF (0x00BBGGRR) integers; expose them as #RRGGBB for the Web UI
	static string colorToHex(int aColor) noexcept {
		auto r = aColor & 0xFF;
		auto g = (aColor >> 8) & 0xFF;
		auto b = (aColor >> 16) & 0xFF;

		char buf[8];
		snprintf(buf, sizeof(buf), "#%02X%02X%02X", r, g, b);
		return buf;
	}

	static int colorFromHex(const string& aFieldName, const string& aHex) {
		auto s = aHex;
		if (!s.empty() && s.front() == '#') {
			s.erase(0, 1);
		}

		// std::stoi parses a valid prefix and stops (so "12345g" would slip through); require
		// exactly six hex digits up front.
		if (s.length() != 6 || s.find_first_not_of("0123456789abcdefABCDEF") != string::npos) {
			JsonUtil::throwError(aFieldName, JsonException::ERROR_INVALID, "A #RRGGBB color is required");
		}

		try {
			auto r = std::stoi(s.substr(0, 2), nullptr, 16);
			auto g = std::stoi(s.substr(2, 2), nullptr, 16);
			auto b = std::stoi(s.substr(4, 2), nullptr, 16);
			return r | (g << 8) | (b << 16);
		} catch (const std::exception&) {
			JsonUtil::throwError(aFieldName, JsonException::ERROR_INVALID, "A #RRGGBB color is required");
		}

		return 0;
	}

	HighlightApi::HighlightApi(Session* aSession) : ApiModule(aSession) {
		METHOD_HANDLER(Access::SETTINGS_VIEW,	METHOD_GET,		(EXACT_PARAM("items")),		HighlightApi::handleGetItems);
		METHOD_HANDLER(Access::SETTINGS_EDIT,	METHOD_PUT,		(EXACT_PARAM("items")),		HighlightApi::handleSetItems);
	}

	json HighlightApi::serializeItem(const ColorSettings& aItem) noexcept {
		return {
			{ "match", Text::fromT(aItem.getMatch()) },
			{ "match_type", enumToString(matchTypeNames, aItem.getMatchType(), "contains") },
			{ "context", enumToString(contextNames, aItem.getContext(), "chat") },
			{ "case_sensitive", aItem.getCaseSensitive() },
			{ "whole_line", aItem.getWholeLine() },
			{ "whole_word", aItem.getWholeWord() },
			{ "bold", aItem.getBold() },
			{ "italic", aItem.getItalic() },
			{ "underline", aItem.getUnderline() },
			{ "strikeout", aItem.getStrikeout() },
			{ "popup", aItem.getPopup() },
			{ "tab", aItem.getTab() },
			{ "play_sound", aItem.getPlaySound() },
			{ "sound_file", aItem.getSoundFile() },
			{ "flash_window", aItem.getFlashWindow() },
			{ "has_fg_color", aItem.getHasFgColor() },
			{ "fg_color", colorToHex(aItem.getFgColor()) },
			{ "has_bg_color", aItem.getHasBgColor() },
			{ "bg_color", colorToHex(aItem.getBgColor()) },
			{ "match_column", aItem.getMatchColumn() },
		};
	}

	ColorSettings HighlightApi::deserializeItem(const json& aJson) {
		auto match = JsonUtil::getField<string>("match", aJson, false);

		ColorSettings item;
		item.setContext(enumFromString(contextNames, "context",
			JsonUtil::getOptionalFieldDefault<string>("context", aJson, "chat")));
		item.setMatchType(enumFromString(matchTypeNames, "match_type",
			JsonUtil::getOptionalFieldDefault<string>("match_type", aJson, "contains")));

		item.setCaseSensitive(JsonUtil::getOptionalFieldDefault<bool>("case_sensitive", aJson, false));
		item.setWholeLine(JsonUtil::getOptionalFieldDefault<bool>("whole_line", aJson, false));
		item.setWholeWord(JsonUtil::getOptionalFieldDefault<bool>("whole_word", aJson, false));
		item.setBold(JsonUtil::getOptionalFieldDefault<bool>("bold", aJson, false));
		item.setItalic(JsonUtil::getOptionalFieldDefault<bool>("italic", aJson, false));
		item.setUnderline(JsonUtil::getOptionalFieldDefault<bool>("underline", aJson, false));
		item.setStrikeout(JsonUtil::getOptionalFieldDefault<bool>("strikeout", aJson, false));
		item.setPopup(JsonUtil::getOptionalFieldDefault<bool>("popup", aJson, false));
		item.setTab(JsonUtil::getOptionalFieldDefault<bool>("tab", aJson, false));
		item.setPlaySound(JsonUtil::getOptionalFieldDefault<bool>("play_sound", aJson, false));
		item.setSoundFile(JsonUtil::getOptionalFieldDefault<string>("sound_file", aJson, Util::emptyString));
		item.setFlashWindow(JsonUtil::getOptionalFieldDefault<bool>("flash_window", aJson, false));

		item.setHasFgColor(JsonUtil::getOptionalFieldDefault<bool>("has_fg_color", aJson, false));
		if (item.getHasFgColor()) {
			item.setFgColor(colorFromHex("fg_color", JsonUtil::getField<string>("fg_color", aJson, false)));
		}
		item.setHasBgColor(JsonUtil::getOptionalFieldDefault<bool>("has_bg_color", aJson, false));
		if (item.getHasBgColor()) {
			item.setBgColor(colorFromHex("bg_color", JsonUtil::getField<string>("bg_color", aJson, false)));
		}

		item.setMatchColumn(JsonUtil::getOptionalFieldDefault<int>("match_column", aJson, 0));

		// setMatch derives the magic flags ($ts$/$users$/$mynick$/$Re:) from the string, and
		// setRegexp compiles the expression when it is a regex (reads the case-sensitivity set
		// above), so these must come last and in this order. A malformed "$Re:" pattern makes
		// setRegexp throw boost::regex_error; turn that into a clean 400 rather than a 500.
		item.setMatch(Text::toT(match));
		try {
			item.setRegexp();
		} catch (const std::exception&) {
			JsonUtil::throwError("match", JsonException::ERROR_INVALID, "Invalid regular expression");
		}

		return item;
	}

	api_return HighlightApi::handleGetItems(ApiRequest& aRequest) {
		auto items = HighlightManager::getInstance()->getColors();

		auto ret = json::array();
		for (const auto& item: items) {
			ret.push_back(serializeItem(item));
		}

		aRequest.setResponseBody(ret);
		return http::status::ok;
	}

	api_return HighlightApi::handleSetItems(ApiRequest& aRequest) {
		const auto& itemsJson = aRequest.getRequestBody();
		if (!itemsJson.is_array()) {
			JsonUtil::throwError("items", JsonException::ERROR_INVALID, "An array of highlights is required");
		}

		ColorList items;
		for (const auto& itemJson: itemsJson) {
			items.push_back(deserializeItem(itemJson));
		}

		HighlightManager::getInstance()->setColors(items);

		auto ret = json::array();
		for (const auto& item: HighlightManager::getInstance()->getColors()) {
			ret.push_back(serializeItem(item));
		}

		aRequest.setResponseBody(ret);
		return http::status::ok;
	}
}

#endif // HAVE_CORE_MODULES
