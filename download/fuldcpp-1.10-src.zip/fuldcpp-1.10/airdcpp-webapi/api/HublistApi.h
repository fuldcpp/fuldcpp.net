/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_HUBLIST_API_H
#define DCPLUSPLUS_DCPP_HUBLIST_API_H

#ifdef HAVE_CORE_MODULES

#include <api/base/SubscribableApiModule.h>

#include <airdcpp/core/header/typedefs.h>

#include <airdcpp/modules/HublistEntry.h>
#include <airdcpp/modules/HublistManagerListener.h>

namespace webserver {
	class HublistApi : public SubscribableApiModule, private HublistManagerListener {
	public:
		HublistApi(Session* aSession);
		~HublistApi();
	private:
		static json serializeEntry(const HublistEntry& aEntry) noexcept;

		api_return handleGetStatus(ApiRequest& aRequest);
		api_return handleGetEntries(ApiRequest& aRequest);
		api_return handleSelect(ApiRequest& aRequest);
		api_return handleRefresh(ApiRequest& aRequest);

		void on(HublistManagerListener::DownloadStarting, const string& aServer) noexcept override;
		void on(HublistManagerListener::DownloadFailed, const string& aServer) noexcept override;
		void on(HublistManagerListener::DownloadFinished, const string& aServer) noexcept override;
		void on(HublistManagerListener::LoadedFromCache, const string& aServer, const string& aDate) noexcept override;
		void on(HublistManagerListener::Corrupted, const string& aServer) noexcept override;
	};
}

#endif // HAVE_CORE_MODULES

#endif
