/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#ifdef HAVE_CORE_MODULES

#include <api/FinishedDownloadApi.h>

#include <api/common/Serializer.h>

#include <airdcpp/modules/FinishedManager.h>
#include <airdcpp/util/PathUtil.h>

namespace webserver {
	FinishedDownloadApi::FinishedDownloadApi(Session* aSession) : SubscribableApiModule(aSession, Access::TRANSFERS) {
		createSubscriptions({
			"finished_download_added",
			"finished_download_removed",
			"finished_downloads_cleared"
		});

		METHOD_HANDLER(Access::TRANSFERS,	METHOD_GET,		(),							FinishedDownloadApi::handleGetItems);
		METHOD_HANDLER(Access::TRANSFERS,	METHOD_DELETE,	(TOKEN_PARAM),				FinishedDownloadApi::handleRemoveItem);
		METHOD_HANDLER(Access::TRANSFERS,	METHOD_POST,	(EXACT_PARAM("clear")),		FinishedDownloadApi::handleClear);

		FinishedManager::getInstance()->addListener(this);
	}

	FinishedDownloadApi::~FinishedDownloadApi() {
		FinishedManager::getInstance()->removeListener(this);
	}

	json FinishedDownloadApi::serializeFinishedItem(const FinishedItemPtr& aItem) noexcept {
		return {
			{ "id", aItem->getToken() },
			{ "user", Serializer::serializeHintedUser(aItem->getUser()) },
			{ "name", PathUtil::getFileName(aItem->getTarget()) },
			{ "path", PathUtil::getFilePath(aItem->getTarget()) },
			{ "size", aItem->getSize() },
			{ "speed", aItem->getAvgSpeed() },
			{ "time", aItem->getTime() },
			{ "tth", aItem->getTTH().toBase32() },
		};
	}

	FinishedItemPtr FinishedDownloadApi::parseItemToken(ApiRequest& aRequest) {
		auto token = aRequest.getTokenParam();

		FinishedItemPtr ret = nullptr;
		{
			auto fm = FinishedManager::getInstance();
			for (const auto& item: fm->lockDownloadList()) {
				if (item->getToken() == token) {
					ret = item;
					break;
				}
			}

			fm->unlockList();
		}

		return ret;
	}

	api_return FinishedDownloadApi::handleGetItems(ApiRequest& aRequest) {
		FinishedItemList items;
		{
			auto fm = FinishedManager::getInstance();
			items = fm->lockDownloadList();
			fm->unlockList();
		}

		aRequest.setResponseBody(Serializer::serializeList(items, serializeFinishedItem));
		return http::status::ok;
	}

	api_return FinishedDownloadApi::handleRemoveItem(ApiRequest& aRequest) {
		auto item = parseItemToken(aRequest);
		if (!item) {
			aRequest.setResponseErrorStr("Finished download not found");
			return http::status::not_found;
		}

		FinishedManager::getInstance()->removeDownload(item);
		return http::status::no_content;
	}

	api_return FinishedDownloadApi::handleClear(ApiRequest&) {
		FinishedManager::getInstance()->removeAllDownloads();
		return http::status::no_content;
	}

	void FinishedDownloadApi::on(FinishedManagerListener::AddedDl, const FinishedItemPtr& aItem) noexcept {
		maybeSend("finished_download_added", [&] {
			return serializeFinishedItem(aItem);
		});
	}

	void FinishedDownloadApi::on(FinishedManagerListener::RemovedDl, const FinishedItemPtr& aItem) noexcept {
		maybeSend("finished_download_removed", [&] {
			return serializeFinishedItem(aItem);
		});
	}

	void FinishedDownloadApi::on(FinishedManagerListener::RemovedAllDl) noexcept {
		maybeSend("finished_downloads_cleared", [] {
			return json::object();
		});
	}
}

#endif // HAVE_CORE_MODULES
