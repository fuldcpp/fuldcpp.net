/*
* Copyright (C) 2011-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <web-server/WebServerManager.h>

#include <web-server/ApiSettingItem.h>
#include <web-server/ContextMenuManager.h>
#include <web-server/ExtensionManager.h>
#include <web-server/HttpManager.h>
#include <web-server/SocketManager.h>
#include <web-server/QueueMenuProvider.h>
#include <web-server/Timer.h>
#include <web-server/UserCommandMenuProvider.h>
#include <web-server/WebServerSettings.h>
#include <web-server/WebUserManager.h>

#include <airdcpp/core/header/typedefs.h>

#include <airdcpp/core/crypto/CryptoManager.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/util/NetworkUtil.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/core/timer/TimerManager.h>

#include "BeastServerAdapter.h"

#define CONFIG_DIR AppUtil::PATH_USER_CONFIG

#define HANDSHAKE_TIMEOUT 0 // disabled, affects HTTP downloads

namespace webserver {
	using namespace dcpp;
	WebServerManager::WebServerManager() : 
		ios(4),
		tasks(4),
		wordGuardTasks(tasks.get_executor())
	{
		settingsManager = make_unique<WebServerSettings>(this);

		userManager = make_unique<WebUserManager>(this);
		socketManager = make_unique<SocketManager>(this);
		httpManager = make_unique<HttpManager>(this);

		extManager = make_unique<ExtensionManager>(this);
		contextMenuManager = make_unique<ContextMenuManager>();
		userCommandMenuProvider = make_unique<UserCommandMenuProvider>(*contextMenuManager);
		queueMenuProvider = make_unique<QueueMenuProvider>(*contextMenuManager);

		plainServerConfig = make_unique<ServerConfig>(settingsManager->getSettingItem(WebServerSettings::PLAIN_PORT), settingsManager->getSettingItem(WebServerSettings::PLAIN_BIND));
		tlsServerConfig = make_unique<ServerConfig>(settingsManager->getSettingItem(WebServerSettings::TLS_PORT), settingsManager->getSettingItem(WebServerSettings::TLS_BIND));

		// Prevent io service from running until we load
		ios.stop();
		tasks.stop();
	}

	WebServerManager::~WebServerManager() {
		// Let them remove the listeners
		extManager.reset();
		userManager.reset();
	}

	bool WebServerManager::isRunning() const noexcept {
		return !ios.stopped() || !tasks.stopped();
	}

#if defined _MSC_VER && defined _DEBUG
	class DebugOutputStream : public std::ostream {
	public:
		DebugOutputStream() : std::ostream(&buf) {}
	private:
		class dbgview_buffer : public std::stringbuf {
		public:
			~dbgview_buffer() override {
				sync(); // can be avoided
			}

			int sync() override {
				OutputDebugString(Text::toT(str()).c_str());
				str("");
				return 0;
			}
		};

		dbgview_buffer buf;
	};

	DebugOutputStream debugStreamPlain;
	DebugOutputStream debugStreamTls;
#else
#define debugStreamPlain std::cout
#define debugStreamTls std::cout
#endif

	static void setEndpointLogSettings(IServerEndpoint& aEndpoint, std::ostream& access, std::ostream& error) {
		aEndpoint.configureLogging(&access, &error, true);
	}

	static void disableEndpointLogging(IServerEndpoint& aEndpoint) {
		aEndpoint.configureLogging(nullptr, nullptr, false);
	}

	static void setEndpointOptions(IServerEndpoint& aEndpoint) {
		aEndpoint.setOpenHandshakeTimeout(HANDSHAKE_TIMEOUT);
		aEndpoint.setPongTimeout(WEBCFG(PING_TIMEOUT).num() * 1000);

		aEndpoint.setMaxHttpBodySize(HttpManager::MAX_HTTP_BODY_SIZE);
	}

	bool WebServerManager::startup(const MessageCallback& errorF, const string& aWebResourcePath, const Callback& aShutdownF) {
		httpManager->start(aWebResourcePath);
		socketManager->start();

		shutdownF = aShutdownF;
		return start(errorF);
	}

	bool WebServerManager::start(const MessageCallback& errorF) {
		if (!hasValidServerConfig()) {
			return false;
		}

		ios.restart();
		tasks.restart();
		if (!hasIOContext) {
			hasIOContext = initialize(errorF);
		}

		if (!listen(errorF)) {
			// Stop possible running ios services
			stop();
			return false;
		}

		return true;
	}

	bool WebServerManager::initialize(const MessageCallback& errorF) {
		SettingsManager::getInstance()->setDefault(SettingsManager::PM_MESSAGE_CACHE, 100);
		SettingsManager::getInstance()->setDefault(SettingsManager::HUB_MESSAGE_CACHE, 100);

		try {
			// initialize asio with our external io_context rather than an internal one
			// Phase 1: construct websocketpp adapters and init
			endpoint_plain = std::make_unique<BeastServerAdapter>();
			endpoint_tls = std::make_unique<BeastServerAdapter>();

			endpoint_plain->initAsio(&ios);
			endpoint_tls->initAsio(&ios);
		} catch (const std::exception& e) {
			if (errorF) {
				errorF(e.what());
			}

			return false;
		}

		// Handlers
		socketManager->setEndpointHandlers(*endpoint_plain, false);
		socketManager->setEndpointHandlers(*endpoint_tls, true);

		httpManager->setEndpointHandlers(*endpoint_plain, false);
		httpManager->setEndpointHandlers(*endpoint_tls, true);

		// Misc options
		setEndpointOptions(*endpoint_plain);
		setEndpointOptions(*endpoint_tls);

		// TLS endpoint has an extra handler for the tls init
		endpoint_tls->setTlsInitHandler([this]() { return handleInitTls(); });

		// Logging
		if (enableSocketLogging) {
			setEndpointLogSettings(*endpoint_plain, debugStreamPlain, debugStreamPlain);
			setEndpointLogSettings(*endpoint_tls, debugStreamTls, debugStreamTls);
		} else {
			disableEndpointLogging(*endpoint_plain);
			disableEndpointLogging(*endpoint_tls);
		}

		return true;
	}

	boost::asio::ip::tcp WebServerManager::getDefaultListenProtocol() noexcept {
		auto v6Supported = !NetworkUtil::getLocalIp(true).empty();
		return v6Supported ? boost::asio::ip::tcp::v6() : boost::asio::ip::tcp::v4();
	}

	bool WebServerManager::isListeningPlain() const noexcept {
		return endpoint_plain && endpoint_plain->isListening();
	}

	bool WebServerManager::isListeningTls() const noexcept {
		return endpoint_tls && endpoint_tls->isListening();
	}

	static bool listenEndpoint(IServerEndpoint& aEndpoint, const ServerConfig& aConfig, const string& aProtocol, const MessageCallback& errorF) noexcept {
		if (!aConfig.hasValidConfig()) {
			return false;
		}

#ifndef _WIN32
		// https://github.com/airdcpp-web/airdcpp-webclient/issues/39
		aEndpoint.setReuseAddr(true);
#endif
		try {
			const auto bindAddress = aConfig.bindAddress.str();
			if (!bindAddress.empty()) {
				aEndpoint.listen(bindAddress, aConfig.port.str());
			} else {
				// IPv6 and IPv4-mapped IPv6 addresses are used by default (given that IPv6 is supported by the OS)
				aEndpoint.listen(WebServerManager::getDefaultListenProtocol(), static_cast<uint16_t>(aConfig.port.num()));
			}

			aEndpoint.startAccept();
			return true;
		} catch (const std::exception& e) {
			auto message = STRING_F(WEB_SERVER_SETUP_FAILED, aProtocol % aConfig.port.num() % string(e.what()));
			if (errorF) {
				errorF(message);
			}
		}

		return false;
	}

	bool WebServerManager::listen(const MessageCallback& errorF) {
		bool hasServer = false;

		if (listenEndpoint(*endpoint_plain, *plainServerConfig, "HTTP", errorF)) {
			hasServer = true;
		}

		// Never let the TLS port fall back to plaintext. An endpoint that can't perform a
		// handshake would serve the Web UI - session logins included - in the clear on a port
		// the user believes is encrypted, with nothing to warn them.
		if (!endpoint_tls->supportsTls()) {
			if (tlsServerConfig->hasValidConfig()) {
				const auto message = string("The encrypted web server port was not opened: TLS is not supported by "
					"this build. Use the unencrypted port, or a reverse proxy that terminates TLS.");

				// Report through errorF as well as the log: with a TLS-only configuration this is
				// the reason the whole web server fails to start, and errorF is the only channel
				// the caller sees.
				log(message, LogMessage::SEV_ERROR);
				if (errorF) {
					errorF(message);
				}
			}
		} else if (listenEndpoint(*endpoint_tls, *tlsServerConfig, "HTTPS", errorF)) {
			hasServer = true;
		}

		if (!hasServer) {
			return false;
		}

		ios_threads = make_unique<boost::thread_group>();
		task_threads = make_unique<boost::thread_group>();

		// Start the ASIO io_context run loop running both endpoints
		for (int x = 0; x < WEBCFG(SERVER_THREADS).num(); ++x) {
			ios_threads->create_thread(boost::bind(&boost::asio::io_context::run, &ios));
		}

		for (int x = 0; x < std::max(WEBCFG(SERVER_THREADS).num() / 2, 1); ++x) {
			task_threads->create_thread(boost::bind(&boost::asio::io_context::run, &tasks));
		}

		// Add timers
		{
			const auto logger = getDefaultErrorLogger();
			minuteTimer = addTimer(
				[this, logger] {
					save(logger);
				},
				30 * 1000
			);

			minuteTimer->start(false);
		}

		fire(WebServerManagerListener::Started());
		return true;
	}

	void WebServerManager::onData(const string& aData, TransportType aType, Direction aDirection, const string& aIP) noexcept {
		// Avoid possible deadlocks due to possible simultaneous disconnected/server state listener events
		addAsyncTask([=, this] {
			fire(WebServerManagerListener::Data(), aData, aType, aDirection, aIP);
		});
	}

	context_ptr WebServerManager::handleInitTls() {
		//std::cout << "on_tls_init called with hdl: " << hdl.lock().get() << std::endl;
		auto ctx = make_shared<boost::asio::ssl::context>(boost::asio::ssl::context::tls);

		try {
			ctx->set_options(boost::asio::ssl::context::default_workarounds |
				boost::asio::ssl::context::no_sslv2 |
				boost::asio::ssl::context::no_sslv3 |
				boost::asio::ssl::context::no_tlsv1 |
				boost::asio::ssl::context::no_tlsv1_1 |
				boost::asio::ssl::context::single_dh_use |
				boost::asio::ssl::context::no_compression
			);

			const auto customCert = WEBCFG(TLS_CERT_PATH).str();
			const auto customKey = WEBCFG(TLS_CERT_KEY_PATH).str();

			bool useCustom = !customCert.empty() && !customKey.empty();

			// Apply our options - the security level in particular - before loading the
			// certificate, so a key that the level rejects fails here with a clear error
			// instead of at handshake time on every connection.
			CryptoManager::setContextOptions(ctx->native_handle(), true);

			ctx->use_certificate_file(useCustom ? customCert : SETTING(TLS_CERTIFICATE_FILE), boost::asio::ssl::context::pem);
			ctx->use_private_key_file(useCustom ? customKey : SETTING(TLS_PRIVATE_KEY_FILE), boost::asio::ssl::context::pem);
		} catch (const std::exception& e) {
			// Return nothing rather than a context with no usable certificate. The endpoint
			// refuses to listen on null, which is the whole point: a TLS port that cannot
			// complete a handshake must not be open at all.
			log("Failed to initialize the encrypted web server context: " + string(e.what()), LogMessage::SEV_ERROR);
			return nullptr;
		}

		return ctx;
	}

	void WebServerManager::stop() noexcept {
		if (minuteTimer)
			minuteTimer->stop(true);

		fireReversed(WebServerManagerListener::Stopping());

		if(endpoint_plain && endpoint_plain->isListening())
			endpoint_plain->stopListening();
		if(endpoint_tls && endpoint_tls->isListening())
			endpoint_tls->stopListening();

		httpManager->stop();
		socketManager->stop();

		ios.stop();
		tasks.stop();

		if (task_threads)
			task_threads->join_all();

		if (ios_threads)
			ios_threads->join_all();

		task_threads.reset();
		ios_threads.reset();

		fireReversed(WebServerManagerListener::Stopped());
	}

	TimerPtr WebServerManager::addTimer(Callback&& aCallback, time_t aIntervalMillis, const Timer::CallbackWrapper& aCallbackWrapper) noexcept {
		return make_shared<Timer>(std::move(aCallback), tasks, aIntervalMillis, aCallbackWrapper);
	}

	void WebServerManager::addAsyncTask(Callback&& aCallback) noexcept {
		boost::asio::post(tasks, std::move(aCallback));
	}

	void WebServerManager::log(const string& aMsg, LogMessage::Severity aSeverity) const noexcept {
		if (!LogManager::getInstance()) {
			// Core is not initialized yet
			return;
		}

		LogManager::getInstance()->message(aMsg, aSeverity, STRING(WEB_SERVER));
	}

	MessageCallback WebServerManager::getDefaultErrorLogger() const noexcept {
		return [this](const string& aMessage) {
			log(aMessage, LogMessage::SEV_ERROR);
		};
	}

	string WebServerManager::getLocalServerHttpUrl() noexcept {
		bool isPlain = isListeningPlain();
		const auto& config = isPlain ? plainServerConfig : tlsServerConfig;
		return (isPlain ? "http://" : "https://") + getLocalServerAddress(*config);
	}

	bool WebServerManager::isAnyAddress(const string& aAddress) noexcept {
		if (aAddress.empty()) {
			return true;
		}

		try {
#if BOOST_VERSION >= 106600
			auto ip = boost::asio::ip::make_address(aAddress);
#else
			auto ip = boost::asio::ip::address::from_string(aAddress);
#endif
			if (ip == boost::asio::ip::address_v4::any() || ip == boost::asio::ip::address_v6::any()) {
				return true;
			}
		} catch (...) {
			return true;
		}

		return false;
	}

	string WebServerManager::getLocalServerAddress(const ServerConfig& aConfig) noexcept {
		auto bindAddress = aConfig.bindAddress.str();
		if (isAnyAddress(bindAddress)) {
			/*websocketpp::lib::asio::error_code ec;
			auto isV6 = endpoint_plain.get_local_endpoint(ec).protocol().family() == AF_INET6;
			if (ec) {
				dcassert(0);
			}

			bindAddress = isV6 ? "[::1]" : "127.0.0.1";*/

			// Workaround for https://github.com/zaphoyd/websocketpp/pull/879
			// websocketpp can't currently handle bracketed IPv6 addresses so we need to use something else
			bindAddress = "localhost";
		} else {
			bindAddress = resolveAddress(bindAddress, aConfig.port.str());
		}

		return bindAddress + ":" + Util::toString(aConfig.port.num());
	}

	string WebServerManager::resolveAddress(const string& aHostname, const string& aPort) noexcept {
		boost::asio::ip::tcp::resolver resolver(ios);

		try {
			for (const auto& res: resolver.resolve(aHostname, aPort)) {
				auto ret = res.endpoint().address().to_string();

				if (res.endpoint().protocol() == boost::asio::ip::tcp::v6()) {
					ret = "[" + ret + "]";
				}

				return ret;
			}
		} catch (const std::exception& e) {
			log(e.what(), LogMessage::SEV_ERROR);
		}

		return aHostname;
	}

	bool WebServerManager::hasValidServerConfig() const noexcept {
		return plainServerConfig->hasValidConfig() || tlsServerConfig->hasValidConfig();
	}

	bool WebServerManager::hasUsers() const noexcept {
		return userManager->hasUsers();
	}

	bool WebServerManager::waitExtensionsLoaded() const noexcept {
		return extManager->waitLoaded();
	}

	bool WebServerManager::load(const MessageCallback& aErrorF) noexcept {
		fire(WebServerManagerListener::LoadSettings(), aErrorF);
		return hasValidServerConfig();
	}

	bool WebServerManager::save(const MessageCallback& aCustomErrorF) noexcept {
		auto errorF = aCustomErrorF;
		if (!errorF) {
			// Avoid crashes if the file is saved when core is not loaded
			errorF = [](const string&) {};
		}

		fire(WebServerManagerListener::SaveSettings(), errorF);
		return true;
	}

	bool ServerConfig::hasValidConfig() const noexcept {
		return port.num() > 0;
	}
}