/*
* Copyright (C) 2011-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_WEBSERVER_TIMER_H
#define DCPLUSPLUS_WEBSERVER_TIMER_H

#include "forward.h"

#include <airdcpp/core/header/debug.h>

#include <chrono>

namespace webserver {
	class Timer : public boost::noncopyable, public std::enable_shared_from_this<Timer> {
	public:
		using CallbackWrapper = std::function<void (const Callback &)>;

		// CallbackWrapper is meant to ensure the lifetime of the timer
		// (which necessary only if the timer is called from a class that can be deleted, such as sessions)
		Timer(Callback&& aCallback, boost::asio::io_context& aIO, time_t aIntervalMillis, const CallbackWrapper& aWrapper) :
			cb(std::move(aCallback)),
			cbWrapper(aWrapper),
			timer(aIO),
			interval(std::chrono::milliseconds(aIntervalMillis))
		{
			dcdebug("Timer %p was created\n", this);
		}

		~Timer() {
			stop(true);
			dcdebug("Timer %p was destroyed\n", this);
		}

		bool start(bool aInstantTick) {
			if (shutdown) {
				return false;
			}

			running = true;
			scheduleNext(aInstantTick ? std::chrono::milliseconds(0) : interval);
			return true;
		}

		// Use aShutdown if the timer will be stopped permanently (e.g. the owner is being deleted)
		void stop(bool aShutdown) noexcept {
			running = false;
			shutdown = aShutdown;
			timer.cancel();
		}

		bool isRunning() const noexcept {
			return running;
		}

		void flush() {
			timer.cancel();
			scheduleNext(std::chrono::milliseconds(0));
		}
	private:
		/*
		 * Static, and handed a WEAK reference rather than a raw pointer.
		 *
		 * Being static protected nothing by itself: the handler dereferenced the raw Timer* as soon
		 * as the wait was not an aborted one. cancel() only promises that handlers ALREADY QUEUED
		 * run with operation_aborted, so a tick that had passed that check on the io thread was
		 * still going to touch the object while its owner reset or replaced the TimerPtr on
		 * another -- the sessions this class exists to serve are deleted exactly that way.
		 *
		 * Locking the weak reference makes that case a no-op, and holding the resulting shared_ptr
		 * across the callback is the lifetime guarantee the CallbackWrapper comment above asks for.
		 */
		static void tick(const boost::system::error_code& error, const CallbackWrapper& cbWrapper, const std::weak_ptr<Timer>& aTimer) {
			if (error == boost::asio::error::operation_aborted) {
				return;
			}

			auto timer = aTimer.lock();
			if (!timer) {
				return;
			}

			if (cbWrapper) {
				// We must ensure that the timer still exists when a new start call is performed
				cbWrapper([timer] { timer->runTask(); });
			} else {
				timer->runTask();
			}
		}

		void scheduleNext(std::chrono::milliseconds aFromNow) {
			if (!running) {
				return;
			}

			timer.expires_after(aFromNow);
			timer.async_wait(std::bind(&Timer::tick, std::placeholders::_1, cbWrapper, weak_from_this()));
		}

		void runTask() {
			cb();

			scheduleNext(interval);
		}

		Callback cb;
		CallbackWrapper cbWrapper;

		boost::asio::steady_timer timer;
		std::chrono::milliseconds interval;
		bool running = false;
		bool shutdown = false;
	};

	using TimerPtr = shared_ptr<Timer>;
}

#endif
