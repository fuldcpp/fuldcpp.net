/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_WEBSERVER_USER_COMMAND_MENU_PROVIDER_H
#define DCPLUSPLUS_WEBSERVER_USER_COMMAND_MENU_PROVIDER_H

#include "forward.h"

#include "ContextMenuItem.h"
#include "ContextMenuManagerListener.h"

#include <airdcpp/forward.h>
#include <airdcpp/core/ActionHook.h>
#include <airdcpp/core/header/typedefs.h>
#include <airdcpp/hub/user_command/UserCommand.h>

namespace webserver {

class ContextMenuManager;

// Exposes hub-provided user commands (NMDC $UserCommand / ADC CMD) in the Web UI
// context menus by acting as a native subscriber of the context menu hooks
class UserCommandMenuProvider : private ContextMenuManagerListener {
public:
	explicit UserCommandMenuProvider(ContextMenuManager& aMenuManager);
	~UserCommandMenuProvider() override;

private:
	using MenuItemResultGetter = ActionHookResultGetter<GroupedContextMenuItemPtr>;

	ActionHookResult<GroupedContextMenuItemPtr> getHookResult(const MenuItemResultGetter& aResultGetter, const ContextMenuItemListData& aListData, int aContext, const StringList& aHubs) const noexcept;
	GroupedContextMenuItemPtr getCommandMenu(int aContext, const StringList& aHubs) const noexcept;

	ContextMenuItemList buildMenuItems(const vector<const UserCommand*>& aCommands, size_t aPathLevel) const noexcept;
	ContextMenuItemPtr toLeafItem(const UserCommand& aCommand, const string& aTitle) const noexcept;
	static ExtensionSettingItem::List toFormFieldDefinitions(const UserCommand& aCommand) noexcept;

	static bool hasSendAccess(const AccessList& aAccess) noexcept;

	// Resolves a click into a command that is actually available for the given hubs and context,
	// mirroring the GUI which can only run commands listed by UserCommandManager::getUserCommands
	optional<UserCommand> parseClickedCommand(const ContextMenuItemClickData& aClickData, int aContext, const StringList& aHubs) const noexcept;
	static ParamMap toLineParams(const UserCommand& aCommand, const ContextMenuItemClickData& aClickData) noexcept;

	static StringList getSearchResultHubs(const vector<TTHValue>& aResults, const SearchInstancePtr& aInstance) noexcept;

	void on(HubUserMenuSelected, const vector<dcpp::SID>&, const ClientPtr&, const ContextMenuItemClickData&) noexcept override;
	void on(HubMenuSelected, const vector<ClientToken>&, const ContextMenuItemClickData&) noexcept override;
	void on(GroupedSearchResultMenuSelected, const vector<TTHValue>&, const SearchInstancePtr&, const ContextMenuItemClickData&) noexcept override;
	void on(FilelistItemMenuSelected, const vector<DirectoryListingItemToken>&, const DirectoryListingPtr&, const ContextMenuItemClickData&) noexcept override;

	ContextMenuManager& cmm;
	const ActionHookSubscriber subscriber;
};

} // namespace webserver

#endif // DCPLUSPLUS_WEBSERVER_USER_COMMAND_MENU_PROVIDER_H
