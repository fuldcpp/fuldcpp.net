/*
* Copyright (C) 2011-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_API_VERSION_H
#define DCPLUSPLUS_API_VERSION_H

namespace webserver {
#define API_VERSION 1
// 11: ADC RTF0 rich text - chat messages gain rich_text/rich_spans, highlights
// gain display_text/inline_media, hubs gain supports_rich_text, and outgoing
// messages accept a "rich" flag
// 12: ADC RTF0 in private messages - a private chat gains supports_rich_text, which
// answers for the route that chat will actually take (CCPM or hub); the hub-level
// flag cannot answer it, because a PM also needs the recipient to carry RTF0
// 13: POST /extensions/install_local installs a package file from the server's own disk
#define API_FEATURE_LEVEL 13

}

#endif