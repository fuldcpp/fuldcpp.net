/*
* Copyright (C) 2011-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <semver/semver.hpp>

#include <web-server/NpmRepository.h>

#include <airdcpp/connection/http/HttpDownload.h>
#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/core/classes/ScopedFunctor.h>
#include <airdcpp/core/thread/Thread.h>
#include <airdcpp/util/Util.h>


namespace webserver {
	const string NpmRepository::repository = "npm";

	NpmRepository::NpmRepository(InstallF&& aInstallF, ModuleLogger&& aLoggerF) : installF(std::move(aInstallF)), loggerF(std::move(aLoggerF)) {
		
	}

	NpmRepository::~NpmRepository() {
		// Bounded. A stalled download -- a server that accepts the connection and then sends
		// nothing -- never completes, and this loop had no timeout and nothing that could abort it,
		// so shutdown hung for as long as that peer chose. After a grace period the downloads are
		// dropped instead: ~HttpDownload removes itself as a listener, so a connection still in
		// flight completes into nothing and self-deletes, and the completion handler that captures
		// `this` dies with the map entry.
		static const int SHUTDOWN_GRACE_MS = 5000;
		for (int waited = 0; waited < SHUTDOWN_GRACE_MS; waited += 50) {
			{
				RLock l(cs);
				if (httpDownloads.empty()) {
					return;
				}
			}

			Thread::sleep(50);
		}

		{
			WLock l(cs);
			httpDownloads.clear();
		}
	}

	void NpmRepository::checkUpdates(const string& aName, const string& aCurrentVersion) noexcept {
		// A static, single-version copy of the npm package document
		// (https://github.com/npm/registry/blob/master/docs/REGISTRY-API.md#getpackage),
		// generated from the tarball itself and served from our own site
		const auto url = "https://extensions.fuldcpp.net/" + aName + "/index.json";

		HttpOptions options;
		options.setHeaders(StringPairList({
			{ "Accept", "application/vnd.npm.install-v1+json" },
		}));

		// This document decides which tarball gets installed, so the transport has to be
		// genuine, and it is a few hundred bytes at most
		options.setAllowUntrusted(false);
		options.setMaxBodySize(64 * 1024);

		shared_ptr<HttpDownload> download;

		{
			WLock l(cs);
			auto [pos, added] = httpDownloads.try_emplace(aName, make_shared<HttpDownload>(url, [this, aName, aCurrentVersion]() {
				onPackageInfoDownloaded(aName, aCurrentVersion);
			}, options));

			if (added) {
				download = pos->second;
			}
		}

		// The owner must start the transfer once it is stored where the completion handler
		// can find it; the constructor no longer does it. Without this the check never
		// completes and ~NpmRepository spins forever waiting for httpDownloads to drain.
		// Started after releasing cs because a fast failure completes synchronously.
		if (download) {
			download->start();
		}
	}

	void NpmRepository::install(const string& aName) noexcept {
		checkUpdates(aName, Util::emptyString);
	}

	void NpmRepository::onPackageInfoDownloaded(const string& aName, const string& aCurrentVersion) noexcept {
		// Don't allow the same download to be initiated again until the installation has finished
		ScopedFunctor([&]() {
			WLock l(cs);
			httpDownloads.erase(aName);
		});

		HttpDownloadMap::mapped_type download = nullptr;

		// Get the download
		{
			WLock l(cs);
			auto i = httpDownloads.find(aName);
			if (i == httpDownloads.end()) {
				dcassert(0);
				return;
			}

			download = i->second;
		}

		if (download->buf.empty()) {
			loggerF(STRING_F(WEB_EXTENSION_UPDATE_CHECK_FAILED, aName % download->status), LogMessage::SEV_ERROR);
			return;
		}

		try {
			checkPackageData(download->buf, aName, aCurrentVersion);
		} catch (const std::exception& e) {
			loggerF(STRING_F(WEB_EXTENSION_UPDATE_CHECK_FAILED, aName % e.what()), LogMessage::SEV_ERROR);
		}
	}

	// https://github.com/npm/registry/blob/master/docs/responses/package-metadata.md
	void NpmRepository::checkPackageData(const string& aPackageData, const string& aName, const string& aCurrentVersion) const {
		optional<semver::version> curSemver = !aCurrentVersion.empty() ? optional(semver::version(aCurrentVersion)) : nullopt;

		const auto packageJson = json::parse(aPackageData);
		auto versions = packageJson.at("versions");

		bool majorVersionAnnounced = false;

		// Versions are listed from oldest to newest, start with the newest ones
		for (auto elem = versions.rbegin(); elem != versions.rend(); ++elem) {
			semver::version remoteSemver { elem.key() };

			auto isRemotePrerelease = remoteSemver.prerelease_type != semver::prerelease::none;
			if (curSemver) {
				if (isRemotePrerelease && (*curSemver).prerelease_type == semver::prerelease::none) {
					// Don't update to pre-release versions
					continue;
				}

				if (remoteSemver.major > (*curSemver).major) {
					if (!majorVersionAnnounced) {
						loggerF(STRING_F(WEB_EXTENSION_MAJOR_UPDATE, elem.key() % aName), LogMessage::SEV_INFO);
						majorVersionAnnounced = true;
					}

					// Don't perform major upgrades automatically
					continue;
				} else if (remoteSemver.major == (*curSemver).major) {
					// Same major version, compare normally
					auto comp = (*curSemver).compare(remoteSemver);
					if (comp >= 0) {
						// No new version available
						dcdebug("No updates available for extension %s\n", aName.c_str());
						return;
					} else {
						dcdebug("New update available for extension %s (current version %s, available version %s)\n", aName.c_str(), aCurrentVersion.c_str(), elem.key().c_str());
					}
				} else {
					// Old major version, we shouldn't really be here
					continue;
				}
			} else if (isRemotePrerelease) {
				// Don't install pre-release version for now
				continue;
			}

			// Install
			const auto dist = elem.value().at("dist");

			const auto url = dist.at("tarball");
			const auto sha = dist.at("shasum");

			// Optional only because a repository predating Subresource Integrity would not carry
			// it; every registry in use publishes it, and when it is there it is what decides.
			const auto integrityIter = dist.find("integrity");
			const auto integrity = integrityIter != dist.end() && integrityIter->is_string()
				? integrityIter->get<string>()
				: Util::emptyString;

			installF(aName, url, sha, integrity);
			return;
		}
	}
}