/*
* Copyright (C) 2011-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <web-server/FileServer.h>
#include <web-server/HttpRequest.h>
#include <web-server/HttpUtil.h>
#include <web-server/WebServerManager.h>
#include <web-server/WebUserManager.h>

#include <api/common/Deserializer.h>

#include <airdcpp/util/DupeUtil.h>
#include <airdcpp/core/classes/Exception.h>
#include <airdcpp/core/io/File.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/core/thread/Thread.h>
#include <airdcpp/util/Util.h>

#include <airdcpp/util/LinkUtil.h>
#include <airdcpp/connection/http/HttpDownload.h>
#include <airdcpp/core/classes/ScopedFunctor.h>
#include <airdcpp/util/ValueGenerator.h>
#include <airdcpp/viewed_files/ViewFileManager.h>

#include <sstream>
#include <cstdint>

#include <boost/asio/ip/address.hpp>

namespace webserver {
	// The largest document the CORS proxy will relay to the browser: extension catalogs and
	// release feeds are tens of kilobytes; anything bigger is not what the proxy is for
	static const int64_t MAX_PROXY_BODY_SIZE = 16 * 1024 * 1024;
	using namespace dcpp;

	FileServer::FileServer() {
	}

	FileServer::~FileServer() {
		RLock l(cs);
		for (const auto& [_, path] : tempFiles) {
			File::deleteFile(path);
		}
	}

	const string& FileServer::getResourcePath() const noexcept {
		return resourcePath;
	}

	void FileServer::setResourcePath(const string& aPath) noexcept {
		resourcePath = PathUtil::validateDirectoryPath(aPath);
	}

	string FileServer::getExtension(const string& aResource) noexcept {
		auto extension = PathUtil::getFileExt(aResource);
		if (!extension.empty()) {
			// Strip the dot
			extension = extension.substr(1);
		}

		return extension;
	}

	string FileServer::parseResourcePath(const string& aResource, const HttpRequest& aRequest, StringPairList& headers_) const {
		// Serve files only from the resource directory
		if (aResource.empty() || aResource.find("..") != std::string::npos) {
			throw RequestException(http::status::bad_request, "Invalid resource path");
		}

		auto request = aResource;

		auto extension = getExtension(request);
		if (!extension.empty()) {
			dcassert(extension[0] != '.');

			// We have compressed versions only for JS files
			if (extension == "js" && aRequest.getHeader("Accept-Encoding").find("gzip") != string::npos) {
				request += ".gz";
				headers_.emplace_back("Content-Encoding", "gzip");
			}

			if (extension != "html" && aResource != "/sw.js") {
				// File versioning is done with hashes in filenames (except for the index file and service worker)
				HttpUtil::addCacheControlHeader(headers_, 365);
			}
		} else {
			// Forward all requests for non-static files to index
			// (but try to report API requests or other downloads with an invalid path)

			if (aRequest.getHeader("Accept").find("text/html") == string::npos) {
				if (aRequest.getHeader("Content-Type") == "application/json") {
					throw RequestException(http::status::not_acceptable, "File server won't serve JSON files. Did you mean \"/api" + aResource + "\" instead?");
				}

				throw RequestException(http::status::not_found, "Invalid file path (hint: use \"Accept: text/html\" if you want index.html)");
			}

			request = "index.html";

			// The main chunk name may change and it's stored in the HTML file
			HttpUtil::addCacheControlHeader(headers_, 0);
		}

		// Avoid double separators because of assertions
		if (!request.empty() && request.front() == '/') {
			request = request.substr(1);
		}

		// For windows
		Util::replace(request, "/", PATH_SEPARATOR_STR);

		return resourcePath + request;
	}

	string FileServer::getPath(const TTHValue& aTTH) const {
		auto file = ViewFileManager::getInstance()->getFile(aTTH);
		if (file) {
			return file->getPath();
		}
		
		auto dupe = DupeUtil::checkFileDupe(aTTH);
		if (DupeUtil::allowOpenFileDupe(dupe)) {
			auto paths = DupeUtil::getFileDupePaths(dupe, aTTH);
			if (!paths.empty()) {
				return paths.front();
			}
		}

		throw RequestException(http::status::not_found, "No viewable file matching the TTH " + aTTH.toBase32() + " was found");
	}

	string FileServer::parseViewFilePath(const string& aResource, StringPairList& headers_, const SessionPtr& aSession) const {
		string protocolTmp, tthStr, portTmp, pathTmp, query, fragmentTmp;
		LinkUtil::decodeUrl(aResource, protocolTmp, tthStr, portTmp, pathTmp, query, fragmentTmp);

		auto session = aSession;
		if (!session) {
			auto auth = LinkUtil::decodeQuery(query)["auth_token"];
			if (!auth.empty()) {
				session = WebServerManager::getInstance()->getUserManager().getSession(auth);
			}

			if (!session || !session->getUser()->hasPermission(Access::VIEW_FILES_VIEW)) {
				throw RequestException(http::status::unauthorized, "Not authorized");
			}
		}

		auto tth = Deserializer::parseTTH(tthStr);
		auto path = getPath(tth);

		HttpUtil::addCacheControlHeader(headers_, 1); // One day (files are identified by their TTH so the content won't change)

		return path;
	}

	http::status FileServer::handlePostRequest(const HttpRequest& aRequest,
		std::string& output_, StringPairList& headers_, const SessionPtr& aSession) noexcept {

		const auto& requestPath = aRequest.path;
		if (requestPath == "/temp") {
			if (!aSession || !aSession->getUser()->hasPermission(Access::FILESYSTEM_EDIT)) {
				output_ = "Not authorized";
				return http::status::unauthorized;
			}

			const auto nameHeader = aRequest.getHeader("X-File-Name");
			auto fileName = Util::toString(ValueGenerator::rand());
			if (!nameHeader.empty()) {
				fileName += "_" + PathUtil::validateFileName(nameHeader);
			}

			const auto filePath = AppUtil::getPath(AppUtil::PATH_TEMP) + fileName;

			try {
				File file(filePath, File::WRITE, File::TRUNCATE | File::CREATE, File::BUFFER_SEQUENTIAL);
				file.write(aRequest.body);
			} catch (const FileException& e) {
				output_ = "Failed to write the file: " + e.getError();
				return http::status::internal_server_error;
			}

			{
				WLock l(cs);
				tempFiles.try_emplace(fileName, filePath);
			}

			headers_.emplace_back("Location", fileName);
			return http::status::created;
		}

		output_ = "Requested resource was not found";
		return http::status::not_found;
	}

	string FileServer::getTempFilePath(const string& fileId) const noexcept {
		RLock l(cs);
		auto i = tempFiles.find(fileId);
		return i != tempFiles.end() ? i->second : Util::emptyString;
	}

	http::status FileServer::handleRequest(const HttpRequest& aRequest,
		string& output_, StringPairList& headers_, const FileDeferredHandler& aDeferF) {

		if (aRequest.method == "GET") {
			return handleGetRequest(aRequest, output_, headers_, aRequest.session, aDeferF);
		} else if (aRequest.method == "POST") {
			return handlePostRequest(aRequest, output_, headers_, aRequest.session);
		}

		output_ = "Requested resource was not found";
		return http::status::not_found;
	}

	http::status FileServer::handleGetRequest(const HttpRequest& aRequest,
		string& output_, StringPairList& headers_, const SessionPtr& aSession, const FileDeferredHandler& aDeferF) {

		const auto& requestUrl = aRequest.path;
		dcdebug("Requesting file %s\n", requestUrl.c_str());

		// Proxy request?
		if (requestUrl.starts_with("/proxy")) {
			if (!aSession) {
				output_ = "Not authorized";
				return http::status::unauthorized;
			}

			return handleProxyDownload(requestUrl, output_, aDeferF);
		}

		// File request
		string filePath;
		auto isViewFile = requestUrl.length() >= 6 && requestUrl.compare(0, 6, "/view/") == 0;
		try {
			if (isViewFile) {
				filePath = parseViewFilePath(requestUrl.substr(6), headers_, aSession);
			} else if (requestUrl.length() >= 6 && requestUrl.compare(0, 6, "/proxy") == 0) {
				if (!aSession) {
					throw RequestException(http::status::unauthorized, "Not authorized");
				}

				return handleProxyDownload(requestUrl, output_, aDeferF);
			} else {
				filePath = parseResourcePath(requestUrl, aRequest, headers_);
			}
		} catch (const RequestException& e) {
			output_ = e.what();
			return e.getCode();
		}

		auto fileSize = File::getSize(filePath);
		int64_t startPos = 0, endPos = fileSize - 1;

		auto partialContent = HttpUtil::parsePartialRange(aRequest.getHeader("Range"), startPos, endPos);

		// Ceiling on ONE response body. Without it a request that asks for the whole file -- which is
		// what a plain fetch, or a media element's first request, sends -- reads it entirely into a
		// string and then copies it, so a large viewed file costs several times its size transiently
		// and a big enough one answers 500 on bad_alloc instead of playing. Truncating and answering
		// 206 with an accurate Content-Range is the protocol's way of saying "here is a piece, ask for
		// the rest", which is what every player and resuming downloader already does.
		//
		// The trade-off is deliberate: a client that ignores Content-Range gets a short body rather
		// than a failed request. Serving the whole thing without buffering it would need a streaming
		// response, which this handler (it returns the body as a string) cannot express.
		static constexpr int64_t MAX_RESPONSE_BYTES = 16LL * 1024 * 1024;
		if (fileSize > 0 && endPos >= startPos && endPos - startPos + 1 > MAX_RESPONSE_BYTES) {
			endPos = startPos + MAX_RESPONSE_BYTES - 1;
			partialContent = true;
		}

		// Read file
		try {
			File f(filePath, File::READ, File::OPEN);
			f.setPos(startPos);

			// endPos is the range END OFFSET, not a length. Passing it straight to read()
			// meant "Range: bytes=2147483646-2147483647" against a 2 GB file asked for two
			// bytes but allocated 2 GiB (File::read constructs a string of that size up
			// front), then copied it twice more -- a handful of concurrent 2-byte range
			// requests exhausted memory. It also made the body carry startPos more bytes
			// than the Content-Range header advertised.
			const auto readLen = static_cast<size_t>(endPos - startPos) + 1;
			output_ = f.read(readLen);
		} catch (const FileException& e) {
			dcdebug("Failed to serve the file %s: %s\n", filePath.c_str(), e.getError().c_str());

			// Don't show the local file path for public resources
			auto responsePath = isViewFile ? filePath : requestUrl;
			output_ = e.getError() + " (" + responsePath + ")";
			return http::status::not_found;
		} catch (const std::bad_alloc&) {
			output_ = "Not enough memory on the server to serve this request";
			return http::status::internal_server_error;
		}

		{
			const auto ext = PathUtil::getFileExt(filePath);
			if (ext == ".nfo") {
				string encoding;

				// Platform-independent encoding conversion function could be added if there is more use for it
#ifdef _WIN32
				encoding = "CP.437";
#else
				encoding = "cp437";
#endif
				output_ = Text::toUtf8(output_, encoding);
			}
		}

		{
			// Get the mime type (but get it from the original request with gzipped content)
			auto usingEncoding = ranges::find(headers_ | views::keys, "Content-Encoding").base() != headers_.end();
			auto type = HttpUtil::getMimeType(usingEncoding ? requestUrl : filePath);
			if (type) {
				headers_.emplace_back("Content-Type", type);
			}
		}

		if (partialContent) {
			headers_.emplace_back("Content-Range", HttpUtil::formatPartialRange(startPos, endPos, fileSize));
			headers_.emplace_back("Accept-Ranges", "bytes");
			return http::status::partial_content;
		}

		return http::status::ok;
	}

	// Four decimal labels of at most three digits each, none above 255 -- the only IPv4 spelling
	// the classifier below understands.
	static bool isDottedQuad(const string& aHost) noexcept {
		size_t pos = 0;
		for (size_t i = 0; i < 4; ++i) {
			const auto isLast = (i == 3);
			auto dot = aHost.find('.', pos);
			if (isLast) {
				if (dot != string::npos) return false;
				dot = aHost.size();
			} else if (dot == string::npos) {
				return false;
			}

			const auto labelLen = dot - pos;
			if (labelLen == 0 || labelLen > 3) return false;

			uint32_t value = 0;
			for (size_t j = pos; j < dot; ++j) {
				const auto c = aHost[j];
				if (c < '0' || c > '9') return false;
				value = value * 10 + static_cast<uint32_t>(c - '0');
			}

			if (value > 255) return false;
			pos = dot + 1;
		}

		return true;
	}

	// Returns true if the textual host is a literal IP that belongs to a
	// private, loopback, link-local or otherwise non-routable/reserved range.
	// Returns false for non-literal hostnames (we can't resolve them here without
	// risking a TOCTOU bypass; those are accepted at this layer) and for public IPs.
	static bool isBlockedProxyHost(const string& aHost) noexcept {
		if (aHost.empty()) {
			return true;
		}

		// Well-known loopback NAMES. Everything below classifies numeric literals, and every
		// non-literal fell through as "hostname -> not blocked" -- so "localhost" sailed past a
		// guard whose whole purpose is to stop the server fetching its own internal services.
		// ExtensionApi's equivalent guard rejects it explicitly; this one did not.
		//
		// Deliberately NOT complete: any DNS name the requester controls can be pointed at
		// 127.0.0.1 or an internal address, and even resolving here and re-checking would still
		// leave a rebinding window between the check and the connect. Closing that properly
		// means resolving once and connecting to the address that was checked. This only removes
		// the trivial bypass.
		{
			auto lower = Text::toLower(aHost);
			if (lower == "localhost" || lower == "localhost.localdomain" ||
				lower == "ip6-localhost" || lower == "ip6-loopback" ||
				lower.ends_with(".localhost")) {
				return true;
			}
		}

		// IPv6 literal (decodeUrl strips the surrounding brackets)
		if (aHost.find(':') != string::npos) {
			auto host = Text::toLower(aHost);

			// Strip a possible zone index (e.g. fe80::1%eth0)
			auto zone = host.find('%');
			if (zone != string::npos) {
				host = host.substr(0, zone);
			}

			// Parse as an IPv6 literal so every textual form (abbreviated, hex,
			// ::ffff:a.b.c.d, ::ffff:7f00:1, etc.) is classified numerically.
			boost::system::error_code ec;
			auto v6 = boost::asio::ip::make_address_v6(host, ec);
			if (ec) {
				return false; // not a parseable IPv6 literal -> treat as hostname (not blocked here)
			}

			if (v6.is_loopback() || v6.is_unspecified() || v6.is_multicast() ||
				v6.is_link_local() || v6.is_site_local()) {
				return true;
			}

			// IPv4-mapped (::ffff:a.b.c.d) -> classify the embedded IPv4 numerically
			if (v6.is_v4_mapped()) {
				return isBlockedProxyHost(boost::asio::ip::make_address_v4(boost::asio::ip::v4_mapped, v6).to_string());
			}

			// Unique-local fc00::/7
			const auto bytes = v6.to_bytes();
			if ((bytes[0] & 0xFE) == 0xFC) {
				return true;
			}

			return false;
		}

		// A host made only of digits and dots, or written in hex, is never a DNS name: the resolver
		// reads it numerically, and inet_aton-style parsing accepts octal ("0177.0.0.1"), hex
		// ("0x7f.0.0.1") and short forms ("127.1", "2130706433") -- every one of which names an
		// address this guard exists to block while looking nothing like a dotted quad. Treating
		// them as hostnames and letting them through is the bypass. Checked before the dotted-quad
		// parse below so a well-formed quad still reaches the classifier, and restricted to
		// digits/dots or an explicit 0x so a domain that happens to be spelled with hex letters
		// ("abc.def") is not caught.
		{
			const auto lower = Text::toLower(aHost);
			const auto digitsAndDots = lower.find_first_not_of("0123456789.") == string::npos;
			const auto looksHex = lower.starts_with("0x") || lower.find(".0x") != string::npos;
			if ((digitsAndDots || looksHex) && !isDottedQuad(aHost)) {
				return true;
			}
		}

		// IPv4 literal: only treat it as an IP if it is a dotted quad of decimals.
		// Anything else is considered a hostname (not blocked at this layer).
		uint32_t octets[4];
		{
			size_t pos = 0;
			for (size_t i = 0; i < 4; ++i) {
				bool isLast = (i == 3);
				auto dot = aHost.find('.', pos);

				if (isLast) {
					if (dot != string::npos) {
						return false; // extra label(s) after the 4th octet -> hostname
					}
					dot = aHost.size();
				} else if (dot == string::npos) {
					return false; // fewer than 4 labels -> hostname
				}

				auto labelLen = dot - pos;
				if (labelLen == 0 || labelLen > 3) {
					return false; // not a valid IPv4 literal -> hostname
				}

				uint32_t value = 0;
				for (size_t j = pos; j < dot; ++j) {
					auto c = aHost[j];
					if (c < '0' || c > '9') {
						return false; // contains non-digits -> hostname
					}
					value = value * 10 + static_cast<uint32_t>(c - '0');
				}

				if (value > 255) {
					return false;
				}

				octets[i] = value;
				pos = dot + 1;
			}
		}

		auto a = octets[0], b = octets[1];

		// 0.0.0.0/8 (this network / unspecified)
		if (a == 0) return true;
		// 10.0.0.0/8 (private)
		if (a == 10) return true;
		// 127.0.0.0/8 (loopback)
		if (a == 127) return true;
		// 169.254.0.0/16 (link-local)
		if (a == 169 && b == 254) return true;
		// 172.16.0.0/12 (private)
		if (a == 172 && b >= 16 && b <= 31) return true;
		// 192.168.0.0/16 (private)
		if (a == 192 && b == 168) return true;
		// 100.64.0.0/10 (carrier-grade NAT)
		if (a == 100 && b >= 64 && b <= 127) return true;
		// 192.0.0.0/24 (IETF protocol assignments)
		if (a == 192 && b == 0 && octets[2] == 0) return true;
		// 198.18.0.0/15 (benchmarking)
		if (a == 198 && (b == 18 || b == 19)) return true;
		// 224.0.0.0/4 (multicast) and 240.0.0.0/4 (reserved) and 255.255.255.255
		if (a >= 224) return true;

		return false;
	}

	// Validates that a proxy target URL is safe to fetch: must use http/https and
	// must not resolve to a private/loopback/link-local literal IP (SSRF guard).
	static bool isAllowedProxyUrl(const string& aUrl) noexcept {
		string protocol, host, port, path, query, fragment;
		LinkUtil::decodeUrl(aUrl, protocol, host, port, path, query, fragment);

		auto scheme = Text::toLower(protocol);
		if (scheme != "http" && scheme != "https") {
			return false;
		}

		if (host.empty()) {
			return false;
		}

		if (isBlockedProxyHost(host)) {
			return false;
		}

		return true;
	}

	http::status FileServer::handleProxyDownload(const string& aRequestUrl, string& output_, const FileDeferredHandler& aDeferF) noexcept {
		string protocol, host, port, path, query, fragment;
		LinkUtil::decodeUrl(aRequestUrl, protocol, host, port, path, query, fragment);

		// Parse query
		auto proxyUrlEscaped = LinkUtil::decodeQuery(query)["url"];
		if (proxyUrlEscaped.empty()) {
			output_ = "Proxy URL missing";
			return http::status::bad_request;
		}

		// Decode URL
		string proxyUrl;
		if (!HttpUtil::unescapeUrl(proxyUrlEscaped, proxyUrl)) {
			output_ = "Invalid URL " + proxyUrlEscaped;
			return http::status::bad_request;
		}

		// SSRF guard: only allow http/https targets and reject literal
		// private/loopback/link-local/reserved IP addresses.
		if (!isAllowedProxyUrl(proxyUrl)) {
			output_ = "The requested proxy URL is not allowed";
			return http::status::forbidden;
		}

		// What comes back is handed to the browser as if it were ours, and the web UI decides
		// which extension tarball to install from one of these documents, so an https target
		// must present a chain the OS trusts (the default skips that check for legacy reasons).
		// Capped as well: the proxy exists for catalogs and feeds, not for bulk transfers.
		HttpOptions proxyOptions;
		proxyOptions.setAllowUntrusted(false);
		proxyOptions.setMaxBodySize(MAX_PROXY_BODY_SIZE);
		// Same reasoning as the extension download: the caller picks the URL, so every hop has
		// to stay off this machine's own network, not just the first one.
		proxyOptions.setPublicDestinationsOnly(true);

		// Reserve a unique download id atomically (see proxyDownloadCounter)
		auto downloadId = proxyDownloadCounter.fetch_add(1);
		auto download = std::make_shared<HttpDownload>(
			proxyUrl,
			[this, downloadId, completionHandler = aDeferF()]() {
				onProxyDownloadCompleted(downloadId, completionHandler);
			},
			proxyOptions
		);

		{
			WLock l(cs);
			proxyDownloads.try_emplace(downloadId, download);
		}

		// HttpDownload no longer starts itself in the constructor; the owner must do it
		// once the object is stored where the completion handler can find it. Without
		// this the transfer never begins, so the deferred response never completes: the
		// request leaks a connection and stop() then spins forever waiting for
		// proxyDownloads to drain. Started outside the lock because a fast failure can
		// invoke the completion synchronously, which re-enters cs.
		download->start();

		return http::status::accepted;
	}

	static StringSet forwardedProxyHeaders = { "content-type", "content-encoding", "etag", "expires", "last-modified", "date", "vary" };

	void FileServer::onProxyDownloadCompleted(int64_t aDownloadId, const HTTPFileCompletionF& aCompletionF) noexcept {
		ScopedFunctor([&] {
			WLock l(cs);
			proxyDownloads.erase(aDownloadId);
		});

		shared_ptr<HttpDownload> d = nullptr;

		{
			RLock l(cs);
			auto i = proxyDownloads.find(aDownloadId);
			if (i != proxyDownloads.end()) {
				d = i->second;
			}
		}

		dcassert(d);
		if (d) {
			if (d->buf.empty()) {
				http::status statusCode;
				string statusText;
				if (HttpUtil::parseStatus(d->status, statusCode, statusText)) {
					aCompletionF(statusCode, statusText, StringPairList());
				} else {
					aCompletionF(http::status::not_acceptable, d->status, StringPairList());
				}
			} else {
				StringPairList headers;
				for (const auto& [name, value] : d->headers) {
					if (forwardedProxyHeaders.contains(Text::toLower(name))) {
						headers.push_back({ name, value });
					}
				}

				HttpUtil::addCacheControlHeader(headers, 0);
				aCompletionF(http::status::ok, d->buf, headers);
			}
		}
	}

	void FileServer::stop() noexcept {
		// Bounded. A stalled download -- a server that accepts the connection and then sends
		// nothing -- never completes, and this loop had no timeout and nothing that could abort it,
		// so shutdown hung for as long as that peer chose. After a grace period the downloads are
		// dropped instead: ~HttpDownload removes itself as a listener, so a connection still in
		// flight completes into nothing and self-deletes, and the completion handler that captures
		// `this` dies with the map entry.
		static const int SHUTDOWN_GRACE_MS = 5000;
		for (int waited = 0; waited < SHUTDOWN_GRACE_MS; waited += 50) {
			{
				RLock l(cs);
				if (proxyDownloads.empty()) {
					return;
				}
			}

			Thread::sleep(50);
		}

		{
			WLock l(cs);
			proxyDownloads.clear();
		}
	}
}