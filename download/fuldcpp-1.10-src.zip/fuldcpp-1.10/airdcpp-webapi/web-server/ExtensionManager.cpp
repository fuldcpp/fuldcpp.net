/*
* Copyright (C) 2011-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <web-server/ExtensionManager.h>
#include <web-server/Extension.h>
#include <web-server/NpmRepository.h>
#include <web-server/Session.h>
#include <web-server/SocketManager.h>
#include <web-server/TarFile.h>
#include <web-server/WebServerManager.h>
#include <web-server/WebServerSettings.h>
#include <web-server/WebSocket.h>

#include <airdcpp/util/CryptoUtil.h>
#include <airdcpp/hash/value/Encoder.h>
#include <airdcpp/core/classes/Exception.h>
#include <airdcpp/core/io/File.h>
#include <airdcpp/connection/http/HttpDownload.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/core/classes/ScopedFunctor.h>
#include <airdcpp/core/io/xml/SimpleXML.h>
#include <airdcpp/util/text/StringTokenizer.h>
#include <airdcpp/util/SystemUtil.h>
#include <airdcpp/core/thread/Thread.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/core/update/UpdateManager.h>
#include <airdcpp/core/io/compress/ZUtils.h>

#ifndef _WIN32
#include <cstdlib>
#include <sys/stat.h>
#include <unistd.h>
#endif


namespace webserver {
	namespace {
		// Where the installer keeps its intermediate files. On Windows the temp directory is
		// already per instance under the user's profile. On POSIX it is /tmp, shared with every
		// local user, and the file primitives follow symlinks: a pre-planted link under a
		// guessable name would redirect the decompressed tar, the extraction or the cleanup.
		// A private directory with a random name (mkdtemp, mode 0700) closes that; it is
		// created once per process and removed again when the manager goes away
		const string& getStagingDirectory() noexcept {
			static const string directory = []() -> string {
				const auto shared = AppUtil::getPath(AppUtil::PATH_TEMP);
#ifdef _WIN32
				return shared;
#else
				string templ = shared + "airdcpp-extensions-XXXXXX";
				if (!::mkdtemp(templ.data())) {
					return shared;
				}

				return templ + PATH_SEPARATOR_STR;
#endif
			}();

			return directory;
		}
	}

	ExtensionManager::ExtensionManager(WebServerManager* aWsm) : wsm(aWsm) {
		wsm->addListener(this);
		wsm->getSocketManager().addListener(this);

		npmRepository = make_unique<NpmRepository>(
			std::bind_front(&ExtensionManager::downloadExtension, this),
			std::bind_front(&ExtensionManager::log, this)
		);
	}

	ExtensionManager::~ExtensionManager() {
		wsm->getSocketManager().removeListener(this);
		wsm->removeListener(this);

#ifndef _WIN32
		// Empty by now: every installation cleans up after itself
		if (getStagingDirectory() != AppUtil::getPath(AppUtil::PATH_TEMP)) {
			::rmdir(getStagingDirectory().c_str());
		}
#endif
	}

	void ExtensionManager::log(const string& aMsg, LogMessage::Severity aSeverity) const noexcept {
		LogManager::getInstance()->message(aMsg, aSeverity, STRING(EXTENSIONS));
	}

	void ExtensionManager::on(WebServerManagerListener::Started) noexcept {
		wsm->getSocketManager().addListener(this);

		// Don't add in the constructor as core may not have been initialized at that point
		UpdateManager::getInstance()->addListener(this);

		load();
		fire(ExtensionManagerListener::Started());
	}

	void ExtensionManager::on(WebServerManagerListener::Stopping) noexcept {
		if (updateCheckTask) {
			updateCheckTask->stop(true);
		}

		{
			RLock l(cs);
			for (const auto& ext: extensions) {
				ext->removeListeners();

				if (!ext->isManaged()) {
					// Handle unmanaged extensions in WebServerManagerListener::Stopped (they could still connect at this point as the server is running)
					continue;
				}
				
				// Managed extensions can't be started again after this
				try {
					ext->stopThrow();
				} catch (const Exception& e) {
					log(STRING_F(WEB_EXTENSION_STOP_FAILED, ext->getName() % e.what()), LogMessage::SEV_ERROR);
				}
			}
		}

		wsm->getSocketManager().removeListener(this);

		UpdateManager::getInstance()->removeListener(this);
		fire(ExtensionManagerListener::Stopped());
	}

	void ExtensionManager::on(WebServerManagerListener::Stopped) noexcept {
		// Bounded. A stalled download -- a server that accepts the connection and then sends
		// nothing -- never completes, and this loop had no timeout and nothing that could abort it,
		// so shutdown hung for as long as that peer chose. After a grace period the downloads are
		// dropped instead: ~HttpDownload removes itself as a listener, so a connection still in
		// flight completes into nothing and self-deletes, and the completion handler that captures
		// `this` dies with the map entry.
		static const int SHUTDOWN_GRACE_MS = 5000;
		for (int waited = 0; waited < SHUTDOWN_GRACE_MS; waited += 50) {
			{
				// Installations in progress push into the extension list cleared below
				RLock l(cs);
				if (httpDownloads.empty() && localInstalls.empty()) {
					break;
				}
			}

			Thread::sleep(50);
		}

		{
			WLock l(cs);
			httpDownloads.clear();
		}

		ExtensionList unmanagedExtensions;
		{
			RLock l(cs);
			ranges::copy_if(extensions, back_inserter(unmanagedExtensions), [](const ExtensionPtr& e) { return !e->isManaged(); });
		}

		for (const auto& e: unmanagedExtensions) {
			unregisterRemoteExtension(e);
		}

		WLock l(cs);
		dcassert(ranges::all_of(extensions, [](const ExtensionPtr& aExtension) { return !aExtension->getSession(); }));
		extensions.clear();
	}

	void ExtensionManager::on(SocketManagerListener::SocketDisconnected, const WebSocketPtr& aSocket) noexcept {
		if (!aSocket->getSession()) {
			return;
		}

		aSocket->getSession()->getServer()->addAsyncTask([session = aSocket->getSession(), this] {
			ExtensionPtr extension = nullptr;

			// Remove possible unmanaged extensions matching this session
			{
				RLock l(cs);
				auto i = ranges::find_if(extensions, [&](const ExtensionPtr& aExtension) {
					return aExtension->getSession() == session;
				});

				if (i == extensions.end() || (*i)->isManaged()) {
					return;
				}

				extension = *i;
			}

			unregisterRemoteExtension(extension);
		});
	}

	void ExtensionManager::on(UpdateManagerListener::VersionFileDownloaded, SimpleXML& xml) noexcept {
		if (WEBCFG(EXTENSIONS_AUTO_UPDATE).boolean()) {
			// Wait 10 seconds so that the extensions aren't updated right after they were started
			// (stopping the extensions may fail in such case)
			updateCheckTask = wsm->addTimer([this] {
				checkExtensionUpdates();

				updateCheckTask->stop(true);
				wsm->addAsyncTask([this] {
					updateCheckTask.reset();
				});
			}, 10000);

			updateCheckTask->start(false);
		}

		try {
			xml.resetCurrentChild();
			if (xml.findChild("BlockedExtensions")) {
				xml.stepIn();

				while (xml.findChild("BlockedExtension")) {
					const auto& reason = xml.getChildAttrib("Reason");

					xml.stepIn();
					const auto& name = xml.getData();
					xml.stepOut();

					{
						WLock l(cs);
						blockedExtensions.try_emplace(name, reason);
					}
				}

				xml.stepOut();
			}
		} catch (const SimpleXMLException& e) {
			log("Failed to read blocked extensions: " + e.getError(), LogMessage::SEV_ERROR);
		}

		uninstallBlockedExtensions();
	}

	void ExtensionManager::uninstallBlockedExtensions() noexcept {
		vector<pair<ExtensionPtr, string>> toRemove;

		{
			RLock l(cs);
			for (const auto& e : extensions) {
				auto i = blockedExtensions.find(e->getName());
				if (i != blockedExtensions.end()) {
					toRemove.emplace_back(e, i->second);
				}
			}
		}

		for (const auto& [ext, message] : toRemove) {
			try {
				log(STRING_F(WEB_EXTENSION_UNINSTALL_BLOCKED, ext->getName() % message), LogMessage::SEV_WARNING);
				uninstallLocalExtensionThrow(ext, true);
			} catch (const Exception& e) {
				log(e.what(), LogMessage::SEV_ERROR);
			}
		}
	}

	void ExtensionManager::load() noexcept {
		auto directories = File::findFiles(EXTENSION_DIR_ROOT, "*", File::TYPE_DIRECTORY);
		auto engines = getEngines();

		int started = 0;
		for (const auto& path : directories) {
			auto ext = loadLocalExtension(path);
			if (ext && !ext->isDisabled() && startExtensionImpl(ext, engines)) {
				started++;
			}
		}

		if (started > 0) {
			auto isDebug = WEBCFG(EXTENSIONS_DEBUG_MODE).boolean();
			auto message = STRING_F(X_EXTENSIONS_LOADED, started);
			log(isDebug ? STRING_F(X_DEBUG_MODE, message) : message, LogMessage::SEV_INFO);
		}
	}

	void ExtensionManager::checkExtensionUpdates() const noexcept {
		RLock l(cs);

		for (const auto& ext : extensions) {
			if (!ext->isManaged() || ext->isPrivate()) {
				continue;
			}

			npmRepository->checkUpdates(ext->getName(), ext->getVersion());
		}
	}

	bool ExtensionManager::waitLoaded() const noexcept {
		const auto timeout = GET_TICK() + (WEBCFG(EXTENSIONS_INIT_TIMEOUT).num() * 1000);
		const auto isReady = [](const ExtensionPtr& aExt) {
			return !aExt->isRunning() || !aExt->getSignalReady() || aExt->getReady();
		};

		while (GET_TICK() < timeout) {
			{
				RLock l(cs);
				if (ranges::all_of(extensions, isReady)) {
					return true;
				}
			}

			Thread::sleep(50);
		}

		{
			RLock l(cs);
			for (const auto& ext: extensions) {
				if (!isReady(ext)) {
					log(STRING_F(WEB_EXTENSION_INIT_TIMED_OUT, ext->getName()), LogMessage::SEV_WARNING);
				}
			}
		}

		return false;
	}

	ExtensionList ExtensionManager::getExtensions() const noexcept {
		RLock l(cs);
		return extensions;
	}

	void ExtensionManager::unregisterRemoteExtension(const ExtensionPtr& aExtension) noexcept {
		dcassert(!aExtension->isManaged());
		aExtension->resetSession();
		removeExtension(aExtension);
	}

	bool ExtensionManager::removeExtension(const ExtensionPtr& aExtension) noexcept {
		{
			WLock l(cs);
			auto i = ranges::find(extensions, aExtension);
			if (i != extensions.end()) {
				extensions.erase(i);
			} else {
				dcassert(0);
				return false;
			}
		}

		aExtension->removeListener(this);
		fire(ExtensionManagerListener::ExtensionRemoved(), aExtension);
		return true;
	}

	void ExtensionManager::uninstallLocalExtensionThrow(const ExtensionPtr& aExtension, bool aForced) {
		dcassert(aExtension->isManaged());
		aExtension->removeListeners();

		// Stop running extensions
		try {
			aExtension->stopThrow();
		} catch (const Exception& e) {
			if (!aForced) {
				throw;
			}

			// Try to continue in any case...
			log(e.getError(), LogMessage::SEV_ERROR);
		}

		// Remove from disk
		File::removeDirectoryForced(aExtension->getRootPath());

		// Remove from list
		if (!removeExtension(aExtension)) {
			throw Exception("Extension was not found");
		}

		// removeExtension above already fired ExtensionRemoved. Firing it a second time here sent
		// every listener two removals for one uninstall -- the web API relays it as an
		// extension_removed event, so clients saw the extension disappear twice, and any listener
		// that decrements a count or erases by value on the first one was handed an object that was
		// already gone on the second.
		log(STRING_F(WEB_EXTENSION_UNINSTALLED, aExtension->getName()), LogMessage::SEV_INFO);
	}

	ExtensionPtr ExtensionManager::getExtension(const string& aName) const noexcept {
		RLock l(cs);
		auto i = find(extensions.begin(), extensions.end(), aName);
		return i == extensions.end() ? nullptr : *i;
	}

	bool ExtensionManager::downloadExtension(const string& aInstallId, const string& aUrl, const string& aSha1, const string& aIntegrity) noexcept {
		fire(ExtensionManagerListener::InstallationStarted(), aInstallId);

		// This is a package that will be RUN as a node or python process once unpacked, and the
		// SHA-1 is optional, so a substituted tarball on an https URL is executed with no further
		// check. Default HttpOptions means allowUntrusted = true and no body cap, i.e. any
		// certificate and any length -- while the two siblings that fetch far less dangerous things,
		// the npm index and the web-UI proxy, were both hardened. The catalogue URL comes from a
		// setting, so it is not necessarily one we control.
		HttpOptions options;
		options.setAllowUntrusted(false);
		options.setMaxBodySize(64 * 1024 * 1024);
		// The URL is chosen by whoever called the API, so the transfer must not be usable to
		// reach this machine's own services. The API validates the URL it is given; this covers
		// the redirects underneath it, which that check cannot see.
		options.setPublicDestinationsOnly(true);

		shared_ptr<HttpDownload> download;
		bool added = false;

		{
			WLock l(cs);
			auto [pos, added_] = httpDownloads.try_emplace(aUrl, make_shared<HttpDownload>(aUrl, [aInstallId, aUrl, aSha1, aIntegrity, this]() {
				onExtensionDownloadCompleted(aInstallId, aUrl, aSha1, aIntegrity);
			}, options));

			added = added_;
			if (added) {
				download = pos->second;
			}
		}

		// The owner must start the transfer once the object is stored where the completion
		// handler can find it; the constructor no longer does it. Started after releasing
		// cs because a fast failure can run the completion synchronously, and that path
		// takes cs again.
		if (download) {
			download->start();
		}

		return added;
	}

	// npm publishes dist.integrity in Subresource Integrity form: one or more whitespace-separated
	// "<algorithm>-<base64 digest>" values, any one of which matching is enough. The catalogue
	// carries it for every package and this client ignored it entirely, checking only the SHA-1
	// shasum beside it -- and SHA-1 has been collision-broken for years, while what arrives here is
	// unpacked and RUN as a node or python process.
	//
	// A value we cannot check is refused rather than waved through. Falling back to the weaker
	// digest on an integrity we do not understand would mean the strongest thing the repository
	// published is also the easiest to neutralise: publish nonsense and the check downgrades
	// itself. A package whose integrity cannot be verified is exactly the one not to execute.
	bool ExtensionManager::validateIntegrity(const string& aData, const string& aIntegrity) noexcept {
		if (aIntegrity.empty()) {
			// Nothing published to check. The shasum, when there is one, still has to match; an
			// install started from a bare URL deliberately carries neither.
			return true;
		}

		static const string sha512Prefix = "sha512-";
		string calculated;

		for (size_t pos = 0; pos < aIntegrity.size();) {
			const auto start = aIntegrity.find_first_not_of(" \t", pos);
			if (start == string::npos) {
				break;
			}

			auto end = aIntegrity.find_first_of(" \t", start);
			if (end == string::npos) {
				end = aIntegrity.size();
			}

			pos = end;

			const auto token = aIntegrity.substr(start, end - start);
			if (!token.starts_with(sha512Prefix)) {
				continue;
			}

			// Computed at most once, however many values are listed.
			if (calculated.empty()) {
				calculated = CryptoUtil::calculateSha512Base64(aData);
				if (calculated.empty()) {
					return false;
				}
			}

			// SRI permits "?options" after the digest. Nothing publishes them, and comparing the
			// whole remainder leaves such a value failing rather than half-understood.
			if (token.compare(sha512Prefix.size(), string::npos, calculated) == 0) {
				return true;
			}
		}

		// Either every value named an algorithm this does not implement, or a sha512 was published
		// and the package does not match it. Both are refusals.
		return false;
	}

	bool ExtensionManager::validateSha1(const string& aData, const string& aSha1) noexcept {
		if (aSha1.empty()) {
			return true;
		}

		auto calculatedSha1 = CryptoUtil::calculateSha1(aData);
		if (calculatedSha1) {
			// Each byte is formatted into a buffer of its own. Writing into the middle of one
			// shared buffer while passing that buffer's FULL size is a size argument that is
			// wrong from the second byte onwards - larger than what is actually left from the
			// offset. Nothing overflows here in practice, but a hardened runtime does not wait
			// for that: on the POSIX daemon glibc's _FORTIFY_SOURCE aborted the process for
			// every download that carried a checksum, which is every catalog install and every
			// automatic extension update.
			string calculated;
			calculated.reserve(SHA_DIGEST_LENGTH * 2);
			for (const auto byte: *calculatedSha1) {
				char hex[3];
				snprintf(hex, sizeof(hex), "%02x", byte);
				calculated += hex;
			}

			// The calculated checksum is lowercase hex; compare case-insensitively
			// so that an uppercase (or mixed-case) expected checksum still matches
			if (Util::stricmp(calculated, aSha1) == 0) {
				return true;
			}
		}

		return false;
	}

	void ExtensionManager::onExtensionDownloadCompleted(const string& aInstallId, const string& aUrl, const string& aSha1, const string& aIntegrity) noexcept {
		auto tempFile = getTempStagingPath(getPackageFileName(aUrl)) + ".tmp";

		// Don't allow the same download to be initiated again until the installation has finished
		ScopedFunctor([&]() {
			File::deleteFile(tempFile);

			WLock l(cs);
			httpDownloads.erase(aUrl);
		});

		{
			HttpDownloadMap::mapped_type download = nullptr;

			// Get the download
			{
				WLock l(cs);
				auto i = httpDownloads.find(aUrl);
				if (i == httpDownloads.end()) {
					dcassert(0);
					return;
				}

				download = i->second;
			}

			if (download->buf.empty()) {
				failInstallation(aInstallId, STRING(WEB_EXTENSION_DOWNLOAD_FAILED), download->status);
				return;
			}

			// Validate the possible checksums. Both must pass: the integrity is the stronger
			// statement, and a repository publishing one that disagrees with its own shasum is
			// not a package to unpack and run either way.
			if (!validateSha1(download->buf, aSha1) || !validateIntegrity(download->buf, aIntegrity)) {
				failInstallation(aInstallId, STRING(WEB_EXTENSION_DOWNLOAD_FAILED), STRING(WEB_EXTENSION_CHECKSUM_MISMATCH));
				return;
			}

			// Save on disk
			try {
				File(tempFile, File::WRITE, File::CREATE | File::TRUNCATE).write(download->buf);
			} catch (const FileException& e) {
				failInstallation(aInstallId, STRING(WEB_EXTENSION_PACKAGE_SAVE_FAILED), e.what());
				return;
			}
		}

		// Install
		installLocalExtension(aInstallId, tempFile);
	}

	string ExtensionManager::getTempStagingPath(const string& aFileName) noexcept {
		// A short, unique name. The whole download URL used to be the file name, which put the
		// temp extraction root (this name again, under "extension_") close to MAX_PATH: a package
		// with deeper paths inside then failed to extract with "path not found". The counter
		// keeps two installs of same-named packages apart within this process, the process id
		// keeps two instances sharing the temp directory apart.
		static std::atomic<uint64_t> installCounter { 0 };
#ifdef _WIN32
		const auto processId = static_cast<uint64_t>(::GetCurrentProcessId());
#else
		const auto processId = static_cast<uint64_t>(::getpid());
#endif
		return getStagingDirectory() + Util::toString(processId) + "_" + Util::toString(++installCounter) + "_" + PathUtil::validateFileName(aFileName);
	}

	string ExtensionManager::getPackageFileName(const string& aPath) noexcept {
		return PathUtil::getFileName(PathUtil::getAdcFileName(aPath));
	}

	void ExtensionManager::validateExtensionNameThrow(const string& aName) {
		if (aName.empty()) {
			throw Exception(STRING(WEB_EXTENSION_PACKAGE_MALFORMED_CONTENT));
		}

		// Reject anything that could escape the extension root when used as a directory name:
		// path separators, traversal sequences, absolute paths and (Windows) drive/UNC prefixes.
		if (aName == "." || aName == ".." ||
			aName.find('/') != string::npos ||
			aName.find('\\') != string::npos ||
			aName.find(':') != string::npos ||
			aName.find("..") != string::npos ||
			File::isAbsolutePath(aName)
		) {
			throw Exception(STRING(WEB_EXTENSION_PACKAGE_MALFORMED_CONTENT));
		}

		// Defense in depth: verify that the resolved root path actually stays inside the extension root
		const auto rootPath = Extension::getRootPath(aName);
		if (!PathUtil::isParentOrExactLocal(EXTENSION_DIR_ROOT, rootPath) ||
			PathUtil::isParentOrExactLocal(rootPath, EXTENSION_DIR_ROOT)
		) {
			throw Exception(STRING(WEB_EXTENSION_PACKAGE_MALFORMED_CONTENT));
		}
	}

	void ExtensionManager::installLocalExtension(const string& aInstallId, const string& aInstallFilePath) noexcept {
		// The package may be the user's own file, possibly on read-only media: every intermediate
		// file lives in the temp directory under a unique name, and nothing is written beside it
		const auto staging = getTempStagingPath(getPackageFileName(aInstallFilePath));
		string tarFile = staging + ".tar";
		ScopedFunctor([&tarFile]() {
			// Nothing to delete when the package could not be opened for decompression
			File::deleteFile(tarFile);
		});

		try {
			GZ::decompress(aInstallFilePath, tarFile);
		} catch (const Exception& e) {
			failInstallation(aInstallId, STRING(WEB_EXTENSION_PACKAGE_EXTRACT_FAILED), e.what());
			return;
		}

		string tempRoot = getStagingDirectory() + "extension_" + PathUtil::getFileName(staging) + PATH_SEPARATOR_STR;
		ScopedFunctor([&tempRoot]() {
			try {
				File::removeDirectoryForced(tempRoot);
			} catch (const FileException& e) {
				dcdebug("Failed to delete the temporary extension directory %s: %s\n", tempRoot.c_str(), e.getError().c_str());
			}
		});

		try {
			// Unpack the content to temp directory for validation purposes
			TarFile tar(tarFile);
			tar.extract(tempRoot);
		} catch (const Exception& e) {
			failInstallation(aInstallId, STRING(WEB_EXTENSION_PACKAGE_EXTRACT_FAILED), e.what());
			return;
		}

		// Parse the extension directory
		string tempPackageDirectory;
		{
			auto directories = File::findFiles(tempRoot, "*", File::TYPE_DIRECTORY);
			if (directories.size() != 1) {
				failInstallation(aInstallId, STRING(WEB_EXTENSION_PACKAGE_MALFORMED_CONTENT), "There should be a single directory directly inside the extension package");
				return;
			}

			tempPackageDirectory = directories.front();
		}


		string extensionName;
		try {
			// Validate the package content
			Extension extensionInfo(tempPackageDirectory, nullptr, true);

			extensionInfo.checkCompatibilityThrow();
			extensionName = extensionInfo.getName();
		} catch (const std::exception& e) {
			failInstallation(aInstallId, STRING(WEB_EXTENSION_LOAD_ERROR), e.what());
			return;
		}

		// Ensure the (attacker-controlled) package name can't be used to escape the extension
		// root directory when it's later passed to Extension::getRootPath()
		try {
			validateExtensionNameThrow(extensionName);
		} catch (const Exception& e) {
			failInstallation(aInstallId, STRING(WEB_EXTENSION_PACKAGE_MALFORMED_CONTENT), e.what());
			return;
		}

		// Check blocked extensions
		{
			RLock l(cs);
			auto i = blockedExtensions.find(extensionName);
			if (i != blockedExtensions.end()) {
				failInstallation(aInstallId, STRING(WEB_EXTENSION_INSTALL_BLOCKED), i->second);
				return;
			}
		}

		// Updating an existing extension?
		auto extension = getExtension(extensionName);
		auto wasStopped = false;
		if (extension) {
			wasStopped = !extension->isRunning();
			if (!extension->isManaged()) {
				failInstallation(aInstallId, STRING(WEB_EXTENSION_EXISTS), "Unmanaged extensions can't be upgraded");
				return;
			}

			// Stop and remove the old package
			try {
				extension->stopThrow();
			} catch (const Exception& e) {
				failInstallation(aInstallId, e.what(), Util::emptyString);
				return;
			}

			try {
				File::removeDirectoryForced(PathUtil::joinDirectory(extension->getRootPath(), EXT_PACKAGE_DIR));
			} catch (const FileException& e) {
				failInstallation(aInstallId, "Failed to remove the old extension package directory " + PathUtil::joinDirectory(extension->getRootPath(), EXT_PACKAGE_DIR), e.getError());
				return;
			}
		}

		try {
			// Move files to final destination directory
			File::moveDirectory(tempPackageDirectory, PathUtil::joinDirectory(Extension::getRootPath(extensionName), EXT_PACKAGE_DIR));
		} catch (const FileException& e) {
			failInstallation(aInstallId, "Failed to move extension files to the final destination directory", e.what());
			return;
		}

		bool updated = !!extension;
		if (updated) {
			// Updating
			try {
				extension->reloadThrow();
			} catch (const Exception& e) {
				// Shouldn't happen since the package has been validated earlier
				dcassert(0);
				failInstallation(aInstallId, "Failed to reload the updated extension package", e.what());
				return;
			}

			log(STRING_F(WEB_EXTENSION_UPDATED, extension->getName()), LogMessage::SEV_INFO);
		} else {
			// Install new
			extension = loadLocalExtension(Extension::getRootPath(extensionName));
			if (!extension) {
				// Shouldn't happen since the package has been validated earlier; the outcome is
				// still reported so that a waiting caller is not left without one
				dcassert(0);
				failInstallation(aInstallId, STRING(WEB_EXTENSION_LOAD_ERROR), Util::emptyString);
				return;
			}

			fire(ExtensionManagerListener::ExtensionAdded(), extension);
			log(STRING_F(WEB_EXTENSION_INSTALLED, extension->getName()), LogMessage::SEV_INFO);
		}

		if (!wasStopped) {
			startExtensionImpl(extension, getEngines());
		}

		fire(ExtensionManagerListener::InstallationSucceeded(), aInstallId, extension, updated);
	}

	// Only a plain file may be installed. A device or pipe path (Windows: the \\.\ and \\?\ forms,
	// or a device attribute) passes the existence check but blocks the decompressor for as long
	// as the other end cares to, and the installation is waited for on shutdown
	static bool isRegularFile(const string& aPath) noexcept {
#ifdef _WIN32
		const auto isSep = [](char c) { return c == '/' || c == '\\'; };
		if (aPath.size() >= 4 && isSep(aPath[0]) && isSep(aPath[1]) && (aPath[2] == '.' || aPath[2] == '?') && isSep(aPath[3])) {
			return false;
		}

		const auto attributes = ::GetFileAttributesW(Text::toT(aPath).c_str());
		return attributes != INVALID_FILE_ATTRIBUTES && !(attributes & (FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_DEVICE));
#else
		struct stat st;
		return ::stat(aPath.c_str(), &st) == 0 && S_ISREG(st.st_mode);
#endif
	}

	bool ExtensionManager::installExtensionFromFile(const string& aInstallId, const string& aPath) noexcept {
		{
			WLock l(cs);
			if (!localInstalls.insert(aInstallId).second) {
				return false;
			}
		}

		// Released only after the outcome has been reported, so the id stays busy until then
		ScopedFunctor([&]() {
			WLock l(cs);
			localInstalls.erase(aInstallId);
		});

		fire(ExtensionManagerListener::InstallationStarted(), aInstallId);

		// The id names the file already, and the outcome event reaches every subscriber, so
		// the path itself stays out of it
		if (!isRegularFile(aPath)) {
			failInstallation(aInstallId, STRING(FILE_NOT_FOUND), Util::emptyString);
			return true;
		}

		installLocalExtension(aInstallId, aPath);
		return true;
	}

	void ExtensionManager::failInstallation(const string& aInstallId, const string& aMessage, const string& aException) noexcept {
		auto msg = aMessage;
		if (!aException.empty()) {
			msg += " (" + aException + ")";
		}

		fire(ExtensionManagerListener::InstallationFailed(), aInstallId, msg);

		log(STRING_F(WEB_EXTENSION_INSTALLATION_FAILED, aInstallId % msg), LogMessage::SEV_ERROR);
	}

	ExtensionPtr ExtensionManager::registerRemoteExtensionThrow(const SessionPtr& aSession, const json& aPackageJson) {
		auto ext = std::make_shared<Extension>(aSession, aPackageJson);

		auto existing = getExtension(ext->getName());
		if (existing) {
			if (existing->isManaged()) {
				throw Exception(STRING(WEB_EXTENSION_EXISTS));
			}

			unregisterRemoteExtension(existing);
		}

		{
			WLock l(cs);
			extensions.push_back(ext);
		}

		ext->addListener(this);

		fire(ExtensionManagerListener::ExtensionAdded(), ext);
		return ext;
	}

	void ExtensionManager::onExtensionStateUpdated(const Extension* aExtension) noexcept {
		fire(ExtensionManagerListener::ExtensionStateUpdated(), aExtension);
	}


	void ExtensionManager::on(ExtensionListener::ExtensionStarted, const Extension* aExt) noexcept {
		onExtensionStateUpdated(aExt);
	}

	void ExtensionManager::on(ExtensionListener::ExtensionStopped, const Extension* aExt, bool /*aFailed*/) noexcept {
		onExtensionStateUpdated(aExt);
	}

	void ExtensionManager::on(ExtensionListener::SettingValuesUpdated, const Extension* aExt, const SettingValueMap&) noexcept {
		onExtensionStateUpdated(aExt);
	}

	void ExtensionManager::on(ExtensionListener::SettingDefinitionsUpdated, const Extension* aExt) noexcept {
		onExtensionStateUpdated(aExt);
	}

	void ExtensionManager::on(ExtensionListener::PackageUpdated, const Extension* aExt) noexcept {
		onExtensionStateUpdated(aExt);
	}

#define EXIT_CODE_TIMEOUT 124
#define EXIT_CODE_IO_ERROR 74
#define EXIT_CODE_TEMP_ERROR 75
	void ExtensionManager::onExtensionFailed(const Extension* aExtension, uint32_t aExitCode) noexcept {
		if (aExitCode == EXIT_CODE_TIMEOUT || aExitCode == EXIT_CODE_IO_ERROR || aExitCode == EXIT_CODE_TEMP_ERROR) {
			// Attempt to restart it (but outside of extension's timer thread)
			const auto& name = aExtension->getName();
			wsm->addAsyncTask([aExtension, name, this] {
				// Wait for the log file handles to get closed
				Thread::sleep(3000);

				auto extension = getExtension(name);
				if (extension && startExtensionImpl(extension, getEngines())) {
					log(STRING_F(WEB_EXTENSION_TIMED_OUT, aExtension->getName()), LogMessage::SEV_INFO);
				}
			});
		} else {
			if (WEBCFG(EXTENSIONS_DEBUG_MODE).boolean()) {
				log(
					"Extension " + aExtension->getName() + " exited with code " + Util::toString(aExitCode), 
					LogMessage::SEV_ERROR
				);
			}

			log(
				STRING_F(WEB_EXTENSION_EXITED, aExtension->getName() % aExtension->getErrorLogPath()),
				LogMessage::SEV_ERROR
			);
		 }
	}

	ExtensionPtr ExtensionManager::loadLocalExtension(const string& aPath) noexcept {
		// Parse
		ExtensionPtr ext = nullptr;
		try {
			ext = std::make_shared<Extension>(
				PathUtil::joinDirectory(aPath, EXT_PACKAGE_DIR),
				std::bind_front(&ExtensionManager::onExtensionFailed, this)
			);
		} catch (const Exception& e) {
			log(STRING_F(WEB_EXTENSION_LOAD_ERROR_X, aPath % e.what()), LogMessage::SEV_ERROR);
			return nullptr;
		}

		if (getExtension(ext->getName())) {
			dcassert(0);
			log(STRING_F(WEB_EXTENSION_LOAD_ERROR_X, aPath % STRING(WEB_EXTENSION_EXISTS)), LogMessage::SEV_ERROR);
			return nullptr;
		}

		// Store in the extension list
		{
			WLock l(cs);
			extensions.push_back(ext);
		}

		ext->addListener(this);
		return ext;
	}

	bool ExtensionManager::startExtensionImpl(const ExtensionPtr& aExtension, const ExtensionEngine::List& aInstalledEngines) noexcept {
		try {
			auto launchInfo = getStartCommandThrow(aExtension->getEngines(), aInstalledEngines);
			aExtension->startThrow(launchInfo.command, wsm, launchInfo.arguments);
		} catch (const Exception& e) {
			log(STRING_F(WEB_EXTENSION_START_ERROR, aExtension->getName() % e.what()), LogMessage::SEV_ERROR);
			return false;
		}

		return true;
	}

	ExtensionManager::ExtensionLaunchInfo ExtensionManager::getStartCommandThrow(const StringList& aSupportedExtEngines, const ExtensionEngine::List& aInstalledEngines) const {
		string lastError;
		for (const auto& supportedExtEngine: aSupportedExtEngines) {
			// Find an installed engine that can run this extension
			auto engineIter = ranges::find_if(aInstalledEngines, [&supportedExtEngine](const auto& e) { return e.name == supportedExtEngine; });
			if (engineIter == aInstalledEngines.end()) {
				lastError = STRING_F(WEB_EXTENSION_ENGINE_NO_CONFIG, supportedExtEngine);
				continue;
			}

			// We have a match, choose the correct command
			auto parsedCommand = selectEngineCommand(engineIter->command);
			if (!parsedCommand.empty()) {
				return { parsedCommand, engineIter->arguments };
			}

			lastError = STRING_F(WEB_EXTENSION_ENGINE_NOT_INSTALLED, supportedExtEngine % engineIter->command);
		}

		dcassert(!lastError.empty());
		throw Exception(lastError);
	}

	ExtensionEngine::List ExtensionManager::getEngines() const noexcept {
		return WEBCFG(EXTENSION_ENGINES).getValue().get<ExtensionEngine::List>();
	}

	string ExtensionManager::selectEngineCommand(const string& aEngineCommands) noexcept {
		auto tokens = StringTokenizer<string>(aEngineCommands, ';', false);
		for (const auto& token: tokens.getTokens()) {
			if (File::isAbsolutePath(token)) {
				// Full path
				if (PathUtil::fileExists(token)) {
					return token;
				}
			} else if (token.length() >= 2 && token.compare(0, 2, "./") == 0) {
				// Relative path
				auto fullPath = AppUtil::getAppFilePath() + token.substr(2);
				if (PathUtil::fileExists(fullPath)) {
					return fullPath;
				}
			} else {
				// Application in PATH
#ifdef _WIN32
				string testCommand = "where";
#else
				string testCommand = "command -v";
#endif
				testCommand += " " + token;

				if (dcpp::SystemUtil::runSystemCommand(testCommand) == 0) {
					return token;
				}
			}
		}

		return Util::emptyString;
	}
}