/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_WEBSERVER_QUEUE_MENU_PROVIDER_H
#define DCPLUSPLUS_WEBSERVER_QUEUE_MENU_PROVIDER_H

#include "forward.h"

#include "ContextMenuItem.h"
#include "ContextMenuManagerListener.h"

#include <airdcpp/forward.h>
#include <airdcpp/core/ActionHook.h>
#include <airdcpp/core/header/typedefs.h>

namespace webserver {

class ContextMenuManager;

// Exposes queue actions that have no dedicated API endpoints (recheck integrity,
// re-add sources, sequential order, timed pause, slow source disconnecting)
// in the Web UI context menus via the native context menu hooks
class QueueMenuProvider : private ContextMenuManagerListener {
public:
	explicit QueueMenuProvider(ContextMenuManager& aMenuManager);
	~QueueMenuProvider() override;

private:
	using MenuItemResultGetter = ActionHookResultGetter<GroupedContextMenuItemPtr>;

	GroupedContextMenuItemPtr getBundleMenu() const noexcept;
	GroupedContextMenuItemPtr getFileMenu() const noexcept;
	ContextMenuItemPtr toItem(const string& aId, const string& aTitle, const ExtensionSettingItem::List& aFormFields = ExtensionSettingItem::List()) const noexcept;

	static bool hasQueueEditAccess(const AccessList& aAccess) noexcept;

	void on(QueueBundleMenuSelected, const vector<QueueToken>&, const ContextMenuItemClickData&) noexcept override;
	void on(QueueFileMenuSelected, const vector<QueueToken>&, const ContextMenuItemClickData&) noexcept override;

	ContextMenuManager& cmm;
	const ActionHookSubscriber subscriber;
};

} // namespace webserver

#endif // DCPLUSPLUS_WEBSERVER_QUEUE_MENU_PROVIDER_H
