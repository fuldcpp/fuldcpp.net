/*
* Copyright (C) 2011-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_WEBSERVER_TARFILE_H
#define DCPLUSPLUS_WEBSERVER_TARFILE_H

#include "forward.h"

#include <microtar/microtar.h>

namespace webserver {
	class TarFile {
	public:
		TarFile(const string& aPath);
		~TarFile();

		void extract(const string& aDestPath);
	private:
		// Returns the validated, containment-checked destination path for a tar entry,
		// or an empty string if the entry name would escape the destination root.
		static string getSafeDestinationPath(const string& aDestPath, const string& aEntryName) noexcept;

		mtar_t tar;
		const string path;
		// Taken once when the archive is opened: an entry larger than the whole archive lies
		const int64_t archiveSize;
	};
}

#endif
