/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include "UserCommandMenuProvider.h"

#include "ContextMenuManager.h"

#include <airdcpp/core/classes/Magnet.h>
#include <airdcpp/filelist/DirectoryListing.h>
#include <airdcpp/filelist/DirectoryListingDirectory.h>
#include <airdcpp/hub/Client.h>
#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/hub/user_command/UserCommandManager.h>
#include <airdcpp/search/GroupedSearchResult.h>
#include <airdcpp/search/SearchInstance.h>
#include <airdcpp/user/OnlineUser.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/Util.h>

namespace webserver {

	static const string HOOK_ID = "user_commands";
	static const string LEAF_ID_PREFIX = "uc_";

	// Keep in line with MAX_MENU_NESTING in MenuApi; deeper paths are flattened into the leaf title
	static const size_t MAX_MENU_DEPTH = 6;

	UserCommandMenuProvider::UserCommandMenuProvider(ContextMenuManager& aMenuManager) :
		cmm(aMenuManager), subscriber(HOOK_ID, "User commands", nullptr)
	{
		auto added = cmm.hubUserMenuHook.addSubscriber(
			ActionHookSubscriber(subscriber),
			[this](const vector<dcpp::SID>&, const ContextMenuItemListData& aListData, const ClientPtr& aClient, const MenuItemResultGetter& aResultGetter) {
				return getHookResult(aResultGetter, aListData, UserCommand::CONTEXT_USER, aClient ? StringList({ aClient->getHubUrl() }) : StringList());
			}
		);
		dcassert(added);

		// Menus opened with multiple hubs selected list the commands of the first hub only;
		// clicks are still validated per target hub
		added = cmm.hubMenuHook.addSubscriber(
			ActionHookSubscriber(subscriber),
			[this](const vector<ClientToken>& aTokens, const ContextMenuItemListData& aListData, const MenuItemResultGetter& aResultGetter) {
				auto client = aTokens.empty() ? ClientPtr(nullptr) : ClientManager::getInstance()->findClient(aTokens.front());
				return getHookResult(aResultGetter, aListData, UserCommand::CONTEXT_HUB, client ? StringList({ client->getHubUrl() }) : StringList());
			}
		);
		dcassert(added);

		added = cmm.groupedSearchResultMenuHook.addSubscriber(
			ActionHookSubscriber(subscriber),
			[this](const vector<TTHValue>& aResults, const ContextMenuItemListData& aListData, const SearchInstancePtr& aInstance, const MenuItemResultGetter& aResultGetter) {
				return getHookResult(aResultGetter, aListData, UserCommand::CONTEXT_SEARCH, getSearchResultHubs(aResults, aInstance));
			}
		);
		dcassert(added);

		added = cmm.filelistItemMenuHook.addSubscriber(
			ActionHookSubscriber(subscriber),
			[this](const vector<DirectoryListingItemToken>&, const ContextMenuItemListData& aListData, const DirectoryListingPtr& aList, const MenuItemResultGetter& aResultGetter) {
				return getHookResult(aResultGetter, aListData, UserCommand::CONTEXT_FILELIST, aList ? ClientManager::getInstance()->getHubUrls(aList->getUser()) : StringList());
			}
		);
		dcassert(added);

		cmm.addListener(this);
	}

	UserCommandMenuProvider::~UserCommandMenuProvider() {
		cmm.removeListener(this);
		cmm.hubUserMenuHook.removeSubscriber(subscriber.getId());
		cmm.hubMenuHook.removeSubscriber(subscriber.getId());
		cmm.groupedSearchResultMenuHook.removeSubscriber(subscriber.getId());
		cmm.filelistItemMenuHook.removeSubscriber(subscriber.getId());
	}

	bool UserCommandMenuProvider::hasSendAccess(const AccessList& aAccess) noexcept {
		return ranges::any_of(aAccess, [](auto a) { return a == Access::HUBS_SEND || a == Access::ADMIN; });
	}

	StringList UserCommandMenuProvider::getSearchResultHubs(const vector<TTHValue>& aResults, const SearchInstancePtr& aInstance) noexcept {
		StringList hubs;
		if (!aInstance) {
			return hubs;
		}

		// Merge the hubs of all users so that op commands can be used in all of them (same as the desktop GUI)
		for (const auto& tth: aResults) {
			auto result = aInstance->getResult(tth);
			if (!result) {
				continue;
			}

			for (const auto& url: ClientManager::getInstance()->getHubUrls(result->getBaseUser().user->getCID())) {
				if (ranges::find(hubs, url) == hubs.end()) {
					hubs.push_back(url);
				}
			}
		}

		return hubs;
	}

	ActionHookResult<GroupedContextMenuItemPtr> UserCommandMenuProvider::getHookResult(const MenuItemResultGetter& aResultGetter, const ContextMenuItemListData& aListData, int aContext, const StringList& aHubs) const noexcept {
		if (!hasSendAccess(aListData.access)) {
			return ActionHookResult<GroupedContextMenuItemPtr>();
		}

		auto menu = getCommandMenu(aContext, aHubs);

		// Returning an empty result (no data, no error) omits the group without raising hook errors
		return menu ? aResultGetter.getData(menu) : ActionHookResult<GroupedContextMenuItemPtr>();
	}

	GroupedContextMenuItemPtr UserCommandMenuProvider::getCommandMenu(int aContext, const StringList& aHubs) const noexcept {
		if (aHubs.empty()) {
			return nullptr;
		}

		bool op = false;
		auto commands = UserCommandManager::getInstance()->getUserCommands(aContext, aHubs, op);

		// Separators can't be displayed in the Web UI menus
		vector<const UserCommand*> filtered;
		for (const auto& uc: commands) {
			if (uc.isRaw() || uc.isChat()) {
				filtered.push_back(&uc);
			}
		}

		auto items = buildMenuItems(filtered, 0);
		if (items.empty()) {
			return nullptr;
		}

		return std::make_shared<GroupedContextMenuItem>(subscriber.getId(), subscriber.getName(), StringMap(), items);
	}

	ContextMenuItemList UserCommandMenuProvider::buildMenuItems(const vector<const UserCommand*>& aCommands, size_t aPathLevel) const noexcept {
		struct Entry {
			const UserCommand* leaf = nullptr;
			string title;
			vector<const UserCommand*> folderCommands;
		};

		// Merge commands sharing a path segment into a single submenu while preserving the hub-sent order
		vector<Entry> entries;
		std::map<string, size_t> folderPositions;

		for (const auto* uc: aCommands) {
			const auto& path = uc->getDisplayName();
			if (path.empty() || path.size() <= aPathLevel) {
				continue;
			}

			if (path.size() == aPathLevel + 1 || aPathLevel + 1 >= MAX_MENU_DEPTH) {
				Entry e;
				e.leaf = uc;
				e.title = Util::toString(" / ", StringList(path.begin() + aPathLevel, path.end()));
				entries.push_back(std::move(e));
			} else {
				const auto& name = path[aPathLevel];
				auto p = folderPositions.find(name);
				if (p == folderPositions.end()) {
					folderPositions.emplace(name, entries.size());

					Entry e;
					e.title = name;
					e.folderCommands.push_back(uc);
					entries.push_back(std::move(e));
				} else {
					entries[p->second].folderCommands.push_back(uc);
				}
			}
		}

		ContextMenuItemList ret;
		for (const auto& e: entries) {
			if (e.leaf) {
				ret.push_back(toLeafItem(*e.leaf, e.title));
			} else {
				auto children = buildMenuItems(e.folderCommands, aPathLevel + 1);
				ret.push_back(std::make_shared<ContextMenuItem>(
					"folder_" + Util::toString(aPathLevel) + "_" + e.title, e.title,
					StringMap(), subscriber, StringList(), ExtensionSettingItem::List(), children
				));
			}
		}

		return ret;
	}

	ContextMenuItemPtr UserCommandMenuProvider::toLeafItem(const UserCommand& aCommand, const string& aTitle) const noexcept {
		return std::make_shared<ContextMenuItem>(
			LEAF_ID_PREFIX + Util::toString(aCommand.getId()), aTitle, StringMap(), subscriber,
			StringList(), toFormFieldDefinitions(aCommand), ContextMenuItemList()
		);
	}

	ExtensionSettingItem::List UserCommandMenuProvider::toFormFieldDefinitions(const UserCommand& aCommand) noexcept {
		ExtensionSettingItem::List ret;

		// %[line:name] parameters are prompted from the user before sending (see ActionUtil::getUCParams in the Windows GUI)
		// Unlike the GUI, the same name used with both prefixes is prompted (and filled) for each prefix separately
		static const string prefixes[] = { "%[line:", "%[kickline:" };
		for (const auto& prefix: prefixes) {
			string::size_type i = 0;
			while ((i = aCommand.getCommand().find(prefix, i)) != string::npos) {
				i += prefix.size();
				auto j = aCommand.getCommand().find(']', i);
				if (j == string::npos) {
					break;
				}

				auto name = aCommand.getCommand().substr(i, j - i);

				// Param lookup on send uses the raw name; only the displayed title gets unescaped
				auto key = prefix.substr(2) + name;
				if (!ApiSettingItem::findSettingItem<ExtensionSettingItem>(ret, key)) {
					auto title = name;
					if (aCommand.adc()) {
						Util::replace("\\\\", "\\", title);
						Util::replace("\\s", " ", title);
					}

					ret.emplace_back(key, title, json(""), ApiSettingItem::TYPE_STRING, false);
				}

				i = j + 1;
			}
		}

		return ret;
	}

	optional<UserCommand> UserCommandMenuProvider::parseClickedCommand(const ContextMenuItemClickData& aClickData, int aContext, const StringList& aHubs) const noexcept {
		if (aClickData.hookId != subscriber.getId() || aHubs.empty()) {
			return nullopt;
		}

		// Sending anything to a hub requires the same permission as posting chat messages
		if (!hasSendAccess(aClickData.access)) {
			return nullopt;
		}

		// Strict id parsing; Util::toInt would turn any garbage into command id 0
		if (aClickData.menuItemId.size() <= LEAF_ID_PREFIX.size() || aClickData.menuItemId.compare(0, LEAF_ID_PREFIX.size(), LEAF_ID_PREFIX) != 0) {
			return nullopt;
		}

		auto idStr = aClickData.menuItemId.substr(LEAF_ID_PREFIX.size());
		if (!ranges::all_of(idStr, [](char c) { return isdigit(static_cast<unsigned char>(c)); })) {
			return nullopt;
		}

		auto commandId = Util::toInt(idStr);

		// Accept only commands that are currently being listed for these hubs and context
		// (prevents replaying another hub's commands or ones filtered out as op-only)
		bool op = false;
		auto commands = UserCommandManager::getInstance()->getUserCommands(aContext, aHubs, op);
		auto uc = ranges::find_if(commands, [commandId](const UserCommand& aUc) { return aUc.getId() == commandId; });
		if (uc == commands.end() || (!uc->isRaw() && !uc->isChat())) {
			return nullopt;
		}

		return *uc;
	}

	ParamMap UserCommandMenuProvider::toLineParams(const UserCommand& aCommand, const ContextMenuItemClickData& aClickData) noexcept {
		ParamMap params;

		// Accept only the command's own prompted parameters; arbitrary caller-supplied
		// keys could otherwise fill any %[param] placeholder in the command
		for (const auto& field: toFormFieldDefinitions(aCommand)) {
			auto v = aClickData.formValues.find(field.name);
			if (v != aClickData.formValues.end() && v->second.is_string()) {
				params[field.name] = v->second.get<string>();
			}
		}

		return params;
	}

	void UserCommandMenuProvider::on(HubUserMenuSelected, const vector<dcpp::SID>& aSelections, const ClientPtr& aClient, const ContextMenuItemClickData& aClickData) noexcept {
		if (!aClient) {
			return;
		}

		auto uc = parseClickedCommand(aClickData, UserCommand::CONTEXT_USER, { aClient->getHubUrl() });
		if (!uc) {
			return;
		}

		auto ucParams = toLineParams(*uc, aClickData);
		aClient->getMyIdentity().getParams(ucParams, "my", true);
		aClient->getHubIdentity().getParams(ucParams, "hub", false);

		// Dedupe by user; the API would accept duplicate SIDs, firing "once" commands multiple times
		std::set<UserPtr> handledUsers;
		for (const auto sid: aSelections) {
			auto ou = aClient->findUser(sid);
			if (ou && ou->getUser()->isOnline() && handledUsers.insert(ou->getUser()).second) {
				auto params = ucParams;
				ou->getIdentity().getParams(params, "user", true);
				aClient->sendUserCmd(*uc, params);
			}
		}
	}

	void UserCommandMenuProvider::on(HubMenuSelected, const vector<ClientToken>& aSelections, const ContextMenuItemClickData& aClickData) noexcept {
		for (const auto token: aSelections) {
			auto client = ClientManager::getInstance()->findClient(token);
			if (!client) {
				continue;
			}

			// Validated per hub; a command listed for one hub isn't necessarily available for the others
			auto uc = parseClickedCommand(aClickData, UserCommand::CONTEXT_HUB, { client->getHubUrl() });
			if (!uc) {
				continue;
			}

			auto params = toLineParams(*uc, aClickData);
			client->getMyIdentity().getParams(params, "my", true);
			client->getHubIdentity().getParams(params, "hub", false);
			client->sendUserCmd(*uc, params);
		}
	}

	void UserCommandMenuProvider::on(GroupedSearchResultMenuSelected, const vector<TTHValue>& aSelections, const SearchInstancePtr& aInstance, const ContextMenuItemClickData& aClickData) noexcept {
		if (!aInstance) {
			return;
		}

		auto uc = parseClickedCommand(aClickData, UserCommand::CONTEXT_SEARCH, getSearchResultHubs(aSelections, aInstance));
		if (!uc) {
			return;
		}

		const auto lineParams = toLineParams(*uc, aClickData);

		// Mirrors SearchFrame::runUserCommand: "once" commands run only once per user
		std::set<CID> onceUsers;
		for (const auto& tth: aSelections) {
			auto result = aInstance->getResult(tth);
			if (!result || !result->getBaseUser().user->isOnline()) {
				continue;
			}

			if (uc->once() && !onceUsers.insert(result->getBaseUser().user->getCID()).second) {
				continue;
			}

			auto params = lineParams;
			params["fileFN"] = PathUtil::toNmdcFile(result->getAdcPath());
			params["fileSI"] = Util::toString(result->getSize());
			params["fileSIshort"] = Util::formatBytes(result->getSize());
			if (!result->isDirectory()) {
				params["fileTR"] = result->getTTH().toBase32();
			}
			params["fileMN"] = Magnet::makeMagnet(result->getTTH(), result->getFileName(), result->getSize());

			// Compatibility with 0.674 and earlier
			params["file"] = params["fileFN"];
			params["filesize"] = params["fileSI"];
			params["filesizeshort"] = params["fileSIshort"];
			params["tth"] = params["fileTR"];

			UserCommandManager::getInstance()->userCommand(result->getBaseUser(), *uc, params, true);
		}
	}

	namespace {
		struct FilelistItem {
			DirectoryListing::File::Ptr file;
			DirectoryListing::Directory::Ptr directory;
		};

		void findListItems(const DirectoryListing::Directory::Ptr& aDir, const std::set<DirectoryListingItemToken>& aTokens, vector<FilelistItem>& results_) noexcept {
			for (const auto& d: aDir->directories | views::values) {
				if (aTokens.contains(d->getToken())) {
					results_.push_back({ nullptr, d });
				}

				findListItems(d, aTokens, results_);
			}

			for (const auto& f: aDir->files) {
				if (aTokens.contains(f->getToken())) {
					results_.push_back({ f, nullptr });
				}
			}
		}
	}

	void UserCommandMenuProvider::on(FilelistItemMenuSelected, const vector<DirectoryListingItemToken>& aSelections, const DirectoryListingPtr& aList, const ContextMenuItemClickData& aClickData) noexcept {
		if (!aList) {
			return;
		}

		auto uc = parseClickedCommand(aClickData, UserCommand::CONTEXT_FILELIST, ClientManager::getInstance()->getHubUrls(aList->getUser()));
		if (!uc) {
			return;
		}

		auto lineParams = toLineParams(*uc, aClickData);
		auto tokens = std::set<DirectoryListingItemToken>(aSelections.begin(), aSelections.end());

		// Filelist items must be accessed from the list's own thread
		aList->addAsyncTask([uc = *uc, lineParams = std::move(lineParams), tokens = std::move(tokens), list = aList] {
			if (!list->getUser()->isOnline()) {
				return;
			}

			vector<FilelistItem> items;
			findListItems(list->getRoot(), tokens, items);

			// Mirrors DirectoryListingFrame::runUserCommand: a single user, so "once" commands run only once
			for (const auto& item: items) {
				auto params = lineParams;
				if (item.file) {
					params["type"] = "File"s;
					params["fileFN"] = PathUtil::toNmdcFile(item.file->getAdcPathUnsafe());
					params["fileSI"] = Util::toString(item.file->getSize());
					params["fileSIshort"] = Util::formatBytes(item.file->getSize());
					params["fileTR"] = item.file->getTTH().toBase32();
					params["fileMN"] = Magnet::makeMagnet(item.file->getTTH(), item.file->getName(), item.file->getSize());
				} else {
					params["type"] = "Directory"s;
					params["fileFN"] = PathUtil::toNmdcFile(item.directory->getAdcPathUnsafe());
					params["fileSI"] = Util::toString(item.directory->getTotalSize(item.directory != list->getRoot()));
					params["fileSIshort"] = Util::formatBytes(item.directory->getTotalSize(true));
				}

				// Compatibility with 0.674 and earlier
				params["file"] = params["fileFN"];
				params["filesize"] = params["fileSI"];
				params["filesizeshort"] = params["fileSIshort"];
				params["tth"] = params["fileTR"];

				UserCommandManager::getInstance()->userCommand(list->getHintedUser(), uc, params, true);

				if (uc.once()) {
					break;
				}
			}
		});
	}

} // namespace webserver
