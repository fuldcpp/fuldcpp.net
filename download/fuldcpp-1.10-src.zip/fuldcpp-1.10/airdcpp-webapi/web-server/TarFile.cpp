/*
* Copyright (C) 2011-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"
#include <web-server/TarFile.h>

#include <airdcpp/core/classes/Exception.h>
#include <airdcpp/core/io/File.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/text/Text.h>
#include <airdcpp/util/Util.h>

#include <algorithm>
#include <cstdint>

#include <boost/algorithm/string/replace.hpp>

namespace webserver {
	TarFile::TarFile(const string& aPath) : path(aPath), archiveSize(File::getSize(aPath)) {
		auto res = mtar_open(&tar, Text::fromUtf8(aPath).c_str(), "r");
		if (res != MTAR_ESUCCESS) {
			throw Exception(mtar_strerror(res));
		}
	}

	// Maximum size we are willing to allocate/extract for a single tar entry (1 GiB).
	// Tar headers store the size as an octal-encoded 32-bit value, so without this cap a
	// crafted entry could request up to ~4 GiB (or, due to the size + 1 overflow below,
	// wrap a tiny allocation while attempting a huge read -> heap overflow).
	static const uint64_t MAX_TAR_ENTRY_SIZE = static_cast<uint64_t>(1) << 30;

	// Aggregate limits to guard against decompression bombs: cap the total extracted size
	// and the number of entries we are willing to process from a single archive.
	static const uint64_t MAX_TAR_TOTAL_SIZE = static_cast<uint64_t>(2) << 30; // 2 GiB
	static const uint64_t MAX_TAR_ENTRY_COUNT = 100000;

	string TarFile::getSafeDestinationPath(const string& aDestPath, const string& aEntryName) noexcept {
		if (aEntryName.empty()) {
			return Util::emptyString;
		}

		// Reject Windows drive-letter prefixes (e.g. "C:..." or "C:\...").
		if (aEntryName.size() >= 2 && aEntryName[1] == ':') {
			return Util::emptyString;
		}

		// Normalize separators so that both '/' (tar) and '\\' are treated as path separators.
		string normalized = aEntryName;
		std::replace(normalized.begin(), normalized.end(), '\\', '/');

		// A package built by hand with "tar czf x.tgz ./dir" names every entry "./dir/...":
		// one leading "./" is the archive's own root, not a traversal
		if (normalized.size() > 2 && normalized.compare(0, 2, "./") == 0) {
			normalized.erase(0, 2);
		}

		// Reject absolute paths and UNC paths ("/foo", "//host/share").
		if (normalized.front() == '/') {
			return Util::emptyString;
		}

		// Reject any path that contains a "." or ".." traversal component.
		size_t start = 0;
		while (start <= normalized.size()) {
			auto end = normalized.find('/', start);
			auto component = normalized.substr(start, end == string::npos ? string::npos : end - start);
			if (component == "." || component == "..") {
				return Util::emptyString;
			}

			if (end == string::npos) {
				break;
			}
			start = end + 1;
		}

		auto destRoot = PathUtil::ensureTrailingSlash(aDestPath);
		string destFile = destRoot + normalized;

#ifdef _WIN32
		// Wrong path separators would hit assertions...
		boost::replace_all(destFile, "/", PATH_SEPARATOR_STR);
#endif

		// Final containment check: the resolved path must stay under the destination root.
		if (!PathUtil::isParentOrExactLocal(destRoot, destFile) || destFile == destRoot) {
			return Util::emptyString;
		}

		return destFile;
	}

	void TarFile::extract(const string& aDestPath) {
		// Zero-initialised so a first-iteration failure cannot be read as a stale header.
		mtar_header_t h = {};
		uint64_t totalSize = 0;
		uint64_t entryCount = 0;

		// Only ENULLRECORD means "clean end of archive". Every other error -- EREADFAIL on
		// a truncated file, ESEEKFAIL, EBADCHKSUM -- used to fall through into the loop
		// body, where raw_to_header had returned WITHOUT writing a single field: the size
		// caps and the tar-slip check below then operated on the PREVIOUS entry's header,
		// and mtar_next also failed without advancing, so the same bad record was re-read
		// until the 100000-entry counter tripped.
		for (;;) {
			const auto readResult = mtar_read_header(&tar, &h);
			if (readResult == MTAR_ENULLRECORD) {
				break;
			}

			if (readResult != MTAR_ESUCCESS) {
				throw Exception("Malformed tar archive: " + string(mtar_strerror(readResult)));
			}

			if (++entryCount > MAX_TAR_ENTRY_COUNT) {
				throw Exception("Tar archive contains too many entries");
			}

			if (h.type != MTAR_TDIR && strcmp(h.name, "pax_global_header") != 0) {
				// Validate the entry size before allocating: use 64-bit math to avoid the
				// "h.size + 1" unsigned wraparound (which could turn a huge read into a
				// tiny allocation -> heap overflow). Also reject sizes that exceed our cap
				// or that cannot fit within the remaining bytes of the archive.
				const uint64_t entrySize = static_cast<uint64_t>(h.size);
				if (entrySize > MAX_TAR_ENTRY_SIZE) {
					throw Exception("Tar entry is too large");
				}

				// Accumulate total extracted size (64-bit) and enforce the aggregate cap.
				totalSize += entrySize;
				if (totalSize > MAX_TAR_TOTAL_SIZE) {
					throw Exception("Tar archive is too large to extract");
				}

				if (archiveSize >= 0 && entrySize > static_cast<uint64_t>(archiveSize)) {
					throw Exception("Tar entry size exceeds the archive size");
				}

				// Validate the destination path to prevent tar-slip (path traversal).
				const string destFile = getSafeDestinationPath(aDestPath, h.name);
				if (destFile.empty()) {
					throw Exception("Invalid tar entry path: " + string(h.name));
				}

				boost::scoped_array<char> buf(new char[entrySize + 1]);
				auto res = mtar_read_data(&tar, &buf[0], h.size);
				if (res != MTAR_ESUCCESS) {
					throw Exception(mtar_strerror(res));
				}

				File::ensureDirectory(destFile);
				{
					File f(destFile, File::WRITE, File::OPEN | File::CREATE | File::TRUNCATE, File::BUFFER_SEQUENTIAL);
					f.write(&buf[0], h.size);
				}
			}

			const auto nextResult = mtar_next(&tar);
			if (nextResult != MTAR_ESUCCESS) {
				throw Exception("Malformed tar archive: " + string(mtar_strerror(nextResult)));
			}
		}
	}

	TarFile::~TarFile() {
		mtar_close(&tar);
	}
}