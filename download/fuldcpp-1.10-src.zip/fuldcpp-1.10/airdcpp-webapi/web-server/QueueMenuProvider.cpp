/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include "QueueMenuProvider.h"

#include "ContextMenuManager.h"
#include "WebServerManager.h"

#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/core/types/Priority.h>
#include <airdcpp/queue/Bundle.h>
#include <airdcpp/queue/QueueItem.h>
#include <airdcpp/queue/QueueManager.h>

namespace webserver {

	static const string HOOK_ID = "queue_actions";

	static const string ITEM_RECHECK = "recheck_integrity";
	static const string ITEM_READD_SOURCES = "readd_sources";
	static const string ITEM_SEQ_ORDER = "toggle_seq_order";
	static const string ITEM_SLOW_DISCONNECT = "toggle_slow_disconnect";
	static const string ITEM_PAUSE_TIMED = "pause_timed";

	static const string PAUSE_MINUTES_FIELD = "minutes";

	QueueMenuProvider::QueueMenuProvider(ContextMenuManager& aMenuManager) :
		cmm(aMenuManager), subscriber(HOOK_ID, "Queue actions", nullptr)
	{
		auto added = cmm.queueBundleMenuHook.addSubscriber(
			ActionHookSubscriber(subscriber),
			[this](const vector<QueueToken>&, const ContextMenuItemListData& aListData, const MenuItemResultGetter& aResultGetter) {
				auto menu = hasQueueEditAccess(aListData.access) ? getBundleMenu() : nullptr;
				return menu ? aResultGetter.getData(menu) : ActionHookResult<GroupedContextMenuItemPtr>();
			}
		);
		dcassert(added);

		added = cmm.queueFileMenuHook.addSubscriber(
			ActionHookSubscriber(subscriber),
			[this](const vector<QueueToken>&, const ContextMenuItemListData& aListData, const MenuItemResultGetter& aResultGetter) {
				auto menu = hasQueueEditAccess(aListData.access) ? getFileMenu() : nullptr;
				return menu ? aResultGetter.getData(menu) : ActionHookResult<GroupedContextMenuItemPtr>();
			}
		);
		dcassert(added);

		cmm.addListener(this);
	}

	QueueMenuProvider::~QueueMenuProvider() {
		cmm.removeListener(this);
		cmm.queueBundleMenuHook.removeSubscriber(subscriber.getId());
		cmm.queueFileMenuHook.removeSubscriber(subscriber.getId());
	}

	bool QueueMenuProvider::hasQueueEditAccess(const AccessList& aAccess) noexcept {
		return ranges::any_of(aAccess, [](auto a) { return a == Access::QUEUE_EDIT || a == Access::ADMIN; });
	}

	ContextMenuItemPtr QueueMenuProvider::toItem(const string& aId, const string& aTitle, const ExtensionSettingItem::List& aFormFields) const noexcept {
		return std::make_shared<ContextMenuItem>(aId, aTitle, StringMap(), subscriber, StringList(), aFormFields, ContextMenuItemList());
	}

	GroupedContextMenuItemPtr QueueMenuProvider::getBundleMenu() const noexcept {
		ExtensionSettingItem::List pauseFields;
		pauseFields.emplace_back(PAUSE_MINUTES_FIELD, "Minutes", json(30), ApiSettingItem::TYPE_NUMBER, false);

		return std::make_shared<GroupedContextMenuItem>(subscriber.getId(), subscriber.getName(), StringMap(), ContextMenuItemList({
			toItem(ITEM_PAUSE_TIMED, "Pause for...", pauseFields),
			toItem(ITEM_RECHECK, "Recheck integrity"),
			toItem(ITEM_READD_SOURCES, "Re-add all sources"),
			toItem(ITEM_SEQ_ORDER, "Toggle sequential download order"),
			toItem(ITEM_SLOW_DISCONNECT, "Toggle slow source disconnecting"),
		}));
	}

	GroupedContextMenuItemPtr QueueMenuProvider::getFileMenu() const noexcept {
		return std::make_shared<GroupedContextMenuItem>(subscriber.getId(), subscriber.getName(), StringMap(), ContextMenuItemList({
			toItem(ITEM_RECHECK, "Recheck integrity"),
			toItem(ITEM_READD_SOURCES, "Re-add all sources"),
		}));
	}

	void QueueMenuProvider::on(QueueBundleMenuSelected, const vector<QueueToken>& aSelections, const ContextMenuItemClickData& aClickData) noexcept {
		if (aClickData.hookId != subscriber.getId() || !hasQueueEditAccess(aClickData.access)) {
			return;
		}

		auto qm = QueueManager::getInstance();
		if (aClickData.menuItemId == ITEM_RECHECK) {
			// Rechecking re-hashes the downloaded content from disk; never run it on an API thread
			// (the desktop GUI threads this as well)
			WebServerManager::getInstance()->addAsyncTask([aSelections] {
				for (const auto token: aSelections) {
					QueueManager::getInstance()->recheckBundle(token);
				}
			});
		} else if (aClickData.menuItemId == ITEM_READD_SOURCES) {
			// Source-add hooks may run extension subscribers; keep API threads free
			WebServerManager::getInstance()->addAsyncTask([aSelections] {
				auto queue = QueueManager::getInstance();
				for (const auto token: aSelections) {
					if (auto b = queue->findBundle(token)) {
						for (const auto& source: queue->getBadBundleSources(b)) {
							queue->readdBundleSourceHooked(b, source.getUser());
						}
					}
				}
			});
		} else if (aClickData.menuItemId == ITEM_SEQ_ORDER) {
			for (const auto token: aSelections) {
				if (auto b = qm->findBundle(token)) {
					qm->onUseSeqOrder(b);
				}
			}
		} else if (aClickData.menuItemId == ITEM_SLOW_DISCONNECT) {
			for (const auto token: aSelections) {
				qm->toggleSlowDisconnectBundle(token);
			}
		} else if (aClickData.menuItemId == ITEM_PAUSE_TIMED) {
			// Form definitions in click data come from the caller, so this is the only real validation
			auto v = aClickData.formValues.find(PAUSE_MINUTES_FIELD);
			if (v == aClickData.formValues.end() || !v->second.is_number_integer()) {
				return;
			}

			auto minutes = v->second.get<int64_t>();
			if (minutes <= 0 || minutes > 7 * 24 * 60) { // Cap at a week
				return;
			}

			for (const auto token: aSelections) {
				if (auto b = qm->findBundle(token)) {
					qm->setBundlePriority(b, Priority::PAUSED_FORCE, false, GET_TIME() + static_cast<time_t>(minutes) * 60);
				}
			}
		}
	}

	void QueueMenuProvider::on(QueueFileMenuSelected, const vector<QueueToken>& aSelections, const ContextMenuItemClickData& aClickData) noexcept {
		if (aClickData.hookId != subscriber.getId() || !hasQueueEditAccess(aClickData.access)) {
			return;
		}

		auto qm = QueueManager::getInstance();
		if (aClickData.menuItemId == ITEM_RECHECK) {
			// Rechecking re-hashes the downloaded content from disk; never run it on an API thread
			WebServerManager::getInstance()->addAsyncTask([aSelections] {
				auto queue = QueueManager::getInstance();

				QueueItemList files;
				for (const auto token: aSelections) {
					if (auto qi = queue->findFile(token)) {
						files.push_back(qi);
					}
				}

				if (!files.empty()) {
					queue->recheckFiles(files);
				}
			});
		} else if (aClickData.menuItemId == ITEM_READD_SOURCES) {
			// Source-add hooks may run extension subscribers; keep API threads free
			WebServerManager::getInstance()->addAsyncTask([aSelections] {
				auto queue = QueueManager::getInstance();
				for (const auto token: aSelections) {
					if (auto qi = queue->findFile(token)) {
						for (const auto& source: queue->getBadSources(qi)) {
							queue->readdQISourceHooked(qi->getTarget(), source.getUser());
						}
					}
				}
			});
		}
	}

} // namespace webserver
