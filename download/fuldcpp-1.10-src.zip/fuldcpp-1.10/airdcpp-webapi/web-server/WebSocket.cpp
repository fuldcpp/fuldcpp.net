/*
* Copyright (C) 2011-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <web-server/WebSocket.h>

#include <web-server/ApiRouter.h>
#include <web-server/HttpUtil.h>
#include <web-server/JsonUtil.h>
#include <web-server/Session.h>
#include <web-server/WebServerManager.h>

#include <airdcpp/core/header/format.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/util/Util.h>


namespace webserver {
	WebSocket::WebSocket(bool aIsSecure, ConnectionHdl aHdl, IServerEndpoint& aEndpoint, WebServerManager* aWsm) :
		hdl(aHdl), endpoint(aEndpoint), wsm(aWsm), secure(aIsSecure), timeCreated(GET_TICK())
	{
		debugMessage("Websocket created");

		// Parse remote IP
		ip = endpoint.getRemoteIp(hdl);

		// Parse URL
		url = endpoint.getUri(hdl);
		if (!url.empty() && url.back() != '/') {
			url += '/';
		}
	}

	WebSocket::~WebSocket() {
		dcdebug("Websocket was deleted\n");
	}

	void WebSocket::sendApiResponse(const json& aResponseJson, const json& aErrorJson, http::status aCode, int aCallbackId) noexcept {
		json j;

		if (aCallbackId > 0) {
			j["callback_id"] = aCallbackId;
		} else {
			// Failed to parse the request
			dcassert(!aErrorJson.is_null());
		}
		
		j["code"] = aCode;

		if (!HttpUtil::isStatusOk(aCode)) {
			dcdebug("Socket request %d failed: %s\n", aCallbackId, aErrorJson.dump().c_str());
			j["error"] = aErrorJson;
		} else if (!aResponseJson.is_null()) {
			j["data"] = aResponseJson;
		} else {
			dcassert(aCode == http::status::no_content);
		}

		try {
			sendPlain(j);
		} catch (const json::exception& e) {
			sendApiResponse(
				nullptr, 
				{
					{ "message", "Failed to convert data to JSON: " + string(e.what()) }
				}, 
				http::status::internal_server_error, 
				aCallbackId
			);
		}
	}

	void WebSocket::logError(const string& aMessage) const noexcept {
		auto message = (dcpp_fmt("Websocket: " + aMessage + " (%s)") % (session ? session->getAuthToken().c_str() : "no session")).str();
		// In phase 2 without websocketpp logging, just print to debug output
		dcdebug("%s\n", message.c_str());
	}

	void WebSocket::debugMessage(const string& aMessage) const noexcept {
		dcdebug(string(aMessage + " (%s)\n").c_str(), session ? session->getAuthToken().c_str() : "no session");
	}

	void WebSocket::sendPlain(const json& aJson) {
		string str;
		try {
			str = aJson.dump();
		} catch (const json::exception& e) {
			logError("Failed to convert data to JSON: " + string(e.what()));
			throw;
		}

		wsm->onData(str, TransportType::TYPE_SOCKET, Direction::OUTGOING, getIp());

		try {
			endpoint.wsSendText(hdl, str);
		} catch (const std::exception& e) {
			logError("Failed to send data: " + string(e.what()));
		}
	}

	void WebSocket::ping() noexcept {
		try {
			endpoint.wsPing(hdl);
		} catch (const std::exception& e) {
			debugMessage(string("WebSocket::ping failed: ") + e.what());
		}
	}

	void WebSocket::close(uint16_t aCode, const string& aMsg) {
		debugMessage("WebSocket::close");
		try {
			endpoint.wsClose(hdl, aCode, aMsg);
		} catch (const std::exception& e) {
			debugMessage(string("WebSocket::close failed: ") + e.what());
		}
	}

	void WebSocket::parseRequest(const string& aRequest, int& callbackId_, string& method_, string& path_, json& data_) {
		const auto requestJson = json::parse(aRequest);

		callbackId_ = JsonUtil::getOptionalFieldDefault<int>("callback_id", requestJson, -1);
		path_ = requestJson.at("path");
		data_ = JsonUtil::getOptionalRawField("data", requestJson);
		method_ = requestJson.at("method");
	}

	void WebSocket::onData(const string& aMessage, const SessionCallback& aAuthCallback) {
		// Logging
		wsm->onData(aMessage, TransportType::TYPE_SOCKET, Direction::INCOMING, getIp());
		dcdebug("Received socket request: %s\n", Util::truncate(aMessage, 500).c_str());

		// Parse request
		int callbackId = -1;
		string method, path;
		json data;
		try {
			parseRequest(aMessage, callbackId, method, path, data);
		} catch (const json::exception& e) {
			sendApiResponse(nullptr, ApiRequest::toResponseErrorStr("Failed to parse JSON: " + string(e.what())), http::status::bad_request, callbackId);
			return;
		} catch (const std::invalid_argument& e) {
			sendApiResponse(nullptr, ApiRequest::toResponseErrorStr(e.what()), http::status::bad_request, callbackId);
			return;
		}

		// Prepare response handlers
		const auto responseF = [callbackId, this](http::status aStatus, const json& aResponseJsonData, const json& aResponseErrorJson) {
			sendApiResponse(aResponseJsonData, aResponseErrorJson, aStatus, callbackId);
		};

		bool isDeferred = false;
		const auto deferredF = [&isDeferred, callbackId, weak = weak_from_this()]() {
			isDeferred = true;

			// A deferred completion outlives this call: the handler stores it in an async
			// task and runs it later. If the client disconnects meanwhile,
			// SocketManager::handleSocketDisconnected erases the socket and every
			// SubscribableApiModule drops its reference, so the WebSocket is gone --
			// ApiModule::asyncRunWrapper only pins the SESSION, which deliberately
			// outlives the socket. Capturing `this` therefore dereferenced freed memory.
			// The HTTP path already does exactly this with a weak handle + selfKeep.
			return [weak, callbackId](http::status aStatus, const json& aResponseJsonData, const json& aResponseErrorJson) {
				if (auto socket = weak.lock(); socket) {
					socket->sendApiResponse(aResponseJsonData, aResponseErrorJson, aStatus, callbackId);
				}
			};
		};

		// Route request

		http::status code;
		json responseJsonData, responseErrorJson;
		try {
			ApiRequest apiRequest(url + path, method, std::move(data), getSession(), deferredF, responseJsonData, responseErrorJson);
			RouterRequest routerRequest{ apiRequest, secure, aAuthCallback, getIp() };
			code = ApiRouter::handleRequest(routerRequest);
		} catch (const std::invalid_argument& e) {
			sendApiResponse(nullptr, ApiRequest::toResponseErrorStr(e.what()), http::status::bad_request, callbackId);
			return;
		}

		if (!isDeferred) {
			responseF(code, responseJsonData, responseErrorJson);
		}

	}
}