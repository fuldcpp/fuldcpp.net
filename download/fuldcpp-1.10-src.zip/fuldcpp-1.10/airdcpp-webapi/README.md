# FulDC++ Web API

A Websocket/REST API for applications using the DC++ core, as used by [FulDC++](https://github.com/KhwanTosawat8/airdcpp-windows).

This module originates from the [AirDC++ Web API](https://github.com/airdcpp-web/airdcpp-webclient/) and is vendored here via `git subtree`; most of it is unchanged upstream code.

Issues and pull requests for this fork should be posted to [FulDC++](https://github.com/KhwanTosawat8/airdcpp-windows/issues).

## Documentation

API reference is available at http://apidocs.airdcpp.net — the API surface documented there applies to this module as well.
