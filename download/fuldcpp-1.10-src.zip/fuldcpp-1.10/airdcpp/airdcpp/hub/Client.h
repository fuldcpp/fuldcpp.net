/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_CLIENT_H
#define DCPLUSPLUS_DCPP_CLIENT_H

#include <airdcpp/core/header/compiler.h>
#include <airdcpp/forward.h>

#include <airdcpp/connection/socket/BufferedSocketListener.h>
#include <airdcpp/hub/ClientListener.h>
#include <airdcpp/share/profiles/ShareProfileManagerListener.h>
#include <airdcpp/core/timer/TimerManagerListener.h>

#include <airdcpp/protocol/AdcSupports.h>
#include <airdcpp/core/classes/FloodCounter.h>
#include <airdcpp/settings/HubSettings.h>
#include <airdcpp/message/MessageCache.h>
#include <airdcpp/plugins/PluginEntity.h>
#include <airdcpp/user/OnlineUser.h>
#include <airdcpp/search/SearchQueue.h>
#include <airdcpp/core/Speaker.h>

#include <boost/noncopyable.hpp>

#include <atomic>

namespace dcpp {

class ClientBase
{
public:
	
	ClientBase() { }
	
	virtual const string& getHubUrl() const noexcept = 0;
	virtual string getHubName() const noexcept = 0;
	virtual bool isOp() const noexcept = 0;
	virtual int connect(const OnlineUser& user, const string& token, string& lastError_) noexcept = 0;
	virtual bool privateMessageHooked(const OnlineUserPtr& aUser, const OutgoingChatMessage& aMessage, string& error_, bool aEcho = true) noexcept = 0;
	virtual bool directSearchHooked(const OnlineUser&, const SearchPtr&, string&) noexcept {
		dcassert(0);
		return false;
	}
};

/** Yes, this should probably be called a Hub */
class Client :
	public ClientBase, public ChatHandlerBase, public Speaker<ClientListener>, public BufferedSocketListener, protected TimerManagerListener,
	private ShareProfileManagerListener, public HubSettings, public PluginEntity<HubData>, private boost::noncopyable {
public:
	using UrlMap = unordered_map<string *, ClientPtr, noCaseStringHash, noCaseStringEq>;
	using IdMap = unordered_map<ClientToken, ClientPtr>;

	virtual void connect(bool withKeyprint = true) noexcept;
	// aLocal false = the disconnect is a protocol failure, not our decision, so failover still runs.
	virtual void disconnect(bool graceless, bool aLocal = true) noexcept;

	// Default message method
	bool sendMessageHooked(const OutgoingChatMessage& aMessage, string& error_) noexcept override;
	bool sendPrivateMessageHooked(const OnlineUserPtr& aUser, const OutgoingChatMessage& aMessage, string& error_, bool aEcho = true) noexcept;

	// NMDC $MCTo: a private message displayed in the recipient's main chat.
	// Default: unsupported (ADC hubs and NMDC hubs without the MCTo extension).
	virtual bool mcPrivateMessage(const OnlineUserPtr& aUser, const string& aMessage, bool aThirdPerson, string& error_) noexcept;

	virtual int connect(const OnlineUser& user, const string& token, string& lastError_) noexcept override = 0;
	virtual void sendUserCmd(const UserCommand& command, const ParamMap& params) = 0;

	uint64_t queueSearch(const SearchPtr& aSearch) noexcept;
	optional<uint64_t> getQueueTime(CallerPtr aOwner) const noexcept;
	bool cancelSearch(CallerPtr aOwner) noexcept { return searchQueue.cancelSearch(aOwner); }
	int getSearchQueueSize() const noexcept { return searchQueue.getQueueSize(); }
	bool hasSearchOverflow() const noexcept { return searchQueue.hasOverflow(); }
	
	virtual void password(const string& pwd) noexcept = 0;
	void info();

	/** Our detected external address changed (hourly IP check or port mapper). Decides per hub
		between an in-session re-announce and a reconnect; marshals to the socket thread. */
	void onExternalIPChanged(const string& aNewIP, bool aV6) noexcept;

	/** Change our nick while connected. Only NMDC hubs advertising NickChange support this;
		returns false when the hub (or protocol) can't do it, or the nick is unusable. */
	virtual bool changeNick(const string& /*aNick*/) noexcept { return false; }

	/** Ask the other users on this hub for their public favorites (DFAV, ADC-EXT 4.6).
		Returns false when the protocol can't do it or the request was throttled. */
	virtual bool requestDistributedFavorites() noexcept { return false; }

	virtual size_t getUserCount() const noexcept = 0;
	int64_t getTotalShare() const noexcept { return availableBytes; };
	
	virtual bool sendHooked(const AdcCommand& command, CallerPtr aOwner, string& error_) = 0;

	void callAsync(AsyncF f) noexcept;

	bool isConnected() const noexcept;
	bool isSocketSecure() const noexcept;
	bool isTrusted() const noexcept;
	std::string getEncryptionInfo() const noexcept;
	ByteVector getKeyprint() const noexcept;

	bool isOp() const noexcept override { return getMyIdentity().isOp(); }

	virtual void refreshUserList(bool) noexcept = 0;
	virtual void getUserList(OnlineUserList& list, bool aListHidden) const noexcept = 0;
	virtual OnlineUserPtr findUser(const string& aNick) const noexcept = 0;
	virtual OnlineUserPtr findUser(dcpp::SID aSID) const noexcept = 0;
	
	const string& getPort() const noexcept { return port; }
	const string& getAddress() const noexcept { return address; }

	const string& getIp() const noexcept { return ip; }
	string getIpPort() const noexcept { return getIp() + ':' + port; }

	void updated(const OnlineUserPtr& aUser) noexcept;
	void updated(OnlineUserList& users) noexcept;
	
	void setActive() noexcept;
	void reconnect() noexcept;
	virtual void shutdown(ClientPtr& aClient, bool aRedirect);
	bool isActive() const noexcept;
	bool isActiveV4() const noexcept;
	bool isActiveV6() const noexcept;

	void send(const string& aMessage) { send(aMessage.c_str(), aMessage.length()); }
	void send(const char* aMessage, size_t aLen);

	// Feed a protocol line to the hub as if it had been received from the socket (DCAPI plugin support)
	virtual void emulateCommand(const string& aCmd) noexcept = 0;

	string getMyNick() const noexcept { return myIdentity.getNick(); }
	string getHubName() const noexcept override { return hubIdentity.getNick().empty() ? getHubUrl() : hubIdentity.getNick(); }
	string getHubDescription() const noexcept { return hubIdentity.getDescription(); }

	GETSET(Identity, myIdentity, MyIdentity);
	GETSET(Identity, hubIdentity, HubIdentity);

	const string& getHubUrl() const noexcept override { return hubUrl; }

	GETSET(string, defpassword, Password);

	GETSET(uint64_t, lastActivity, LastActivity);
	IGETSET(uint32_t, reconnDelay, ReconnDelay, 120);
	
	IGETSET(bool, registered, Registered, false);
	IGETSET(bool, autoReconnect, AutoReconnect, false);
	IGETSET(FavoriteHubToken, favToken, FavToken, 0);

	ClientToken getToken() const noexcept {
		return clientId;
	}

	void setHubSetting(HubSettings::HubBoolSetting aSetting, bool aNewValue) noexcept;

	/* Toggle a hub setting and return the new value */
	bool toggleHubBoolSetting(HubSettings::HubBoolSetting aSetting) noexcept;

	enum CountType: uint8_t {
		COUNT_NORMAL = 0x00,
		COUNT_REGISTERED = 0x01,
		COUNT_OP = 0x04,
		COUNT_UNCOUNTED = 0x08
	};

	CountType getCountType() const noexcept { return countType; }
	long getDisplayCount(CountType aCountType) const noexcept;
	static string getAllCountsStr() noexcept;

	bool isSharingHub() const noexcept;

	void statusMessage(const string& aMessage, LogMessage::Severity aSeverity, LogMessage::Type aType = LogMessage::Type::SERVER, const string& aLabel = Util::emptyString, const string& aOwner = Util::emptyString) noexcept override;

	virtual ~Client();

	int retranslateCache(const MessageCache::TextRewriteF& aRewriteF) noexcept override {
		return cache.retranslate(aRewriteF);
	}

	const MessageCache& getCache() const noexcept override {
		return cache;
	}

	int clearCache() noexcept override;
	void setRead() noexcept override;
	const string& getRedirectUrl() const noexcept {
		return redirectUrl;
	}

	// The hub URL that redirected us here (ADC-EXT 4.10 RF); empty unless this instance was created by a redirect
	const string& getReferrerUrl() const noexcept {
		return referrerUrl;
	}

	void doRedirect() noexcept;
	FavoriteHubEntryPtr saveFavorite();

	enum State: uint8_t {
		STATE_CONNECTING,	///< Waiting for socket to connect
		STATE_PROTOCOL,		///< Protocol setup
		STATE_IDENTIFY,		///< Nick setup
		STATE_VERIFY,		///< Checking password
		STATE_NORMAL,		///< Running
		STATE_DISCONNECTED	///< Nothing in particular
	};

	State getConnectState() const noexcept {
		return state;
	}

	bool stateNormal() const noexcept {
		return state == STATE_NORMAL;
	}

	void allowUntrustedConnect() noexcept;
	bool isKeyprintMismatch() const noexcept;

	// The keyprint the server actually presented when the pinned kp= failed to match
	// (captured at connection failure; empty otherwise)
	const string& getMismatchedKeyprint() const noexcept { return mismatchedKeyprint; }
	// The keyprint currently pinned from the hub address (kp= parameter)
	const string& getExpectedKeyprint() const noexcept { return keyprint; }

	// Re-pin to the keyprint the server presented, persist it into the favorite hub
	// address (when the hub is a favorite) and reconnect with normal validation
	void acceptMismatchedKeyprint() noexcept;

	// Whether the certificate of the current connection can be pinned: a secure, connected,
	// not-yet-pinned session on a hub that is a favorite (the pin is stored in its address)
	bool isKeyprintPinnable() const noexcept;

	// Pin the certificate the hub is currently presenting into the favorite hub address.
	// Takes effect from the next connection; the live session is left untouched
	bool pinCurrentKeyprint() noexcept;

	// Returns the favorite entry this connection's certificate could be pinned into, or null
	FavoriteHubEntryPtr getPinnableFavorite() const noexcept;

	// The redirect target of a pending permanent redirect prompt (ADC-EXT 4.32 PT1); empty otherwise
	string getPendingPermanentRedirect() const noexcept;

	// Follow a permanent redirect and persist the new address into the favorite hub entry
	void acceptPermanentRedirect() noexcept;
	// Follow a permanent redirect without updating the favorite
	void declinePermanentRedirect() noexcept;
	// Dismiss a pending permanent redirect (stay on the current address)
	void clearPermanentRedirect() noexcept;

	// Failover hub addresses (ADC-EXT 4.21), from the hub's INF FO field or the favorite entry
	StringList getFailovers() const noexcept;
	void setFailovers(const StringList& aUrls) noexcept;

	AdcSupports& getSupports() noexcept {
		return supports;
	}

	// Whether this hub carries ADC RTF0 rich text right now. Deliberately not cached
	// anywhere: the spec lets a hub announce the feature late and withdraw it again,
	// and requires clients to honour the current state.
	virtual bool supportsRichText() const noexcept {
		return false;
	}
protected:
	mutable SharedMutex cs;

	virtual bool hubMessageHooked(const OutgoingChatMessage& aMessage, string& error_) noexcept = 0;
	virtual bool privateMessageHooked(const OnlineUserPtr& aUser, const OutgoingChatMessage& aMessage, string& error_, bool aEcho) noexcept override = 0;
	virtual void clearUsers() noexcept = 0;

	void setConnectState(State aState) noexcept;
	MessageCache cache;

	// Replace (or append) the kp= query parameter value in a hub URL. Used when a pin has to
	// travel with an address (failover hops, hub-driven redirects, re-pinning a favorite)
	static string replaceKeyprintParam(const string& aUrl, const string& aKeyprint) noexcept;

	// Vet a hub-supplied redirect target ($ForceMove, ADC QUI RD/RX) before following it and
	// apply our own pin where it still applies. Rejects targets that would weaken the current
	// session: a hub-chosen keyprint, a downgrade off TLS, or a hop away from the pinned host.
	// Returns false (with a localized reason in error_) if the redirect must be refused.
	bool prepareHubRedirect(string& url_, string& error_) const noexcept;

	Client(const string& hubURL, char separator, const ClientPtr& aOldClient);

	SearchQueue searchQueue;
	BufferedSocket* sock = nullptr;

	std::atomic<int64_t> availableBytes = 0;

	bool updateCounts(bool aRemove) noexcept;
	void updateActivity() noexcept;

	/** Reload details from favmanager or settings */
	void reloadSettings(bool updateNick) noexcept;

	string getDescription() const noexcept;

	virtual string checkNick(const string& nick) noexcept = 0;
	virtual void search(const SearchPtr& aSearch) noexcept = 0;
	virtual void infoImpl() noexcept = 0;

	// Whether this hub tracks our address in the given family at all (base: the family
	// of the hub socket; AdcHub also counts the HBRI-carried secondary family)
	virtual bool isIpFamilyRelevant(bool aV6) const noexcept;
	// Whether a real I4/I6 announce will go out in-session, making the hub's record
	// correctable without a reconnect. Only ADC can carry an address at all ($MyINFO
	// has no IP field), and even there only in the NO_IP_OVERRIDE + external IP config.
	virtual bool canAnnounceIp(bool /*aV6*/) const noexcept { return false; }
	// Our own row in this hub's user list
	virtual OnlineUserPtr getMyOnlineUser() const noexcept { return findUser(getMyNick()); }

	// TimerManagerListener
	virtual void on(Second, uint64_t aTick) noexcept override;

	// BufferedSocketListener
	virtual void on(BufferedSocketListener::Connecting) noexcept override;
	virtual void on(BufferedSocketListener::Connected) noexcept override;
	virtual void on(BufferedSocketListener::Line, const string& aLine) noexcept override;
	virtual void on(BufferedSocketListener::Failed, const string&) noexcept override;

	// ShareManagerListener
	void on(ShareProfileManagerListener::DefaultProfileChanged, ProfileToken aOldDefault, ProfileToken aNewDefault) noexcept override;
	void on(ShareProfileManagerListener::ProfileRemoved, ProfileToken aProfile) noexcept override;

	virtual bool v4only() const noexcept = 0;
	void onPassword() noexcept;

	void onPrivateMessage(const ChatMessagePtr& aMessage) noexcept;
	void onChatMessage(const ChatMessagePtr& aMessage) noexcept;
	void onRedirect(const string& aRedirectUrl) noexcept;
	// Permanent redirect (ADC-EXT 4.32 PT1): prompts via RedirectPrompt for favorite hubs,
	// falls back to the plain redirect flow otherwise
	void onPermanentRedirect(const string& aRedirectUrl) noexcept;

	void onUserConnected(const OnlineUserPtr& aUser) noexcept;
	void onUserDisconnected(const OnlineUserPtr& aUser, bool aDisconnectTransfers) noexcept;

	string redirectUrl;

	FloodCounter ctmFloodCounter;
	FloodCounter searchFloodCounter;

	static FloodCounter::FloodLimits getCTMLimits(const OnlineUserPtr& aAdcUser) noexcept;
	static FloodCounter::FloodLimits getSearchLimits() noexcept;

	bool checkIncomingCTM(const string& aTarget, const OnlineUserPtr& aAdcUser = nullptr) noexcept;
	bool checkIncomingSearch(const string& aTarget, const OnlineUserPtr& aAdcUser = nullptr) noexcept;

	AdcSupports supports;
private:
	const ClientToken clientId;
	static atomic<long> allCounts[COUNT_UNCOUNTED];
	static atomic<long> sharingCounts[COUNT_UNCOUNTED];

	atomic<State> state { STATE_DISCONNECTED };

	const string hubUrl;
	const string referrerUrl;
	string address;
	string ip;
	string localIp;
	string keyprint;
	string mismatchedKeyprint;
	string pendingPermanentRedirect;

	// Connection-failure burst tracking for the reconnect backoff
	uint64_t failBurstWindowStart = 0;
	int failBurstCount = 0;

	// Set on locally initiated disconnects (user action, shutdown) so the resulting
	// socket failure doesn't trigger failover rotation; cleared on connect()
	std::atomic<bool> localDisconnect { false };

	// Nick and password supplied by whoever created this client explicitly -- the plugin API's
	// add_hub. reloadSettings() rebuilds HubSettings from the global settings on every connect,
	// and clears the password outright for a hub with no favourite, so without these the caller's
	// values were gone before the handshake. A favourite still wins.
	string nickOverride;
	string passwordOverride;
public:
	void setCredentialOverrides(const string& aNick, const string& aPassword) noexcept {
		nickOverride = aNick;
		passwordOverride = aPassword;
	}
private:

	// Failover rotation state (ADC-EXT 4.21); guarded by cs, threaded to the next
	// instance through the aOldClient ctor parameter on each failover hop
	StringList failoverUrls;
	string failoverPrimaryUrl;
	int failoverHopCount = 0;
	uint64_t failoverWindowStart = 0;

	// Pick the next failover address to try after a connect-time failure; empty when
	// there is none (no list, address already connected, or the hop window is exhausted)
	string getNextFailoverUrl() noexcept;

	// Atomically consume the pending permanent-redirect target
	string takePendingPermanentRedirect() noexcept;

	// External-IP change handling; runs on the socket thread (via callAsync)
	void handleExternalIPChangedImpl(const string& aNewIP, bool aV6) noexcept;
	// Stamp the new address into our own user-list row and fire UserUpdated
	void updateMyIp(const string& aNewIP, bool aV6) noexcept;

	// Flap guard for the IP-change reconnect: one bounce per distinct address with a time
	// floor, so an oscillating detector can't bounce the hub in a loop. Socket-thread-only.
	string lastIpChangeReconnect4;
	string lastIpChangeReconnect6;
	uint64_t lastIpChangeReconnectTick = 0;

	// A change suppressed by the floor is parked here and re-evaluated when the floor
	// expires; without this the hub's record would stay stale until the NEXT address
	// change, because the settings-level compare swallows every later identical
	// detection. Socket-thread-only.
	string pendingIpReconnect4;
	string pendingIpReconnect6;
	// The tick to retry at (0 = nothing parked); the only piece the timer thread reads
	std::atomic<uint64_t> ipReconnectRetryTick { 0 };

	string port;
	const char separator;

	// Last used count type information for this hub
	CountType countType = COUNT_UNCOUNTED;
	bool countIsSharing = false;

	void destroySocket(const AsyncF& aShutdownAction = nullptr) noexcept;
	void handleFlood(const FloodCounter::FloodResult& aResult, const string& aMessage) noexcept;

	HubData* getPluginObject() noexcept override;

public:
	// See PluginEntity::copyPluginObjectDetached -- the find_hub copy path.
	HubData* copyDetachedPluginObject() noexcept;
};

} // namespace dcpp

#endif // !defined(CLIENT_H)
