/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/hub/NmdcHub.h>

#include <airdcpp/connectivity/ConnectivityManager.h>
#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/message/Message.h>
#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/search/SearchManager.h>
#include <airdcpp/share/ShareManager.h>
#include <airdcpp/core/crypto/CryptoManager.h>
#include <airdcpp/connection/ConnectionManager.h>
#include <airdcpp/core/version.h>

#include <airdcpp/connection/socket/Socket.h>
#include <airdcpp/hash/value/Encoder.h>
#include <airdcpp/hash/value/TigerHash.h>
#include <airdcpp/favorites/FavoriteManager.h>
#include <airdcpp/util/LinkUtil.h>
#include <airdcpp/hub/user_command/UserCommand.h>
#include <airdcpp/util/text/StringTokenizer.h>
#include <airdcpp/protocol/ProtocolCommandManager.h>
#include <airdcpp/queue/QueueManager.h>
#include <airdcpp/core/io/compress/ZUtils.h>
#include <airdcpp/connection/ThrottleManager.h>
#include <airdcpp/transfer/upload/UploadManager.h>
#include <airdcpp/hub/activity/ActivityManager.h>
#include <airdcpp/util/NetworkUtil.h>
#include <airdcpp/plugins/PluginManager.h>
#include <airdcpp/util/ValueGenerator.h>

namespace dcpp {

NmdcHub::NmdcHub(const string& aHubURL, const ClientPtr& aOldClient) : Client(aHubURL, '|', aOldClient)
{
}

NmdcHub::~NmdcHub() {

}

string NmdcHub::toUtf8(const string& str) noexcept {
	if (str.empty() || Text::validateUtf8(str)) {
		return str;
	}

	if (Util::stricmp(get(HubSettings::NmdcEncoding), Text::utf8) == 0) {
		// The hub is configured as UTF-8 but this line isn't. Bridged/mixed hubs relay
		// $MyINFO from legacy clients verbatim (CP1251/CP1252 bytes), so dropping the
		// line would silently lose those users from the list - keep the ASCII protocol
		// structure and replace only the invalid bytes instead.
		reportEncodingError(STRING(UTF_VALIDATION_ERROR));
		return Text::sanitizeUtf8(str);
	}

	auto ret = Text::toUtf8(str, get(HubSettings::NmdcEncoding));
	if (ret.empty()) {
		reportEncodingError(STRING_F(DECODING_ERROR, get(HubSettings::NmdcEncoding)));
	}

	return ret;
}

void NmdcHub::reportEncodingError(const string& aMessage) noexcept {
	// A single mismatched user produces one failing line per update, so report the
	// problem once per connection instead of flooding the status pane
	if (encodingErrorReported) {
		dcdebug("NmdcHub: suppressed repeated encoding error (%s)\n", aMessage.c_str());
		return;
	}

	encodingErrorReported = true;
	statusMessage(aMessage, LogMessage::SEV_ERROR);
}

string NmdcHub::fromUtf8(const string& str) noexcept {
	if (str.empty()) {
		return str;
	}

	auto ret = Text::fromUtf8(str, get(HubSettings::NmdcEncoding));
	if (ret.empty()) {
		statusMessage(STRING_F(INVALID_ENCODING, get(HubSettings::NmdcEncoding)), LogMessage::SEV_ERROR);
	}

	return ret;
}


#define checkstate() if(!stateNormal()) return

int NmdcHub::connect(const OnlineUser& aUser, const string&, string& /*lastError_*/) noexcept {
	if(stateNormal()) {
		dcdebug("NmdcHub::connect %s\n", aUser.getIdentity().getNick().c_str());
		if (hasActiveAddress()) {
			connectToMe(aUser);
		} else {
			revConnectToMe(aUser);
		}
	}

	return AdcCommand::SUCCESS;
}

bool NmdcHub::canSendActiveV4() const noexcept {
	return isActiveV4() && !localIp.empty();
}

bool NmdcHub::canSendActiveV6() const noexcept {
	// A v6 literal may only ever reach an IP64 hub; on anything else it would
	// be an unparseable line for the hub and every legacy client
	return (supportFlags & SUPPORTS_IP64) && isActiveV6() && !localIp6.empty();
}

const string& NmdcHub::myActiveAddress() const noexcept {
	if (canSendActiveV4()) {
		return localIp;
	}
	if (canSendActiveV6()) {
		return localIp6;
	}

	return Util::emptyString;
}

void NmdcHub::refreshLocalIp() noexcept {
	if((!CONNSETTING(NO_IP_OVERRIDE) || get(HubSettings::UserIp4).empty()) && !getMyIdentity().getIp4().empty()) {
		// Best case - the server detected it
		localIp = getMyIdentity().getIp4();
	} else {
		localIp.clear();
	}
	if(localIp.empty()) {
		localIp = get(HubSettings::UserIp4);
		if(!localIp.empty()) {
			localIp = Socket::resolve(localIp, AF_INET);
		}
		if(localIp.empty()) {
			// The hub socket itself may be connected over IPv6; its local
			// address must not poison the v4 slot
			if (!sock->isV6Valid()) {
				localIp = sock->getLocalIp();
			}
			if(localIp.empty()) {
				localIp = NetworkUtil::getLocalIp(false);
			}
		}
	}

	// The v6 address mirrors the v4 chain: hub-reported ($UserIP) first, then
	// the per-hub override, then the hub socket, then the adapter list
	if ((!CONNSETTING(NO_IP_OVERRIDE6) || get(HubSettings::UserIp6).empty()) && !getMyIdentity().getIp6().empty()) {
		localIp6 = getMyIdentity().getIp6();
	} else {
		localIp6.clear();
	}
	if (localIp6.empty()) {
		localIp6 = get(HubSettings::UserIp6);
		if (!localIp6.empty()) {
			localIp6 = Socket::resolve(localIp6, AF_INET6);
		}
		if (localIp6.empty()) {
			if (sock->isV6Valid()) {
				localIp6 = sock->getLocalIp();
			}
			if (localIp6.empty()) {
				localIp6 = NetworkUtil::getLocalIp(true);
			}
		}
	}
}

void NmdcHub::refreshUserList(bool refreshOnly) noexcept {
	if(refreshOnly) {
		RLock l(cs);

		OnlineUserList v;
		for(auto n: users | views::values)
			v.push_back(n);

		fire(ClientListener::UsersUpdated(), this, v);
	} else {
		clearUsers();
		getNickList();
	}
}

OnlineUserPtr NmdcHub::getUser(const string& aNick) noexcept {
	OnlineUserPtr u = nullptr;
	{
		RLock l(cs);
		
		auto i = users.find(aNick);
		if(i != users.end())
			return i->second;
	}

	UserPtr p;
	// The runtime nick can differ from the configured one after a $ClientNick (NMDC 4.5.14),
	// so match either or we would create a second, non-us entry for ourselves
	if(aNick == get(HubSettings::Nick) || (!getMyNick().empty() && aNick == getMyNick())) {
		p = ClientManager::getInstance()->getMe();
	} else {
		p = ClientManager::getInstance()->getNmdcUser(aNick, getHubUrl());
	}

	auto client = ClientManager::getInstance()->findClient(getHubUrl());

	{
		WLock l(cs);
		u = users.emplace(aNick, std::make_shared<OnlineUser>(p, client, ValueGenerator::rand())).first->second;
		u->getIdentity().setNick(aNick);
		if (u->getUser() == getMyIdentity().getUser()) {
			setMyIdentity(u->getIdentity());
		}
	}
	
	onUserConnected(u);
	return u;
}

// $NickChange <old> <new> (NMDC 4.5.13). The hub confirms with $ClientNick; until then we keep
// using the current nick, since the hub may simply refuse.
bool NmdcHub::changeNick(const string& aNick) noexcept {
	if (!(supportFlags & SUPPORTS_NICKCHANGE) || !stateNormal())
		return false;

	// A nick with a separator in it would corrupt the command framing
	if (aNick.empty() || aNick.find_first_of(" |$") != string::npos)
		return false;

	const auto currentNick = getMyNick();
	if (aNick == currentNick)
		return false;

	send("$NickChange " + fromUtf8(currentNick) + " " + fromUtf8(aNick) + "|");
	return true;
}

void NmdcHub::supports(const StringList& feat) {
	string x;
	for(const auto& f: feat)
		x+= f + ' ';

	send("$Supports " + x + '|');
}

OnlineUserPtr NmdcHub::findUser(const string& aNick) const noexcept {
	RLock l(cs);
	NickIter i = users.find(aNick);
	return i == users.end() ? nullptr : i->second;
}


OnlineUserPtr NmdcHub::findUser(dcpp::SID aSID) const noexcept {
	RLock l(cs);
	auto i = ranges::find_if(users | views::values, [=](const OnlineUserPtr& u) {
		return u->getIdentity().getSID() == aSID;
	});

	return i.base() != users.end() ? *i : nullptr;
}

void NmdcHub::putUser(const string& aNick) noexcept {
	OnlineUserPtr ou = nullptr;
	{
		WLock l(cs);
		NickIter i = users.find(aNick);
		if(i == users.end())
		return;
		ou = i->second;
		users.erase(i);

		availableBytes.fetch_sub(ou->getIdentity().getBytesShared());
	}

	onUserDisconnected(ou, false);
}

void NmdcHub::clearUsers() noexcept {
	NickMap u2;

	{
		WLock l(cs);
		u2.swap(users);
		availableBytes.store(0);
	}

	for(auto ou: u2 | views::values) {
		ClientManager::getInstance()->putOffline(ou);
	}
}

void NmdcHub::updateFromTag(Identity& id, const string& tag) {
	StringTokenizer<string> tok(tag, ',');
	string::size_type j;
	id.set("US", Util::emptyString);
	//if(tag.find("AirDC++") != string::npos)
	//	id.getUser()->setFlag(User::AIRDCPLUSPLUS);

	for(auto& i: tok.getTokens()) {
		if(i.length() < 2)
			continue;

		if(i.compare(0, 2, "H:") == 0) {
			StringTokenizer<string> t(i.substr(2), '/', true);
			if(t.getTokens().size() != 3)
				continue;
			id.set("HN", t.getTokens()[0]);
			id.set("HR", t.getTokens()[1]);
			id.set("HO", t.getTokens()[2]);
		} else if(i.compare(0, 2, "S:") == 0) {
			id.set("SL", i.substr(2));		
		} else if((j = i.find("V:")) != string::npos) {
			if (j > 2)
				id.set("AP", i.substr(0, j-1));
			i.erase(i.begin(), i.begin() + j + 2);
			id.set("VE", i);
		} else if(i.compare(0, 2, "M:") == 0) {
			// User flags are global across hubs: never rewrite them from our
			// own echoed tag (an IP64 hub may translate/rewrite it)
			const auto self = id.getUser() == getMyIdentity().getUser();
			if(i.size() == 3) {
				if (self)
					continue;
				if(i[2] == 'A')
					id.getUser()->unsetFlag(User::PASSIVE);
				else
					id.getUser()->setFlag(User::PASSIVE);
			} else if(i.size() == 4 && (supportFlags & SUPPORTS_IP64)) {
				// IP64 mode tag M:XY - X = IPv4 mode (A/P/5, or N when the
				// client has no IPv4), Y = IPv6 mode. Stored per hub on the
				// Identity as the ADC-style connectivity tokens so the
				// existing per-family predicates and mode columns work
				// unchanged (a global User flag would alias across hubs
				// with different capabilities).
				string su;
				if (i[2] == 'A') {
					su = "TCP4,UDP4";
				}
				if (i[3] == 'A') {
					su += su.empty() ? "TCP6,UDP6" : ",TCP6,UDP6";
				}
				id.setSupports(su);

				if (self)
					continue;
				if (i[2] == 'A')
					id.getUser()->unsetFlag(User::PASSIVE);
				else
					id.getUser()->setFlag(User::PASSIVE);
			}
		} else if((j = i.find("L:")) != string::npos) {
			i.erase(i.begin() + j, i.begin() + j + 2);
			// Widened and clamped. This is a remote string: toInt() * 1024 overflowed a signed int
			// for anything above about two million, which is undefined behaviour reached directly
			// from a hub line, and a nonsense limit either way.
			const auto limitKib = Util::toInt64(i);
			constexpr int64_t maxKib = numeric_limits<int64_t>::max() / 1024;
			id.set("US", Util::toString(limitKib <= 0 ? 0 : min(limitKib, maxKib) * 1024));
		}
	}
	/// @todo Think about this
	id.set("TA", '<' + tag + '>');
}

// Identity field appliers shared by $MyINFO and the incremental $IN (NMDC 4.5.11). $IN carries
// exactly the same fields, one at a time, so both paths must apply them identically.

void NmdcHub::applyDescription(const OnlineUserPtr& u, const string& aRawDescription) noexcept {
	auto description = unescape(aRawDescription);

	// Look for a tag...
	if (!description.empty() && description.back() == '>') {
		auto x = description.rfind('<');
		if (x != string::npos) {
			// Hm, we have something...disassemble it...
			updateFromTag(u->getIdentity(), description.substr(x + 1, description.length() - x - 2));
			description.erase(x);
		}
	}

	u->getIdentity().setDescription(description);
}

void NmdcHub::applyConnection(const OnlineUserPtr& u, const string& aConnection) noexcept {
	if (aConnection.empty()) {
		// No connection = bot... 	 VERY unreliable but...
		// Users cant understand why it sends away messages to bots/opchats so...
		u->getUser()->setFlag(User::BOT);
		u->getIdentity().setBot(true);
	} else if (u->getIdentity().get("BL").empty()) {
		// Never clear a $BotList-confirmed bot ("BL"); only the heuristic flag may flip back
		u->getUser()->unsetFlag(User::BOT);
		u->getIdentity().setBot(false);
	}

	u->getIdentity().setNmdcConnection(aConnection);
}

void NmdcHub::applyStatus(const OnlineUserPtr& u, uint8_t aStatus) noexcept {
	u->getIdentity().setStatus(Util::toString(aStatus));

	// User flags are global across hubs: never rewrite them from our own
	// echoed $MyINFO (an IP64 hub owns the high status bits and may
	// rewrite the whole byte)
	if (u->getUser() != getMyIdentity().getUser()) {
		if(u->getIdentity().getStatus() & Identity::TLS) {
			u->getUser()->setFlag(User::TLS);
		} else {
			u->getUser()->unsetFlag(User::TLS);
		}

		if(u->getIdentity().getStatus() & Identity::NAT) {
			u->getUser()->setFlag(User::NAT_TRAVERSAL);
		} else {
			u->getUser()->unsetFlag(User::NAT_TRAVERSAL);
		}
	}

	// Skip our own echoed identity for consistency with the flag writes
	// above (our outbound family choice comes from Client settings, not our
	// own parsed identity, so this is belt-and-suspenders)
	if ((supportFlags & SUPPORTS_IP64) && u->getUser() != getMyIdentity().getUser()) {
		// Hub-verified per-family availability: the hub sets these bits
		// itself once it has gathered each address. Verified absence
		// overrides the self-declared M: modes stored as connectivity
		// tokens by updateFromTag above.
		const auto status = u->getIdentity().getStatus();
		if (!(status & Identity::IP64_IPV4) || !(status & Identity::IP64_IPV6)) {
			string su;
			for (const auto& token : u->getIdentity().getSupports()) {
				const auto v4Token = token == "TCP4" || token == "UDP4";
				const auto v6Token = token == "TCP6" || token == "UDP6";
				if ((v4Token && !(status & Identity::IP64_IPV4)) || (v6Token && !(status & Identity::IP64_IPV6))) {
					continue;
				}

				su += su.empty() ? token : "," + token;
			}

			u->getIdentity().setSupports(su);
		}
	}
}

void NmdcHub::applyShared(const OnlineUserPtr& u, const string& aBytesShared) noexcept {
	availableBytes.fetch_sub(u->getIdentity().getBytesShared());
	u->getIdentity().setBytesShared(aBytesShared);
	availableBytes.fetch_add(u->getIdentity().getBytesShared());
}

// $IN carries a 32-bit status word whose layout diverges from the $MyINFO status byte above bit 4:
// bit 5 is OP and bit 6 is bot, where $MyINFO has TLS and NAT. It must be translated rather than
// stored raw, or every operator would be read as a TLS user.
void NmdcHub::applyInStatus(const OnlineUserPtr& u, uint32_t aFlags) noexcept {
	enum InStatusFlags : uint32_t {
		IN_NORMAL		= 0x001,
		IN_AWAY			= 0x002,
		IN_SERVER		= 0x004,
		IN_FIREBALL		= 0x008,
		IN_OP			= 0x010,
		IN_BOT			= 0x020,
		IN_DND			= 0x040,
		IN_TLS			= 0x080,
		IN_PARTIAL		= 0x100
	};

	uint8_t status = 0;
	if (aFlags & IN_NORMAL)		status |= Identity::NORMAL;
	if (aFlags & IN_AWAY)		status |= Identity::AWAY;
	if (aFlags & IN_SERVER)		status |= Identity::SERVER;
	if (aFlags & IN_FIREBALL)	status |= Identity::FIREBALL;
	if (aFlags & IN_TLS)		status |= Identity::TLS;

	// $IN has no room for the hub-set IP64 family bits, so carry the current ones over instead of
	// letting an incremental update strip the user's advertised connectivity
	status |= static_cast<uint8_t>(u->getIdentity().getStatus() & (Identity::IP64_IPV4 | Identity::IP64_IPV6));

	applyStatus(u, status);

	// Read-only per the spec: only the hub sets these
	u->getIdentity().setOp((aFlags & IN_OP) != 0);
	if (aFlags & IN_BOT) {
		u->getUser()->setFlag(User::BOT);
		u->getIdentity().setBot(true);
	}

	// IN_DND and IN_PARTIAL have no equivalent in our identity model and are ignored
}

// $IN tag parts are space separated and each carries its own one-character identifier, unlike the
// comma separated "K:value" form in $MyINFO. Re-assemble the $MyINFO shape so updateFromTag stays
// the single implementation (it owns the IP64 M:XY handling, hub counts, and the displayed tag).
void NmdcHub::applyInTag(const OnlineUserPtr& u, const string& aTag) noexcept {
	string client, version, mode, hubs, slots, freeSlots, limit;

	StringTokenizer<string> tokens(aTag, ' ');
	for (const auto& token : tokens.getTokens()) {
		if (token.empty())
			continue;

		const auto value = token.substr(1);
		switch (token[0]) {
			case 'c': client = value; break;
			case 'v': version = value; break;
			case 'm': mode = value; break;
			case 'h': hubs = value; break;
			case 's': slots = value; break;
			case 'f': freeSlots = value; break;
			case 'l': limit = value; break;
			// 'o' and 'r' (automatic slots, reverse bandwidth) have no identity field here
			default: break;
		}
	}

	string tag;
	auto append = [&tag](const string& aToken) {
		if (!aToken.empty())
			tag += tag.empty() ? aToken : "," + aToken;
	};

	if (!client.empty() || !version.empty())
		append(client.empty() ? "V:" + version : client + " V:" + version);
	append(mode.empty() ? Util::emptyString : "M:" + mode);
	append(hubs.empty() ? Util::emptyString : "H:" + hubs);
	append(slots.empty() ? Util::emptyString : "S:" + slots);
	append(limit.empty() ? Util::emptyString : "L:" + limit);

	if (!tag.empty())
		updateFromTag(u->getIdentity(), tag);

	// Free slots have no $MyINFO tag token, so they are set directly
	if (!freeSlots.empty())
		u->getIdentity().set("FS", freeSlots);
}

void NmdcHub::onLine(const string& aLine) noexcept {
	if(aLine.empty())
		return;

	if(aLine[0] != '$') {
		// Check if we're being banned...
		if(!stateNormal()) {
			if(Util::findSubString(aLine, "banned") != string::npos) {
				setAutoReconnect(false);
			}
		}
		string line = toUtf8(aLine);
		if (line.empty()) {
			return;
		}

		if(line[0] != '<') {
			statusMessage(unescape(line), LogMessage::SEV_INFO);
			return;
		}
		string::size_type i = line.find('>', 2);
		if(i == string::npos) {
			statusMessage(unescape(line), LogMessage::SEV_INFO);
			return;
		}
		string nick = line.substr(1, i-1);
		string message;
		if((line.length()-1) > i && line[i+1] == ' ') {
			message = line.substr(i+2);
		} else {
			statusMessage(unescape(line), LogMessage::SEV_INFO);
			return;
		}

		if((line.find("Hub-Security") != string::npos) && (line.find("was kicked by") != string::npos)) {
			statusMessage(unescape(line), LogMessage::SEV_VERBOSE);
			return;
		} else if((line.find("is kicking") != string::npos) && (line.find("because:") != string::npos)) {
			statusMessage(unescape(line), LogMessage::SEV_VERBOSE);
			return;
		}

		bool thirdPerson = false;
		auto text = unescape(message);
		if (Util::strnicmp(text, "/me ", 4) == 0) {
			thirdPerson = true;
			text = text.substr(4);
		}

		auto chatMessage = std::make_shared<ChatMessage>(text, findUser(nick));
		chatMessage->setThirdPerson(thirdPerson);

		if(!chatMessage->getFrom()) {
			auto o = getUser(nick);
			// Assume that messages from unknown users come from the hub
			o->getIdentity().setHub(true);
			o->getIdentity().setHidden(true);
			fire(ClientListener::UserUpdated(), this, o);

			chatMessage->setFrom(o);
		}

		if(PluginManager::getInstance()->runHook<HubData>(HOOK_CHAT_IN, this, chatMessage->getText()))
			return;

		onChatMessage(chatMessage);
		return;
    }

 	string cmd;
	string param;
	string::size_type x;
	
	if( (x = aLine.find(' ')) == string::npos) {
		cmd = aLine.substr(1);
	} else {
		cmd = aLine.substr(1, x - 1);
		param = toUtf8(aLine.substr(x+1));
	}

	if(cmd == "Search") {
		if (!stateNormal()) {
			return;
		}
		string::size_type i = 0;
		string::size_type j = param.find(' ', i);
		if(j == string::npos || i == j)
			return;
		
		string seeker = param.substr(i, j-i);

		bool isPassive = seeker.size() > 4 && seeker.compare(0, 4, "Hub:") == 0;
		bool meActive = hasActiveAddress();

		// Filter own searches (an IP64 hub may translate the seeker and echo
		// either address family back)
		if (meActive && !isPassive) {
			const auto& searchPort = SearchManager::getInstance()->getPort();
			if (seeker == (localIp + ":" + searchPort) ||
				(!localIp6.empty() && seeker == (localIp6 + ":" + searchPort))) {
				return;
			}
		} else if (isPassive && Util::stricmp(seeker.c_str() + 4, getMyNick().c_str()) == 0) {
			return;
		}

		i = j + 1;

		{
			// Nick (passive) or IP (active)
			auto target = isPassive ? seeker.substr(4) : seeker;
			if (!checkIncomingSearch(target)) {
				return;
			}
		}

		// An active seeker is used verbatim as the UDP destination for our reply. It is hub-supplied
		// and was never checked to be an address, so a hub could put a NAME there and have every
		// client that saw the search resolve it and send it a datagram -- a resolver and reflector
		// pointed wherever the hub liked, from every connected client at once. Require a literal.
		if (!isPassive) {
			const auto portSep = seeker.rfind(':');
			const auto host = portSep == string::npos ? seeker : seeker.substr(0, portSep);
			if (host.empty() || !NetworkUtil::isValidIp(host)) {
				dcdebug("NmdcHub::onSearch: non-literal seeker address, ignoring\n");
				return;
			}
		}

		if(i + 2 >= param.size())
			return;

		int a;
		if(param[i] == 'F') {
			a = Search::SIZE_DONTCARE;
		} else if(param[i+2] == 'F') {
			a = Search::SIZE_ATLEAST;
		} else {
			a = Search::SIZE_ATMOST;
		}
		i += 4;
		j = param.find('?', i);
		if(j == string::npos || i == j)
			return;
		string size = param.substr(i, j-i);
		i = j + 1;
		j = param.find('?', i);
		if(j == string::npos || i == j)
			return;
		int type = Util::toInt(param.substr(i, j-i)) - 1;
		i = j + 1;
		string terms = unescape(param.substr(i));

		// without terms, this is an invalid search.
		if (!terms.empty()) {
			if (isPassive) {
				// mark the user as passive
				auto u = findUser(seeker.substr(4));
				if (!u) {
					return;
				}

				if(!u->getUser()->isSet(User::PASSIVE)) {
					u->getUser()->setFlag(User::PASSIVE);
					updated(u);
				}

				// ignore if we or remote client don't support NAT traversal in passive mode
				// although many NMDC hubs won't send us passive if we're in passive too, so just in case...
				if(!meActive && !u->getUser()->isSet(User::NAT_TRAVERSAL))
					return;
			}

			SearchManager::getInstance()->respond(this, seeker, a, Util::toInt64(size), type, terms, isPassive);
		}
	} else if(cmd == "SA") {
		// TTHS active short search: $SA <tth> <ip>:<port> (equivalent to a full TTH $Search)
		if (!stateNormal())
			return;
		string::size_type sp = param.find(' ');
		if (sp == string::npos || sp == 0)
			return;
		string tth = param.substr(0, sp);
		string addr = param.substr(sp + 1);
		if (tth.empty() || addr.empty())
			return;
		// Filter our own search echoed back by the hub (either address family
		// on an IP64 hub)
		if (hasActiveAddress()) {
			const auto& searchPort = SearchManager::getInstance()->getPort();
			if (addr == (localIp + ":" + searchPort) || (!localIp6.empty() && addr == (localIp6 + ":" + searchPort)))
				return;
		}
		if (!checkIncomingSearch(addr))
			return;

		// The address is hub-supplied and used verbatim as the UDP destination for our reply, so it
		// was never checked to be an address at all: a hub could put a NAME there and have every
		// client that saw the search resolve it and send it a datagram. Require a literal.
		{
			const auto portSep = addr.rfind(':');
			const auto host = portSep == string::npos ? addr : addr.substr(0, portSep);
			if (host.empty() || !NetworkUtil::isValidIp(host)) {
				dcdebug("NmdcHub: non-literal search reply address, ignoring\n");
				return;
			}
		}
		SearchManager::getInstance()->respond(this, addr, Search::SIZE_DONTCARE, 0, Search::TYPE_TTH, "TTH:" + tth, false);
	} else if(cmd == "SP") {
		// TTHS passive short search: $SP <tth> <nick>
		if (!stateNormal())
			return;
		string::size_type sp = param.find(' ');
		if (sp == string::npos || sp == 0)
			return;
		string tth = param.substr(0, sp);
		string nick = param.substr(sp + 1);
		if (tth.empty() || nick.empty())
			return;
		if (Util::stricmp(nick.c_str(), getMyNick().c_str()) == 0)
			return;
		if (!checkIncomingSearch(nick))
			return;
		auto u = findUser(nick);
		if (!u)
			return;
		if (!u->getUser()->isSet(User::PASSIVE)) {
			u->getUser()->setFlag(User::PASSIVE);
			updated(u);
		}
		// Passive-to-passive transfers need NAT traversal on both sides
		if (!hasActiveAddress() && !u->getUser()->isSet(User::NAT_TRAVERSAL))
			return;
		SearchManager::getInstance()->respond(this, "Hub:" + nick, Search::SIZE_DONTCARE, 0, Search::TYPE_TTH, "TTH:" + tth, true);
	} else if(cmd == "MyINFO") {
		string::size_type i, j;
		i = 5;
		j = param.find(' ', i);
		if( (j == string::npos) || (j == i) )
			return;
		string nick = param.substr(i, j-i);
		
		if(nick.empty())
			return;

		i = j + 1;

		auto u = getUser(nick);

		// If he is already considered to be the hub (thus hidden), probably should appear in the UserList
		if(u->getIdentity().isHidden()) {
			u->getIdentity().setHidden(false);
			u->getIdentity().setHub(false);
		}

		j = param.find('$', i);
		if(j == string::npos)
			return;

		applyDescription(u, param.substr(i, j-i));

		i = j + 3;
		j = param.find('$', i);
		if(j == string::npos)
			return;

		string connection = (i == j) ? Util::emptyString : param.substr(i, j-i-1);

		applyConnection(u, connection);

		u->getIdentity().setHub(false);
		u->getIdentity().setHidden(false);

		// Read the status byte unsigned: a high-bit flag (0x80) in a signed char would
		// otherwise become a negative value and corrupt the whole status word.
		applyStatus(u, static_cast<uint8_t>(param[j-1]));

		i = j + 1;
		j = param.find('$', i);

		if(j == string::npos)
			return;

		u->getIdentity().setEmail(unescape(param.substr(i, j-i)));

		i = j + 1;
		j = param.find('$', i);
		if(j == string::npos)
			return;

		applyShared(u, param.substr(i, j-i));

		if(u->getUser() == getMyIdentity().getUser()) {
			setMyIdentity(u->getIdentity());
		}
		
		fire(ClientListener::UserUpdated(), this, u);
	} else if(cmd == "IN") {
		// $IN <nick>$<part>[$<part>...] (NMDC 4.5.11): the incremental replacement for $MyINFO.
		// Every part is a one-character identifier followed by its data; an identifier with no
		// data clears that field. Unlisted fields keep their current value.
		auto sep = param.find('$');
		const string nick = param.substr(0, sep);
		if (nick.empty())
			return;

		auto u = getUser(nick);

		// Same as $MyINFO: an entry we had written off as the hub is a real user after all
		if (u->getIdentity().isHidden()) {
			u->getIdentity().setHidden(false);
			u->getIdentity().setHub(false);
		}

		bool updatedIdentity = false;
		if (sep != string::npos) {
			StringTokenizer<string> parts(param.substr(sep + 1), '$');
			for (const auto& part : parts.getTokens()) {
				if (part.empty())
					continue;

				const auto data = part.substr(1);
				switch (part[0]) {
				case 'D':
					applyDescription(u, data);
					break;
				case 'C':
					if (data.empty()) {
						// An explicit clear, not $MyINFO's "empty connection means bot" heuristic
						u->getIdentity().setNmdcConnection(Util::emptyString);
					} else {
						applyConnection(u, data);
					}
					break;
				case 'E':
					u->getIdentity().setEmail(unescape(data));
					break;
				case 'S':
					applyShared(u, data);
					break;
				case 'F':
					applyInStatus(u, static_cast<uint32_t>(Util::toInt(data)));
					break;
				case 'T':
					applyInTag(u, data);
					break;
				default:
					// Unknown part identifier: leave the identity alone rather than guessing
					continue;
				}

				updatedIdentity = true;
			}
		}

		if (!updatedIdentity)
			return;

		if (u->getUser() == getMyIdentity().getUser()) {
			setMyIdentity(u->getIdentity());
		}

		fire(ClientListener::UserUpdated(), this, u);
	} else if(cmd == "Quit") {
		if(!param.empty()) {
			const string& nick = param;
			OnlineUserPtr u = findUser(nick);
			if(!u)
				return;

			// putUser reaches Client::onUserDisconnected, which fires UserRemoved itself -- an
			// explicit fire here made it two per departure, so every subscribed web/extension client
			// saw two disconnect events and the hub frame queued two removals. It also fired while
			// the user was still in the list and still flagged online, i.e. before putOffline.
			// Every other removal path (clearUsers, AdcHub::putUser) fires exactly once.
			putUser(nick);
		}
	} else if(cmd == "ConnectToMe") {
		if(!stateNormal()) {
			return;
		}

		// $ConnectToMe <mynick> <addr>:<port>[S|R|RS|N|NS] [<sendernick>]
		// The address may be IPv4, bare IPv6 (IP64 hubs translate it per
		// recipient) or bracketed IPv6 from other client implementations.
		string::size_type i = param.find(' ');
		if( (i == string::npos) || ((i + 1) >= param.size()) ) {
			return;
		}
		i++;

		string senderNick;
		string addrPort;
		auto j = param.find(' ', i);
		if (j == string::npos) {
			addrPort = param.substr(i);
		} else {
			addrPort = param.substr(i, j - i);
			senderNick = param.substr(j + 1);
		}

		// Peel the trailing flag letters off before the address parse: they
		// are appended to the port digits and would otherwise defeat the
		// bare-IPv6 port detection. None of S/R/N is a hex digit, so an
		// IPv6 group can never lose characters here.
		string flagSuffix;
		while (!addrPort.empty() && (addrPort.back() == 'S' || addrPort.back() == 'R' || addrPort.back() == 'N')) {
			flagSuffix.insert(flagSuffix.begin(), addrPort.back());
			addrPort.pop_back();
		}

		string server, senderPort;
		Util::parseIpPort(addrPort, server, senderPort);
		if (server.empty() || senderPort.empty()) {
			return;
		}

		// Only plain IP literals are accepted: a hostname here would let the
		// hub use this client as a connect-anywhere proxy, and garbage must
		// never reach the resolver
		if (!NetworkUtil::isValidIp(server)) {
			return;
		}

		bool connectSecure = false;
		if (!flagSuffix.empty() && flagSuffix.back() == 'S') {
			flagSuffix.pop_back();
			if(CryptoManager::getInstance()->TLSOk()) {
				connectSecure = true;
			}
		}

		if (!checkIncomingCTM(server)) {
			return;
		}

		if (flagSuffix == "N") {
			if(senderNick.empty())
				return;

			// Trigger connection attempt sequence locally ...
			SocketConnectOptions connectOptions(senderPort, connectSecure, NatRole::CLIENT);
			ConnectionManager::getInstance()->nmdcConnect(server, connectOptions, Util::toString(sock->getLocalPort()),
				getMyNick(), getHubUrl(), get(HubSettings::NmdcEncoding));

			// ... and signal other client to do likewise. Reply over the
			// family the peer's address belongs to; bail if we have no address
			// of that family rather than emit a malformed ":port".
			const auto& natIp = server.find(':') != string::npos ? localIp6 : localIp;
			if (natIp.empty()) {
				return;
			}
			send("$ConnectToMe " + fromUtf8(senderNick) + " " + natIp + ":" + Util::toString(sock->getLocalPort()) + (connectSecure ? "RS" : "R") + "|");
			return;
		} else if (flagSuffix == "R") {
			// Trigger connection attempt sequence locally
			SocketConnectOptions connectOptions(senderPort, connectSecure, NatRole::SERVER);
			ConnectionManager::getInstance()->nmdcConnect(server, connectOptions, Util::toString(sock->getLocalPort()),
				getMyNick(), getHubUrl(), get(HubSettings::NmdcEncoding));
			return;
		} else if (!flagSuffix.empty()) {
			return;
		}

		// For simplicity, we make the assumption that users on a hub have the same character encoding
		SocketConnectOptions connectOptions(senderPort, connectSecure);
		ConnectionManager::getInstance()->nmdcConnect(server, connectOptions, getMyNick(), getHubUrl(), get(HubSettings::NmdcEncoding));
	} else if(cmd == "RevConnectToMe") {
		if(!stateNormal()) {
			return;
		}

		string::size_type j = param.find(' ');
		if(j == string::npos) {
			return;
		}

		OnlineUserPtr u = findUser(param.substr(0, j));
		if (!u)
			return;

		if (hasActiveAddress()) {
			connectToMe(*u);
		} else if(u->getIdentity().getStatus() & Identity::NAT) {
			bool connectSecure = CryptoManager::getInstance()->TLSOk() && u->getUser()->isSet(User::TLS);
			// NMDC v2.205 supports "$ConnectToMe sender_nick remote_nick ip:port", but many NMDC hubsofts block it
			// sender_nick at the end should work at least in most used hubsofts
			send("$ConnectToMe " + fromUtf8(u->getIdentity().getNick()) + " " + localIp + ":" + Util::toString(sock->getLocalPort()) + (connectSecure ? "NS " : "N ") + fromUtf8(getMyNick()) + "|");
		} else {
			if(!u->getUser()->isSet(User::PASSIVE)) {
				u->getUser()->setFlag(User::PASSIVE);
				// Notify the user that we're passive too...
				revConnectToMe(*u);
				updated(u);

				return;
			}
		}
	} else if(cmd == "SR") {
		SearchManager::getInstance()->onSR(aLine);
	} else if(cmd == "HubName") {


		// Workaround replace newlines in topic with spaces, to avoid funny window titles //ApexDC
		// If " - " found, the first part goes to hub name, rest to description
		// If no " - " found, first word goes to hub name, rest to description

		string::size_type i;
		while((i = param.find("\r\n")) != string::npos)
			param.replace(i, 2, " ");
		i = param.find(" - ");
		if(i == string::npos) {
			i = param.find(' ');
			if(i == string::npos) {
				hubIdentity.setNick(unescape(param));
				hubIdentity.setDescription(Util::emptyString);
			} else {
				hubIdentity.setNick(unescape(param.substr(0, i)));
				hubIdentity.setDescription(unescape(param.substr(i+1)));
			}
		} else {
			hubIdentity.setNick(unescape(param.substr(0, i)));
			hubIdentity.setDescription(unescape(param.substr(i+3)));
		}
		fire(ClientListener::HubUpdated(), this);

		

	} else if(cmd == "Supports") {
		StringTokenizer<string> st(param, ' ', true);
		for(const auto& i: st.getTokens()) {
			if(i == "UserCommand") {
				supportFlags |= SUPPORTS_USERCOMMAND;
			} else if(i == "NoGetINFO") {
				supportFlags |= SUPPORTS_NOGETINFO;
			} else if(i == "UserIP2") {
				supportFlags |= SUPPORTS_USERIP2;
			} else if(i == "SaltPass") {
				supportFlags |= SUPPORTS_SALTPASS;
			} else if(i == "MCTo") {
				supportFlags |= SUPPORTS_MCTO;
			} else if(i == "NickRule") {
				supportFlags |= SUPPORTS_NICKRULE;
			} else if(i == "SearchRule") {
				supportFlags |= SUPPORTS_SEARCHRULE;
			} else if(i == "TTHS") {
				supportFlags |= SUPPORTS_TTHS;
			} else if(i == "FailOver") {
				supportFlags |= SUPPORTS_FAILOVER;
			} else if(i == "HubURL") {
				supportFlags |= SUPPORTS_HUBURL;
			} else if(i == "IP64") {
				// NMDC IPv4/IPv6 extensions (protocol doc 1.3): both are
				// announced with this single token
				supportFlags |= SUPPORTS_IP64;
			} else if(i == "NickChange" || i == "ClientNick") {
				// The hub acknowledges a runtime nick change with $ClientNick (NMDC 4.5.13-14);
				// hubs announce one or both tokens
				supportFlags |= SUPPORTS_NICKCHANGE;
			}
		}

		// If the hub can report its canonical URL, ask for it (reply arrives as $MyHubURL).
		if (supportFlags & SUPPORTS_HUBURL) {
			send("$GetHubURL|");
		}

		// NMDC does not guarantee the hub's $Supports precedes $Hello: when
		// IP64 is learned after the first $MyINFO went out, re-send it so the
		// mode tag and status byte take their IP64 shape (alwaysSend bypasses
		// the anti-spam guard, so it goes out immediately; no loop - myInfo
		// never re-triggers $Supports)
		if ((supportFlags & SUPPORTS_IP64) && getConnectState() == STATE_NORMAL) {
			myInfo(true);
		}
	} else if(cmd == "UserCommand") {
		string::size_type i = 0;
		string::size_type j = param.find(' ');
		if(j == string::npos)
			return;

		int type = Util::toInt(param.substr(0, j));
		i = j+1;
 		if(type == UserCommand::TYPE_SEPARATOR || type == UserCommand::TYPE_CLEAR) {
			int ctx = Util::toInt(param.substr(i));
			fire(ClientListener::HubUserCommand(), this, type, ctx, Util::emptyString, Util::emptyString);
		} else if(type == UserCommand::TYPE_RAW || type == UserCommand::TYPE_RAW_ONCE) {
			j = param.find(' ', i);
			if(j == string::npos)
				return;
			int ctx = Util::toInt(param.substr(i));
			i = j+1;
			j = param.find('$', i);
			if(j == string::npos)
				return;
			string name = unescape(param.substr(i, j-i));
			// NMDC uses '\' as a separator but both ADC and our internal representation use '/'
			Util::replace("/", "//", name);
			Util::replace("\\", "/", name);
			i = j+1;
			string command = unescape(param.substr(i, param.length() - i));
			fire(ClientListener::HubUserCommand(), this, type, ctx, name, command);
		}
	} else if(cmd == "Lock") {
		if(getConnectState() != STATE_PROTOCOL || aLine.size() < 6) {
			return;
		}

		setConnectState(STATE_IDENTIFY);

		// Param must not be toUtf8'd...
		param = aLine.substr(6);

		if(!param.empty()) {
			string::size_type j = param.find(" Pk=");
			string lock, pk;
			if( j != string::npos ) {
				lock = param.substr(0, j);
				pk = param.substr(j + 4);
			} else {
				// Workaround for faulty linux hubs...
				j = param.find(' ');
				if(j != string::npos)
					lock = param.substr(0, j);
				else
					lock = param;
			}

			if(CryptoManager::getInstance()->isExtended(lock)) {
				StringList feat;
				feat.emplace_back("UserCommand");
				feat.emplace_back("NoGetINFO");
				feat.emplace_back("NoHello");
				feat.emplace_back("UserIP2");
				feat.emplace_back("TTHSearch");
				feat.emplace_back("ZPipe0");
				feat.emplace_back("MCTo");
				feat.emplace_back("SaltPass");
				feat.emplace_back("BotList");
				feat.emplace_back("TTHS");
				feat.emplace_back("NickRule");
				feat.emplace_back("SearchRule");
				feat.emplace_back("FailOver");
				feat.emplace_back("HubURL");
				feat.emplace_back("IP64");
				// The hub only sends $HubTopic to clients that ask for it (NMDC 4.5.8),
				// so the token is required for the handler below to ever fire.
				feat.emplace_back("HubTopic");
				// Incremental $MyINFO updates (NMDC 4.5.11)
				feat.emplace_back("IN");
				// Runtime nick changes (NMDC 4.5.13-14): we send $NickChange, the hub acks
				// with $ClientNick
				feat.emplace_back("NickChange");
				feat.emplace_back("ClientNick");

				if(CryptoManager::getInstance()->TLSOk())
					feat.emplace_back("TLS");
					
				supports(feat);
			}

			key(CryptoManager::getInstance()->makeKey(lock));
			auto& ou = *getUser(get(HubSettings::Nick));
			validateNick(ou.getIdentity().getNick());
		}
	} else if(cmd == "Hello") {
		if(!param.empty()) {
			auto u = getUser(param);

			if(u->getUser() == getMyIdentity().getUser()) {
				// u.getUser()->setFlag(User::AIRDCPLUSPLUS);
				if (hasActiveAddress())
					u->getUser()->unsetFlag(User::PASSIVE);
				else
					u->getUser()->setFlag(User::PASSIVE);
			}

			if((getConnectState() == STATE_IDENTIFY || getConnectState() == STATE_VERIFY) && u->getUser() == getMyIdentity().getUser()) {
				setConnectState(STATE_NORMAL);
				updateCounts(false);
				fire(ClientListener::HubUpdated(), this);

				version();
				getNickList();
				myInfo(true);
			}

			fire(ClientListener::UserUpdated(), this, u);
		}
	} else if(cmd == "ForceMove") {
		onForceMove(param);
	} else if(cmd == "HubIsFull") {
		fire(ClientListener::HubFull(), this);
	} else if(cmd == "ValidateDenide") {		// Mind the spelling...
		disconnect(false);
		statusMessage(STRING(NICK_TAKEN), LogMessage::SEV_ERROR);
	} else if(cmd == "UserIP") {
		if(!param.empty()) {
			OnlineUserList v;
			StringTokenizer<string> t(param, "$$", true);
			for(const auto& it: t.getTokens()) {
				string::size_type j = 0;
				if((j = it.find(' ')) == string::npos)
					continue;
				if((j+1) == it.length())
					continue;

				auto u = findUser(it.substr(0, j));

				if(!u)
					continue;

				// The hub reports one address per nick; store it in the slot
				// of its actual family (an IP64 hub may report IPv6) and drop
				// anything that is not a plain IP literal
				auto ip = it.substr(j+1);
				if (ip.find(':') != string::npos) {
					if (!NetworkUtil::isValidIp(ip, AF_INET6))
						continue;
					u->getIdentity().setIp6(ip);
				} else {
					if (!NetworkUtil::isValidIp(ip, AF_INET))
						continue;
					u->getIdentity().setIp4(ip);
				}

				if(u->getUser() == getMyIdentity().getUser()) {
					setMyIdentity(u->getIdentity());
					refreshLocalIp();
				}
				v.push_back(u);
			}

			updated(v);
		}
	} else if(cmd == "NickList") {
		if(!param.empty()) {
			OnlineUserList v;
			StringTokenizer<string> t(param, "$$");
			StringList& sl = t.getTokens();

			for(const auto& it: sl) {
				v.push_back(getUser(it));
			}

			if(!(supportFlags & SUPPORTS_NOGETINFO)) {
				string tmp;
				// Let's assume 10 characters per nick...
				tmp.reserve(v.size() * (11 + 10 + getMyNick().length())); 
				string n = ' ' + fromUtf8(getMyNick()) + '|';
				for(const auto& i: v) {
					tmp += "$GetINFO ";
					tmp += fromUtf8(i->getIdentity().getNick());
					tmp += n;
				}
				if(!tmp.empty()) {
					send(tmp);
				}
			} 

			fire(ClientListener::UsersUpdated(), this, v);
		}
	} else if(cmd == "OpList") {
		if(!param.empty()) {
			OnlineUserList v;
			StringTokenizer<string> t(param, "$$");
			StringList& sl = t.getTokens();
			for(const auto& it: sl) {
				if(it.empty())
					continue;	// trailing/duplicate "$$" must not create a ""-nick user
				auto ou = getUser(it);
				ou->getIdentity().setOp(true);
				if(ou->getUser() == getMyIdentity().getUser()) {
					setMyIdentity(ou->getIdentity());
				}
				v.push_back(ou);
			}

			updateCounts(false);
			fire(ClientListener::UsersUpdated(), this, v);

			// Special...to avoid op's complaining that their count is not correctly
			// updated when they log in (they'll be counted as registered first...)
			myInfo(false);
		}
	} else if(cmd == "BotList") {
		// $BotList <nick1>$$<nick2>$$...| — hub-confirmed bots (same shape as $OpList).
		// "BL" marks the confirmation so a later $MyINFO heuristic can't unmark it.
		if(!param.empty()) {
			OnlineUserList v;
			StringTokenizer<string> t(param, "$$");
			for(const auto& it: t.getTokens()) {
				if(it.empty())
					continue;
				auto ou = getUser(it);
				ou->getUser()->setFlag(User::BOT);
				ou->getIdentity().setBot(true);
				ou->getIdentity().set("BL", "1");
				v.push_back(ou);
			}

			fire(ClientListener::UsersUpdated(), this, v);
		}
	} else if(cmd == "To:") {
		string::size_type i = param.find("From:");
		if(i == string::npos)
			return;

		i+=6;
		string::size_type j = param.find('$', i);
		if(j == string::npos)
			return;

		// A '$' sitting exactly at i (no nick, no separating space) would make the
		// j - 1 - i length wrap to SIZE_MAX and pull the whole remainder into rtNick.
		if(j <= i)
			return;

		string rtNick = param.substr(i, j - 1 - i);
		if(rtNick.empty())
			return;
		i = j + 1;

		if(param.size() < i + 3 || param[i] != '<')
			return;

		j = param.find('>', i);
		if(j == string::npos)
			return;

		string fromNick = param.substr(i+1, j-i-1);
		if(fromNick.empty() || param.size() < j + 2)
			return;

		bool thirdPerson = false;
		auto text = unescape(param.substr(j + 2));
		if (Util::strnicmp(text, "/me ", 4) == 0) {
			thirdPerson = true;
			text = text.substr(4);
		}

		auto message = std::make_shared<ChatMessage>(text, findUser(fromNick), getUser(getMyNick()), findUser(rtNick));
		message->setThirdPerson(thirdPerson);

		if(!message->getReplyTo() || !message->getFrom()) {
			if(!message->getReplyTo()) {
				// Assume it's from the hub
				auto replyTo = getUser(rtNick);
				replyTo->getIdentity().setHub(true);
				replyTo->getIdentity().setHidden(true);
				fire(ClientListener::UserUpdated(), this, replyTo);
			}
			if(!message->getFrom()) {
				// Assume it's from the hub
				auto from = getUser(fromNick);
				from->getIdentity().setHub(true);
				from->getIdentity().setHidden(true);
				fire(ClientListener::UserUpdated(), this, from);
			}

			// Update pointers just in case they've been invalidated
			message->setReplyTo(findUser(rtNick));
			message->setFrom(findUser(fromNick));
		}

		if(PluginManager::getInstance()->runHook<UserData>(HOOK_CHAT_PM_IN, message->getReplyTo().get(), message->getText()))
			return;

		onPrivateMessage(message);
	} else if(cmd == "MCTo:") {
		// $MCTo: <target> $<sender> <message> — a private message displayed in main chat.
		// Nicks cannot contain '$' or spaces, so " $" delimits target from sender.
		string::size_type i = param.find(" $");
		if(i == string::npos || i == 0)
			return;

		// The target was delimited and then never read, so a hub relaying $MCTo for OTHER
		// recipients had their private messages rendered in our main chat. Only accept messages
		// actually addressed to us. param is UTF-8 (onLine converts before dispatch), and the
		// comparison is case-insensitive to match how $Search handles our own nick.
		if(Util::stricmp(param.substr(0, i).c_str(), getMyNick().c_str()) != 0)
			return;

		string::size_type j = param.find(' ', i + 2);
		if(j == string::npos)
			return;

		string fromNick = param.substr(i + 2, j - i - 2);
		if(fromNick.empty() || param.size() <= j + 1)
			return;

		bool thirdPerson = false;
		auto text = unescape(param.substr(j + 1));
		if (Util::strnicmp(text, "/me ", 4) == 0) {
			thirdPerson = true;
			text = text.substr(4);
		}

		auto chatMessage = std::make_shared<ChatMessage>(text, findUser(fromNick));
		chatMessage->setThirdPerson(thirdPerson);

		if(!chatMessage->getFrom()) {
			// Assume that messages from unknown users come from the hub
			auto o = getUser(fromNick);
			o->getIdentity().setHub(true);
			o->getIdentity().setHidden(true);
			fire(ClientListener::UserUpdated(), this, o);

			chatMessage->setFrom(o);
		}

		if(PluginManager::getInstance()->runHook<HubData>(HOOK_CHAT_IN, this, chatMessage->getText()))
			return;

		onChatMessage(chatMessage);
	} else if(cmd == "GetPass") {
		// SaltPass: the challenge rides on $GetPass and is re-read on EVERY $GetPass
		// (the hub sends a fresh salt after $BadPass). Strict negotiation: honor it only
		// when the hub advertised SaltPass and the value is sane base32; otherwise fall
		// back to the plaintext $MyPass path. The >= 2 minimum is load-bearing: a 1-char
		// salt decodes to a zero-byte buffer, which Encoder::fromBase32 writes past
		// before its bounds checks kick in.
		if((supportFlags & SUPPORTS_SALTPASS) && param.size() >= 2 && param.size() <= 1024 && Encoder::isBase32(param.c_str())) {
			salt = param;
		} else {
			salt.clear();
		}
		auto& ou = *getUser(getMyNick());
		ou.getIdentity().set("RG", "1");
		setMyIdentity(ou.getIdentity());
		onPassword();
	} else if(cmd == "BadPass") {
		setPassword(Util::emptyString);
	} else if(cmd == "ZOn") {
		try {
			sock->setMode(BufferedSocket::MODE_ZPIPE);
		} catch (const Exception& e) {
			dcdebug("NmdcHub::onLine %s failed with error: %s\n", cmd.c_str(), e.getError().c_str());
		}

	} else if(cmd == "ClientNick") {
		// $ClientNick <newnick> (NMDC 4.5.14): the hub acknowledges the runtime nick change we
		// asked for with $NickChange. Only then does the new nick become ours.
		if(param.empty())
			return;

		// Only accept a rename the hub is entitled to make, and only a nick we would have asked for
		// ourselves. Unvalidated, a hub could send this at any point in the connection: pre-login
		// getMyNick() is still empty, so the lookup below missed and getUser(param) bound a FOREIGN
		// user as our own identity -- after which the $Hello login check never matched and the
		// connection hung until the handshake watchdog killed it.
		if(!(supportFlags & SUPPORTS_NICKCHANGE) || !stateNormal())
			return;

		if(param != checkNick(param))
			return;

		const auto oldNick = getMyNick();
		if(param == oldNick)
			return;

		OnlineUserPtr u;
		{
			WLock l(cs);
			auto i = users.find(oldNick);
			if(i != users.end()) {
				// emplace is a no-op when the key already exists, and our own entry has just been
				// erased -- so a hub naming a nick already in the list dropped us from `users`
				// entirely while we stayed registered in ClientManager, leaking an online-user entry
				// holding a reference to a hub that later shuts down. Put ourselves back and refuse.
				u = i->second;
				users.erase(i);
				if(!users.emplace(param, u).second) {
					users.emplace(oldNick, u);
					return;
				}
			}
		}

		// Our own UserPtr is CID-stable (getMe()), so only the nick key and the identity move
		if(!u)
			u = getUser(param);

		u->getIdentity().setNick(param);
		setMyIdentity(u->getIdentity());

		statusMessage(STRING(NICK_CHANGED) + " " + param, LogMessage::SEV_INFO, LogMessage::Type::SYSTEM);
		fire(ClientListener::UserUpdated(), this, u);
	} else if(cmd == "LogedIn") {
		// $LogedIn <nick> (NMDC 4.4.8, spelling per the spec): hubs send this to a user whose
		// login succeeded, normally only to operators
		statusMessage(param.empty() || param == get(HubSettings::Nick) ?
			STRING(HUB_LOGGED_IN) : STRING(HUB_LOGGED_IN) + " (" + param + ")",
			LogMessage::SEV_INFO, LogMessage::Type::SYSTEM);
	} else if(cmd == "HubTopic") {
		statusMessage(STRING(HUB_TOPIC) + "\t" + param, LogMessage::SEV_INFO, LogMessage::Type::SYSTEM);
	} else if(cmd == "NickRule") {
		// $NickRule Min <n>$$Max <n>$$Char <c1> <c2>...$$Pref <p1> <p2>...
		// Advisory only (we never silently rename the user): warn if our configured nick
		// can't satisfy the rules so the user isn't left guessing why login fails.
		int minLen = 0, maxLen = 0;
		StringList prefixes;
		StringTokenizer<string> rules(param, "$$");
		for (const auto& rule : rules.getTokens()) {
			if (rule.empty())
				continue;
			auto rsp = rule.find(' ');
			string name = rsp == string::npos ? rule : rule.substr(0, rsp);
			string val = rsp == string::npos ? Util::emptyString : rule.substr(rsp + 1);
			if (name == "Min")
				minLen = Util::toInt(val);
			else if (name == "Max")
				maxLen = Util::toInt(val);
			else if (name == "Pref")
				prefixes = StringTokenizer<string>(val, ' ').getTokens();
		}

		const string myNick = get(HubSettings::Nick);
		string problem;
		if (minLen > 0 && myNick.size() < static_cast<size_t>(minLen))
			problem = "it is shorter than the hub minimum of " + Util::toString(minLen) + " characters";
		else if (maxLen > 0 && myNick.size() > static_cast<size_t>(maxLen))
			problem = "it is longer than the hub maximum of " + Util::toString(maxLen) + " characters";
		else if (!prefixes.empty()) {
			bool ok = false;
			for (const auto& p : prefixes) {
				if (!p.empty() && myNick.compare(0, p.size(), p) == 0) {
					ok = true;
					break;
				}
			}
			if (!ok)
				problem = "the hub requires a nick starting with one of: " + Util::toString(" ", prefixes);
		}

		if (!problem.empty())
			statusMessage("The hub may reject your nick \"" + myNick + "\": " + problem + ".", LogMessage::SEV_WARNING);
	} else if(cmd == "BadNick") {
		// $BadNick <rule> — the hub rejected our nick (the param names the violated rule).
		const string reason = param.empty() ? Util::emptyString : (" (" + param + ")");
		statusMessage("The hub rejected your nick" + reason + ". Change your nick for this hub and reconnect.", LogMessage::SEV_WARNING);
	} else if(cmd == "SearchRule") {
		// $SearchRule Min <n>$$Max <n>$$Num <n>$$Int <sec>$$IntPas <sec>$$Share <bytes>
		// Honour the hub-imposed minimum search interval so our searches aren't dropped or banned.
		int activeInt = 0, passiveInt = 0;
		int64_t minShare = -1;
		StringTokenizer<string> rules(param, "$$");
		for (const auto& rule : rules.getTokens()) {
			if (rule.empty())
				continue;
			auto rsp = rule.find(' ');
			if (rsp == string::npos)
				continue;
			string name = rule.substr(0, rsp);
			string val = rule.substr(rsp + 1);
			if (name == "Int")
				activeInt = Util::toInt(val);
			else if (name == "IntPas")
				passiveInt = Util::toInt(val);
			else if (name == "Share")
				minShare = Util::toInt64(val);
		}

		const int wanted = hasActiveAddress() ? activeInt : passiveInt;
		if (wanted < 0) {
			statusMessage("This hub does not allow searching.", LogMessage::SEV_WARNING);
		} else if (wanted > 0) {
			// Raise (never lower) the local throttle to satisfy the hub. Compute in int64 and
			// clamp to a sane ceiling: `wanted` is hub-controlled, so `wanted * 1000` in int
			// would overflow (UB) above ~35 min, and an unclamped value lets a hostile hub pin
			// this hub's search interval to days.
			const auto wantedMs = static_cast<int>(std::min<int64_t>(static_cast<int64_t>(wanted) * 1000, 60 * 60 * 1000));
			if (wantedMs > searchQueue.getMinInterval())
				searchQueue.setMinInterval(wantedMs);
		}

		if (minShare > 0) {
			const int64_t myShare = ShareManager::getInstance()->getTotalShareSize(get(HubSettings::ShareProfile));
			if (myShare < minShare)
				statusMessage("This hub requires a minimum share of " + Util::formatBytes(minShare) +
					" to search (you share " + Util::formatBytes(myShare) + ").", LogMessage::SEV_WARNING);
		}
	} else if(cmd == "FailOver") {
		// $FailOver <host1>[,<host2>...] — reconnect backups; an empty command clears the list.
		updateFailoversFromHub(param);
	} else if(cmd == "MyHubURL") {
		// The hub announces its canonical address. We do NOT force a redirect (loop risk);
		// only seed it as a reconnect backup when we have no $FailOver list of our own.
		if (!param.empty() && getFailovers().empty())
			updateFailoversFromHub(param);
	} else {
		dcdebug("NmdcHub::onLine Unknown command %s\n", aLine.c_str());
	}
}

// SaltPass (NMDC): base32(Tiger192(passwordBytes + base32decode(salt))).
// aPassBytes must be the exact bytes the plaintext path would send (i.e. fromUtf8()).
// Caller guarantees aSaltBase32.size() >= 2 so the decode buffer is at least one byte.
static string saltedPassword(const string& aPassBytes, const string& aSaltBase32) {
	std::vector<uint8_t> saltBytes(aSaltBase32.size() * 5 / 8);
	Encoder::fromBase32(aSaltBase32.c_str(), saltBytes.data(), saltBytes.size());

	TigerHash th;
	th.update(aPassBytes.data(), aPassBytes.size());
	th.update(saltBytes.data(), saltBytes.size());
	return Encoder::toBase32(th.finalize(), TigerHash::BYTES);
}

void NmdcHub::password(const string& aPass) noexcept {
	setPassword(aPass);
	if((supportFlags & SUPPORTS_SALTPASS) && !salt.empty()) {
		send("$MyPass " + saltedPassword(fromUtf8(aPass), salt) + "|");
	} else {
		send("$MyPass " + fromUtf8(aPass) + "|");
	}
}

string NmdcHub::checkNick(const string& aNick) noexcept {
	string tmp = aNick;
	for(size_t i = 0; i < aNick.size(); ++i) {
		if(static_cast<uint8_t>(tmp[i]) <= 32 || tmp[i] == '|' || tmp[i] == '$' || tmp[i] == '<' || tmp[i] == '>') {
			tmp[i] = '_';
		}
	}
	return tmp;
}

void NmdcHub::connectToMe(const OnlineUser& aUser) {
	checkstate();
	dcdebug("NmdcHub::connectToMe %s\n", aUser.getIdentity().getNick().c_str());
	string nick = fromUtf8(aUser.getIdentity().getNick());
	ConnectionManager::getInstance()->nmdcExpect(nick, getMyNick(), getHubUrl());
	
	bool connectSecure = CryptoManager::getInstance()->TLSOk() && aUser.getUser()->isSet(User::TLS);
	string ownPort = connectSecure ? ConnectionManager::getInstance()->getSecurePort() : ConnectionManager::getInstance()->getPort();

	// v4 preferred; the peer's family when they cannot use v4 (an IP64 hub
	// also translates the address per recipient, so one form is enough)
	const string* addr = &myActiveAddress();
	if (canSendActiveV6() && !aUser.getIdentity().isTcp4Active() && aUser.getIdentity().isTcp6Active()) {
		addr = &localIp6;
	}

	send("$ConnectToMe " + nick + " " + *addr + ":" + ownPort + (connectSecure ? "S" : "") + "|");
}

void NmdcHub::revConnectToMe(const OnlineUser& aUser) {
	checkstate(); 
	dcdebug("NmdcHub::revConnectToMe %s\n", aUser.getIdentity().getNick().c_str());
	send("$RevConnectToMe " + fromUtf8(getMyNick()) + " " + fromUtf8(aUser.getIdentity().getNick()) + "|");
}

bool NmdcHub::hubMessage(const string& aMessage, bool aThirdPerson) noexcept {
	// A plugin may veto (and thereby suppress) the outgoing message
	if(PluginManager::getInstance()->runHook<HubData>(HOOK_CHAT_OUT, this, aMessage))
		return true;

	send(fromUtf8( "<" + getMyNick() + "> " + escape(aThirdPerson ? "/me " + aMessage : aMessage) + "|" ) );
	return true;
}

bool NmdcHub::normalizeNmdcHubUrl(string& url_, const string& aCurrentHubUrl) noexcept {
	// Hub-controlled data that may be persisted to the user's favorites or connected to
	// directly: accept only NMDC hub links and cap the length, mirroring
	// AdcHub::updateFailoversFromHub.
	static const size_t MAX_HUB_URL_LENGTH = 256;

	// Strip the surrounding junk (whitespace and <>") before any structural decision, so
	// that e.g. "\r\nevil.example.com" can't be read as a bare host below
	LinkUtil::sanitizeUrl(url_);
	if (url_.empty())
		return false;

	// Nothing legitimate survives inside a hub address; a stray CR/LF would additionally
	// let the entry be split into a second command by anything that re-serializes it.
	// A fragment has no meaning for a hub address either, and '#' shifts where the query
	// ends, which is how a pin can be made to land somewhere decodeUrl will not look.
	if (url_.find_first_of(" \t\r\n#") != string::npos)
		return false;

	// The hub never gets to choose a certificate pin. Without this, a hub-supplied kp=
	// would let a redirect/failover point at an attacker's host with the attacker's own
	// keyprint and still pass validation; the caller re-applies our pin where it applies.
	{
		string proto, host, port, file, query, fragment;
		LinkUtil::decodeUrl(url_, proto, host, port, file, query, fragment);
		if (!LinkUtil::decodeQuery(query)["kp"].empty())
			return false;
	}

	if (url_.find("://") == string::npos) {
		// The spec's bare host[:port] form: adopt this hub's own scheme.
		string scheme = "nmdc://";
		auto schemeEnd = aCurrentHubUrl.find("://");
		if (schemeEnd != string::npos) {
			scheme = aCurrentHubUrl.substr(0, schemeEnd + 3);
		}

		url_ = scheme + url_;
	} else if (Util::strnicmp("nmdc://", url_.c_str(), 7) != 0 &&
		Util::strnicmp("nmdcs://", url_.c_str(), 8) != 0 &&
		Util::strnicmp("dchub://", url_.c_str(), 8) != 0) {
		// An entry arriving with a non-NMDC scheme (e.g. adcs://) would inject a
		// cross-protocol, attacker-chosen URL. The bare-host format never authorizes
		// this; reject it.
		return false;
	}

	return url_.length() <= MAX_HUB_URL_LENGTH && LinkUtil::isHubLink(url_);
}

void NmdcHub::onForceMove(const string& aRedirectUrl) noexcept {
	string url = aRedirectUrl;
	if (!normalizeNmdcHubUrl(url, getHubUrl())) {
		statusMessage(STRING(REDIRECT_REJECTED_PROTOCOL), LogMessage::SEV_WARNING);
		return;
	}

	if (string error; !prepareHubRedirect(url, error)) {
		statusMessage(error, LogMessage::SEV_WARNING);
		return;
	}

	disconnect(false);
	onRedirect(url);
}

void NmdcHub::updateFailoversFromHub(const string& aFailoverStr) noexcept {
	// $FailOver carries a comma-separated list of bare host[:port] entries
	static const size_t MAX_FAILOVERS = 5;

	StringList urls;
	if (!aFailoverStr.empty()) {
		StringTokenizer<string> tok(aFailoverStr, ',');
		for (const auto& host : tok.getTokens()) {
			string url = host;
			if (!normalizeNmdcHubUrl(url, getHubUrl()))
				continue;

			urls.push_back(url);
			if (urls.size() >= MAX_FAILOVERS)
				break;
		}
	}

	if (urls == getFailovers())
		return;

	setFailovers(urls);

	if (getFavToken() > 0) {
		FavoriteManager::getInstance()->updateFailovers(getFavToken(), Util::toString(",", urls));
	}
}

bool NmdcHub::mcPrivateMessage(const OnlineUserPtr& aUser, const string& aMessage, bool aThirdPerson, string& error_) noexcept {
	if(!stateNormal()) {
		error_ = STRING(CONNECTING_IN_PROGRESS);
		return false;
	}

	if(!(supportFlags & SUPPORTS_MCTO)) {
		error_ = STRING(MCTO_NOT_SUPPORTED);
		return false;
	}

	// A plugin may veto (and thereby suppress) the outgoing message
	if(PluginManager::getInstance()->runHook<HubData>(HOOK_CHAT_OUT, this, aMessage))
		return true;

	send("$MCTo: " + fromUtf8(aUser->getIdentity().getNick()) + " $" + fromUtf8(getMyNick())
		+ " " + fromUtf8(escape(aThirdPerson ? "/me " + aMessage : aMessage)) + "|");

	// The hub delivers $MCTo only to the target, so echo locally — except to self,
	// where the hub's delivery back to us would make a duplicate.
	if(aUser->getUser() != getMyIdentity().getUser()) {
		if(auto me = findUser(getMyNick()); me) {
			auto chatMessage = std::make_shared<ChatMessage>(aMessage, me);
			chatMessage->setThirdPerson(aThirdPerson);
			onChatMessage(chatMessage);
		}
	}

	return true;
}

void NmdcHub::myInfo(bool alwaysSend) {
	// Reload before the antispam gate: a settings/favorite change must reach the live
	// HubSettings (chat behavior reads them directly) even when the resulting $MyINFO
	// send is rate-limited away.
	reloadSettings(false);

	if(!alwaysSend && lastUpdate + 15000 > GET_TICK()) return; // antispam

	checkstate();

	
	char status = Identity::NORMAL;
	const auto ip64 = (supportFlags & SUPPORTS_IP64) != 0;

	char modeChar = '?';
	if(SETTING(OUTGOING_CONNECTIONS) == SettingsManager::OUTGOING_SOCKS5)
		modeChar = '5';
	else if (canSendActiveV4())
		modeChar = 'A';
	else if (ip64 && get(HubSettings::Connection) == SettingsManager::INCOMING_DISABLED)
		modeChar = 'N';	// IP64: no IPv4 on this hub at all
	else
		modeChar = 'P';

	// IP64 mode tag is two characters (M:XY, Y = the IPv6 mode); legacy hubs
	// keep the single-character form byte for byte
	string modeTag(1, modeChar);
	if (ip64) {
		modeTag += canSendActiveV6() ? 'A' : 'P';
	}

	if (!ip64) {
		// Under IP64 the 0x40 bit belongs to the hub (verified-IPv4 marker),
		// which collides with this legacy AirDC marker; the hub is
		// authoritative for both high bits there
		status |= Identity::AIRDC;
	}
	if (ActivityManager::getInstance()->isAway()) {
		status |= Identity::AWAY;
	}
	if (!hasActiveAddress()) {
		status |= Identity::NAT;
	}


	if (CryptoManager::getInstance()->TLSOk()) {
		status |= Identity::TLS;
	}

	string uploadSpeed;
	auto upLimit = ThrottleManager::getInstance()->getUpLimit();
	if (upLimit > 0) {
		uploadSpeed = Util::toString(upLimit) + " KiB/s";
	} else {
		uploadSpeed = SETTING(UPLOAD_SPEED);
	}

	char myInfo[256];
	snprintf(myInfo, sizeof(myInfo), "$MyINFO $ALL %s %s<%s V:%s,M:%s,H:%ld/%ld/%ld,S:%d>$ $%s%c$%s$", fromUtf8(getMyNick()).c_str(),
		fromUtf8(escape(get(HubSettings::Description))).c_str(), APPNAME, VERSIONSTRING.c_str(), modeTag.c_str(),
		getDisplayCount(COUNT_NORMAL), getDisplayCount(COUNT_REGISTERED), getDisplayCount(COUNT_OP),
		UploadManager::getInstance()->getSlots(), fromUtf8(uploadSpeed).c_str(), status, fromUtf8(escape(get(HubSettings::Email))).c_str());

	int64_t newBytesShared = ShareManager::getInstance()->getTotalShareSize(get(HubSettings::ShareProfile));
	if (strcmp(myInfo, lastMyInfo.c_str()) != 0 || alwaysSend || (newBytesShared != lastBytesShared && lastUpdate + 15*60*1000 < GET_TICK())) {
		dcdebug("MyInfo %s...\n", getMyNick().c_str());		
		send(string(myInfo) + Util::toString(newBytesShared) + "$|");
		
		lastMyInfo = myInfo;
		lastBytesShared = newBytesShared;
		lastUpdate = GET_TICK();
	}
}

void NmdcHub::search(const SearchPtr& s) noexcept {
	checkstate();
	if (s->aschOnly)
		return;

	// TTHS: the most common search (TTH download-alternative lookup) has a short form
	// that saves hub bandwidth. Only when the hub advertised TTHS, and only for TTH.
	if (s->fileType == Search::TYPE_TTH && (supportFlags & SUPPORTS_TTHS)) {
		const auto& searchAddr = myActiveAddress();
		if (!searchAddr.empty() && !SETTING(SEARCH_PASSIVE)) {
			send("$SA " + s->query + ' ' + searchAddr + ':' + SearchManager::getInstance()->getPort() + "|");
		} else {
			send("$SP " + s->query + ' ' + fromUtf8(getMyNick()) + "|");
		}
		return;
	}

	auto [size, sizeMode] = s->parseLegacySize();
	char c1 = (sizeMode == Search::SIZE_DONTCARE || sizeMode == Search::SIZE_EXACT) ? 'F' : 'T';
	char c2 = (sizeMode == Search::SIZE_ATLEAST) ? 'F' : 'T';

	string tmp = ((s->fileType == Search::TYPE_TTH) ? "TTH:" + s->query : fromUtf8(escape(s->query)));
	Util::replace(tmp, "\"", ""); //can't use quotes in NMDC searches

	string::size_type i;
	while((i = tmp.find(' ')) != string::npos) {
		tmp[i] = '$';
	}
	string tmp2;
	const auto& searchAddr = myActiveAddress();
	if (!searchAddr.empty() && !SETTING(SEARCH_PASSIVE)) {
		tmp2 = searchAddr + ':' + SearchManager::getInstance()->getPort();
	} else {
		tmp2 = "Hub:" + fromUtf8(getMyNick());
	}

	string type = Util::toString((s->fileType == Search::TYPE_FILE ? Search::TYPE_ANY : s->fileType)+1);

	send("$Search " + tmp2 + ' ' + c1 + '?' + c2 + '?' + Util::toString(size) + '?' + type + '?' + tmp + '|');
}

string NmdcHub::validateMessage(string tmp, bool reverse) {
	string::size_type i = 0;

	if(reverse) {
		while( (i = tmp.find("&#36;", i)) != string::npos) {
			tmp.replace(i, 5, "$");
			i++;
		}
		i = 0;
		while( (i = tmp.find("&#124;", i)) != string::npos) {
			tmp.replace(i, 6, "|");
			i++;
		}
		i = 0;
		while( (i = tmp.find("&amp;", i)) != string::npos) {
			tmp.replace(i, 5, "&");
			i++;
		}
	} else {
		i = 0;
		while( (i = tmp.find("&amp;", i)) != string::npos) {
			tmp.replace(i, 1, "&amp;");
			i += 4;
		}
		i = 0;
		while( (i = tmp.find("&#36;", i)) != string::npos) {
			tmp.replace(i, 1, "&amp;");
			i += 4;
		}
		i = 0;
		while( (i = tmp.find("&#124;", i)) != string::npos) {
			tmp.replace(i, 1, "&amp;");
			i += 4;
		}
		i = 0;
		while( (i = tmp.find('$', i)) != string::npos) {
			tmp.replace(i, 1, "&#36;");
			i += 4;
		}
		i = 0;
		while( (i = tmp.find('|', i)) != string::npos) {
			tmp.replace(i, 1, "&#124;");
			i += 5;
		}
	}

	dcassert(Text::validateUtf8(tmp));
	return tmp;
}

void NmdcHub::privateMessage(const string& aNick, const string& aMessage, bool aThirdPerson) {
	send("$To: " + fromUtf8(aNick) + " From: " + fromUtf8(getMyNick()) + " $" + fromUtf8(escape("<" + getMyNick() + "> " + (aThirdPerson ? "/me " + aMessage : aMessage))) + "|");
}

bool NmdcHub::privateMessage(const OnlineUserPtr& aUser, const string& aMessage, string& error_, bool aThirdPerson, bool aEcho) noexcept {
	if(!stateNormal()) {
		error_ = STRING(CONNECTING_IN_PROGRESS);
		return false;
	}

	privateMessage(aUser->getIdentity().getNick(), aMessage, aThirdPerson);

	auto ou = findUser(getMyNick());
	if (!ou) {
		error_ = STRING(USER_OFFLINE);
		return false;
	}

	if (aEcho) {
		// Emulate a returning message...
		auto message = std::make_shared<ChatMessage>(aMessage, ou, aUser, ou);
		onPrivateMessage(message);
	}

	return true;
}

void NmdcHub::sendUserCmd(const UserCommand& command, const ParamMap& params) {
	checkstate();
	string cmd = Util::formatParams(command.getCommand(), params);
	if(command.isChat()) {
		if(command.getTo().empty()) {
			hubMessage(cmd);
		} else {
			privateMessage(command.getTo(), cmd, false);
		}
	} else {
		send(fromUtf8(cmd));
	}
}

void NmdcHub::on(Connected) noexcept {
	Client::on(Connected());

	if(getConnectState() != STATE_PROTOCOL) {
		return;
	}

	supportFlags = 0;
	encodingErrorReported = false;
	salt.clear();
	lastMyInfo.clear();
	lastBytesShared = 0;
	lastUpdate = 0;
	refreshLocalIp();
}

void NmdcHub::on(Line, const string& aLine) noexcept {
	Client::on(Line(), aLine);

	// Pass the raw wire line to the hook. NOTE: unlike DC++, AirDC's validateMessage()
	// asserts the result is valid UTF-8, but the raw NMDC line is still in the hub's native
	// encoding here (e.g. CP1251) — so we must NOT run it through validateMessage() (it would
	// assert/crash on non-UTF-8 hubs). Raw bytes are also the correct payload for a
	// network-protocol-in hook (e.g. the Dev plugin shows raw traffic).
	if(PluginManager::getInstance()->runHook<HubData>(HOOK_NETWORK_HUB_IN, this, aLine))
		return;

	onLine(aLine);
}

void NmdcHub::on(Second, uint64_t aTick) noexcept {
	Client::on(Second(), aTick);

	if(stateNormal() && (aTick > (getLastActivity() + 120*1000)) ) {
		send("|", 1);
	}
}

void NmdcHub::on(Minute, uint64_t /*aTick*/) noexcept {
	callAsync([this] { refreshLocalIp(); });
}

void NmdcHub::getUserList(OnlineUserList& list, bool aListHidden) const noexcept {
	RLock l(cs);
	for(auto& u: users | views::values) {
		if (!aListHidden && u->isHidden()) {
			continue;
		}

		list.push_back(u);
	}
}

size_t NmdcHub::getUserCount() const noexcept { 
	RLock l(cs); 
	size_t userCount = 0;
	for (const auto& [_, ou] : users) {
		if (!ou->isHidden()) {
			++userCount;
		}
	}
	return userCount;
}

} // namespace dcpp
