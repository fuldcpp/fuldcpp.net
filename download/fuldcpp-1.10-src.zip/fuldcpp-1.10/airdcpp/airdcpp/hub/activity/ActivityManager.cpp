/*
* Copyright (C) 2011-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include <airdcpp/hub/activity/ActivityManager.h>
#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/settings/SettingsManager.h>


namespace dcpp {

ActivityManager::ActivityManager() {
	TimerManager::getInstance()->addListener(this);
	SettingsManager::getInstance()->addListener(this);
}

ActivityManager::~ActivityManager() {
	TimerManager::getInstance()->removeListener(this);
	SettingsManager::getInstance()->removeListener(this);
}

void ActivityManager::on(SettingsManagerListener::LoadCompleted, bool) noexcept {
	if (SETTING(AWAY)) {
		setAway(AWAY_MANUAL);
	}
}

void ActivityManager::updateActivity(uint64_t aLastActivity) noexcept {
	if (aLastActivity < lastActivity) {
		return;
	}

	lastActivity = aLastActivity;

	// Only idle-away is cleared by user input; the GUI-owned modes (minimized,
	// fullscreen, lock) are cleared solely by their own falling edges. A fullscreen
	// game generates constant input, so clearing them here would flap the away
	// state once per second and spam MyINFO updates to every connected hub.
	if (awayMode == AWAY_IDLE) {
		setAway(AWAY_OFF);
	}
}

void ActivityManager::on(TimerManagerListener::Second, uint64_t aTick) noexcept {
	if (!SETTING(AWAY_IDLE_TIME) || awayMode != AWAY_OFF) {
		return;
	}

	if ((lastActivity + Util::minutesToMs(SETTING(AWAY_IDLE_TIME))) < aTick) {
		setAway(AWAY_IDLE); 
	}
}

bool ActivityManager::isAway() const noexcept {
	return awayMode != AWAY_OFF; 
}

void ActivityManager::setAway(AwayMode aNewMode) {
	if (aNewMode == awayMode) {
		return;
	}

	if (aNewMode == AWAY_IDLE && !SETTING(AWAY_IDLE_TIME)) {
		return;
	}

	if (aNewMode == AWAY_MANUAL || (awayMode == AWAY_MANUAL && aNewMode == AWAY_OFF)) {
		//only save the state if away mode is set by user
		SettingsManager::getInstance()->set(SettingsManager::AWAY, aNewMode != AWAY_OFF);
	}

	awayMode = aNewMode;
	// Entering away: base tick for the %[idleTI] "away since" param. Returning
	// to off: restart the idle countdown, so e.g. a session lock longer than
	// AWAY_IDLE_TIME doesn't re-fire AWAY_IDLE right after the unlock clears it
	lastActivity = GET_TICK();

	ClientManager::getInstance()->myInfoUpdated();
	fire(ActivityManagerListener::AwayModeChanged(), awayMode);
}

string ActivityManager::getAwayMessage(const string& aAwayMsg, ParamMap& params) const noexcept {
	params["idleTI"] = Util::formatSeconds((GET_TICK() - lastActivity) / 1000);

	// A non-empty state-specific message overrides the passed-in (per-hub or
	// default) template; empty means fall back. Note that a state override thus
	// also outranks a per-hub AwayMsg override — matching on "is the passed
	// template the default one" instead would break for per-hub messages that
	// happen to equal the default, so precedence-wins is the predictable rule.
	auto tmpl = aAwayMsg;
	switch (awayMode) {
		case AWAY_IDLE:
			if (!SETTING(AWAY_MESSAGE_IDLE).empty()) tmpl = SETTING(AWAY_MESSAGE_IDLE);
			break;
		case AWAY_LOCK:
			if (!SETTING(AWAY_MESSAGE_LOCK).empty()) tmpl = SETTING(AWAY_MESSAGE_LOCK);
			break;
		case AWAY_FULLSCREEN:
			if (!SETTING(AWAY_MESSAGE_FULLSCREEN).empty()) tmpl = SETTING(AWAY_MESSAGE_FULLSCREEN);
			break;
		default:
			break;
	}

	return Util::formatParams(tmpl, params);
}

} // namespace dcpp