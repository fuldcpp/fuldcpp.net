/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/core/version.h>

#include <airdcpp/hub/activity/ActivityManager.h>
#include <airdcpp/protocol/AdcCommand.h>
#include <airdcpp/util/AutoLimitUtil.h>
#include <airdcpp/hub/AdcHub.h>
#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/connection/ConnectionManager.h>
#include <airdcpp/connectivity/ConnectivityManager.h>
#include <airdcpp/core/crypto/CryptoManager.h>
#include <airdcpp/favorites/FavoriteManager.h>
#include <airdcpp/hub/HBRIValidation.h>
#include <airdcpp/util/LinkUtil.h>
#include <airdcpp/util/NetworkUtil.h>
#include <airdcpp/core/localization/Localization.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/message/Message.h>
#include <airdcpp/queue/partial_sharing/PartialSharingManager.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/modules/RSSManager.h>
#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/core/classes/ScopedFunctor.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/search/SearchManager.h>
#include <airdcpp/search/SearchQuery.h>
#include <airdcpp/share/ShareManager.h>
#include <airdcpp/connection/ThrottleManager.h>
#include <airdcpp/transfer/upload/UploadManager.h>
#include <airdcpp/hub/user_command/UserCommand.h>
#include <airdcpp/plugins/PluginManager.h>
#include <airdcpp/util/text/StringTokenizer.h>
#include <airdcpp/util/Util.h>

namespace dcpp {

const string AdcHub::BASE_SUPPORT("BASE");
const string AdcHub::BAS0_SUPPORT("BAS0");
const string AdcHub::TIGR_SUPPORT("TIGR");
const string AdcHub::UCM0_SUPPORT("UCM0");
const string AdcHub::BLO0_SUPPORT("BLO0");
const string AdcHub::ZLIF_SUPPORT("ZLIF");
const string AdcHub::HBRI_SUPPORT("HBRI");
const string AdcHub::RTF0_SUPPORT("RTF0");

const vector<StringList> AdcHub::searchExtensions = {
	// these extensions *must* be sorted alphabetically!
	{ "ape", "flac", "m4a", "mid", "mp3", "mpc", "ogg", "ra", "wav", "wma" },
	{ "7z", "ace", "arj", "bz2", "gz", "lha", "lzh", "rar", "tar", "z", "zip" },
	{ "doc", "docx", "htm", "html", "nfo", "odf", "odp", "ods", "odt", "pdf", "ppt", "pptx", "rtf", "txt", "xls", "xlsx", "xml", "xps" },
	{ "app", "bat", "cmd", "com", "dll", "exe", "jar", "msi", "ps1", "vbs", "wsf" },
	{ "bmp", "cdr", "eps", "gif", "ico", "img", "jpeg", "jpg", "png", "ps", "psd", "sfw", "tga", "tif", "webp" },
	{ "3gp", "asf", "asx", "avi", "divx", "flv", "mkv", "mov", "mp4", "mpeg", "mpg", "ogm", "pxp", "qt", "rm", "rmvb", "swf", "vob", "webm", "wmv" }
};

AdcHub::AdcHub(const string& aHubURL, const ClientPtr& aOldClient) :
	Client(aHubURL, '\n', aOldClient) {

	TimerManager::getInstance()->addListener(this);
}

AdcHub::~AdcHub() {

}

void AdcHub::shutdown(ClientPtr& aClient, bool aRedirect) {
	resetHBRI();

	Client::shutdown(aClient, aRedirect);
	TimerManager::getInstance()->removeListener(this);
}

size_t AdcHub::getUserCount() const noexcept {
	size_t userCount = 0;

	RLock l(cs);
	for (const auto& u: users | views::values) {
		if (!u->isHidden()) {
			++userCount;
		}
	}
	return userCount;
}

OnlineUserPtr AdcHub::getUser(dcpp::SID aSID, const CID& aCID) noexcept {
	auto ou = findUser(aSID);
	if (ou) {
		return ou;
	}

	auto user = ClientManager::getInstance()->getUser(aCID);
	auto client = ClientManager::getInstance()->findClient(getHubUrl());

	{
		WLock l(cs);
		ou = users.emplace(aSID, std::make_shared<OnlineUser>(user, client, aSID)).first->second;
	}

	return ou;
}

OnlineUserPtr AdcHub::findUser(dcpp::SID aSID) const noexcept {
	RLock l(cs);
	auto i = users.find(aSID);
	return i == users.end() ? nullptr : i->second;
}

OnlineUserPtr AdcHub::findUser(const CID& aCID) const noexcept {
	RLock l(cs);
	for(const auto& ou: users | views::values) {
		if(ou->getUser()->getCID() == aCID) {
			return ou;
		}
	}
	return nullptr;
}

void AdcHub::getUserList(OnlineUserList& list, bool aListHidden) const noexcept {
	RLock l(cs);
	for (const auto& [_, user] : users) {
		if (!aListHidden && user->isHidden()) {
			continue;
		}

		list.push_back(user);
	}
}

void AdcHub::putUser(dcpp::SID aSID, bool aDisconnectTransfers) noexcept {
	OnlineUserPtr ou = nullptr;
	{
		WLock l(cs);
		auto i = users.find(aSID);
		if(i == users.end())
			return;

		ou = i->second;
		users.erase(i);

		availableBytes.fetch_sub(ou->getIdentity().getBytesShared());
	}

	onUserDisconnected(ou, aDisconnectTransfers);
}

void AdcHub::clearUsers() noexcept {
	SIDMap tmp;
	{
		WLock l(cs);
		users.swap(tmp);
		availableBytes.store(0);
	}

	for (const auto& [sid, user] : tmp) {
		if(sid != AdcCommand::HUB_SID)
			ClientManager::getInstance()->putOffline(user, false);
	}
}

pair<OnlineUserPtr, bool> AdcHub::parseInfUser(const AdcCommand& c) noexcept {
	string cid;
	OnlineUserPtr u = nullptr;
	bool newUser = false;
	if (c.getParam("ID", 0, cid)) {
		u = findUser(CID(cid));
		if (u) {
			if (u->getIdentity().getSID() != c.getFrom()) {
				// Same CID but different SID not allowed - buggy hub?
				string nick;
				if (!c.getParam("NI", 0, nick)) {
					nick = "[nick unknown]";
				}

				auto message = u->getIdentity().getNick() + " (" + u->getIdentity().getSIDString() +
					") has same CID {" + cid + "} as " + nick + " (" + AdcCommand::fromSID(c.getFrom()) + "), ignoring.";
				statusMessage(message, LogMessage::SEV_VERBOSE);
				return { nullptr, false };
			}
		} else {
			u = getUser(c.getFrom(), CID(cid));
			newUser = true;
		}
	} else if (c.getFrom() == AdcCommand::HUB_SID) {
		u = getUser(c.getFrom(), CID());
	} else {
		u = findUser(c.getFrom());
	}

	return { u, newUser };
}

void AdcHub::updateInfUserProperties(const OnlineUserPtr& u, const StringList& aParams) noexcept {
	for (const auto& p: aParams) {
		if(p.length() < 2)
			continue;

		if(p.starts_with("SS")) {
			availableBytes.fetch_sub(u->getIdentity().getBytesShared());
			u->getIdentity().setBytesShared(p.substr(2));
			availableBytes.fetch_add(u->getIdentity().getBytesShared());
		} else if (p.starts_with("SU")) {
			u->getIdentity().setSupports(p.substr(2));
		} else {
			u->getIdentity().set(p.c_str(), p.substr(2));
		}
	}

	if (u->getIdentity().isBot()) {
		u->getUser()->setFlag(User::BOT);
	} else {
		u->getUser()->unsetFlag(User::BOT);
	}

	if (u->getIdentity().hasSupport(OnlineUser::ADCS_FEATURE)) {
		u->getUser()->setFlag(User::TLS);

		//CCPM support flag is only sent if we support encryption too, so keep persistent here also...
		if (u->getIdentity().hasSupport(OnlineUser::CCPM_FEATURE)) {
			u->getUser()->setFlag(User::CCPM);
		}
	}

	if (u->getIdentity().hasSupport(OnlineUser::ASCH_FEATURE)) {
		u->getUser()->setFlag(User::ASCH);
	}
}

void AdcHub::recalculateConnectModes() noexcept {
	fire(ClientListener::HubUpdated(), this);

	OnlineUserList ouList;

	{
		RLock l(cs);
		ranges::copy_if(users | views::values, back_inserter(ouList), [this](const OnlineUserPtr& ou) {
			return ou->getIdentity().getTcpConnectMode() != Identity::MODE_ME && ou->getIdentity().updateAdcConnectModes(getMyIdentity(), this);
		});
	}

	fire(ClientListener::UsersUpdated(), this, ouList);
}

void AdcHub::handle(AdcCommand::INF, AdcCommand& c) noexcept {
	if(c.getParameters().empty())
		return;

	auto [u, newUser] = parseInfUser(c);
	if (!u) {
		dcdebug("AdcHub::INF Unknown user / no ID\n");
		return;
	}

	updateInfUserProperties(u, c.getParameters());

	if (u->getUser() == getMyIdentity().getUser()) {
		auto oldState = getConnectState();
		if (oldState != STATE_NORMAL) {
			setConnectState(STATE_NORMAL);
			setAutoReconnect(true);

			// Login is complete once the hub echoes our own INF, which is the first point
			// a broadcast can reach anyone (ADC-EXT 4.25)
			sendOnlineIdentities();

			if (u->getIdentity().getAdcConnectionSpeed(false) == 0) {
				statusMessage("WARNING: This hub is not displaying the connection speed fields, which prevents the client from choosing the best sources for downloads. Please advise the hub owner to fix this.", LogMessage::SEV_WARNING);
			}
		}

		u->getIdentity().updateAdcConnectModes(u->getIdentity(), this);
		setMyIdentity(u->getIdentity());
		updateCounts(false);

		// We have to update the modes in case our connectivity changed
		if (oldState != STATE_NORMAL || ranges::any_of(c.getParameters(), Identity::isConnectModeParam)) {
			resetHBRI();
			recalculateConnectModes();
		}
	} else if (stateNormal()) {
		u->getIdentity().updateAdcConnectModes(getMyIdentity(), this);
	}

	// The CT bit says "I am the hub"; the SID is what makes it true. Trusting CT alone let any
	// PEER on the hub declare itself the hub identity, and the FO handling just below writes the
	// failover list it supplies into the user's favourite entry -- so an ordinary user could
	// redirect someone's saved hub address. Every other hub-authority test in this file is the
	// same comparison.
	if (u->getIdentity().isHub() && c.getFrom() == AdcCommand::HUB_SID) {
		setHubIdentity(u->getIdentity());

		// Hub INFs are deltas: only apply FO when the field is actually present
		// (an explicitly empty FO clears the stored failovers)
		if (string fo; c.getParam("FO", 0, fo)) {
			updateFailoversFromHub(fo);
		}

		fire(ClientListener::HubUpdated(), this);
	} else if (!newUser) {
		fire(ClientListener::UserUpdated(), this, u);
	} else {
		onUserConnected(u);
	}
}

void AdcHub::updateFailoversFromHub(const string& aFailoverStr) noexcept {
	// Hub-controlled data that may end up persisted in the user's favorites: accept only
	// ADC hub schemes and cap the entry count/length (ADC-EXT 4.21)
	static const size_t MAX_FAILOVERS = 5;
	static const size_t MAX_FAILOVER_URL_LENGTH = 256;

	StringList urls;
	if (!aFailoverStr.empty()) {
		StringTokenizer<string> tok(aFailoverStr, ',');
		for (auto& url: tok.getTokens()) {
			LinkUtil::sanitizeUrl(url);
			if (url.empty() || url.length() > MAX_FAILOVER_URL_LENGTH || !LinkUtil::isAdcHub(url)) {
				continue;
			}

			// The hub never gets to choose a certificate pin: a hub-supplied kp= would let
			// a failover hop reach an attacker's host with the attacker's own keyprint and
			// still pass validation in getNextFailoverUrl. Our own pin is applied there.
			{
				string proto, host, port, file, query, fragment;
				LinkUtil::decodeUrl(url, proto, host, port, file, query, fragment);
				if (!LinkUtil::decodeQuery(query)["kp"].empty()) {
					continue;
				}
			}

			urls.push_back(url);
			if (urls.size() >= MAX_FAILOVERS) {
				break;
			}
		}
	}

	if (urls == getFailovers()) {
		return;
	}

	setFailovers(urls);

	if (getFavToken() > 0) {
		FavoriteManager::getInstance()->updateFailovers(getFavToken(), Util::toString(",", urls));
	}
}

void AdcHub::handle(AdcCommand::SUP, AdcCommand& c) noexcept {
	for (const auto& param: c.getParameters()) {
		if (param.size() != 6) {
			statusMessage("Invalid support " + param + " received from the hub", LogMessage::SEV_WARNING);
			continue;
		}

		auto adding = param.starts_with("AD");
		auto removing = param.starts_with("RM");
		if (!adding && !removing) {
			continue;
		}

		auto support = param.substr(2);
		if (adding) {
			supports.add(support);
		} else if (removing) {
			supports.remove(support);
		}
	}
	
	if (!supports.includes(BAS0_SUPPORT) && !supports.includes(BASE_SUPPORT)) {
		statusMessage("Failed to negotiate base protocol", LogMessage::SEV_ERROR);
		disconnect(false);
		return;
	} else if (!supports.includes(TIGR_SUPPORT)) {
		oldPassword = true;
		// Some hubs fake BASE support without TIGR support =/
		statusMessage("Hub probably uses an old version of ADC, please encourage the owner to upgrade", LogMessage::SEV_ERROR);
	}

	if (getConnectState() != STATE_PROTOCOL) {
		fire(ClientListener::HubUpdated(), this);
	}
}

void AdcHub::handle(AdcCommand::SID, AdcCommand& c) noexcept {
	if(getConnectState() != STATE_PROTOCOL) {
		dcdebug("Invalid state for SID\n");
		return;
	}

	if(c.getParameters().empty())
		return;

	mySID = AdcCommand::toSID(c.getParam(0));

	setConnectState(STATE_IDENTIFY);
	infoImpl();
}

void AdcHub::handle(AdcCommand::MSG, AdcCommand& c) noexcept {
	if(c.getParameters().empty())
		return;

	// RTF0: "A client MUST NOT act on RT1 from a hub that did not announce RTF0; the
	// message MUST be treated as plain text." The support check is therefore part of
	// the condition, not a nicety. hasFlag matches only the exact token "RT1", which
	// also gives the spec's "values of RT other than 1 are reserved" handling.
	const auto richText = c.hasFlag("RT", 1) && supports.includes(RTF0_SUPPORT) && SETTING(RICH_TEXT_ENABLED);

	auto message = std::make_shared<ChatMessage>(c.getParam(0), findUser(c.getFrom()), nullptr, nullptr, richText);
	if(!message->getFrom())
		return;

	message->setThirdPerson(c.hasFlag("ME", 1));

	string temp;
	if (c.getParam("TS", 1, temp))
		message->setTime(Util::toTimeT(temp));

	if(c.getParam("PM", 1, temp)) { // add PM<group-cid> as well
		message->setTo(findUser(c.getTo()));
		if(!message->getTo())
			return;

		message->setReplyTo(findUser(AdcCommand::toSID(temp)));
		if(!message->getReplyTo())
			return;

		if(PluginManager::getInstance()->runHook<UserData>(HOOK_CHAT_PM_IN, message->getReplyTo().get(), message->getText()))
			return;

		onPrivateMessage(message);
		return;
	}

	if(PluginManager::getInstance()->runHook<HubData>(HOOK_CHAT_IN, this, message->getText()))
		return;

	onChatMessage(message);
}

// TPN <code> (ADC-EXT 4.18): the hub-routed counterpart of our CCPM typing notification, used
// when no client-to-client connection exists. Codes: 00 gone, 01 inactive, 02 paused,
// 10 active, 11 composing - only the last one means "is typing right now".
void AdcHub::handle(AdcCommand::TPN, AdcCommand& c) noexcept {
	if (c.getParameters().empty())
		return;

	auto from = findUser(c.getFrom());
	if (!from || from->getUser() == getMyIdentity().getUser())
		return;

	const auto& code = c.getParam(0);
	if (code.size() != 2)
		return;

	fire(ClientListener::UserTyping(), this, from, code == "11");
}

// RSS <url> (ADC-EXT 4.19): a feed item pushed by the hub. RSSManager decides whether to keep it -
// only already-subscribed feeds are accepted, and hub items never drive the auto-download filters.
void AdcHub::handle(AdcCommand::RSS, AdcCommand& c) noexcept {
	if (c.getParameters().empty())
		return;

	const auto& url = c.getParam(0);

	string title, link, date, remove;
	if (c.getParam("RM", 1, remove) && remove == "1") {
		// Removing a feed is the user's decision, not the hub's
		return;
	}

	c.getParam("TI", 1, title);
	c.getParam("LI", 1, link);
	c.getParam("DT", 1, date);

	RSSManager::getInstance()->addHubFeedItem(url, title, link, date);
}

// OID <service> [named params] and OIR <service> [named params] (ADC-EXT 4.25). The parameters are
// service specific, so they are stored verbatim under the service name rather than modelled.
// ADC-EXT 4.25: the identities we publish about ourselves, stored one per line as
// "service<TAB>params". Tab, because params are free-form and routinely contain ':' and '/'.
AdcHub::OnlineIdentityList AdcHub::parseOnlineIdentities(const string& aSetting) noexcept {
	OnlineIdentityList ret;

	// The tokenizer must be a named local: StringTokenizer::getTokens() returns a reference to
	// the object's own vector, so iterating StringTokenizer(...).getTokens() directly would walk
	// a dangling reference (the temporary is destroyed at the end of the range-init expression).
	StringTokenizer<string> tokenizer(aSetting, '\n');
	for (const auto& line: tokenizer.getTokens()) {
		auto sep = line.find('\t');
		if (sep == string::npos) {
			continue;
		}

		auto service = Text::toLower(line.substr(0, sep));
		auto params = line.substr(sep + 1);
		if (service.empty() || service.size() > 32 || params.empty()) {
			continue;
		}

		ret.emplace_back(service, params);
	}

	return ret;
}

string AdcHub::serializeOnlineIdentities(const OnlineIdentityList& aIdentities) noexcept {
	string ret;
	for (const auto& [service, params]: aIdentities) {
		if (!ret.empty()) {
			ret += '\n';
		}

		ret += service + '\t' + params;
	}

	return ret;
}

// Publish our own identities (ADC-EXT 4.25). Broadcast, because the extension is about telling
// the hub's population who we are elsewhere; sending nothing when the list is empty is what
// keeps this opt-in.
void AdcHub::sendOnlineIdentities() noexcept {
	if (!stateNormal()) {
		return;
	}

	const auto& setting = SETTING(ONLINE_IDENTITIES);
	lastSentIdentities = setting;

	for (const auto& [service, params]: parseOnlineIdentities(setting)) {
		AdcCommand c(AdcCommand::CMD_OID, AdcCommand::TYPE_BROADCAST);
		c.addParam(service);
		c.addParam(params);

		string error;
		sendHooked(c, this, error);
	}
}

void AdcHub::handle(AdcCommand::OID, AdcCommand& c) noexcept {
	handleOnlineIdentity(c, false);
}

void AdcHub::handle(AdcCommand::OIR, AdcCommand& c) noexcept {
	handleOnlineIdentity(c, true);
}

void AdcHub::handleOnlineIdentity(AdcCommand& c, bool aIsRequest) noexcept {
	if (c.getParameters().empty())
		return;

	auto u = findUser(c.getFrom());
	if (!u)
		return;

	// Service names are matched case-insensitively (ADC-OID.txt), so store them folded
	const auto service = Text::toLower(c.getParam(0));
	if (service.empty() || service.size() > 32)
		return;

	// An OIR carrying only a service name is a request. Answer it directly when we publish
	// that service and stay silent otherwise - the extension allows saying nothing, and a
	// "no" would still confirm that somebody asked us.
	if (c.getParameters().size() < 2) {
		if (!aIsRequest)
			return;

		for (const auto& [ourService, params]: parseOnlineIdentities(SETTING(ONLINE_IDENTITIES))) {
			if (ourService != service)
				continue;

			AdcCommand reply(AdcCommand::CMD_OID, u->getIdentity().getSID(), AdcCommand::TYPE_DIRECT);
			reply.addParam(ourService);
			reply.addParam(params);

			string error;
			sendHooked(reply, this, error);
			break;
		}

		return;
	}

	string value;
	for (auto i = c.getParameters().begin() + 1; i != c.getParameters().end(); ++i) {
		if (i->size() < 2)
			continue;

		value += value.empty() ? *i : ", " + *i;
	}

	// Identity keys are exactly two bytes (they are packed into a short), so every service
	// shares the one "OI" entry, formatted as "service: params" and separated by " | ".
	// Re-sending a service replaces its entry, as OID requires.
	// Bounded. Every distinct service name adds another entry and nothing ever removed one, so a
	// hub could grow this single identity string without limit by sending ONID under a new service
	// each time -- and it is re-tokenised and rebuilt on every one of them, so the cost climbs with
	// it. The caps are far above any real use (a handful of services, short parameter lists).
	static constexpr size_t MAX_SERVICES = 16;
	static constexpr size_t MAX_OI_LENGTH = 1024;

	const auto prefix = service + ": ";
	size_t kept = 0;
	string merged;
	// Named local, not an inline temporary: getTokens() returns a reference into the tokenizer,
	// so iterating StringTokenizer(...).getTokens() directly would walk a dangling reference.
	StringTokenizer<string> existingServices(u->getIdentity().get("OI"), " | ");
	for (const auto& existing : existingServices.getTokens()) {
		if (existing.empty() || existing.compare(0, prefix.size(), prefix) == 0)
			continue;

		// The entry being (re)sent is appended after this loop and is never dropped, so the
		// oldest entries are what a full list gives up.
		if (kept + 1 >= MAX_SERVICES || merged.size() + existing.size() + 3 > MAX_OI_LENGTH) {
			break;
		}

		merged += existing + " | ";
		kept++;
	}

	merged += prefix + value;
	if (merged.size() > MAX_OI_LENGTH) {
		merged.resize(MAX_OI_LENGTH);
	}

	u->getIdentity().set("OI", merged);

	fire(ClientListener::UserUpdated(), this, u);
}

// GFA (ADC-EXT 4.6): another client asks for our publicly connectable favorite hubs. Answering is
// opt-in per hub entry; without that flag we stay silent, which the extension allows.
void AdcHub::handle(AdcCommand::GFA, AdcCommand& c) noexcept {
	auto from = findUser(c.getFrom());
	if (!from || from->getUser() == getMyIdentity().getUser())
		return;

	for (const auto& entry : FavoriteManager::getInstance()->getShareableFavoriteHubs()) {
		AdcCommand rfa(AdcCommand::CMD_RFA, from->getIdentity().getSID(), AdcCommand::TYPE_DIRECT);
		rfa.addParam("HA", entry.first);
		if (entry.second > 0) {
			rfa.addParam("LG", Util::toString(entry.second));
		}

		string error;
		sendHooked(rfa, this, error);
	}
}

// GFA (ADC-EXT 4.6), our side of the exchange: ask everyone on this hub that speaks DFAV for
// their public favorites. Throttled, because the answer is one RFA per hub per user and a
// crowded hub would otherwise let a keypress generate thousands of messages.
bool AdcHub::requestDistributedFavorites() noexcept {
	if (!stateNormal()) {
		return false;
	}

	// Nobody on this hub speaks DFAV: the request is a feature broadcast, so the hub would
	// forward it to no one anyway. Skipping is not just an optimization - ADC-EXT 4.6 gives
	// GFA the contexts "T, C" and never mentions the hub relaying it, so hubs that police
	// command contexts (ADCH++ with the guard script, for one) answer a feature-broadcast GFA
	// with a protocol error in main chat instead. Don't earn that on hubs where the request
	// could not have been answered in the first place.
	{
		RLock l(cs);
		auto anyDfavUser = ranges::any_of(users | views::values, [this](const OnlineUserPtr& ou) {
			return ou->getIdentity().getSID() != mySID && ou->getIdentity().hasSupport(OnlineUser::DFAV_FEATURE);
		});

		if (!anyDfavUser) {
			return false;
		}
	}

	// Test the throttle and arm the round under one lock: handle(RFA) is closing the previous
	// window on the socket thread at the same time, and an unsynchronized clear() against its
	// operator[] is undefined behaviour, not just a lost count.
	{
		auto now = GET_TICK();

		Lock l(dfavCs);
		if (lastFavoriteRequest != 0 && now < lastFavoriteRequest + DFAV_REQUEST_INTERVAL) {
			return false;
		}

		lastFavoriteRequest = now;
		pendingFavoriteRequest = now;
		favoriteReplyCounts.clear();
	}

	callAsync([this] {
		AdcCommand c(AdcCommand::CMD_GFA, AdcCommand::TYPE_FEATURE);
		c.addFeature(OnlineUser::DFAV_FEATURE, AdcCommand::FeatureType::REQUIRED);

		string error;
		sendHooked(c, this, error);
	});

	return true;
}

// RFA (ADC-EXT 4.6): a reply to our GFA, one hub address per message. We only believe replies
// that arrive inside the window we actually asked in, and only so many per user, because
// nothing stops a peer from answering a request we never made or answering it forever.
void AdcHub::handle(AdcCommand::RFA, AdcCommand& c) noexcept {
	if (c.getParameters().empty()) {
		return;
	}

	auto from = findUser(c.getFrom());
	if (!from || from->getUser() == getMyIdentity().getUser()) {
		return;
	}

	string address;
	if (!c.getParam("HA", 0, address) || address.empty() || address.length() > 512) {
		return;
	}

	// Window check and per-user quota under the one lock, since requestDistributedFavorites()
	// arms the next round from the UI thread. The counter is keyed by SID and reset when a
	// round starts, so a peer cannot spend another user's budget.
	{
		Lock l(dfavCs);

		if (pendingFavoriteRequest == 0 || GET_TICK() > pendingFavoriteRequest + DFAV_REPLY_WINDOW) {
			pendingFavoriteRequest = 0;
			return;
		}

		auto& count = favoriteReplyCounts[c.getFrom()];
		if (count >= MAX_DFAV_REPLIES_PER_USER) {
			return;
		}

		count++;
	}

	time_t lastLogin = 0;
	if (string lg; c.getParam("LG", 0, lg)) {
		lastLogin = static_cast<time_t>(Util::toInt64(lg));
	}

	FavoriteManager::getInstance()->addDiscoveredHub(address, lastLogin, getHubUrl(), from->getUser()->getCID());
}

void AdcHub::handle(AdcCommand::GPA, AdcCommand& c) noexcept {
	if(c.getParameters().empty() || c.getFrom() != AdcCommand::HUB_SID)
		return;
	salt = c.getParam(0);

	onPassword();
}

// Reconnect delay from a hub-supplied TL parameter, clamped. Unclamped, a value above 4294967
// overflowed the `delay * 1000` used by the reconnect check and produced a sub-second wait instead
// of a long one -- with setAutoReconnect(true) on the same line, a hub could hold the client in a
// ~1s reconnect loop. The fork's own $SearchRule handling already clamps for the same reason.
static uint32_t validateReconnectDelay(const string& aValue) noexcept {
	static const int64_t MAX_RECONNECT_DELAY = 24 * 60 * 60; // a day is plenty

	auto delay = Util::toInt64(aValue);
	if (delay < 0) {
		return 0;
	}

	return static_cast<uint32_t>(min(delay, MAX_RECONNECT_DELAY));
}

void AdcHub::handle(AdcCommand::QUI, AdcCommand& c) noexcept {
	auto s = AdcCommand::toSID(c.getParam(0));

	auto victim = findUser(s);
	if (victim) {
		string tmp;
		if(c.getParam("MS", 1, tmp)) {
			OnlineUserPtr source;
			if (string tmp2; c.getParam("ID", 1, tmp2)) {
				source = findUser(AdcCommand::toSID(tmp2));
			}
		
			if(source) {
				tmp = victim->getIdentity().getNick() + " was kicked by " +	source->getIdentity().getNick() + ": " + tmp;
			} else {
				tmp = victim->getIdentity().getNick() + " was kicked: " + tmp;
			}

			statusMessage(tmp, LogMessage::SEV_VERBOSE);
		}
	
		putUser(s, c.getParam("DI", 1, tmp)); 
	}
	
	if(s == mySID) {
		// this QUI is directed to us

		string tmp;
		if(c.getParam("TL", 1, tmp)) {
			if(tmp == "-1") {
				setAutoReconnect(false);
			} else {
				setAutoReconnect(true);
				setReconnDelay(validateReconnectDelay(tmp));
			}
		}

		if(!victim && c.getParam("MS", 1, tmp)) {
			statusMessage(tmp, LogMessage::SEV_INFO);
		}

		// Extended redirects (ADC-EXT 4.32): RX lists alternative addresses, with plain RD as the
		// fallback. Every candidate is collected first and then tried in turn, because the trust
		// rules below can reject one -- and the whole point of being handed a LIST of alternatives
		// is that the next may be fine. Taking only the first supported scheme and giving up when
		// prepareHubRedirect refused it meant a hub offering one bad address ahead of three good
		// ones lost the session outright.
		auto allowSecure = CryptoManager::getInstance()->TLSOk();

		StringList candidates;
		if (string rx; c.getParam("RX", 1, rx)) {
			StringTokenizer<string> urls(rx, ',');
			for (auto& url: urls.getTokens()) {
				LinkUtil::sanitizeUrl(url);
				if (!url.empty() && LinkUtil::isSupportedHubScheme(url, allowSecure)) {
					candidates.push_back(url);
				}
			}
		}

		// Kept last so RX still takes precedence, as it did before.
		if (c.getParam("RD", 1, tmp)) {
			LinkUtil::sanitizeUrl(tmp);
			if (!tmp.empty()) {
				candidates.push_back(tmp);
			}
		}

		string lastError;
		for (auto redirectTarget: candidates) {
			// Same trust rules as the NMDC $ForceMove path: the hub may not pick our
			// keyprint, drop us off TLS, or move a pinned session to another host.
			// prepareHubRedirect is const apart from rewriting the URL it accepts, so trying
			// the next candidate after a refusal leaves nothing behind.
			if (string error; !prepareHubRedirect(redirectTarget, error)) {
				lastError = error;
				continue;
			}

			// Only offer to persist addresses with a scheme we can connect to; anything
			// else keeps the plain (non-permanent) redirect behavior
			if (c.hasFlag("PT", 1) && LinkUtil::isSupportedHubScheme(redirectTarget, allowSecure)) {
				onPermanentRedirect(redirectTarget);
			} else {
				onRedirect(redirectTarget);
			}

			return;
		}

		// Only reported once every candidate has been refused, so a list where a later address
		// works does not also produce a warning about an earlier one.
		if (!lastError.empty()) {
			statusMessage(lastError, LogMessage::SEV_WARNING);
		}
	}
}

#define ASSERT_DIRECT_TO_ME(c) \
	if (c.getType() == AdcCommand::TYPE_DIRECT) { \
		if (c.getTo() != myIdentity.getSID()) { \
			statusMessage("SECURITY WARNING: received a " + c.getFourCC() + " message that should have been sent to a different user. This should never happen. Please inform the hub owner in order to get the security issue fixed.", LogMessage::SEV_WARNING); \
			return; \
		} \
	}

void AdcHub::handle(AdcCommand::CTM, AdcCommand& c) noexcept {
	auto ou = findUser(c.getFrom());
	if(c.getParameters().size() < 3)
		return;

	ASSERT_DIRECT_TO_ME(c)
	const string& protocol = c.getParam(0);
	const string& remotePort = c.getParam(1);
	const string& token = c.getParam(2);

	bool allowSecure = false;
	if (!validateConnectUser(ou, allowSecure, protocol, token, remotePort))
		return;

	SocketConnectOptions options(remotePort, allowSecure);
	ConnectionManager::getInstance()->adcConnect(*ou, options, token);
}

void AdcHub::handle(AdcCommand::ZON, AdcCommand& c) noexcept {
	if (c.getFrom() != AdcCommand::HUB_SID)
		return;

	try {
		sock->setMode(BufferedSocket::MODE_ZPIPE);
	} catch (const Exception& e) {
		dcdebug("AdcHub::handleZON failed with error: %s\n", e.getError().c_str());
	}
}

void AdcHub::handle(AdcCommand::ZOF, AdcCommand& c) noexcept {
	if (c.getFrom() != AdcCommand::HUB_SID)
		return;

	try {
		sock->setMode(BufferedSocket::MODE_LINE);
	} catch (const Exception& e) {
		dcdebug("AdcHub::handleZOF failed with error: %s\n", e.getError().c_str());
	}
}

void AdcHub::handle(AdcCommand::RCM, AdcCommand& c) noexcept {
	if (c.getParameters().size() < 2) {
		return;
	}

	auto u = findUser(c.getFrom());
	if (!u || u->getUser() == ClientManager::getInstance()->getMe())
		return;

	ASSERT_DIRECT_TO_ME(c)
	const string& protocol = c.getParam(0);
	const string& token = c.getParam(1);

	bool allowSecure = false;
	if (!checkProtocol(*u, allowSecure, protocol, token))
		return;

	if (getMyIdentity().isTcp4Active() || getMyIdentity().isTcp6Active()) {
		// We are active the other guy is not (and he wants to connect to us)
		connect(*u, token, allowSecure, true);
		return;
	}

	if (!u->getIdentity().hasSupport(OnlineUser::NAT0_FEATURE))
		return;

	// Attempt to traverse NATs and/or firewalls with TCP.
	// If they respond with their own, symmetric, RNT command, both
	// clients call ConnectionManager::adcConnect.
	sendHooked(AdcCommand(AdcCommand::CMD_NAT, u->getIdentity().getSID(), AdcCommand::TYPE_DIRECT).
		addParam(protocol).addParam(Util::toString(sock->getLocalPort())).addParam(token));
}

void AdcHub::handle(AdcCommand::CMD, AdcCommand& c) noexcept {
	if(c.getParameters().size() < 1)
		return;
	const string& name = c.getParam(0);
	bool rem = c.hasFlag("RM", 1);
	if(rem) {
		fire(ClientListener::HubUserCommand(), this, (int)UserCommand::TYPE_REMOVE, 0, name, Util::emptyString);
		return;
	}
	bool sep = c.hasFlag("SP", 1);
	string sctx;
	if(!c.getParam("CT", 1, sctx))
		return;
	int ctx = Util::toInt(sctx);
	if(ctx <= 0)
		return;
	if(sep) {
		fire(ClientListener::HubUserCommand(), this, (int)UserCommand::TYPE_SEPARATOR, ctx, name, Util::emptyString);
		return;
	}
	bool once = c.hasFlag("CO", 1);
	string txt;
	if(!c.getParam("TT", 1, txt))
		return;
	fire(ClientListener::HubUserCommand(), this, (int)(once ? UserCommand::TYPE_RAW_ONCE : UserCommand::TYPE_RAW), ctx, name, txt);
}

void AdcHub::handle(AdcCommand::STA, AdcCommand& c) noexcept {
	if(c.getParameters().size() < 2)
		return;

	auto u = c.getFrom() == AdcCommand::HUB_SID ? getUser(c.getFrom(), CID()) : findUser(c.getFrom());
	if (!u)
		return;

	int severity = Util::toInt(c.getParam(0).substr(0, 1));
	if(c.getParam(0).size() != 3) {
		return;
	}

	if (severity == AdcCommand::SUCCESS) {
		string fc;
		if(!c.getParam("FC", 1, fc) || fc.size() != 4)
			return;

		if (fc == "DSCH") {
			string token;
			if(!c.getParam("TO", 2, token))
				return;

			string resultCount;
			if(!c.getParam("RC", 2, resultCount))
				return;

			auto slash = token.find('/');
			if (slash != string::npos)
				ClientManager::getInstance()->fire(ClientManagerListener::DirectSearchEnd(), token.substr(slash+1), Util::toInt(resultCount));
		}
	} else {
		onErrorMessage(c, u);
	}
}

void AdcHub::onErrorMessage(const AdcCommand& c, const OnlineUserPtr& aSender) noexcept {
	switch(Util::toInt(c.getParam(0).substr(1))) {

	case AdcCommand::ERROR_BAD_PASSWORD:
		{
			if (c.getFrom() == AdcCommand::HUB_SID)
				setPassword(Util::emptyString);
			break;
		}

	case AdcCommand::ERROR_COMMAND_ACCESS:
		{
			if (c.getFrom() == AdcCommand::HUB_SID) {
				string tmp;
				if(c.getParam("FC", 1, tmp) && tmp.size() == 4)
					forbiddenCommands.insert(AdcCommand::toFourCC(tmp.c_str()));
			}
			break;
		}

	case AdcCommand::ERROR_PROTOCOL_UNSUPPORTED:
		{
			string protocol;
			if(c.getParam("PR", 1, protocol)) {
				if(protocol == OnlineUser::CLIENT_PROTOCOL) {
					aSender->getUser()->setFlag(User::NO_ADC_1_0_PROTOCOL);
				} else if(protocol == OnlineUser::SECURE_CLIENT_PROTOCOL_TEST) {
					aSender->getUser()->setFlag(User::NO_ADCS_0_10_PROTOCOL);
					aSender->getUser()->unsetFlag(User::TLS);
				}
				// Try again...
				//ConnectionManager::getInstance()->force(u->getUser());
				string token;
				if (c.getParam("TO", 2, token))
					ConnectionManager::getInstance()->failDownload(token, STRING_F(REMOTE_PROTOCOL_UNSUPPORTED, protocol), true);
			}
			return;
		}

	case AdcCommand::ERROR_HBRI_TIMEOUT:
		{
			if (c.getFrom() == AdcCommand::HUB_SID && hbriValidator) {
				resetHBRI();
				statusMessage(c.getParam(1), LogMessage::SEV_ERROR);
			}
			return;
		}
	case AdcCommand::ERROR_BAD_STATE:
		{
			string tmp;
			if (c.getParam("FC", 1, tmp) && tmp.size() == 4) {
				statusMessage(c.getParam(1) + " (command " + tmp + ", client state " + Util::toString(getConnectState()) + ")", LogMessage::SEV_ERROR);
				return;
			}
			break;
		}

	case AdcCommand::ERROR_FEATURE_INVALID:
		{
			// FC is a comma-separated list of rejected feature FOURCCs (ADC-EXT 4.15), unlike the single FOURCC in ERROR_COMMAND_ACCESS
			string features;
			if (c.getParam("FC", 1, features) && !features.empty()) {
				statusMessage(c.getParam(1) + " (rejected features: " + features + ")", LogMessage::SEV_WARNING);
			} else {
				statusMessage(c.getParam(1), LogMessage::SEV_WARNING);
			}
			return;
		}

	case AdcCommand::ERROR_INF_MISSING:
		{
			// FM names a field we left out, FB one the hub could not accept. Naming it turns
			// "the hub kicked me" into something the user can actually fix.
			if (c.getFrom() != AdcCommand::HUB_SID) {
				break;
			}

			string field;
			if (c.getParam("FM", 1, field) && !field.empty()) {
				statusMessage(STRING_F(ADC_INF_FIELD_MISSING, field % c.getParam(1)), LogMessage::SEV_ERROR);
				return;
			}

			if (c.getParam("FB", 1, field) && !field.empty()) {
				statusMessage(STRING_F(ADC_INF_FIELD_INVALID, field % c.getParam(1)), LogMessage::SEV_ERROR);
				return;
			}

			break;
		}

	case AdcCommand::ERROR_BAD_IP:
		{
			// ADC BASE: the hub reports the address it actually sees in I4/I6. We normally
			// send a zero address (which no hub can reject), so this only happens when the
			// user configured a manual IP the hub disagrees with. Stop insisting on it for
			// this session and let the hub decide, rather than looping on the same INF.
			if (c.getFrom() != AdcCommand::HUB_SID) {
				break;
			}

			auto changed = false;
			if (string ip; c.getParam("I4", 1, ip) && !hubIpRejected4) {
				hubIpRejected4 = true;
				changed = true;
				statusMessage(STRING_F(ADC_HUB_REJECTED_IP, get(HubSettings::UserIp4) % ip), LogMessage::SEV_WARNING);
			}

			if (string ip; c.getParam("I6", 1, ip) && !hubIpRejected6) {
				hubIpRejected6 = true;
				changed = true;
				statusMessage(STRING_F(ADC_HUB_REJECTED_IP, get(HubSettings::UserIp6) % ip), LogMessage::SEV_WARNING);
			}

			// Only re-send when something actually changed, or a hub that keeps saying no
			// would bounce INFs with us forever
			if (changed) {
				info();
				return;
			}

			break;
		}

	case AdcCommand::ERROR_NO_HUB_HASH:
	case AdcCommand::ERROR_NO_CLIENT_HASH:
		{
			// ADC-REC: both must be fatal. There is no hash algorithm in common, so
			// reconnecting cannot help - stop trying and say why.
			//
			// Only the hub can say so. STA is also routed as a direct message, so without
			// this check any user on the hub could send "DSTA <us> <them> 247" and knock
			// us off the hub with the reconnect timer disabled - the other fatal branches
			// below already refuse a non-hub sender.
			if (c.getFrom() != AdcCommand::HUB_SID) {
				break;
			}

			statusMessage(c.getParam(1), LogMessage::SEV_ERROR);
			setAutoReconnect(false);
			disconnect(false);
			return;
		}

	case AdcCommand::ERROR_HUB_FULL:
		{
			// Recoverable by waiting, so the reconnect loop is left alone
			statusMessage(c.getParam(1), LogMessage::SEV_WARNING);
			return;
		}

	case AdcCommand::ERROR_HUB_DISABLED:
	case AdcCommand::ERROR_REGGED_ONLY:
	case AdcCommand::ERROR_PERM_BANNED:
	case AdcCommand::ERROR_NICK_INVALID:
	case AdcCommand::ERROR_CID_TAKEN:
	case AdcCommand::ERROR_INVALID_PID:
		{
			// ADC-REC: all fatal, and none of them get better by retrying on a timer
			if (c.getFrom() != AdcCommand::HUB_SID) {
				break;
			}

			statusMessage(c.getParam(1), LogMessage::SEV_ERROR);
			setAutoReconnect(false);
			return;
		}

	case AdcCommand::ERROR_NICK_TAKEN:
		{
			// Fatal for this attempt, but a different nick would work, so keep the
			// reconnect timer: the user may be fixing the setting right now
			if (c.getFrom() != AdcCommand::HUB_SID) {
				break;
			}

			statusMessage(c.getParam(1), LogMessage::SEV_ERROR);
			return;
		}

	case AdcCommand::ERROR_TEMP_BANNED:
		{
			// TL is the number of seconds left, -1 meaning never (ADC BASE); same shape as
			// the QUI handler above, and worth honouring so we do not hammer a hub that
			// already told us how long to wait.
			if (c.getFrom() != AdcCommand::HUB_SID) {
				break;
			}

			if (string tl; c.getParam("TL", 1, tl)) {
				if (tl == "-1") {
					setAutoReconnect(false);
				} else {
					setAutoReconnect(true);
					setReconnDelay(validateReconnectDelay(tl));
				}
			}

			statusMessage(c.getParam(1), LogMessage::SEV_ERROR);
			return;
		}
	}

	auto message = std::make_shared<ChatMessage>(c.getParam(1), aSender);
	onChatMessage(message);
}

void AdcHub::handle(AdcCommand::SCH, AdcCommand& c) noexcept {
	auto ou = findUser(c.getFrom());
	if (!ou) {
		dcdebug("Invalid user in AdcHub::onSCH\n");
		return;
	}

	{
		auto remotePort = ou->getIdentity().getUdpPort();
		auto target = !remotePort.empty() ? ou->getIdentity().getUdpIp() + ":" + remotePort : ou->getIdentity().getNick();
		if (!checkIncomingSearch(target, ou)) {
			return;
		}
	}

	ASSERT_DIRECT_TO_ME(c)

	// Filter own searches
	if(ou->getUser() == ClientManager::getInstance()->getMe())
		return;

	// No point to send results if downloads aren't possible
	auto mode = ou->getIdentity().getTcpConnectMode();
	if (!Identity::allowConnections(mode)) {
		return;
	}

	auto isUdpActive = Identity::isActiveMode(mode);
	SearchManager::getInstance()->respond(c, this, ou, isUdpActive, get(HubSettings::ShareProfile));
}

void AdcHub::handle(AdcCommand::RES, AdcCommand& c) noexcept {
	auto ou = findUser(c.getFrom());
	if (!ou) {
		dcdebug("Invalid user in AdcHub::onRES\n");
		return;
	}
	ASSERT_DIRECT_TO_ME(c)
	SearchManager::getInstance()->onRES(c, ou->getUser(), ou->getIdentity().getUdpIp());
}

void AdcHub::handle(AdcCommand::GET, AdcCommand& c) noexcept {
	if(c.getParameters().size() < 5) {
		if(c.getParameters().size() > 0) {
			if(c.getParam(0) == "blom") {
				sendHooked(AdcCommand(AdcCommand::SEV_FATAL, AdcCommand::ERROR_PROTOCOL_GENERIC,
					"Too few parameters for blom", AdcCommand::TYPE_HUB));
			} else {
				sendHooked(AdcCommand(AdcCommand::SEV_FATAL, AdcCommand::ERROR_TRANSFER_GENERIC,
					"Unknown transfer type", AdcCommand::TYPE_HUB));
			}
		} else {
			sendHooked(AdcCommand(AdcCommand::SEV_FATAL, AdcCommand::ERROR_PROTOCOL_GENERIC,
				"Too few parameters for GET", AdcCommand::TYPE_HUB));
		}
		return;
	}

	const string& type = c.getParam(0);
	string sk, sh;
	if(type == "blom" && c.getParam("BK", 4, sk) && c.getParam("BH", 4, sh))  {
		ByteVector v;
		size_t m = Util::toUInt32(c.getParam(3)) * 8;
		size_t k = Util::toUInt32(sk);
		size_t h = Util::toUInt32(sh);
				
		if(k > 8 || k < 1) {
			sendHooked(AdcCommand(AdcCommand::SEV_FATAL, AdcCommand::ERROR_TRANSFER_GENERIC,
				"Unsupported k", AdcCommand::TYPE_HUB));
			return;
		}
		if(h > 64 || h < 1) {
			sendHooked(AdcCommand(AdcCommand::SEV_FATAL, AdcCommand::ERROR_TRANSFER_GENERIC,
				"Unsupported h", AdcCommand::TYPE_HUB));
			return;
		}

		size_t n = ShareManager::getInstance()->getBloomFileCount(get(HubSettings::ShareProfile));

		// Ideal size for m is n * k / ln(2), but we allow some slack
		// When h >= 32, m can't go above 2^h anyway since it's stored in a size_t.
		if(m > static_cast<size_t>((5 * Util::roundUp((int64_t)(n * k / log(2.)), (int64_t)64))) || (h < 32 && m > static_cast<size_t>(1ULL << h))) {
			sendHooked(AdcCommand(AdcCommand::SEV_FATAL, AdcCommand::ERROR_TRANSFER_GENERIC,
				"Unsupported m", AdcCommand::TYPE_HUB));
			return;
		}
		
		if (m > 0) {
			dcdebug("Creating bloom filter, k=" SIZET_FMT ", m=" SIZET_FMT ", h=" SIZET_FMT "\n", k, m, h);
			ShareManager::getInstance()->getBloom(get(HubSettings::ShareProfile), v, k, m, h);
		}
		AdcCommand cmd(AdcCommand::CMD_SND, AdcCommand::TYPE_HUB);
		cmd.addParam(c.getParam(0));
		cmd.addParam(c.getParam(1));
		cmd.addParam(c.getParam(2));
		cmd.addParam(c.getParam(3));
		cmd.addParam(c.getParam(4));
		sendHooked(cmd);
		if (m > 0) {
			send((char*)&v[0], v.size());
		}
	}
}

void AdcHub::handle(AdcCommand::NAT, AdcCommand& c) noexcept {
	ASSERT_DIRECT_TO_ME(c)
	auto u = findUser(c.getFrom());
	if (c.getParameters().size() < 3)
		return;

	const string& protocol = c.getParam(0);
	const string& remotePort = c.getParam(1);
	const string& token = c.getParam(2);

	bool allowSecure = false;
	if (!validateConnectUser(u, allowSecure, protocol, token, remotePort))
		return;

	// Trigger connection attempt sequence locally ...
	auto localPort = Util::toString(sock->getLocalPort());
	dcdebug("triggering connecting attempt in NAT: remote port = %s, local IP = %s, local port = %d\n", remotePort.c_str(), sock->getLocalIp().c_str(), sock->getLocalPort());

	SocketConnectOptions options(remotePort, allowSecure, NatRole::CLIENT);
	ConnectionManager::getInstance()->adcConnect(*u, options, localPort, token);

	// ... and signal other client to do likewise.
	sendHooked(AdcCommand(AdcCommand::CMD_RNT, u->getIdentity().getSID(), AdcCommand::TYPE_DIRECT).addParam(protocol).
		addParam(localPort).addParam(token));
}

void AdcHub::handle(AdcCommand::RNT, AdcCommand& c) noexcept {
	ASSERT_DIRECT_TO_ME(c)
	// Sent request for NAT traversal cooperation, which
	// was acknowledged (with requisite local port information).
	auto u = findUser(c.getFrom());
	if(c.getParameters().size() < 3)
		return;

	const string& protocol = c.getParam(0);
	const string& remotePort = c.getParam(1);
	const string& token = c.getParam(2);

	bool allowSecure = false;
	if (!validateConnectUser(u, allowSecure, protocol, token, remotePort))
		return;

	// Trigger connection attempt sequence locally
	dcdebug("triggering connecting attempt in RNT: remote port = %s, local IP = %s, local port = %d\n", remotePort.c_str(), sock->getLocalIp().c_str(), sock->getLocalPort());

	SocketConnectOptions options(remotePort, allowSecure, NatRole::SERVER);
	ConnectionManager::getInstance()->adcConnect(*u, options, Util::toString(sock->getLocalPort()), token);
}

void AdcHub::resetHBRI() noexcept {
	if (hbriValidator) {
		hbriValidator->stopAndWait();
		hbriValidator.reset();
	}
}

void AdcHub::handle(AdcCommand::TCP, AdcCommand& c) noexcept {
	if (c.getType() != AdcCommand::TYPE_INFO)
		return;

	resetHBRI();

	// Validate the command
	if (c.getParameters().size() < 3 || c.getFrom() != AdcCommand::HUB_SID) {
		return;
	}

	HBRIValidator::ConnectInfo connectInfo(!sock->isV6Valid(), isSocketSecure());

	string token;
	if (!c.getParam("TO", 2, token))
		return;

	if (!c.getParam(connectInfo.v6 ? "I6" : "I4", 0, connectInfo.ip))
		return;

	if (!c.getParam(connectInfo.v6 ? "P6" : "P4", 0, connectInfo.port))
		return;

	// The address must be a literal, and the port a real port. Socket::resolveAddr passes this to
	// getaddrinfo with no flags, so a hostname here is RESOLVED and connected to -- which turns any
	// ADC hub into an arbitrary-destination connect and DNS-lookup primitive, from a background
	// thread, before we have even answered SUP. The NMDC side already refuses a non-literal
	// $ConnectToMe address for exactly this reason; this path had no equivalent.
	if (!NetworkUtil::isValidIp(connectInfo.ip, connectInfo.v6 ? AF_INET6 : AF_INET)) {
		dcdebug("AdcHub::handle(TCP): refusing non-literal HBRI address %s\n", connectInfo.ip.c_str());
		return;
	}

	if (auto port = Util::toInt(connectInfo.port); port <= 0 || port > 65535) {
		dcdebug("AdcHub::handle(TCP): refusing HBRI port %s\n", connectInfo.port.c_str());
		return;
	}

	statusMessage(STRING_F(HBRI_VALIDATING_X, (connectInfo.v6 ? "IPv6" : "IPv4")), LogMessage::SEV_INFO);

	hbriValidator = make_unique<HBRIValidator>(
		connectInfo,
		getHBRIRequest(connectInfo.v6, token).toString(mySID),
		[this](auto... args) { statusMessage(args...); }
	);
}

AdcCommand AdcHub::getHBRIRequest(bool v6, const string& aToken) const noexcept {
	AdcCommand hbriCmd(AdcCommand::CMD_TCP, AdcCommand::TYPE_HUB);

	StringMap dummyMap;
	appendConnectivity(dummyMap, hbriCmd, !v6, v6);
	hbriCmd.addParam("TO", aToken);
	return hbriCmd;
}

int AdcHub::connect(const OnlineUser& user, const string& token, string& lastError_) noexcept {
	bool allowSecure = CryptoManager::getInstance()->TLSOk() && user.getUser()->isSet(User::TLS);
	auto conn = allowConnect(user, allowSecure, lastError_, true);
	if (conn == AdcCommand::SUCCESS) {
		connect(user, token, allowSecure);
	}

	return conn;
}


bool AdcHub::validateConnectUser(const OnlineUserPtr& aUser, bool& secure_, const string& aRemoteProtocol, const string& aToken, const string& aRemotePort) noexcept {
	if (!aUser || aUser->getUser() == ClientManager::getInstance()->getMe())
		return false;

	if (!checkProtocol(*aUser, secure_, aRemoteProtocol, aToken)) {
		return false;
	}

	auto target = aUser->getIdentity().getTcpConnectIp() + ":" + aRemotePort;
	if (!checkIncomingCTM(target, aUser)) {
		return false;
	}

	return true;
}

bool AdcHub::checkProtocol(const OnlineUser& aUser, bool& secure_, const string& aRemoteProtocol, const string& aToken) noexcept {
	string failedProtocol;
	AdcCommand::Error errCode = AdcCommand::SUCCESS;

	if(aRemoteProtocol == OnlineUser::CLIENT_PROTOCOL) {
		// Nothing special
	} else if(aRemoteProtocol == OnlineUser::SECURE_CLIENT_PROTOCOL_TEST) {
		if (!CryptoManager::getInstance()->TLSOk())
			return false;
		secure_ = true;
	} else {
		errCode = AdcCommand::ERROR_PROTOCOL_UNSUPPORTED;
		failedProtocol = aRemoteProtocol;
	}


	if (errCode == AdcCommand::SUCCESS)
		errCode = allowConnect(aUser, secure_, failedProtocol, false);

	if (errCode != AdcCommand::SUCCESS) {
		if (errCode == AdcCommand::ERROR_TLS_REQUIRED) {
			sendHooked(AdcCommand(AdcCommand::SEV_FATAL, errCode, "TLS encryption required", AdcCommand::TYPE_DIRECT).setTo(aUser.getIdentity().getSID()));
		} else if (errCode == AdcCommand::ERROR_PROTOCOL_UNSUPPORTED) {
			AdcCommand cmd(AdcCommand::SEV_FATAL, AdcCommand::ERROR_PROTOCOL_UNSUPPORTED, failedProtocol + " protocol not supported", AdcCommand::TYPE_DIRECT);
			cmd.setTo(aUser.getIdentity().getSID());
			cmd.addParam("PR", failedProtocol);
			cmd.addParam("TO", aToken);

			sendHooked(cmd);
		}

		return false;
	}

	return true;
}

AdcCommand::Error AdcHub::allowConnect(const OnlineUser& aUser, bool aSecure, string& failedProtocol_, bool checkBase) const noexcept {
	//check the state
	if(!stateNormal())
		return AdcCommand::ERROR_BAD_STATE;

	if (checkBase) {
		//check the ADC protocol
		if(aSecure) {
			if(aUser.getUser()->isSet(User::NO_ADCS_0_10_PROTOCOL)) {
				failedProtocol_ = OnlineUser::SECURE_CLIENT_PROTOCOL_TEST;
				return AdcCommand::ERROR_PROTOCOL_UNSUPPORTED;
			}
		} else {
			if(aUser.getUser()->isSet(User::NO_ADC_1_0_PROTOCOL)) {
				failedProtocol_ = OnlineUser::CLIENT_PROTOCOL;
				return AdcCommand::ERROR_PROTOCOL_UNSUPPORTED;
			}
		}
	}

	//check TLS
	if (!aSecure && SETTING(TLS_MODE) == SettingsManager::TLS_FORCED) {
		return AdcCommand::ERROR_TLS_REQUIRED;
	}

	//check the passive mode
	if (aUser.getIdentity().getTcpConnectMode() == Identity::MODE_NOCONNECT_PASSIVE) {
		return AdcCommand::ERROR_FEATURE_MISSING;
	}

	//check the IP protocol
	if (aUser.getIdentity().getTcpConnectMode() == Identity::MODE_NOCONNECT_IP) {
		if (!getMyIdentity().getIp6().empty() && !Identity::allowV6Connections(aUser.getIdentity().getTcpConnectMode())) {
			failedProtocol_ = "IPv6";
			return AdcCommand::ERROR_PROTOCOL_UNSUPPORTED;
		}

		if (!getMyIdentity().getIp4().empty() && !Identity::allowV4Connections(aUser.getIdentity().getTcpConnectMode())) {
			failedProtocol_ = "IPv4";
			return AdcCommand::ERROR_PROTOCOL_UNSUPPORTED;
		}

		return AdcCommand::ERROR_PROTOCOL_GENERIC;
	}

	return AdcCommand::SUCCESS;
}


bool AdcHub::acceptUserConnections(const OnlineUser& aUser) const noexcept {
	auto allowV4 = Identity::allowV4Connections(aUser.getIdentity().getTcpConnectMode()) && getMyIdentity().isTcp4Active();
	auto allowV6 = Identity::allowV6Connections(aUser.getIdentity().getTcpConnectMode()) && getMyIdentity().isTcp6Active();
	return allowV4 || allowV6;
}

void AdcHub::connect(const OnlineUser& aUser, const string& aToken, bool aSecure, bool aReplyingRCM) noexcept {
	const string* proto = aSecure ? &OnlineUser::SECURE_CLIENT_PROTOCOL_TEST : &OnlineUser::CLIENT_PROTOCOL;

	// Always let the other user connect if he requested that even if we haven't determined common connectivity
	if (aReplyingRCM || acceptUserConnections(aUser)) {
		const string& ownPort = aSecure ? ConnectionManager::getInstance()->getSecurePort() : ConnectionManager::getInstance()->getPort();
		if(ownPort.empty()) {
			// Oops?
			LogManager::getInstance()->message(STRING(NOT_LISTENING), LogMessage::SEV_ERROR, STRING(CONNECTIVITY));
			return;
		}

		auto cmd = AdcCommand(AdcCommand::CMD_CTM, aUser.getIdentity().getSID(), AdcCommand::TYPE_DIRECT).addParam(*proto).addParam(ownPort).addParam(aToken);
		auto user = aUser.getUser();
		callAsync([=, this, cmd = std::move(cmd)] {
			if (sendHooked(cmd)) {
				// We are expecting an incoming connection from these, map so we know where its coming from.
				ConnectionManager::getInstance()->adcExpect(aToken, user->getCID(), getHubUrl());
			}
		});
	} else {
		auto cmd = AdcCommand(AdcCommand::CMD_RCM, aUser.getIdentity().getSID(), AdcCommand::TYPE_DIRECT).addParam(*proto).addParam(aToken);
		callAsync([this, cmd = std::move(cmd)] {
			sendHooked(cmd);
		});
	}
}

bool AdcHub::hubMessageHooked(const OutgoingChatMessage& aMessage, string& error_) noexcept {
	// A plugin may veto (and thereby suppress) the outgoing message
	if(PluginManager::getInstance()->runHook<HubData>(HOOK_CHAT_OUT, this, aMessage.text))
		return true;

	AdcCommand c(AdcCommand::CMD_MSG, AdcCommand::TYPE_BROADCAST);
	c.addParam(aMessage.text);
	if (aMessage.thirdPerson)
		c.addParam("ME", "1");
	// RTF0: "A client MUST NOT send rich text on a hub that has not announced RTF0."
	// Enforced here rather than only in the GUI - it is a protocol invariant, and the
	// hub may withdraw the feature between composing and sending.
	if (aMessage.rich && supports.includes(RTF0_SUPPORT))
		c.addParam("RT", "1");
	// ADC-EXT 4.5: when the message was sent, so a hub replaying history and clients with a
	// skewed clock show the right time. We already read TS on the way in.
	c.addParam("TS", Util::toString(GET_TIME()));

	if (!sendHooked(c, aMessage.owner, error_)) {
		return false;
	}

	return true;
}

bool AdcHub::privateMessageHooked(const OnlineUserPtr& aUser, const OutgoingChatMessage& aMessage, string& error_, bool aEcho) noexcept {
	if(!stateNormal()) {
		error_ = STRING(CONNECTING_IN_PROGRESS);
		return false;
	}

	AdcCommand c(AdcCommand::CMD_MSG, aUser->getIdentity().getSID(), aEcho ? AdcCommand::TYPE_ECHO : AdcCommand::TYPE_DIRECT);
	c.addParam(aMessage.text);
	if(aMessage.thirdPerson)
		c.addParam("ME", "1");
	// Both gates matter for a PM: the hub must carry rich text at all, and the SU field
	// is what tells us this particular recipient will render it rather than show markers.
	if (aMessage.rich && supports.includes(RTF0_SUPPORT) && aUser->getIdentity().hasSupport(OnlineUser::RTF0_FEATURE))
		c.addParam("RT", "1");
	c.addParam("TS", Util::toString(GET_TIME()));	// ADC-EXT 4.5
	c.addParam("PM", getMySID());

	if (!sendHooked(c, aMessage.owner, error_)) {
		return false;
	}

	return true;
}

void AdcHub::sendUserCmd(const UserCommand& aUserCommand, const ParamMap& params) {
	if(!stateNormal())
		return;

	string userCommandStr = Util::formatParams(aUserCommand.getCommand(), params, escape);
	if (aUserCommand.isChat()) {
		callAsync([aUserCommand, this, userCommandStr = std::move(userCommandStr)] {
			// This probably shouldn't trigger the message hooks...
			string error;
			OutgoingChatMessage c(userCommandStr, this, "user_command", false);
			if (aUserCommand.getTo().empty()) {
				hubMessageHooked(c, error);
			} else {
				auto ou = findUser(aUserCommand.getTo());
				if (ou) {
					privateMessageHooked(ou, c, error, false);
				}
			}
		});
	} else {
		send(userCommandStr);
	}
}

const vector<StringList>& AdcHub::getSearchExts() noexcept {
	return searchExtensions;
}

StringList AdcHub::parseSearchExts(int flag) noexcept {
	StringList ret;
	const auto& searchExts = getSearchExts();
	for(auto i = searchExts.cbegin(), iend = searchExts.cend(); i != iend; ++i) {
		if(flag & (1 << (i - searchExts.cbegin()))) {
			ret.insert(ret.begin(), i->begin(), i->end());
		}
	}
	return ret;
}

bool AdcHub::directSearchHooked(const OnlineUser& user, const SearchPtr& aSearch, string& error_) noexcept {
	if (!stateNormal()) {
		error_ = STRING(CONNECTING_IN_PROGRESS);
		return false;
	}

	AdcCommand c(AdcCommand::CMD_SCH, (user.getIdentity().getSID()), AdcCommand::TYPE_DIRECT);
	if (user.getUser()->isSet(User::ASCH)) {
		if (!PathUtil::isAdcRoot(aSearch->path)) {
			dcassert(PathUtil::isAdcDirectoryPath(aSearch->path));
			c.addParam("PA", aSearch->path);
		}

		if (aSearch->requireReply) {
			c.addParam("RE", "1");
		}

		if (aSearch->returnParents) {
			c.addParam("PP", "1");
		}

		if (aSearch->matchType != Search::MATCH_PATH_PARTIAL) {
			c.addParam("MT", Util::toString(aSearch->matchType)); // name matches only
		}

		c.addParam("MR", Util::toString(aSearch->maxResults));
	}

	if (!sendSearchHooked(c, aSearch, &user)) {
		error_ = STRING(PERMISSION_DENIED_HUB);
		return false;
	}

	return true;
}

uint8_t AdcHub::groupExtensions(StringList& exts_, StringList& excluded_) noexcept {
	uint8_t gr = 0;
	const auto& searchExts = getSearchExts();
	for (auto i = searchExts.cbegin(), iend = searchExts.cend(); i != iend; ++i) {
		const StringList& def = *i;

		// gather the exts not present in any of the lists
		StringList temp(def.size() + exts_.size());
		temp = StringList(temp.begin(), set_symmetric_difference(def.begin(), def.end(),
			exts_.begin(), exts_.end(), temp.begin()));

		// figure out whether the remaining exts have to be added or removed from the set
		StringList rx_;
		bool ok = true;
		for (auto diff = temp.begin(); diff != temp.end();) {
			if (find(def.cbegin(), def.cend(), *diff) == def.cend()) {
				++diff; // will be added further below as an "EX"
			} else {
				if (rx_.size() == 2) {
					ok = false;
					break;
				}
				rx_.push_back(*diff);
				diff = temp.erase(diff);
			}
		}
		if (!ok) // too many "RX"s necessary - disregard this group
			continue;

		// let's include this group!
		gr += 1 << (i - searchExts.cbegin());

		exts_ = temp; // the exts to still add (that were not defined in the group)

		excluded_.insert(excluded_.begin(), rx_.begin(), rx_.end());

		if (exts_.size() <= 2)
			break;
		// keep looping to see if there are more exts that can be grouped
	}

	return gr;
}

void AdcHub::handleSearchExtensions(AdcCommand& c, const SearchPtr& aSearch, const OnlineUser* aDirectUser) noexcept {
	auto appendAllExtensions = [&aSearch](AdcCommand& aCmd) {
		for (const auto& ex : aSearch->exts)
			aCmd.addParam("EX", ex);
	};

	if (aSearch->exts.size() <= 2) {
		// No need for grouping
		appendAllExtensions(c);
		return;
	}

	StringList exts = aSearch->exts;
	sort(exts.begin(), exts.end());

	StringList excluded;
	auto group = groupExtensions(exts, excluded);

	if (!group) {
		return;
	}

	auto appendGroupInfo = [&excluded, &exts, group] (AdcCommand& aCmd) {
		for(const auto& ext: exts)
			aCmd.addParam("EX", ext);

		aCmd.addParam("GR", Util::toString(group));
		for(const auto& i: excluded)
			aCmd.addParam("RX", i);
	};

	if (aDirectUser) {
		if (aDirectUser->getIdentity().hasSupport(OnlineUser::SEGA_FEATURE)) {
			appendGroupInfo(c);
		} else {
			appendAllExtensions(c);
		}
	} else {
		// some extensions can be grouped; let's send a command with grouped exts.
		AdcCommand c_gr(AdcCommand::CMD_SCH, AdcCommand::TYPE_FEATURE);
		c_gr.setFeatures(c.getFeatures());
		c_gr.addFeature(OnlineUser::SEGA_FEATURE, AdcCommand::FeatureType::REQUIRED);

		const auto& params = c.getParameters();
		for(const auto& p: params)
			c_gr.addParam(p);

		appendGroupInfo(c_gr);
		sendSearch(c_gr);

		// make sure users with the feature don't receive the search twice.
		c.setType(AdcCommand::TYPE_FEATURE);
		c.addFeature(OnlineUser::SEGA_FEATURE, AdcCommand::FeatureType::EXCLUDED);

		appendAllExtensions(c);
	}
}

bool AdcHub::sendSearchHooked(AdcCommand& c, const SearchPtr& aSearch, const OnlineUser* aDirectUser) noexcept {
	if(!aSearch->token.empty()) {
		c.addParam("TO", Util::toString(getToken()) + "/" + aSearch->token);

		// Remember what we asked for, so an incoming RES carrying a token we never sent can be
		// rejected. This is the funnel: the wire token is built here, so every outgoing ADC
		// search (broadcast and direct) passes through.
		SearchManager::getInstance()->onSearchTokenSent(aSearch->token);
	}

	if(aSearch->fileType == Search::TYPE_TTH) {
		c.addParam("TR", aSearch->query);

	} else {
		// ADC BASE: EQ is an exact-size match. A GE/LE pair with the same bound means the
		// same thing but makes every responder run two comparisons, and EQ is what the
		// receiving side already parses (SearchQuery).
		if (aSearch->minSize && aSearch->maxSize && *aSearch->minSize == *aSearch->maxSize) {
			c.addParam("EQ", Util::toString(*aSearch->minSize));
		} else {
			if (aSearch->minSize) {
				c.addParam("GE", Util::toString(*aSearch->minSize));
			}

			if (aSearch->maxSize) {
				c.addParam("LE", Util::toString(*aSearch->maxSize));
			}
		}

		auto searchTokens = SearchQuery::parseSearchString(aSearch->query);
		for(const auto& t: searchTokens)
			c.addParam("AN", t);

		for(const auto& e: aSearch->excluded) {
			c.addParam("NO", e);
		}

		if(aSearch->fileType == Search::TYPE_DIRECTORY) {
			c.addParam("TY", "2");
		} else if (aSearch->fileType == Search::TYPE_FILE) {
			c.addParam("TY", "1");
		}

		if (aSearch->minDate) {
			c.addParam("NT", Util::toString(*aSearch->minDate));
		}

		if (aSearch->maxDate) {
			c.addParam("OT", Util::toString(*aSearch->maxDate));
		}

		if (!aSearch->key.empty() && isSocketSecure() && myIdentity.isUdpActive()) {
			c.addParam("KY", aSearch->key);
		}

		handleSearchExtensions(c, aSearch, aDirectUser);
	}

	return sendHooked(c);
}

void AdcHub::search(const SearchPtr& s) noexcept {
	if(!stateNormal())
		return;

	callAsync([this, s] {
		AdcCommand c(AdcCommand::CMD_SCH, AdcCommand::TYPE_BROADCAST);
		if (s->aschOnly) {
			c.setType(AdcCommand::TYPE_FEATURE);
			c.addFeature(OnlineUser::ASCH_FEATURE, AdcCommand::FeatureType::REQUIRED);
		}

		sendSearchHooked(c, s, nullptr);
	});
}

void AdcHub::sendSearch(AdcCommand& c) {
	if (isActive()) {
		sendHooked(c);
	} else {
		c.setType(AdcCommand::TYPE_FEATURE);
		string features = c.getFeatures();
		c.setFeatures(features + '+' + OnlineUser::TCP4_FEATURE + '-' + OnlineUser::NAT0_FEATURE);
		sendHooked(c);
		c.setFeatures(features + "+" + OnlineUser::NAT0_FEATURE);

		sendHooked(c);
	}
}

void AdcHub::password(const string& pwd) noexcept {
	if(getConnectState() != STATE_VERIFY)
		return;

	setPassword(pwd);
	// The ADC spec requires the salt to be at least 24 bytes; one prevalent hub
	// software sends only a 6 byte long one. A hub-supplied salt that is too
	// short, oversized or not valid base32 is rejected outright (no PAS is sent)
	// rather than hashed as-is. @todo raise the minimum to 24 when feasible
	if(salt.size() >= 10 && salt.size() <= 1024 && Encoder::isBase32(salt.c_str())) {
		size_t saltBytes = salt.size() * 5 / 8;
		boost::scoped_array<uint8_t> buf(new uint8_t[saltBytes]);
		Encoder::fromBase32(salt.c_str(), &buf[0], saltBytes);
		TigerHash th;
		if(oldPassword) {
			CID cid = getMyIdentity().getUser()->getCID();
			th.update(cid.data(), CID::SIZE);
		}
		th.update(pwd.data(), pwd.length());
		th.update(&buf[0], saltBytes);
		salt.clear();

		auto cmd = AdcCommand(AdcCommand::CMD_PAS, AdcCommand::TYPE_HUB).addParam(Encoder::toBase32(th.finalize(), TigerHash::BYTES));
		callAsync([this, cmd = std::move(cmd)] {
			sendHooked(cmd);
		});
	}
}

static void addParam(StringMap& lastInfoMap, AdcCommand& c, const string& var, const string& value) noexcept {
	auto i = lastInfoMap.find(var);
	if(i != lastInfoMap.end()) {
		if(i->second != value) {
			if(value.empty()) {
				lastInfoMap.erase(i);
			} else { 
				i->second = value;
			}
			c.addParam(var, value);
		}
	} else if(!value.empty()) {
		lastInfoMap.try_emplace(var, value);
		c.addParam(var, value);
	}
}

bool AdcHub::isIpFamilyRelevant(bool aV6) const noexcept {
	// Mirrors infoImpl's addV4/addV6: the socket family, plus the secondary family
	// when it is enabled and the hub can carry it via HBRI
	if (!sock) {
		return false;
	}

	auto supportsHBRI = supports.includes(HBRI_SUPPORT);
	if (aV6) {
		return sock->isV6Valid() || (get(HubSettings::Connection6) != SettingsManager::INCOMING_DISABLED && supportsHBRI);
	}

	return !sock->isV6Valid() || (get(HubSettings::Connection) != SettingsManager::INCOMING_DISABLED && supportsHBRI);
}

bool AdcHub::canAnnounceIp(bool aV6) const noexcept {
	// Mirrors appendConnectivity: in every other configuration we send a zero address,
	// which tells the hub to keep using what it sees on the (unchanged) socket
	if (aV6) {
		return CONNSETTING(NO_IP_OVERRIDE6) && !get(HubSettings::UserIp6).empty() && !hubIpRejected6;
	}

	return CONNSETTING(NO_IP_OVERRIDE) && !get(HubSettings::UserIp4).empty() && !hubIpRejected4;
}

OnlineUserPtr AdcHub::getMyOnlineUser() const noexcept {
	return findUser(mySID);
}

void AdcHub::appendConnectivity(StringMap& aLastInfoMap, AdcCommand& c, bool v4, bool v6) const noexcept {
	if (v4) {
		// A zero address asks the hub to fill in what it sees, so it can never be rejected;
		// hubIpRejected4 records that the hub turned down our manual override with STA 46
		// and we fell back to letting it decide for the rest of this session.
		if(CONNSETTING(NO_IP_OVERRIDE) && !get(HubSettings::UserIp4).empty() && !hubIpRejected4) {
			addParam(aLastInfoMap, c, "I4", Socket::resolve(get(HubSettings::UserIp4), AF_INET));
		} else {
			addParam(aLastInfoMap, c, "I4", "0.0.0.0");
		}

		if(isActiveV4()) {
			addParam(aLastInfoMap, c, "U4", SearchManager::getInstance()->getPort());
		} else {
			addParam(aLastInfoMap, c, "U4", "");
		}
	} else {
		addParam(aLastInfoMap, c, "I4", "");
		addParam(aLastInfoMap, c, "U4", "");
	}

	if (v6) {
		if (CONNSETTING(NO_IP_OVERRIDE6) && !get(HubSettings::UserIp6).empty() && !hubIpRejected6) {
			addParam(aLastInfoMap, c, "I6", Socket::resolve(get(HubSettings::UserIp6), AF_INET6));
		} else {
			addParam(aLastInfoMap, c, "I6", "::");
		}

		if(isActiveV6()) {
			addParam(aLastInfoMap, c, "U6", SearchManager::getInstance()->getPort());
		} else {
			addParam(aLastInfoMap, c, "U6", "");
		}
	} else {
		addParam(aLastInfoMap, c, "I6", "");
		addParam(aLastInfoMap, c, "U6", "");
	}
}


void AdcHub::appendClientSupports(StringMap& aLastInfoMap, AdcCommand& c, bool v4, bool v6) const noexcept {
	string su(OnlineUser::SEGA_FEATURE);

	if (CryptoManager::getInstance()->TLSOk()) {
		su += "," + OnlineUser::ADCS_FEATURE;
		su += "," + OnlineUser::CCPM_FEATURE;
	}

	if (SETTING(ENABLE_SUDP)) {
		su += "," + OnlineUser::SUD1_FEATURE;
	}

	if (SETTING(USE_PARTIAL_SHARING)) {
		su += "," + OnlineUser::PFSR_FEATURE;
	}

	if (v4 && isActiveV4()) {
		su += "," + OnlineUser::TCP4_FEATURE;
		su += "," + OnlineUser::UDP4_FEATURE;
	}

	if (v6 && isActiveV6()) {
		su += "," + OnlineUser::TCP6_FEATURE;
		su += "," + OnlineUser::UDP6_FEATURE;
	}

	if ((v6 && !isActiveV6() && get(HubSettings::Connection6) != SettingsManager::INCOMING_DISABLED) ||
		(v4 && !isActiveV4() && get(HubSettings::Connection) != SettingsManager::INCOMING_DISABLED)) {
		su += "," + OnlineUser::NAT0_FEATURE;
	}
	su += "," + OnlineUser::ASCH_FEATURE;

	// ADC-EXT extensions we answer: typing notifications (4.18), hub-pushed feeds (4.19) and
	// online identities (4.25)
	su += "," + OnlineUser::TYPE_FEATURE;
	su += "," + OnlineUser::FEED_FEATURE;
	su += "," + OnlineUser::ONID_FEATURE;

	// RTF0 says a client that can interpret rich text MUST advertise it here, and MUST NOT
	// unless it implements the whole markdown language. RichTextParser does, so this tracks
	// the same setting as the SUP token.
	if (SETTING(RICH_TEXT_ENABLED)) {
		su += "," + OnlineUser::RTF0_FEATURE;
	}

	// Distributed favorites, only while we have hubs the user opted in to sharing - otherwise
	// we would invite GFA requests we always answer with nothing
	if (!FavoriteManager::getInstance()->getShareableFavoriteHubs().empty()) {
		su += "," + OnlineUser::DFAV_FEATURE;
	}

	for (const auto& support: ClientManager::getInstance()->hubUserSupports.getAll()) {
		su += "," + support;
	}

	addParam(aLastInfoMap, c, "SU", su);
}

void AdcHub::appendConnectionSpeed(StringMap& aLastInfoMap, AdcCommand& c, const string& aParam, const string& aConnection, int64_t aLimitKbps) const noexcept {
	auto limit = aLimitKbps * 1000;
	auto connSpeed = static_cast<int64_t>((Util::toDouble(aConnection) * 1000.0 * 1000.0) / 8.0);
	addParam(aLastInfoMap, c, aParam, Util::toString(limit > 0 ? min(limit, connSpeed) : connSpeed));
}

void AdcHub::infoImpl() noexcept {
	// Reload before the state gate (same reasoning as NmdcHub::myInfo): a settings or
	// favorite change must reach the live HubSettings even while the hub is still
	// connecting - only the INF itself has to wait for IDENTIFY/NORMAL.
	reloadSettings(false);

	if (getConnectState() != STATE_IDENTIFY && getConnectState() != STATE_NORMAL)
		return;

	// Same trigger as the INF refresh: several SUP features track settings and favorites,
	// so re-announce their delta before broadcasting the new INF (ADC-EXT / ADC BASE SUP).
	updateHubSupports();

	// ONID has no delta form, so only re-publish when the list actually changed
	if (stateNormal() && SETTING(ONLINE_IDENTITIES) != lastSentIdentities) {
		sendOnlineIdentities();
	}

	AdcCommand c(AdcCommand::CMD_INF, AdcCommand::TYPE_BROADCAST);

	if (stateNormal()) {
		if (!updateCounts(false))
			return;
	}

	addParam(lastInfoMap, c, "ID", ClientManager::getInstance()->getMyCID().toBase32());
	addParam(lastInfoMap, c, "PD", ClientManager::getInstance()->getMyPID().toBase32());
	addParam(lastInfoMap, c, "NI", get(HubSettings::Nick));
	addParam(lastInfoMap, c, "DE", get(HubSettings::Description));
	addParam(lastInfoMap, c, "SL", Util::toString(UploadManager::getInstance()->getSlots()));
	addParam(lastInfoMap, c, "FS", Util::toString(UploadManager::getInstance()->getFreeSlots()));

	// ADC BASE automatic slot allocator: AS is the upload speed below which we stop opening
	// extra slots, AM the most we will open. We have had this feature for years without
	// telling anyone about it.
	//
	// Send nothing rather than a zero: addParam only skips EMPTY values, and "AS0" would
	// claim we open extra slots at any throughput, which is the opposite of what 0 means
	// here (MinUploadSpeed defaults to 0 = the limiter is off).
	{
		auto autoSlotSpeed = static_cast<int64_t>(AutoLimitUtil::getSpeedLimitKbps(false)) * 1024;
		auto autoSlots = AutoLimitUtil::getMaxAutoOpened();
		addParam(lastInfoMap, c, "AS", autoSlotSpeed > 0 ? Util::toString(autoSlotSpeed) : Util::emptyString);
		addParam(lastInfoMap, c, "AM", autoSlots > 0 ? Util::toString(autoSlots) : Util::emptyString);
	}

	addParam(lastInfoMap, c, "SS", Util::toString(ShareManager::getInstance()->getTotalShareSize(get(HubSettings::ShareProfile))));
	addParam(lastInfoMap, c, "SF", Util::toString(ShareManager::getInstance()->getBloomFileCount(get(HubSettings::ShareProfile))));

	addParam(lastInfoMap, c, "EM", get(HubSettings::Email));
	addParam(lastInfoMap, c, "HN", Util::toString(getDisplayCount(COUNT_NORMAL)));
	addParam(lastInfoMap, c, "HR", Util::toString(getDisplayCount(COUNT_REGISTERED)));
	addParam(lastInfoMap, c, "HO", Util::toString(getDisplayCount(COUNT_OP)));

	addParam(lastInfoMap, c, "AP", getAppName());
	addParam(lastInfoMap, c, "VE", getVersionTag());
	addParam(lastInfoMap, c, "AW", ActivityManager::getInstance()->isAway() ? "1" : Util::emptyString);
	addParam(lastInfoMap, c, "LC", Localization::getLocale());
	addParam(lastInfoMap, c, "RF", getReferrerUrl());

	// Accepted redirect protocols (ADC-EXT 4.32): 1 = ADC, 2 = ADCS, 4 = NMDC; 0 = no automatic redirects
	{
		int redirectProtocols = 0;
		if (SETTING(AUTO_FOLLOW)) {
			redirectProtocols = 1 | (CryptoManager::getInstance()->TLSOk() ? 2 : 0) | 4;
		}
		addParam(lastInfoMap, c, "RP", Util::toString(redirectProtocols));
	}

	appendConnectionSpeed(lastInfoMap, c, "US", SETTING(UPLOAD_SPEED), ThrottleManager::getUpLimit());
	appendConnectionSpeed(lastInfoMap, c, "DS", SETTING(DOWNLOAD_SPEED), ThrottleManager::getDownLimit());

	if (CryptoManager::getInstance()->TLSOk()) {
		auto &kp = CryptoManager::getInstance()->getKeyprint();
		addParam(lastInfoMap, c, "KP", CryptoManager::keyprintToString(kp));
	}

	auto supportsHBRI = supports.includes(HBRI_SUPPORT);
	bool addV4 = !sock->isV6Valid() || (get(HubSettings::Connection) != SettingsManager::INCOMING_DISABLED && supportsHBRI);
	bool addV6 = sock->isV6Valid() || (get(HubSettings::Connection6) != SettingsManager::INCOMING_DISABLED && supportsHBRI);

	appendClientSupports(lastInfoMap, c, addV4, addV6);
	appendConnectivity(lastInfoMap, c, addV4, addV6);

	if(c.getParameters().size() > 0) {
		sendHooked(c);
	}
}

void AdcHub::refreshUserList(bool) noexcept {
	OnlineUserList v;

	{
		RLock l(cs);
		for (const auto& [sid, user] : users) {
			if (sid != AdcCommand::HUB_SID) {
				v.push_back(user);
			}
		}
	}

	fire(ClientListener::UsersUpdated(), this, v);
}

string AdcHub::checkNick(const string& aNick) noexcept {
	string tmp = aNick;
	for(size_t i = 0; i < aNick.size(); ++i) {
		if(static_cast<uint8_t>(tmp[i]) <= 32) {
			tmp[i] = '_';
		}
	}
	return tmp;
}

bool AdcHub::sendHooked(const AdcCommand& cmd, CallerPtr aOwner, string& error_) {
	if(!forbiddenCommands.contains(AdcCommand::toFourCC(cmd.getFourCC().c_str()))) {
		AdcCommand::ParamMap params;

		// Hooks
		try {
			auto results = ClientManager::getInstance()->outgoingHubCommandHook.runHooksDataThrow(aOwner, cmd, *this);
			params = ActionHook<AdcCommand::ParamMap>::normalizeMap(results);
		} catch (const HookRejectException& e) {
			error_ = ActionHookRejection::formatError(e.getRejection());
			return false;
		}

		// Listeners
		ProtocolCommandManager::getInstance()->fire(ProtocolCommandManagerListener::OutgoingHubCommand(), cmd, *this);

		// Send
		if (!params.empty()) {
			send(AdcCommand(cmd).addParams(params).toString(mySID));
		} else {
			send(cmd.toString(mySID));
		}

		return true;
	}

	error_ = STRING(HUB_PERMISSION_DENIED);
	return false;
}

void AdcHub::on(Connected c) noexcept {
	Client::on(c);

	if(getConnectState() != STATE_PROTOCOL) {
		return;
	}

	lastInfoMap.clear();
	mySID = 0;
	forbiddenCommands.clear();

	// This object is reused across reconnects, so anything scoped to "this session" has to be
	// reset here or it is really scoped to the client's lifetime. The IP flags would otherwise
	// keep suppressing a configured address the user has since corrected, and the DFAV state is
	// keyed by SID - which the hub reassigns on reconnect, so a stale entry would throttle
	// whichever user inherits that SID.
	hubIpRejected4 = false;
	hubIpRejected6 = false;

	{
		Lock l(dfavCs);
		lastFavoriteRequest = 0;
		pendingFavoriteRequest = 0;
		favoriteReplyCounts.clear();
	}

	AdcCommand cmd(AdcCommand::CMD_SUP, AdcCommand::TYPE_HUB);
	lastSentSupports = getHubSupportTokens();
	for (const auto& support: lastSentSupports) {
		cmd.addParam("AD" + support);
	}

	sendHooked(cmd);
}

// The features we currently want the hub to know about. Split out from appendHubSupports so the
// same list can be diffed against what we last sent (see updateHubSupports) - several of these
// depend on settings or favorites that the user can change while connected.
StringList AdcHub::getHubSupportTokens() noexcept {
	StringList ret{ BAS0_SUPPORT, BASE_SUPPORT, TIGR_SUPPORT, ZLIF_SUPPORT, HBRI_SUPPORT };

	if (SETTING(HUB_USER_COMMANDS)) {
		ret.push_back(UCM0_SUPPORT);
	}

	if (SETTING(BLOOM_MODE) == SettingsManager::BLOOM_ENABLED) {
		ret.push_back(BLO0_SUPPORT);
	}

	// ADC-EXT requires these in SUP as well as the INF SU field: 4.12 PFSR, 4.17 SUDP,
	// 4.18 TYPE, 4.19 FEED. We keep the de-facto DC++ spelling for SUDP (SUD1).
	if (SETTING(USE_PARTIAL_SHARING)) {
		ret.push_back(OnlineUser::PFSR_FEATURE);
	}

	if (SETTING(ENABLE_SUDP)) {
		ret.push_back(OnlineUser::SUD1_FEATURE);
	}

	ret.push_back(OnlineUser::TYPE_FEATURE);
	ret.push_back(OnlineUser::FEED_FEATURE);

	// RTF0 rich text. Going through this list rather than straight into the connect-time
	// SUP is what lets the user toggle the setting mid-session: updateHubSupports diffs
	// it and emits ADRTF0 / RMRTF0. The spec requires exactly that - a client MUST honour
	// the current state and MUST NOT cache the answer.
	if (SETTING(RICH_TEXT_ENABLED)) {
		ret.push_back(RTF0_SUPPORT);
	}

	// DFAV is only worth announcing when there is something we would actually hand out -
	// otherwise we invite GFA requests we always answer with nothing (ADC-EXT 4.6)
	if (!FavoriteManager::getInstance()->getShareableFavoriteHubs().empty()) {
		ret.push_back(OnlineUser::DFAV_FEATURE);
	}

	for (const auto& support: ClientManager::getInstance()->hubSupports.getAll()) {
		ret.push_back(support);
	}

	return ret;
}

void AdcHub::appendHubSupports(AdcCommand& cmd) {
	for (const auto& support: getHubSupportTokens()) {
		cmd.addParam("AD" + support);
	}
}

// SUP is not a one-shot handshake: it can add and remove features at any time. Re-announce the
// delta when the settings behind our list change, otherwise a hub keeps believing whatever we
// claimed at login (e.g. still offering DFAV after the last shared favorite is turned off).
void AdcHub::updateHubSupports() noexcept {
	if (!stateNormal()) {
		return;
	}

	auto current = getHubSupportTokens();

	AdcCommand cmd(AdcCommand::CMD_SUP, AdcCommand::TYPE_HUB);
	auto changed = false;

	for (const auto& support: current) {
		if (ranges::find(lastSentSupports, support) == lastSentSupports.end()) {
			cmd.addParam("AD" + support);
			changed = true;
		}
	}

	for (const auto& support: lastSentSupports) {
		if (ranges::find(current, support) == current.end()) {
			cmd.addParam("RM" + support);
			changed = true;
		}
	}

	if (!changed) {
		return;
	}

	lastSentSupports = current;
	sendHooked(cmd);
}

void AdcHub::on(Line l, const string& aLine) noexcept {
	Client::on(l, aLine);

	if(!Text::validateUtf8(aLine)) {
		statusMessage(STRING(UTF_VALIDATION_ERROR) + "(" + Text::sanitizeUtf8(aLine) + ")", LogMessage::SEV_ERROR);
		return;
	}

	if(PluginManager::getInstance()->runHook<HubData>(HOOK_NETWORK_HUB_IN, this, aLine))
		return;

	dispatch(aLine, [this](const AdcCommand& aCmd) {
		ProtocolCommandManager::getInstance()->fire(ProtocolCommandManagerListener::IncomingHubCommand (), aCmd, *this);
	});
}

void AdcHub::on(TimerManagerListener::Second s, uint64_t aTick) noexcept {
	Client::on(s, aTick);
	if(stateNormal() && (aTick > (getLastActivity() + 120*1000)) ) {
		send("\n", 1);
	}
}

OnlineUserPtr AdcHub::findUser(const string& aNick) const noexcept {
	RLock l(cs); 
	for(const auto& ou: users | views::values) { 
		if(ou->getIdentity().getNick() == aNick) { 
			return ou; 
		} 
	} 
	return nullptr; 
}

} // namespace dcpp