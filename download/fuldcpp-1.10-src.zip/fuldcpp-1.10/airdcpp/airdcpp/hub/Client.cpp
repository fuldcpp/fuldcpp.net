/* 
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/hub/Client.h>

#include <airdcpp/connection/socket/BufferedSocket.h>
#include <airdcpp/hub/AdcHub.h>
#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/connection/ConnectionManager.h>
#include <airdcpp/connectivity/ConnectivityManager.h>
#include <airdcpp/protocol/ProtocolCommandManager.h>
#include <airdcpp/favorites/FavoriteManager.h>
#include <airdcpp/util/LinkUtil.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/core/crypto/CryptoManager.h>
#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/share/ShareManager.h>
#include <airdcpp/share/profiles/ShareProfileManager.h>
#include <airdcpp/connection/ThrottleManager.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/plugins/PluginManager.h>
#include <airdcpp/util/text/StringTokenizer.h>
#include <airdcpp/util/ValueGenerator.h>

namespace dcpp {

atomic<long> Client::allCounts[COUNT_UNCOUNTED];
atomic<long> Client::sharingCounts[COUNT_UNCOUNTED];
atomic<ClientToken> idCounter { 0 };

#define FLOOD_PERIOD 60

// Minimum spacing between IP-change reconnects of the same hub (see handleExternalIPChangedImpl)
static const uint64_t IP_CHANGE_RECONNECT_FLOOR = 10 * 60 * 1000;

Client::Client(const string& aHubUrl, char aSeparator, const ClientPtr& aOldClient) :
	myIdentity(ClientManager::getInstance()->getMe(), 0), lastActivity(GET_TICK()),
	cache(aOldClient ? MessageCache(aOldClient->getCache()) : MessageCache(SettingsManager::HUB_MESSAGE_CACHE)),
	ctmFloodCounter(FLOOD_PERIOD),
	searchFloodCounter(FLOOD_PERIOD),
	clientId(aOldClient ? aOldClient->getToken() : ++idCounter),
	hubUrl(aHubUrl),
	referrerUrl(aOldClient ? aOldClient->getHubUrl() : Util::emptyString),
	separator(aSeparator)
{
	TimerManager::getInstance()->addListener(this);
	ShareManager::getInstance()->getProfileMgr().addListener(this);

	string file, proto, query, fragment;
	LinkUtil::decodeUrl(hubUrl, proto, address, port, file, query, fragment);

	keyprint = LinkUtil::decodeQuery(query)["kp"];

	if (aOldClient) {
		// Carry failover state (and thereby the favorite association) only when hopping
		// inside the old client's failover set; a redirect to an unrelated hub must not
		// inherit the favorite's credentials (ADC-EXT 4.21)
		RLock l(aOldClient->cs);
		auto urlMatches = [this](const string& aUrl) { return Util::stricmp(aUrl, hubUrl) == 0; };
		if (urlMatches(aOldClient->failoverPrimaryUrl) || ranges::any_of(aOldClient->failoverUrls, urlMatches)) {
			failoverUrls = aOldClient->failoverUrls;
			failoverPrimaryUrl = aOldClient->failoverPrimaryUrl;
			failoverHopCount = aOldClient->failoverHopCount;
			failoverWindowStart = aOldClient->failoverWindowStart;
			favToken = aOldClient->favToken;
		}
	}
}

Client::~Client() {
	dcdebug("Client %s was deleted\n", hubUrl.c_str());
}

void Client::reconnect() noexcept {
	disconnect(true);
	setAutoReconnect(true);
	setReconnDelay(0);
	supports.clear();
}

void Client::setActive() noexcept {
	fire(ClientListener::SetActive(), this);
}

void Client::shutdown(ClientPtr& aClient, bool aRedirect) {
	localDisconnect = true;
	TimerManager::getInstance()->removeListener(this);
	ShareManager::getInstance()->getProfileMgr().removeListener(this);

	if (!aRedirect) {
		fire(ClientListener::Close(), this);
	}

	if(sock) {
		destroySocket([=, this] { // Ensure that the pointer won't be deleted too early
			sock = nullptr;

			// Users store a reference that prevents the client from being deleted
			// so the lists must be cleared manually 
			if (!aRedirect) {
				cache.clear();
			}

			aClient->clearUsers();
			updateCounts(true);
		});
	}
}

string Client::getDescription() const noexcept {
	string ret = get(HubSettings::Description);

	int upLimit = ThrottleManager::getInstance()->getUpLimit();
	if(upLimit > 0)
		ret = "[L:" + Util::toString(upLimit) + "KB] " + ret;
	return ret;
}

void Client::on(ShareProfileManagerListener::DefaultProfileChanged, ProfileToken aOldDefault, ProfileToken /*aNewDefault*/) noexcept {
	if (get(HubSettings::ShareProfile) == aOldDefault) {
		reloadSettings(false);
	}
}

void Client::on(ShareProfileManagerListener::ProfileRemoved, ProfileToken aProfile) noexcept {
	if (get(HubSettings::ShareProfile) == aProfile) {
		reloadSettings(false);
	}
}

/// @todo update the nick in ADC hubs?
void Client::reloadSettings(bool aUpdateNick) noexcept {
	HubSettings oldHubSettings = *static_cast<HubSettings*>(this);

	// Merging
	*static_cast<HubSettings*>(this) = SettingsManager::getInstance()->getHubSettings();

	auto fav = FavoriteManager::getInstance()->getFavoriteHubEntry(getHubUrl());
	if (!fav && favToken > 0) {
		// The favorite address may diverge from the live hubUrl (e.g. its keyprint was
		// updated, or the address was edited while connected); fall back to the stable
		// token so the hub keeps its favorite settings (nick, password, encoding).
		fav = FavoriteManager::getInstance()->getFavoriteHubEntry(favToken);
	}
	if(fav) {
		FavoriteManager::getInstance()->mergeHubSettings(fav, *this);
		favToken = fav->getToken();

		// Seed the failover list from the favorite so it's usable even when the primary
		// address is down at startup; a live hub INF FO overrides it later (ADC-EXT 4.21)
		if (!fav->getFailovers().empty() && getFailovers().empty()) {
			setFailovers(StringTokenizer<string>(fav->getFailovers(), ',').getTokens());
		}
	}

	// Restore the old nick if nick change is not allowed.
	// checkNick returns a sanitised copy rather than modifying in place, so its result has to be
	// assigned -- discarding it meant the whole sanitisation was dead and a nick containing '$',
	// '<' or '>' went out verbatim in $MyINFO, $ValidateNick, $Search and $ConnectToMe, shifting
	// every field of the message for the hub and every other client parsing it.
	if (aUpdateNick) {
		get(Nick) = checkNick(get(Nick));
	} else {
		get(Nick) = oldHubSettings.get(Nick);
	}

	// The password is reloaded BEFORE the early return below, because Password is not a HubSetting
	// and so never makes the comparison unequal. A hub sending $BadPass / STA 223 clears
	// defpassword, and with the reload sitting past the return nothing ever restored it: correcting
	// the password in the favourite and reconnecting still prompted, on every auto-reconnect, until
	// the hub window was closed and reopened. One line from a hostile hub broke unattended
	// reconnects permanently.
	if (fav) {
		if (!fav->getPassword().empty()) {
			setPassword(fav->getPassword());
		}
	} else {
		setPassword(Util::emptyString);
	}

	// Credentials from a caller that created this client for a hub the user has NOT configured.
	// Everything above rebuilds HubSettings from the global settings, and the password branch
	// clears the password for a hub with no favourite, so a nick and password handed in before
	// connect() were both discarded on the way in -- the plugin API's add_hub took two arguments
	// and used neither. A favourite wins, because a hub the user has set up should not be
	// silently re-credentialled by a plugin.
	if (!fav) {
		if (!nickOverride.empty()) {
			get(Nick) = checkNick(nickOverride);
		}

		if (!passwordOverride.empty()) {
			setPassword(passwordOverride);
		}
	}

	// Avoid unnecessary listener updates
	if (oldHubSettings == *static_cast<HubSettings*>(this)) {
		return;
	}

	searchQueue.setMinInterval(get(HubSettings::SearchInterval) * 1000); //convert from seconds

	fire(ClientListener::SettingsUpdated(), this);
}


bool Client::toggleHubBoolSetting(HubSettings::HubBoolSetting aSetting) noexcept {
	auto newValue = static_cast<bool>(!get(aSetting));
	setHubSetting(aSetting, newValue);
	return newValue;
}

void Client::setHubSetting(HubSettings::HubBoolSetting aSetting, bool aNewValue) noexcept {
	get(aSetting) = aNewValue;

	//save for a favorite hub if needed
	if (favToken > 0) {
		FavoriteManager::getInstance()->setHubSetting(hubUrl, aSetting, aNewValue);
	}

	fire(ClientListener::SettingsUpdated(), this);
}

void Client::updated(const OnlineUserPtr& aUser) noexcept {
	fire(ClientListener::UserUpdated(), this, aUser);
}

void Client::updated(OnlineUserList& users) noexcept {
	//std::for_each(users.begin(), users.end(), [](OnlineUser* user) { UserMatchManager::getInstance()->match(*user); });

	fire(ClientListener::UsersUpdated(), this, users);
}

bool Client::isActive() const noexcept {
	return isActiveV4() || isActiveV6();
}

bool Client::isActiveV4() const noexcept {
	return get(HubSettings::Connection) != SettingsManager::INCOMING_PASSIVE && get(HubSettings::Connection) != SettingsManager::INCOMING_DISABLED;
}

bool Client::isActiveV6() const noexcept {
	return !v4only() && get(HubSettings::Connection6) != SettingsManager::INCOMING_PASSIVE && get(HubSettings::Connection6) != SettingsManager::INCOMING_DISABLED;
}

void Client::destroySocket(const AsyncF& aShutdownAction) noexcept {
	state = STATE_DISCONNECTED;

	BufferedSocket::putSocket(sock, aShutdownAction);
}

void Client::connect(bool withKeyprint) noexcept {
	if (sock) {
		destroySocket();
	}

	redirectUrl = Util::emptyString;
	localDisconnect = false;
	// Cleared here rather than only in reconnect(): an auto-reconnect comes straight back to
	// connect(), so the SUP set negotiated with the PREVIOUS session survived into the new one
	// and we went on believing a hub supported features it had not offered this time.
	supports.clear();
	setAutoReconnect(true);
	setReconnDelay(120 + ValueGenerator::rand(0, 60));
	reloadSettings(true);
	setRegistered(false);
	setMyIdentity(Identity(ClientManager::getInstance()->getMe(), 0));
	setHubIdentity(Identity());

	setConnectState(STATE_CONNECTING);

	try {
		sock = BufferedSocket::getSocket(separator, v4only());
		sock->addListener(this);
		sock->connect(
			AddressInfo(address, AddressInfo::TYPE_URL), 
			SocketConnectOptions(port, LinkUtil::isSecure(hubUrl)),
			SETTING(ALLOW_UNTRUSTED_HUBS), 
			true, 
			withKeyprint ? keyprint : Util::emptyString
		);
	} catch (const Exception& e) {
		setConnectState(STATE_DISCONNECTED);
		fire(ClientListener::Disconnected(), hubUrl, e.getError());
	}
	updateActivity();
}

void Client::info() {
	callAsync([this] { infoImpl(); });
}

void Client::onExternalIPChanged(const string& aNewIP, bool aV6) noexcept {
	callAsync([this, aNewIP, aV6] { handleExternalIPChangedImpl(aNewIP, aV6); });
}

bool Client::isIpFamilyRelevant(bool aV6) const noexcept {
	return sock && sock->isV6Valid() == aV6;
}

void Client::handleExternalIPChangedImpl(const string& aNewIP, bool aV6) noexcept {
	if (aNewIP.empty() || !sock || !stateNormal()) {
		// Hubs still logging in announce fresh values on their own
		return;
	}

	// The globals just changed; refresh HubSettings::UserIp4/6 before consulting them
	reloadSettings(false);
	if (!isIpFamilyRelevant(aV6)) {
		return;
	}

	auto hubReported = aV6 ? getMyIdentity().getIp6() : getMyIdentity().getIp4();
	if (hubReported == aNewIP) {
		// The socket already died and reconnected during the address flip
		return;
	}

	if (canAnnounceIp(aV6)) {
		updateMyIp(aNewIP, aV6);
		info();
		return;
	}

	// The hub stamped our address from the socket at login and its protocol can't carry
	// the new one, so only a fresh socket corrects the record everyone else sees. One
	// bounce per distinct address plus a time floor, so an oscillating detector (hourly
	// HTTP check vs. mapper renewal) can't bounce the hub in a loop.
	auto& lastReconnectIP = aV6 ? lastIpChangeReconnect6 : lastIpChangeReconnect4;
	if (lastReconnectIP == aNewIP) {
		// Already bounced for this address; show it in our own list and let the fresh
		// session's login stamp the hub record
		updateMyIp(aNewIP, aV6);
		return;
	}

	auto tick = GET_TICK();
	if (lastIpChangeReconnectTick > 0 && tick < lastIpChangeReconnectTick + IP_CHANGE_RECONNECT_FLOOR) {
		// Within the floor: park the bounce until the floor expires (on(Second) re-runs
		// the whole decision then). Deliberately no updateMyIp here: it would stamp the
		// new address into myIdentity, and the retry's "hub record already fresh" check
		// above would then read our own stamp and conclude there is nothing to do
		(aV6 ? pendingIpReconnect6 : pendingIpReconnect4) = aNewIP;
		ipReconnectRetryTick.store(lastIpChangeReconnectTick + IP_CHANGE_RECONNECT_FLOOR);
		return;
	}

	lastReconnectIP = aNewIP;
	lastIpChangeReconnectTick = tick;
	(aV6 ? pendingIpReconnect6 : pendingIpReconnect4).clear();

	statusMessage("External IP address changed (" +
		(hubReported.empty() ? string("hub-reported address unknown") : hubReported) + " -> " + aNewIP +
		"), reconnecting so the hub picks up the new address", LogMessage::SEV_INFO);
	reconnect();
}

void Client::updateMyIp(const string& aNewIP, bool aV6) noexcept {
	// Socket thread; Identity setters lock internally and the existing protocol paths
	// fire UserUpdated from here too ($UserIP handling, own-INF echo)
	if (auto ou = getMyOnlineUser(); ou) {
		if (aV6) {
			ou->getIdentity().setIp6(aNewIP);
		} else {
			ou->getIdentity().setIp4(aNewIP);
		}

		// Keep the snapshot copy in sync, like the $UserIP path does
		setMyIdentity(ou->getIdentity());
		updated(ou);
	}
}

void Client::send(const char* aMessage, size_t aLen) {
	if (!isConnected() || !sock) {
		dcassert(0);
		return;
	}

	// DCAPI contract (as in DC++): this is the funnel for ALL outbound hub traffic,
	// including handshake commands (SUP/INF/PAS). A plugin that vetoes here suppresses
	// the write with no error surfaced, so a buggy plugin can wedge the connection.
	// Plugins are trusted in-process native code; default (no subscriber) is pass-through.
	if(PluginManager::getInstance()->runHook<HubData>(HOOK_NETWORK_HUB_OUT, this, string(aMessage, aLen)))
		return;

	updateActivity();
	sock->write(aMessage, aLen);
	COMMAND_DEBUG(aMessage, ProtocolCommandManager::TYPE_HUB, ProtocolCommandManager::OUTGOING, getIpPort());
}

void Client::on(BufferedSocketListener::Connected) noexcept {
	statusMessage(STRING(CONNECTED), LogMessage::SEV_INFO);

	updateActivity();
	ip = sock->getIp();
	localIp = sock->getLocalIp();

	// Successful connect: reset the failure-burst backoff and any captured mismatch
	failBurstWindowStart = 0;
	failBurstCount = 0;
	mismatchedKeyprint.clear();

	fire(ClientListener::Connected(), this);
	setConnectState(STATE_PROTOCOL);
}

void Client::setConnectState(State aState) noexcept {
	if (state == aState) {
		return;
	}

	state = aState;

	if (aState == STATE_NORMAL) {
		// A successful login re-arms failover rotation
		WLock l(cs);
		failoverHopCount = 0;
		failoverWindowStart = 0;
	}

	fire(ClientListener::ConnectStateChanged(), this, aState);
}

void Client::statusMessage(const string& aMessage, LogMessage::Severity aSeverity, LogMessage::Type aType, const string& aLabel, const string& aOwner) noexcept {
	auto message = std::make_shared<LogMessage>(aMessage, aSeverity, aType, aLabel);

	if (aOwner.empty() && aType != LogMessage::Type::SPAM && aType != LogMessage::Type::PRIVATE) {
		cache.addMessage(message);

		if (SETTING(LOG_STATUS_MESSAGES)) {
			ParamMap params;
			getHubIdentity().getParams(params, "hub", false);
			params["hubURL"] = getHubUrl();
			getMyIdentity().getParams(params, "my", true);
			params["message"] = aMessage;
			LOG(LogManager::STATUS, params);
		}
	}

	fire(ClientListener::StatusMessage(), this, message, aOwner);
}

void Client::setRead() noexcept {
	auto unreadInfo = cache.setRead();
	if (unreadInfo.hasMessages()) {
		fire(ClientListener::MessagesRead(), this);
	}
}

int Client::clearCache() noexcept {
	auto ret = cache.clear();
	if (ret > 0) {
		fire(ClientListener::MessagesCleared(), this);
	}

	return ret;
}

void Client::onPassword() noexcept {
	setConnectState(STATE_VERIFY);
	if (!defpassword.empty()) {
		password(defpassword);
		statusMessage(STRING(STORED_PASSWORD_SENT), LogMessage::SEV_INFO);
	} else {
		fire(ClientListener::GetPassword(), this);
	}
}

void Client::onRedirect(const string& aRedirectUrl) noexcept {
	if (ClientManager::getInstance()->findClient(aRedirectUrl)) {
		statusMessage(STRING(REDIRECT_ALREADY_CONNECTED), LogMessage::SEV_INFO);
		return;
	}

	redirectUrl = aRedirectUrl;

	if (SETTING(AUTO_FOLLOW)) {
		doRedirect();
	} else {
		fire(ClientListener::Redirect(), this, redirectUrl);
	}
}

void Client::onUserConnected(const OnlineUserPtr& aUser) noexcept {
	if (!aUser->getIdentity().isHub()) {
		ClientManager::getInstance()->putOnline(aUser);

		if (aUser->getUser() != ClientManager::getInstance()->getMe()) {
			if (!aUser->isHidden() && get(HubSettings::ShowJoins) || (get(HubSettings::FavShowJoins) && aUser->getUser()->isFavorite())) {
				statusMessage(STRING(JOINS) + ": " + aUser->getIdentity().getNick(), LogMessage::SEV_VERBOSE, LogMessage::Type::SYSTEM);
			}
		}
	}

	fire(ClientListener::UserConnected(), this, aUser);
}

void Client::onUserDisconnected(const OnlineUserPtr& aUser, bool aDisconnectTransfers) noexcept {
	if (!aUser->getIdentity().isHub()) {
		ClientManager::getInstance()->putOffline(aUser, aDisconnectTransfers);

		if (aUser->getUser() != ClientManager::getInstance()->getMe()) {
			if (!aUser->isHidden() && get(HubSettings::ShowJoins) || (get(HubSettings::FavShowJoins) && aUser->getUser()->isFavorite())) {
				statusMessage(STRING(PARTS) + ": " + aUser->getIdentity().getNick(), LogMessage::SEV_VERBOSE, LogMessage::Type::SYSTEM);
			}
		}
	}

	fire(ClientListener::UserRemoved(), this, aUser);
}

void Client::allowUntrustedConnect() noexcept {
	if (state != STATE_DISCONNECTED || !SETTING(ALLOW_UNTRUSTED_HUBS) || !LinkUtil::isSecure(hubUrl))
		return;
	//Connect without keyprint just this once...
	connect(false);
}

string Client::replaceKeyprintParam(const string& aUrl, const string& aKeyprint) noexcept {
	// Everything from the first '#' on is the fragment and is not part of the query, so a
	// pin must never be written into it - decodeUrl would not find it there and the address
	// would silently come out unpinned
	auto fragmentStart = aUrl.find('#');
	const auto base = aUrl.substr(0, fragmentStart);
	const auto fragment = fragmentStart == string::npos ? Util::emptyString : aUrl.substr(fragmentStart);

	auto pos = base.find("kp=");
	// only accept it as a query parameter (preceded by ? or &)
	while (pos != string::npos && pos > 0 && base[pos - 1] != '?' && base[pos - 1] != '&') {
		pos = base.find("kp=", pos + 3);
	}

	if (pos == string::npos) {
		return base + (base.find('?') == string::npos ? "?" : "&") + "kp=" + aKeyprint + fragment;
	}

	auto valueStart = pos + 3;
	auto valueEnd = base.find('&', valueStart);
	if (valueEnd == string::npos)
		valueEnd = base.size();
	return base.substr(0, valueStart) + aKeyprint + base.substr(valueEnd) + fragment;
}

void Client::acceptMismatchedKeyprint() noexcept {
	if (state != STATE_DISCONNECTED || mismatchedKeyprint.empty() || !LinkUtil::isSecure(hubUrl))
		return;

	// Re-pin for this session; hubUrl itself stays untouched (it's the client's identity key)
	keyprint = mismatchedKeyprint;
	mismatchedKeyprint.clear();

	auto entry = favToken > 0 ? FavoriteManager::getInstance()->getFavoriteHubEntry(favToken) : nullptr;
	if (entry) {
		// Persist the new pin into the favorite address so future sessions use it. The live
		// client keeps its old hubUrl (the ClientManager map key) for this session; favorite
		// settings still resolve via the token fallback in reloadSettings, but the
		// favorites-list connect indicator and custom tab colour look stale until the next
		// reconnect/restart -- same cosmetic effect as editing a favorite's address while
		// connected. Not re-keying avoids tearing down the live client mid-accept.
		entry->setServer(replaceKeyprintParam(entry->getServer(), keyprint));
		FavoriteManager::getInstance()->onFavoriteHubUpdated(entry);
		statusMessage(STRING(KEYPRINT_MISMATCH_UPDATED), LogMessage::SEV_INFO);
	} else {
		statusMessage(STRING(KEYPRINT_MISMATCH_UPDATED_SESSION), LogMessage::SEV_INFO);
	}

	connect();
}

bool Client::prepareHubRedirect(string& url_, string& error_) const noexcept {
	string proto, host, port, file, query, fragment;
	LinkUtil::decodeUrl(url_, proto, host, port, file, query, fragment);

	// The hub never gets to choose the certificate we validate against. Without this, a
	// redirect could point at an attacker's host carrying the attacker's own keyprint and
	// still pass verification.
	if (!LinkUtil::decodeQuery(query)["kp"].empty()) {
		error_ = STRING(REDIRECT_REJECTED_KEYPRINT);
		return false;
	}

	// A hub that moves a TLS session to a cleartext address strips the user's transport
	// security without consent, and a redirect is exactly the message an on-path attacker
	// would forge. getNextFailoverUrl applies the same invariant to failover hops.
	if ((LinkUtil::isSecure(hubUrl) || !keyprint.empty()) && !LinkUtil::isSecure(url_)) {
		error_ = STRING(REDIRECT_REJECTED_INSECURE);
		return false;
	}

	if (!keyprint.empty()) {
		// The pin is bound to a host, so a hop off that host would silently drop it
		if (Util::stricmp(host, address) != 0) {
			error_ = STRING(REDIRECT_REJECTED_KEYPRINT);
			return false;
		}

		url_ = replaceKeyprintParam(url_, keyprint);
	}

	return true;
}

FavoriteHubEntryPtr Client::getPinnableFavorite() const noexcept {
	if (!isConnected() || !isSocketSecure() || !LinkUtil::isSecure(hubUrl) || !keyprint.empty()) {
		return nullptr;
	}

	// The pin lives in the favorite's address, so there is nothing to pin into for a
	// non-favorite hub (and no reconnect here that a session-only pin could apply to)
	auto entry = favToken > 0 ? FavoriteManager::getInstance()->getFavoriteHubEntry(favToken) : nullptr;
	if (!entry) {
		return nullptr;
	}

	// Already pinned in the favorite even though this session connected without one
	string proto, host, port, file, query, fragment;
	LinkUtil::decodeUrl(entry->getServer(), proto, host, port, file, query, fragment);
	return LinkUtil::decodeQuery(query)["kp"].empty() ? entry : nullptr;
}

bool Client::isKeyprintPinnable() const noexcept {
	return getPinnableFavorite() != nullptr;
}

bool Client::pinCurrentKeyprint() noexcept {
	auto entry = getPinnableFavorite();
	if (!entry) {
		return false;
	}

	auto presented = CryptoManager::keyprintToString(getKeyprint());
	if (presented.empty()) {
		return false;
	}

	// Unlike acceptMismatchedKeyprint (which runs while disconnected and then reconnects),
	// this is invoked from the UI thread on a live session. The member `keyprint` is read
	// unguarded by the reconnect/failover paths on other threads, so it is deliberately NOT
	// touched here: the favorite address is the durable store and the pin takes effect from
	// the next connection. hubUrl stays untouched too - it is the ClientManager map key.
	entry->setServer(replaceKeyprintParam(entry->getServer(), presented));
	FavoriteManager::getInstance()->onFavoriteHubUpdated(entry);
	statusMessage(STRING(KEYPRINT_PINNED), LogMessage::SEV_INFO);
	return true;
}

void Client::onPermanentRedirect(const string& aRedirectUrl) noexcept {
	if (ClientManager::getInstance()->findClient(aRedirectUrl)) {
		statusMessage(STRING(REDIRECT_ALREADY_CONNECTED), LogMessage::SEV_INFO);
		return;
	}

	if (favToken == 0) {
		// Not a favorite hub, nothing to update permanently
		onRedirect(aRedirectUrl);
		return;
	}

	{
		WLock l(cs);
		pendingPermanentRedirect = aRedirectUrl;
	}

	fire(ClientListener::RedirectPrompt(), this, aRedirectUrl);
}

string Client::getPendingPermanentRedirect() const noexcept {
	RLock l(cs);
	return pendingPermanentRedirect;
}

string Client::takePendingPermanentRedirect() noexcept {
	WLock l(cs);
	auto target = std::move(pendingPermanentRedirect);
	pendingPermanentRedirect.clear();
	return target;
}

void Client::acceptPermanentRedirect() noexcept {
	auto target = takePendingPermanentRedirect();
	if (target.empty()) {
		return;
	}

	if (auto entry = favToken > 0 ? FavoriteManager::getInstance()->getFavoriteHubEntry(favToken) : nullptr; entry) {
		if (FavoriteManager::getInstance()->isUnique(target, favToken)) {
			// The live client keeps its old hubUrl until the redirect below re-keys it;
			// see the note in acceptMismatchedKeyprint about the favorite connect indicator
			auto oldServer = entry->getServer();
			entry->setServer(target);

			// ADC-EXT 4.32 wants references updated only after a successful connect; keep
			// the old address reachable as a failover so a dead target stays recoverable
			auto failovers = StringTokenizer<string>(entry->getFailovers(), ',').getTokens();
			if (!oldServer.empty() && ranges::none_of(failovers, [&oldServer](const string& aUrl) { return Util::stricmp(aUrl, oldServer) == 0; })) {
				failovers.insert(failovers.begin(), oldServer);
				entry->setFailovers(Util::toString(",", failovers));
			}

			FavoriteManager::getInstance()->onFavoriteHubUpdated(entry);
			statusMessage(STRING_F(REDIRECT_FAVORITE_UPDATED, target), LogMessage::SEV_INFO);
		} else {
			statusMessage(STRING_F(REDIRECT_FAVORITE_CONFLICT, target), LogMessage::SEV_WARNING);
		}
	}

	redirectUrl = target;
	doRedirect();
}

void Client::declinePermanentRedirect() noexcept {
	auto target = takePendingPermanentRedirect();
	if (target.empty()) {
		return;
	}

	redirectUrl = target;
	doRedirect();
}

void Client::clearPermanentRedirect() noexcept {
	WLock l(cs);
	pendingPermanentRedirect.clear();
}

StringList Client::getFailovers() const noexcept {
	RLock l(cs);
	return failoverUrls;
}

void Client::setFailovers(const StringList& aUrls) noexcept {
	// Defense in depth for hand-edited favorites/profiles; hub-provided lists are
	// already sanitized in AdcHub::updateFailoversFromHub
	StringList urls;
	for (auto url: aUrls) {
		LinkUtil::sanitizeUrl(url);
		if (!url.empty() && url.length() <= 256 && LinkUtil::isHubLink(url)) {
			urls.push_back(std::move(url));
		}
	}

	WLock l(cs);
	failoverUrls = std::move(urls);
	if (failoverPrimaryUrl.empty()) {
		failoverPrimaryUrl = hubUrl;
	}
}

string Client::getNextFailoverUrl() noexcept {
	StringList rotation;
	string primary;

	{
		WLock l(cs);
		if (failoverUrls.empty()) {
			return Util::emptyString;
		}

		// Allow at most one full pass over the address set per window; beyond that the
		// regular reconnect timer and its backoff pace retries on the current address.
		// Each hop creates a fresh Client instance with fresh fail-burst counters, so
		// this window is the only storm control for failover cycling.
		const auto now = GET_TICK();
		constexpr uint64_t WINDOW_MS = 10 * 60 * 1000;
		if (failoverWindowStart == 0 || (now - failoverWindowStart) > WINDOW_MS) {
			failoverWindowStart = now;
			failoverHopCount = 0;
		}

		if (failoverHopCount > static_cast<int>(failoverUrls.size())) {
			return Util::emptyString;
		}
		failoverHopCount++;

		primary = failoverPrimaryUrl.empty() ? hubUrl : failoverPrimaryUrl;
		rotation.push_back(primary);
		rotation.insert(rotation.end(), failoverUrls.begin(), failoverUrls.end());
	}

	// A connect-time failure is attacker-forcible (TCP RST), so hops must never weaken
	// the primary's transport security: a secure/pinned primary only fails over to
	// secure addresses, and a keyprint pin is never silently dropped
	const auto requireSecure = LinkUtil::isSecure(primary) || !keyprint.empty();

	// Wrap-around rotation starting after the current address; findClient must not be
	// called with cs held (lock order against ClientManager)
	auto urlMatches = [this](const string& aUrl) { return Util::stricmp(aUrl, hubUrl) == 0; };
	auto current = ranges::find_if(rotation, urlMatches);
	auto startIndex = current != rotation.end() ? static_cast<size_t>(distance(rotation.begin(), current)) + 1 : size_t(0);

	for (size_t i = 0; i < rotation.size(); ++i) {
		const auto& candidate = rotation[(startIndex + i) % rotation.size()];
		if (urlMatches(candidate) || ClientManager::getInstance()->findClient(candidate)) {
			continue;
		}

		if (requireSecure && !LinkUtil::isSecure(candidate)) {
			continue;
		}

		if (!keyprint.empty()) {
			string proto, host, candidatePort, file, query, fragment;
			LinkUtil::decodeUrl(candidate, proto, host, candidatePort, file, query, fragment);

			// A pinned session never hops off the pinned host: the pin identifies one
			// host's certificate. Checked before the kp= inspection below, so a candidate
			// that carries a keyprint of its own cannot skip it - failover lists are
			// persisted to the favorites, so an entry planted by a hub before the
			// ingest-time kp= filter existed can still be sitting in Favorites.xml.
			if (Util::stricmp(host, address) != 0) {
				continue;
			}

			if (LinkUtil::decodeQuery(query)["kp"].empty()) {
				return replaceKeyprintParam(candidate, keyprint);
			}
		}

		return candidate;
	}

	return Util::emptyString;
}

bool Client::sendMessageHooked(const OutgoingChatMessage& aMessage, string& error_) noexcept {
	if (Util::isChatCommand(aMessage.text)) {
		fire(ClientListener::ChatCommand(), this, aMessage);
		// TODO: don't continue and run hooks after this with API v2
	} else if (!stateNormal()) {
		error_ = STRING(CONNECTING_IN_PROGRESS);
		return false;
	}

	auto error = ClientManager::getInstance()->outgoingHubMessageHook.runHooksError(this, aMessage, *this);
	if (error) {
		error_ = ActionHookRejection::formatError(error);
		return false;
	}


	if (Util::isChatCommand(aMessage.text)) {
		return false;
	}

	return hubMessageHooked(aMessage, error_);
}

bool Client::mcPrivateMessage(const OnlineUserPtr&, const string&, bool, string& error_) noexcept {
	error_ = STRING(MCTO_NOT_SUPPORTED);
	return false;
}

bool Client::sendPrivateMessageHooked(const OnlineUserPtr& aUser, const OutgoingChatMessage& aMessage, string& error_, bool aEcho) noexcept {
	if (!stateNormal() && !Util::isChatCommand(aMessage.text)) {
		error_ = STRING(CONNECTING_IN_PROGRESS);
		return false;
	}

	auto error = ClientManager::getInstance()->outgoingPrivateMessageHook.runHooksError(this, aMessage, HintedUser(aUser->getUser(), aUser->getHubUrl()), aEcho);
	if (error) {
		error_ = ActionHookRejection::formatError(error);
		return false;
	}

	if (Util::isChatCommand(aMessage.text)) {
		return false;
	}

	return privateMessageHooked(aUser, aMessage, error_, aEcho);
}

void Client::onPrivateMessage(const ChatMessagePtr& aMessage) noexcept {
	if (!ClientManager::processChatMessage(aMessage, getMyIdentity(), ClientManager::getInstance()->incomingPrivateMessageHook)) {
		return;
	}

	fire(ClientListener::PrivateMessage(), this, aMessage);
}

void Client::onChatMessage(const ChatMessagePtr& aMessage) noexcept {
	if (!ClientManager::processChatMessage(aMessage, getMyIdentity(), ClientManager::getInstance()->incomingHubMessageHook)) {
		return;
	}

	if (get(HubSettings::LogMainChat)) {
		ParamMap params;
		params["message"] = aMessage->format();
		getHubIdentity().getParams(params, "hub", false);
		params["hubURL"] = getHubUrl();
		getMyIdentity().getParams(params, "my", true);
		// Expose the sender's identity (nick, IP4/IP6, etc.) so the main-chat log format can
		// reference e.g. %[userNI], %[userI4], %[userI6] (issue #96).
		if (aMessage->getFrom()) {
			aMessage->getFrom()->getIdentity().getParams(params, "user", false);
		}
		LOG(LogManager::CHAT, params);
	}

	cache.addMessage(aMessage);
	fire(ClientListener::ChatMessage(), this, aMessage);
}

void Client::on(BufferedSocketListener::Connecting) noexcept {
	statusMessage(STRING(CONNECTING_TO) + " " + getHubUrl() + " ...", LogMessage::SEV_INFO);
	fire(ClientListener::Connecting(), this);
}

FavoriteHubEntryPtr Client::saveFavorite() {
	auto e = std::make_shared<FavoriteHubEntry>();
	e->setServer(getHubUrl());
	e->setName(getHubName());
	e->setDescription(getHubDescription());
	e->setAutoConnect(true);
	if (!defpassword.empty()) {
		e->setPassword(defpassword);
	}

	return FavoriteManager::getInstance()->addFavoriteHub(e) ? e : nullptr;
}

void Client::doRedirect() noexcept {
	if (redirectUrl.empty()) {
		return;
	}

	if (ClientManager::getInstance()->findClient(redirectUrl)) {
		statusMessage(STRING(REDIRECT_ALREADY_CONNECTED), LogMessage::SEV_INFO);
		return;
	}

	auto newClient = ClientManager::getInstance()->redirect(getHubUrl(), redirectUrl);
	fire(ClientListener::Redirected(), getHubUrl(), newClient);
}

void Client::on(BufferedSocketListener::Failed, const string& aLine) noexcept {
	// Failover only applies to connect-time failures; a dropped established session
	// is retried on the same address (captured before the state changes below)
	const auto wasEstablished = stateNormal();

	updateCounts(true);
	clearUsers();

	const auto keyprintMismatch = isKeyprintMismatch();
	if (keyprintMismatch) {
		// Pause auto-reconnect before publishing STATE_DISCONNECTED so the reconnect timer
		// can't race the user's decision in the mismatch prompt (which would flip the state
		// to CONNECTING and make accept/allow a silent no-op). The user's choice re-enables
		// it via connect(); Cancel leaves the hub waiting for a manual reconnect.
		setAutoReconnect(false);

		// The presented keyprint was captured during the TLS verify callback (the peer
		// cert can't be read back reliably after a failed handshake); surface it to the GUI
		mismatchedKeyprint = sock->getPresentedKeyprint();
	}

	setConnectState(STATE_DISCONNECTED);
	statusMessage(aLine, LogMessage::SEV_WARNING);

	if (keyprintMismatch) {
		fire(ClientListener::KeyprintMismatch(), this);
	}

	// Anti-storm: repeated failures ramp the reconnect delay up exponentially so a
	// permanently unreachable/mismatched hub doesn't hammer the server forever. The window
	// must exceed the highest escalated delay, otherwise a failure always lands after the
	// window has elapsed and the counter resets before it can reach the upper tiers.
	{
		const auto now = GET_TICK();
		constexpr uint64_t WINDOW_MS = 60 * 60 * 1000;
		if (failBurstWindowStart == 0 || (now - failBurstWindowStart) > WINDOW_MS) {
			failBurstWindowStart = now;
			failBurstCount = 0;
		}
		failBurstCount++;
		if (failBurstCount >= 3) {
			uint32_t delay = 5 * 60;
			if (failBurstCount >= 4) delay = 10 * 60;
			if (failBurstCount >= 5) delay = 30 * 60;
			if (getReconnDelay() < delay) setReconnDelay(delay);
		}
	}

	fire(ClientListener::Disconnected(), getHubUrl(), aLine);

	// Failover (ADC-EXT 4.21): if the hub never came up, move on to the next known
	// address. Skipped for established-session drops, locally initiated disconnects
	// (user action, shutdown), keyprint mismatches (the user decides in the prompt)
	// and when auto-reconnect is off (e.g. QUI TL-1).
	if (!wasEstablished && !localDisconnect && !keyprintMismatch && getAutoReconnect()) {
		if (auto next = getNextFailoverUrl(); !next.empty()) {
			statusMessage(STRING_F(REDIRECT_FAILOVER_TRYING, next), LogMessage::SEV_INFO);
			redirectUrl = next;
			doRedirect();
		}
	}
}

bool Client::isKeyprintMismatch() const noexcept {
	return sock && !sock->isKeyprintMatch();
}

void Client::callAsync(AsyncF f) noexcept {
	if (sock) {
		sock->callAsync(std::move(f));
	}
}

/*
 * aLocal marks the disconnect as OUR decision, which suppresses failover: the user closed the
 * hub, the client is shutting down, a redirect is being followed. A protocol-level failure is
 * not one of those, even though we are the side closing the socket.
 */
void Client::disconnect(bool graceLess, bool aLocal) noexcept {
	if (aLocal) {
		localDisconnect = true;
	}

	if(sock)
		sock->disconnect(graceLess);
}

bool Client::isConnected() const noexcept {
	State s = state;
	return s != STATE_CONNECTING && s != STATE_DISCONNECTED; 
}

bool Client::isSocketSecure() const noexcept {
	return isConnected() && sock && sock->isSecure();
}

HubData* Client::getPluginObject() noexcept {
	resetEntity();

	pod.url = pluginString(getHubUrl());
	pod.ip = pluginString(getIp());
	pod.object = this;
	pod.port = static_cast<uint16_t>(Util::toInt(getPort()));
	pod.protocol = dynamic_cast<AdcHub*>(this) ? PROTOCOL_ADC : PROTOCOL_NMDC; // TODO: dynamic_cast not practical if more than two protocols
	pod.isOp = isOp() ? True : False;
	pod.isSecure = isSocketSecure() ? True : False;

	return &pod;
}

HubData* Client::copyDetachedPluginObject() noexcept {
	return copyPluginObjectDetached([this]() -> HubData* {
		// Standalone struct off the stack; the two strings back its char* fields and
		// stay alive until copyData has dup'd them. pod is never touched.
		const string url = getHubUrl();
		const string ip = getIp();

		HubData snapshot{};
		snapshot.url = url.c_str();
		snapshot.ip = ip.c_str();
		snapshot.object = this;
		snapshot.port = static_cast<uint16_t>(Util::toInt(getPort()));
		snapshot.protocol = dynamic_cast<AdcHub*>(this) ? PROTOCOL_ADC : PROTOCOL_NMDC;
		snapshot.isOp = isOp() ? True : False;
		snapshot.isSecure = isSocketSecure() ? True : False;

		return PluginApiImpl::copyData(&snapshot);
	});
}

bool Client::isTrusted() const noexcept {
	return isConnected() && sock && sock->isTrusted();
}

std::string Client::getEncryptionInfo() const noexcept {
	return isConnected() && sock ? sock->getEncryptionInfo() : Util::emptyString;
}

ByteVector Client::getKeyprint() const noexcept {
	return isConnected() && sock ? sock->getKeyprint() : ByteVector();
}

void Client::updateActivity() noexcept {
	lastActivity = GET_TICK(); 
}

bool Client::isSharingHub() const noexcept {
	return get(HubSettings::ShareProfile) != SP_HIDDEN;
}

bool Client::updateCounts(bool aRemove) noexcept {
	// We always remove the count and then add the correct one if requested...
	if(countType != COUNT_UNCOUNTED) {
		allCounts[countType]--;
		if (countIsSharing) {
			sharingCounts[countType]--;
		}

		countType = COUNT_UNCOUNTED;
	}

	if(!aRemove) {
		if(getMyIdentity().isOp()) {
			countType = COUNT_OP;
		} else if(getMyIdentity().isRegistered()) {
			countType = COUNT_REGISTERED;
		} else {
			//disconnect before the hubcount is updated.
			if(SETTING(DISALLOW_CONNECTION_TO_PASSED_HUBS)) {
				statusMessage(STRING(HUB_NOT_PROTECTED), LogMessage::SEV_ERROR);
				disconnect(true);
				setAutoReconnect(false);
				return false;
			}

			countType = COUNT_NORMAL;
		}

		countIsSharing = isSharingHub();

		allCounts[countType]++;
		if (countIsSharing) {
			sharingCounts[countType]++;
		}
	}
	return true;
}

uint64_t Client::queueSearch(const SearchPtr& aSearch) noexcept {
	dcdebug("Queue search %s\n", aSearch->query.c_str());
	return searchQueue.add(aSearch);
}

optional<uint64_t> Client::getQueueTime(CallerPtr aOwner) const noexcept {
	return searchQueue.getQueueTime(Search::CompareOwner(aOwner));
}

string Client::getAllCountsStr() noexcept {
	char buf[128];
	return string(buf, snprintf(buf, sizeof(buf), "%ld/%ld/%ld",
		allCounts[COUNT_NORMAL].load(), allCounts[COUNT_REGISTERED].load(), allCounts[COUNT_OP].load()));
}

long Client::getDisplayCount(CountType aCountType) const noexcept {
	//return SETTING(SEPARATE_NOSHARE_HUBS) && isSharingHub() ? sharingCounts[aCountType] : allCounts[aCountType];
	return allCounts[aCountType];
}
 
void Client::on(BufferedSocketListener::Line, const string& aLine) noexcept {
	updateActivity();
	COMMAND_DEBUG(aLine, ProtocolCommandManager::TYPE_HUB, ProtocolCommandManager::INCOMING, getIpPort());
}

void Client::on(TimerManagerListener::Second, uint64_t aTick) noexcept{
	// 64-bit multiply: reconnDelay is a uint32_t, so `* 1000` wrapped above 4294967 seconds and a
	// hub asking for a long wait got a sub-second one instead -- the exact inverse of the request,
	// and with auto-reconnect set on the same line that is a tight reconnect loop.
	if (state == STATE_DISCONNECTED && getAutoReconnect() && (aTick > (getLastActivity() + static_cast<uint64_t>(getReconnDelay()) * 1000))) {
		// Try to reconnect...
		connect();
	}

	// An IP-change reconnect parked by the flap floor; re-run the decision on the socket
	// thread once the floor has expired (only this atomic is touched from the timer thread)
	if (auto retryAt = ipReconnectRetryTick.load(); retryAt > 0 && aTick > retryAt) {
		ipReconnectRetryTick.store(0);
		callAsync([this] {
			for (auto v6 : { false, true }) {
				auto& pending = v6 ? pendingIpReconnect6 : pendingIpReconnect4;
				if (!pending.empty()) {
					auto ip = pending;
					pending.clear();
					handleExternalIPChangedImpl(ip, v6);
				}
			}
		});
	}

	// Watchdog for a hub that accepts the TCP connection but never finishes the protocol
	// handshake: without this the client stays stuck at "Connected" forever (LP #190964).
	// lastActivity is bumped on connect and on every received line, so this only fires when
	// no data has arrived for a while. STATE_VERIFY is excluded (it waits for the user to
	// enter a password).
	static constexpr uint64_t HANDSHAKE_TIMEOUT_MS = 60 * 1000;
	if ((state == STATE_PROTOCOL || state == STATE_IDENTIFY) && aTick > (getLastActivity() + HANDSHAKE_TIMEOUT_MS)) {
		statusMessage(STRING(CONNECTION_TIMEOUT), LogMessage::SEV_WARNING);
		// Not a local disconnect. A hub that accepts TCP and then never speaks is exactly what
		// failover exists for, but marking this as our own decision put it in the same class as
		// the user closing the window, so the next address in the group was never tried.
		disconnect(true, false);
	}

	if (isConnected()){
		auto s = searchQueue.maybePop();
		if (s) {
			fire(ClientListener::OutgoingSearch(), this, s);
			search(s);
		}
	}
}

FloodCounter::FloodLimits Client::getCTMLimits(const OnlineUserPtr& aAdcUser) noexcept {
	// Is it a valid DC client?
	// There may be many connection attempts with MCN users so we don't want to ban them
	if (aAdcUser && ConnectionManager::getInstance()->isMCNUser(aAdcUser->getUser())) {
		return {
			100,
			150,
		};
	}

	return {
		15,
		40,
	};
}

FloodCounter::FloodLimits Client::getSearchLimits() noexcept {
	return {
		20,
		60,
	};
}

bool Client::checkIncomingCTM(const string& aTarget, const OnlineUserPtr& aAdcUser) noexcept {
	auto result = ctmFloodCounter.handleRequest(aTarget, getCTMLimits(aAdcUser));
	if (result.type == FloodCounter::FloodType::OK) {
		return true;
	}

	auto nick = aAdcUser ? aAdcUser->getIdentity().getNick() : STRING(UNKNOWN);
	auto message = STRING_F(CONNECT_REQUEST_SPAM_FROM, aTarget % nick);

	handleFlood(result, ctmFloodCounter.appendFloodRate(aTarget, message, result.type == FloodCounter::FloodType::FLOOD_SEVERE));
	return false;
}

// Flood-counter key for a search target.
//
// Address targets are keyed on the IP alone. In $SA (and an active $Search) the address we would
// answer comes straight out of the hub message, so keying on the full "ip:port" gave an attacker
// a fresh bucket for every port they named -- rotating the port alone defeated the limit
// completely and turned us into a UDP reflector aimed at a third party. Keying on the IP bounds
// what any single victim can be made to receive, without the collateral of a global cap (which
// would throttle answering legitimate searches on a busy hub).
//
// Only stripped when the text before the colon actually looks like an address, so passive
// targets -- which are nicks, and may contain anything -- are left alone.
static string searchFloodKey(const string& aTarget) noexcept {
	const auto colon = aTarget.rfind(':');
	if (colon == string::npos || colon == 0 || colon + 1 >= aTarget.size()) {
		return aTarget;
	}

	// Everything after the colon must be a port
	for (auto i = colon + 1; i < aTarget.size(); ++i) {
		if (aTarget[i] < '0' || aTarget[i] > '9') {
			return aTarget;
		}
	}

	// ...and what precedes it must look like IPv4 ("1.2.3.4") or a bracketed IPv6 ("[::1]"),
	// so a bare IPv6 literal or a nick containing ':' is never truncated.
	const auto host = aTarget.substr(0, colon);
	if (host.find('.') == string::npos && host.back() != ']') {
		return aTarget;
	}

	return host;
}

bool Client::checkIncomingSearch(const string& aTarget, const OnlineUserPtr& aAdcUser) noexcept {
	auto result = searchFloodCounter.handleRequest(searchFloodKey(aTarget), getSearchLimits());
	if (result.type == FloodCounter::FloodType::OK) {
		return true;
	}

	auto nick = aAdcUser ? aAdcUser->getIdentity().getNick() : STRING(UNKNOWN);
	auto message = STRING_F(SEARCH_SPAM_FROM, aTarget % nick);

	handleFlood(result, searchFloodCounter.appendFloodRate(aTarget, message, result.type == FloodCounter::FloodType::FLOOD_SEVERE));
	return false;
}


void Client::handleFlood(const FloodCounter::FloodResult& aResult, const string& aMessage) noexcept {
	if (aResult.type == FloodCounter::FloodType::FLOOD_MINOR) {
		if (aResult.hitLimit) {
			// Status message only
			statusMessage(aMessage, LogMessage::SEV_VERBOSE, LogMessage::Type::SPAM);
		}
	} else if (aResult.type == FloodCounter::FloodType::FLOOD_SEVERE) {
		// If the flood is really severe, there may be lots of incoming messages waiting to be processed
		// We only want to do this once
		if (sock && sock->isDisconnecting()) {
			return;
		}

		statusMessage(
			STRING_F(HUB_DDOS_DISCONNECT, aMessage),
			LogMessage::SEV_ERROR
		);
		setReconnDelay(10 * 60); // 10 minutes
		disconnect(true);
	}
}

}