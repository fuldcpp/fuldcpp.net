/* 
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_NMDC_HUB_H
#define DCPLUSPLUS_DCPP_NMDC_HUB_H

#include <airdcpp/forward.h>
#include <airdcpp/hub/Client.h>
#include <airdcpp/core/thread/CriticalSection.h>

namespace dcpp {

class ClientManager;

class NmdcHub : public Client, private Flags
{
public:
	using Client::send;
	using Client::connect;

	int connect(const OnlineUser& aUser, const string& token, string& lastError_) noexcept override;


	// aMessage.rich is deliberately ignored here and throughout NmdcHub: RTF0 is an ADC
	// extension with no NMDC equivalent, so a rich message goes out as the markdown the
	// user typed and incoming messages are always plain. Client::supportsRichText() stays
	// false for this hub, so the composer never offers rich text on an NMDC route either.
	bool hubMessageHooked(const OutgoingChatMessage& aMessage, string& /*error_*/) noexcept override {
		return hubMessage(aMessage.text, aMessage.thirdPerson);
	}
	bool privateMessageHooked(const OnlineUserPtr& aUser, const OutgoingChatMessage& aMessage, string& error_, bool aEcho) noexcept override {
		return privateMessage(aUser, aMessage.text, error_, aMessage.thirdPerson, aEcho);
	}

	bool hubMessage(const string& aMessage, bool thirdPerson = false) noexcept;
	bool privateMessage(const OnlineUserPtr& aUser, const string& aMessage, string& error_, bool aThirdPerson, bool aEcho) noexcept;
	bool mcPrivateMessage(const OnlineUserPtr& aUser, const string& aMessage, bool aThirdPerson, string& error_) noexcept override;
	void sendUserCmd(const UserCommand& command, const ParamMap& params) override;
	void search(const SearchPtr& aSearch) noexcept override;
	void password(const string& aPass) noexcept override;
	void infoImpl() noexcept override { myInfo(false); }

	size_t getUserCount() const noexcept override;
	
	static string escape(string const& str) { return validateMessage(str, false); }
	static string unescape(const string& str) { return validateMessage(str, true); }

	bool sendHooked(const AdcCommand&, CallerPtr, string&) override { dcassert(0); return false; }

	void emulateCommand(const string& aCmd) noexcept override { onLine(aCmd); }

	static string validateMessage(string tmp, bool reverse);
	void refreshUserList(bool) noexcept override;

	void getUserList(OnlineUserList& list, bool aListHidden) const noexcept override;

	NmdcHub(const string& aHubURL, const ClientPtr& aOldClient = nullptr);
	~NmdcHub() override;
	
	NmdcHub(const NmdcHub&) = delete;
	NmdcHub& operator=(const NmdcHub&) = delete;
private:
	friend class ClientManager;
	enum SupportFlags {
		SUPPORTS_USERCOMMAND	= 0x01,
		SUPPORTS_NOGETINFO		= 0x02,
		SUPPORTS_USERIP2		= 0x04,
		SUPPORTS_SALTPASS		= 0x08,
		SUPPORTS_MCTO			= 0x10,
		SUPPORTS_NICKRULE		= 0x20,
		SUPPORTS_SEARCHRULE		= 0x40,
		SUPPORTS_TTHS			= 0x80,
		SUPPORTS_FAILOVER		= 0x100,
		SUPPORTS_HUBURL			= 0x200,
		SUPPORTS_IP64			= 0x400,	// NMDC IPv4/IPv6 extensions (single token for both)
		SUPPORTS_NICKCHANGE		= 0x800		// Runtime nick changes, acknowledged with $ClientNick
	};

	using NickMap = unordered_map<string, OnlineUserPtr, noCaseStringHash, noCaseStringEq>;
	using NickIter = NickMap::const_iterator;

	NickMap users;

	string localIp;
	string localIp6;	// v6 counterpart, emitted only on IP64 hubs (bare RFC 4291 form)
	string lastMyInfo;
	uint64_t lastUpdate = 0;
	int64_t lastBytesShared = 0;
	int supportFlags = 0;
	string salt;	// SaltPass: base32 challenge from the last $GetPass, consumed by password()
	bool encodingErrorReported = false;	// throttles the per-line encoding complaints to one per connection

	void clearUsers() noexcept override;
	void onLine(const string& aLine) noexcept;

	OnlineUserPtr getUser(const string& aNick) noexcept;
	OnlineUserPtr findUser(const string& aNick) const noexcept override;
	OnlineUserPtr findUser(dcpp::SID aSID) const noexcept override;
	void putUser(const string& aNick) noexcept;
	
	// don't convert to UTF-8 if string is already in this encoding
	string toUtf8(const string& str) noexcept;
	void reportEncodingError(const string& aMessage) noexcept;
	string fromUtf8(const string& str) noexcept;

	void privateMessage(const string& nick, const string& aMessage, bool thirdPerson);
	void validateNick(const string& aNick) { send("$ValidateNick " + fromUtf8(aNick) + "|"); }

	// $FailOver: replace the reconnect-backup list from a comma-separated host list (empty clears it)
	void updateFailoversFromHub(const string& aFailoverStr) noexcept;

	// Normalize a hub-supplied address ($FailOver / $ForceMove) in place: trim it, let the
	// spec's bare host[:port] form inherit aCurrentHubUrl's scheme, and reject anything that
	// is not an NMDC hub link. Returns false if the entry must be dropped.
	static bool normalizeNmdcHubUrl(string& url_, const string& aCurrentHubUrl) noexcept;

	// $ForceMove: validate a hub-driven redirect before following it
	void onForceMove(const string& aRedirectUrl) noexcept;
	void key(const string& aKey) { send("$Key " + aKey + "|"); }
	void version() { send("$Version 1,0091|"); }
	void getNickList() { send("$GetNickList|"); }
	void connectToMe(const OnlineUser& aUser);
	void revConnectToMe(const OnlineUser& aUser);
	void myInfo(bool alwaysSend);
	void supports(const StringList& feat);

	bool changeNick(const string& aNick) noexcept override;

	void updateFromTag(Identity& id, const string& tag);

	// Identity field appliers shared by $MyINFO and the incremental $IN (NMDC 4.5.11)
	void applyDescription(const OnlineUserPtr& u, const string& aRawDescription) noexcept;
	void applyConnection(const OnlineUserPtr& u, const string& aConnection) noexcept;
	void applyStatus(const OnlineUserPtr& u, uint8_t aStatus) noexcept;
	void applyShared(const OnlineUserPtr& u, const string& aBytesShared) noexcept;
	void applyInStatus(const OnlineUserPtr& u, uint32_t aFlags) noexcept;
	void applyInTag(const OnlineUserPtr& u, const string& aTag) noexcept;

	void refreshLocalIp() noexcept;

	// Family-aware activity - the single source of truth for every outgoing
	// address decision. The raw Client::isActive() becomes true for v6-only
	// configurations once NMDC v6 is enabled, which a legacy (non-IP64) hub
	// cannot represent, so NMDC emission paths must never use it directly.
	bool canSendActiveV4() const noexcept;
	bool canSendActiveV6() const noexcept;
	bool hasActiveAddress() const noexcept { return canSendActiveV4() || canSendActiveV6(); }

	// The address to advertise: v4 preferred (IP64 hubs translate per
	// recipient), empty when neither family is emittable (= passive)
	const string& myActiveAddress() const noexcept;

	string checkNick(const string& aNick) noexcept override;
	// NMDC is no longer clamped to IPv4: isActiveV6() now honors the per-hub
	// Connection6 setting and the hub socket may connect over IPv6 (nmdc://[v6]
	// or an AAAA-only hub). All v6 emission is still double-gated on the hub
	// advertising IP64, so legacy hubs receive byte-identical IPv4-only output.
	//
	// This matches AdcHub (which has always returned false): a dual-stack hub
	// reached by hostname may now be connected over IPv6 where NMDC previously
	// forced IPv4. Socket::connect walks the full addrinfo list, so a broken v6
	// path self-heals to v4.
	bool v4only() const noexcept override { return false; }

	// TimerManagerListener
	void on(TimerManagerListener::Second, uint64_t aTick) noexcept override;
	void on(TimerManagerListener::Minute, uint64_t aTick) noexcept override;

	void on(BufferedSocketListener::Connected) noexcept override;
	void on(BufferedSocketListener::Line, const string& l) noexcept override;
};

} // namespace dcpp

#endif // !defined(NMDC_HUB_H)