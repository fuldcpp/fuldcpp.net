/*
 * Copyright (C) 2001-2025 Jacek Sieka, arnetheduck on gmail point com
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * The PluginApiImpl class contains implementations of certain callback functions,
 * they are simply separated here.
 *
 * Port of dcpp/PluginApiImpl to the AirDC++ core. Behavioral deviations from DC++:
 *	- add_download creates a single-file bundle (AirDC queue is bundle-based)
 *	- getConfig("CoreSetup", ...) DOES perform the by-name core setting lookup (see getConfig
 *	  below), including PASSWORD -- the tray-lock secret. This block used to claim the opposite,
 *	  which matters because it is what a reader consults to decide what the boundary exposes.
 *	- the HTTP resource stream hook fires PER CHUNK, from on(Data), not once with the complete
 *	  body. Also previously documented the other way round.
 *	- HOOK_QUEUE_MOVED and HOOK_UI_CHAT_TAGS are created so bind_hook succeeds, but nothing in the
 *	  core runs them: there is no queue-item-moved event to hang the first on, and no chat path
 *	  calls PluginManager::onChatTags, which leaves the DCTagger interface unreachable.
 *	- HOOK_USER_ONLINE and HOOK_USER_OFFLINE are declared in PluginDefs.h but not implemented;
 *	  bind_hook returns NULL for them and now logs a warning rather than failing silently.
 *
 * Every function in the DCAPI tables below is called by plugin code, so every argument is
 * untrusted: pointers may be NULL, stale or plain garbage, and string members may be NULL
 * even when the containing struct is fine. Each entry point therefore
 *	- runs its body inside pluginGuard(), so nothing unwinds back into the plugin's frames
 *	  (see PluginGuard.h for why that is fatal rather than merely rude), and
 *	- validates the object pointer AND every pointer member it touches, routing raw
 *	  const char* through safeStr() before anything constructs a std::string from it.
 * Failures are logged to the "Plugins" log and return the DCAPI "did not work" value
 * (NULL / False / 0) rather than taking the client down with them.
 */

#include "stdinc.h"
#include <airdcpp/plugins/PluginApiImpl.h>

#include <airdcpp/connection/UserConnection.h>
#include <airdcpp/connection/http/HttpConnection.h>
#include <airdcpp/connection/http/HttpConnectionListener.h>
#include <airdcpp/connection/socket/Socket.h>
#include <airdcpp/core/classes/Exception.h>
#include <airdcpp/core/io/File.h>
#include <airdcpp/core/localization/Localization.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/core/version.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/hash/value/Encoder.h>
#include <airdcpp/hub/Client.h>
#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/plugins/PluginGuard.h>
#include <airdcpp/plugins/PluginManager.h>
#include <airdcpp/private_chat/PrivateChat.h>
#include <airdcpp/private_chat/PrivateChatManager.h>
#include <airdcpp/queue/QueueItem.h>
#include <airdcpp/queue/QueueManager.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/user/CID.h>
#include <airdcpp/user/HintedUser.h>
#include <airdcpp/user/OnlineUser.h>
#include <airdcpp/util/AppUtil.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/Util.h>
#include <airdcpp/util/text/Text.h>

#include <limits>

namespace dcpp {

#define IMPL_HOOKS_COUNT 26

static const char* hookGuids[IMPL_HOOKS_COUNT] = {
	HOOK_CHAT_IN,
	HOOK_CHAT_OUT,
	HOOK_CHAT_PM_IN,
	HOOK_CHAT_PM_OUT,

	HOOK_TIMER_SECOND,
	HOOK_TIMER_MINUTE,

	HOOK_HUB_ONLINE,
	HOOK_HUB_OFFLINE,

	HOOK_NETWORK_HUB_IN,
	HOOK_NETWORK_HUB_OUT,
	HOOK_NETWORK_CONN_IN,
	HOOK_NETWORK_CONN_OUT,
	HOOK_NETWORK_UDP_IN,
	HOOK_NETWORK_UDP_OUT,

	HOOK_QUEUE_ADDED,
	HOOK_QUEUE_MOVED,
	HOOK_QUEUE_REMOVED,
	HOOK_QUEUE_FINISHED,

	HOOK_UI_CREATED,
	HOOK_UI_CHAT_TAGS,
	HOOK_UI_CHAT_DISPLAY,
	HOOK_UI_CHAT_COMMAND,
	HOOK_UI_CHAT_COMMAND_PM,

	HOOK_DATAACESSOR_HTTP_RESOURCE_NOTIFICATION,
	HOOK_DATAACESSOR_HTTP_RESOURCE_NOTIFICATION_FAILED,
	HOOK_DATAACESSOR_HTTP_RESOURCE_STREAM
};

DCHooks PluginApiImpl::dcHooks = {
	DCINTF_HOOKS_VER,

	&PluginApiImpl::createHook,
	&PluginApiImpl::destroyHook,

	&PluginApiImpl::bindHook,
	&PluginApiImpl::runHook,
	&PluginApiImpl::releaseHook
};

DCConfig PluginApiImpl::dcConfig = {
	DCINTF_CONFIG_VER,

	&PluginApiImpl::getPath,
	&PluginApiImpl::getInstallPath,

	&PluginApiImpl::setConfig,
	&PluginApiImpl::getConfig,

	&PluginApiImpl::getLanguage,

	&PluginApiImpl::copyData,
	&PluginApiImpl::releaseData
};

DCLog PluginApiImpl::dcLog = {
	DCINTF_LOGGING_VER,

	&PluginApiImpl::log
};

DCConnection PluginApiImpl::dcConnection = {
	DCINTF_DCPP_CONNECTIONS_VER,

	&PluginApiImpl::sendUdpData,
	&PluginApiImpl::sendProtocolCmd,
	&PluginApiImpl::terminateConnection,

	&PluginApiImpl::getUserFromConn
};

DCHub PluginApiImpl::dcHub = {
	DCINTF_DCPP_HUBS_VER,

	&PluginApiImpl::addHub,
	&PluginApiImpl::findHub,
	&PluginApiImpl::removeHub,

	&PluginApiImpl::emulateProtocolCmd,
	&PluginApiImpl::sendProtocolCmd,

	&PluginApiImpl::sendHubMessage,
	&PluginApiImpl::sendLocalMessage,
	&PluginApiImpl::sendPrivateMessage,

	&PluginApiImpl::findUser,
	&PluginApiImpl::copyData,
	&PluginApiImpl::releaseData,

	&PluginApiImpl::copyData,
	&PluginApiImpl::releaseData,

	// DCINTF_DCPP_HUBS_VER 2
	&PluginApiImpl::sendLocalPrivateMessage
};

DCQueue PluginApiImpl::dcQueue = {
	DCINTF_DCPP_QUEUE_VER,

	&PluginApiImpl::addList,
	&PluginApiImpl::addDownload,
	&PluginApiImpl::findDownload,
	&PluginApiImpl::removeDownload,

	&PluginApiImpl::setPriority,
	&PluginApiImpl::pause,

	&PluginApiImpl::copyData,
	&PluginApiImpl::releaseData
};

DCUtils PluginApiImpl::dcUtils = {
	DCINTF_DCPP_UTILS_VER,

	&PluginApiImpl::toUtf8,
	&PluginApiImpl::fromUtf8,

	&PluginApiImpl::Utf8toWide,
	&PluginApiImpl::WidetoUtf8,

	&PluginApiImpl::toBase32,
	&PluginApiImpl::fromBase32,

	// DCINTF_DCPP_UTILS_VER 2
	&PluginApiImpl::toBase32Bounded
};

DCTagger PluginApiImpl::dcTagger = {
	DCINTF_DCPP_TAGGER_VER,

	&PluginApiImpl::getText,

	&PluginApiImpl::addTag,
	&PluginApiImpl::replaceText
};

DCDataAccess PluginApiImpl::dcDataAccess = {
	DCINTF_DCPP_DATAACCESSOR_VER,

	&PluginApiImpl::getHTTPResource,

	&PluginApiImpl::copyData,
	&PluginApiImpl::releaseData
};

CriticalSection PluginApiImpl::udpSocketCS;
Socket* PluginApiImpl::udpSocket = nullptr;

/*
 * One socket, any number of plugin threads.
 *
 * getUdpSocket() handed out a reference to a lazily created static with nothing serialising it:
 * two plugins sending at the same moment both saw the null pointer and both constructed a socket,
 * one of which was leaked while a thread went on writing to it; concurrent writeTo calls shared
 * one socket's state; and shutdown() deleted the socket out from under any send still running.
 *
 * The send happens under the lock instead, which is also what makes the teardown safe.
 */
void PluginApiImpl::sendUdp(const string& aIp, uint32_t aPort, dcptr_t aData, size_t aLen) noexcept {
	Lock l(udpSocketCS);
	if (!udpSocket) {
		try {
			udpSocket = new Socket(Socket::TYPE_UDP);
		} catch (...) {
			return;
		}
	}

	try {
		udpSocket->writeTo(aIp, Util::toString(aPort), aData, aLen);
	} catch (const Exception&) {
		// A plugin's UDP send failing is not something the host reports.
	}
}

static void pluginApiLog(const string& msg) noexcept {
	LogManager::getInstance()->message(msg, LogMessage::SEV_INFO, "Plugins");
}

/*
 * malloc + copy for the C strings inside the plugin-visible data structs.
 *
 * A NULL source becomes an empty string rather than a NULL member: plugins are entitled to
 * assume the structs the host hands back are well-formed, and propagating a NULL into
 * (say) HubData::url just moves the crash somewhere less obvious. nullptr is returned only
 * on allocation failure, which every caller must handle -- the copyData family used to
 * memcpy/strncpy straight into an unchecked malloc result.
 */
static char* dupPluginStr(const char* aStr) noexcept {
	// via safeStr, so an unreadable source becomes an empty copy rather than a fault in
	// strlen -- these run on structs the plugin may have kept past their lifetime.
	auto src = safeStr(aStr);
	auto bufLen = src.size() + 1;
	auto buf = static_cast<char*>(malloc(bufLen));
	if(buf) {
		memcpy(buf, src.c_str(), bufLen);
	}
	return buf;
}

void PluginApiImpl::init() {
	auto& dcCore = *PluginManager::getInstance()->getCore();

	dcCore.apiVersion = DCAPI_CORE_VER;

	// Interface registry
	dcCore.register_interface = &PluginApiImpl::registerInterface;
	dcCore.query_interface = &PluginApiImpl::queryInterface;
	dcCore.release_interface = &PluginApiImpl::releaseInterface;

	// Core functions
	dcCore.has_plugin = &PluginApiImpl::isLoaded;
	dcCore.host_name = &PluginApiImpl::hostName;

	// Interfaces (since these outlast any plugin they don't need to be explictly released)
	dcCore.register_interface(DCINTF_HOOKS, &dcHooks);
	dcCore.register_interface(DCINTF_CONFIG, &dcConfig);
	dcCore.register_interface(DCINTF_LOGGING, &dcLog);

	dcCore.register_interface(DCINTF_DCPP_CONNECTIONS, &dcConnection);
	dcCore.register_interface(DCINTF_DCPP_HUBS, &dcHub);
	dcCore.register_interface(DCINTF_DCPP_QUEUE, &dcQueue);
	dcCore.register_interface(DCINTF_DCPP_UTILS, &dcUtils);
	dcCore.register_interface(DCINTF_DCPP_TAGGER, &dcTagger);
	dcCore.register_interface(DCINTF_DCPP_DATAACCESSOR, &dcDataAccess);

	// Create provided hooks (since these outlast any plugin they don't need to be explictly released)
	for(int i = 0; i < IMPL_HOOKS_COUNT; ++i)
		dcHooks.create_hook(hookGuids[i], NULL);
}

void PluginApiImpl::shutdown() {
	Lock l(udpSocketCS);
	if(udpSocket) {
		udpSocket->disconnect();
		delete udpSocket;
		udpSocket = nullptr;
	}
}

// Functions for DCCore
intfHandle PluginApiImpl::registerInterface(const char* guid, dcptr_t pInterface) {
	return pluginGuard("register_interface", [&]() -> intfHandle {
		if(!guid || !pInterface) {
			return nullptr;
		}
		return PluginManager::getInstance()->registerInterface(safeStr(guid), pInterface);
	});
}

DCInterfacePtr PluginApiImpl::queryInterface(const char* guid, uint32_t version) {
	return pluginGuard("query_interface", [&]() -> DCInterfacePtr {
		if(!guid) {
			return nullptr;
		}

		// we only return the registered interface if it is same or newer than requested
		DCInterface* dci = (DCInterface*)PluginManager::getInstance()->queryInterface(safeStr(guid));
		return (!dci || dci->apiVersion >= version) ? dci : nullptr;
	});
}

Bool PluginApiImpl::releaseInterface(intfHandle hInterface) {
	return pluginGuard("release_interface", [&]() -> Bool {
		return PluginManager::getInstance()->releaseInterface(hInterface) ? True : False;
	});
}

Bool PluginApiImpl::isLoaded(const char* guid) {
	return pluginGuard("has_plugin", [&]() -> Bool {
		if(!guid) {
			return False;
		}
		return PluginManager::getInstance()->isLoaded(safeStr(guid)) ? True : False;
	});
}

const char* PluginApiImpl::hostName() {
	return APPNAME;
}

// Functions for DCHook
hookHandle PluginApiImpl::createHook(const char* guid, DCHOOK defProc) {
	return pluginGuard("create_hook", [&]() -> hookHandle {
		if(!guid) {
			return nullptr;
		}
		return PluginManager::getInstance()->createHook(safeStr(guid), defProc);
	});
}

Bool PluginApiImpl::destroyHook(hookHandle hHook) {
	return pluginGuard("destroy_hook", [&]() -> Bool {
		if(!hHook) {
			return False;
		}
		return PluginManager::getInstance()->destroyHook(reinterpret_cast<PluginHook*>(hHook)) ? True : False;
	});
}

subsHandle PluginApiImpl::bindHook(const char* guid, DCHOOK hookProc, void* pCommon) {
	return pluginGuard("bind_hook", [&]() -> subsHandle {
		if(!guid || !hookProc) {
			return nullptr;
		}
		return PluginManager::getInstance()->bindHook(safeStr(guid), hookProc, pCommon);
	});
}

Bool PluginApiImpl::runHook(hookHandle hHook, dcptr_t pObject, dcptr_t pData) {
	return pluginGuard("run_hook", [&]() -> Bool {
		if(!hHook) {
			return False;
		}
		return PluginManager::getInstance()->runHook(reinterpret_cast<PluginHook*>(hHook), pObject, pData) ? True : False;
	});
}

size_t PluginApiImpl::releaseHook(subsHandle hHook) {
	return pluginGuard("release_hook", [&]() -> size_t {
		return PluginManager::getInstance()->releaseHook(reinterpret_cast<HookSubscriber*>(hHook));
	});
}

// Functions for DCConfig
ConfigStrPtr DCAPI PluginApiImpl::getPath(PathType type) {
	return pluginGuard("get_path", [&]() -> ConfigStrPtr {
		// The first five AppUtil::Paths enumerators match PathType 1:1. AppUtil::getPath
		// indexes a fixed-size array with no bounds check of its own, so an out-of-range
		// PathType from a plugin would read a std::string object off the end of it.
		if(type < PATH_GLOBAL_CONFIG || type > PATH_LOCALE) {
			return nullptr;
		}

		auto str = AppUtil::getPath(static_cast<AppUtil::Paths>(type));
		ConfigStr value = { CFG_TYPE_STRING, str.c_str() };
		return reinterpret_cast<ConfigStrPtr>(copyData(reinterpret_cast<ConfigValuePtr>(&value)));
	});
}

ConfigStrPtr DCAPI PluginApiImpl::getInstallPath(const char* guid) {
	return pluginGuard("get_install_path", [&]() -> ConfigStrPtr {
		if(!guid) {
			return nullptr;
		}

		auto str = PluginManager::getInstallPath(safeStr(guid));
		ConfigStr value = { CFG_TYPE_STRING, str.c_str() };
		return reinterpret_cast<ConfigStrPtr>(copyData(reinterpret_cast<ConfigValuePtr>(&value)));
	});
}

void PluginApiImpl::setConfig(const char* guid, const char* setting, ConfigValuePtr val) {
	return pluginGuard("set_config", [&] {
		if(!val || !guid || !setting) {
			return;
		}

		const auto sGuid = safeStr(guid);
		const auto sSetting = safeStr(setting);
		if(sGuid.empty() || sSetting.empty()) {
			return;
		}

		PluginManager* pm = PluginManager::getInstance();
		switch(val->type) {
			case CFG_TYPE_REMOVE:
				pm->removePluginSetting(sGuid, sSetting);
				break;
			case CFG_TYPE_STRING: {
				auto str = (ConfigStrPtr)val;
				pm->setPluginSetting(sGuid, sSetting, safeStr(str->value));
				break;
			}
			case CFG_TYPE_INT: {
				auto num = (ConfigIntPtr)val;
				pm->setPluginSetting(sGuid, sSetting, Util::toString(num->value));
				break;
			}
			case CFG_TYPE_BOOL: {
				auto num = (ConfigBoolPtr)val;
				pm->setPluginSetting(sGuid, sSetting, Util::toString(num->value));
				break;
			}
			case CFG_TYPE_INT64: {
				auto num = (ConfigInt64Ptr)val;
				pm->setPluginSetting(sGuid, sSetting, Util::toString(num->value));
				break;
			}
			default:
				dcassert(0);
		}
	});
}

ConfigValuePtr PluginApiImpl::getConfig(const char* guid, const char* setting, ConfigType type) {
	return pluginGuard("get_config", [&]() -> ConfigValuePtr {
	if(!guid || !setting) {
		return NULL;
	}

	const auto sGuid = safeStr(guid);
	const auto sSetting = safeStr(setting);
	if(sGuid.empty() || sSetting.empty()) {
		return NULL;
	}

	// DC++ resolves core settings by name via the magic guid "CoreSetup"; look the setting
	// up by its XML tag name and return it in its native type (matches DC++ behavior).
	if(sGuid == "CoreSetup") {
		auto sm = SettingsManager::getInstance();
		int key = SettingsManager::findSettingByTag(sSetting);
		if(key < 0) {
			return NULL;
		}

		if(key >= SettingsManager::STR_FIRST && key < SettingsManager::STR_LAST) {
			string v = sm->get(static_cast<SettingsManager::StrSetting>(key));
			ConfigStr value = { CFG_TYPE_STRING, v.c_str() };
			return copyData((ConfigValuePtr)&value);
		}
		if(key >= SettingsManager::INT_FIRST && key < SettingsManager::INT_LAST) {
			ConfigInt value = { CFG_TYPE_INT, sm->get(static_cast<SettingsManager::IntSetting>(key)) };
			return copyData((ConfigValuePtr)&value);
		}
		if(key >= SettingsManager::BOOL_FIRST && key < SettingsManager::BOOL_LAST) {
			ConfigBool value = { CFG_TYPE_BOOL, sm->get(static_cast<SettingsManager::BoolSetting>(key)) ? True : False };
			return copyData((ConfigValuePtr)&value);
		}
		if(key >= SettingsManager::INT64_FIRST && key < SettingsManager::INT64_LAST) {
			ConfigInt64 value = { CFG_TYPE_INT64, sm->get(static_cast<SettingsManager::Int64Setting>(key)) };
			return copyData((ConfigValuePtr)&value);
		}
		return NULL;
	}

	PluginManager* pm = PluginManager::getInstance();
	switch(type) {
		case CFG_TYPE_STRING: {
			// Copy into a local; getPluginSetting returns a reference into the settings
			// map that another thread could invalidate once its lock is released.
			string settingValue = pm->getPluginSetting(sGuid, sSetting);
			ConfigStr value = { type, settingValue.c_str() };
			return copyData((ConfigValuePtr)&value);
		}
		// The three below copy first for the same reason the string case above does: the reference
		// getPluginSetting hands back points into the settings map and is only valid while the lock
		// it took is held, which it no longer is by the time the value is read. Only the string case
		// was fixed; these read through the same reference.
		case CFG_TYPE_INT: {
			string settingValue = pm->getPluginSetting(sGuid, sSetting);
			ConfigInt value = { type, Util::toInt(settingValue) };
			return copyData((ConfigValuePtr)&value);
		}
		case CFG_TYPE_BOOL: {
			string settingValue = pm->getPluginSetting(sGuid, sSetting);
			ConfigBool value = { type, settingValue != "0" ? True : False };
			return copyData((ConfigValuePtr)&value);
		}
		case CFG_TYPE_INT64: {
			string settingValue = pm->getPluginSetting(sGuid, sSetting);
			ConfigInt64 value = { type, Util::toInt64(settingValue) };
			return copyData((ConfigValuePtr)&value);
		}
		default:
			dcassert(0);
	}

	return NULL;
	});
}

ConfigStrPtr DCAPI PluginApiImpl::getLanguage() {
	return pluginGuard("get_language", [&]() -> ConfigStrPtr {
		// IETF form uses '-' as the subtag separator
		auto str = Localization::getCurLanguageLocale();
		std::replace(str.begin(), str.end(), '_', '-');
		ConfigStr value = { CFG_TYPE_STRING, str.c_str() };
		return reinterpret_cast<ConfigStrPtr>(copyData(reinterpret_cast<ConfigValuePtr>(&value)));
	});
}

ConfigValuePtr PluginApiImpl::copyData(const ConfigValuePtr val) {
	return pluginGuard("config copy", [&]() -> ConfigValuePtr {
	if(!val) {
		return NULL;
	}

	switch(val->type) {
		case CFG_TYPE_STRING: {
			auto str = (ConfigStrPtr)val;
			auto copy = (ConfigStrPtr)malloc(sizeof(ConfigStr));
			if(!copy) {
				return NULL;
			}
			memcpy(copy, str, sizeof(ConfigStr));

			copy->value = dupPluginStr(str->value);
			if(!copy->value) {
				free(copy);
				return NULL;
			}

			return (ConfigValuePtr)copy;
		}
		case CFG_TYPE_INT: {
			auto num = (ConfigIntPtr)val;
			auto copy = (ConfigIntPtr)malloc(sizeof(ConfigInt));
			if(!copy) {
				return NULL;
			}
			memcpy(copy, num, sizeof(ConfigInt));

			return (ConfigValuePtr)copy;
		}
		case CFG_TYPE_BOOL: {
			auto num = (ConfigBoolPtr)val;
			auto copy = (ConfigBoolPtr)malloc(sizeof(ConfigBool));
			if(!copy) {
				return NULL;
			}
			memcpy(copy, num, sizeof(ConfigBool));

			return (ConfigValuePtr)copy;
		}
		case CFG_TYPE_INT64: {
			auto num = (ConfigInt64Ptr)val;
			auto copy = (ConfigInt64Ptr)malloc(sizeof(ConfigInt64));
			if(!copy) {
				return NULL;
			}
			memcpy(copy, num, sizeof(ConfigInt64));

			return (ConfigValuePtr)copy;
		}
		default:
			dcassert(0);
	}

	return NULL;
	});
}

void PluginApiImpl::releaseData(ConfigValuePtr val) {
	return pluginGuard("config release", [&] {
		// Everything below is free()d, so a bogus pointer here is an arbitrary free rather
		// than a read fault. Nothing can validate that the plugin is handing back a block
		// this file allocated; the NULL check is the only cheap guard available, and an
		// unrecognised type tag is treated as "not ours" instead of falling through.
		if(!val) {
			return;
		}

		switch(val->type) {
			case CFG_TYPE_STRING: {
				auto str = (ConfigStrPtr)val;
				free((char*)str->value);
				free(str);
				break;
			}
			case CFG_TYPE_INT: {
				auto num = (ConfigIntPtr)val;
				free(num);
				break;
			}
			case CFG_TYPE_BOOL: {
				auto num = (ConfigBoolPtr)val;
				free(num);
				break;
			}
			case CFG_TYPE_INT64: {
				auto num = (ConfigInt64Ptr)val;
				free(num);
				break;
			}
			default:
				dcassert(0);
		}
	});
}

// Functions for DCLog
void PluginApiImpl::log(const char* msg) {
	return pluginGuard("log", [&] {
		pluginApiLog(safeStr(msg));
	});
}

// A plugin may hand back a ConnectionData it built itself, or one whose `object` was
// never populated -- in which case these reinterpret_casts turned into a call through an
// arbitrary pointer. The DCAPI convention says a plugin must not track a specific
// instance, but the host should not take that on trust: the hub-side equivalents in this
// file already re-resolve rather than trusting the plugin-held pointer.
//
// NOTE: this only closes the NULL case. A plugin that stashes a ConnectionDataPtr and uses
// it after the transfer ended still passes a stale-but-non-null pointer; closing that
// needs a liveness lookup that ConnectionManager does not currently expose.
static UserConnection* connectionFromData(ConnectionDataPtr conn) noexcept {
	if (!conn || !conn->object) {
		return nullptr;
	}

	return reinterpret_cast<UserConnection*>(conn->object);
}

// Functions for DCConnection
void PluginApiImpl::sendProtocolCmd(ConnectionDataPtr conn, const char* cmd) {
	return pluginGuard("conn send_command", [&] {
		// Goes through send() and thus the HOOK_NETWORK_CONN_OUT callsite, same as DC++'s sendRaw
		if (auto uc = connectionFromData(conn); uc && cmd) {
			uc->sendRaw(safeStr(cmd));
		}
	});
}

void PluginApiImpl::terminateConnection(ConnectionDataPtr conn, Bool graceless) {
	return pluginGuard("terminate_connection", [&] {
		if (auto uc = connectionFromData(conn); uc) {
			uc->disconnect(graceless != False);
		}
	});
}

void PluginApiImpl::sendUdpData(const char* ip, uint32_t port, dcptr_t data, size_t n) {
	return pluginGuard("send_udp_data", [&] {
		// data/n describe a buffer inside the plugin; there is no way to validate the
		// length, but a NULL buffer or a zero length is worth refusing rather than handing
		// to the socket layer.
		const auto sIp = safeStr(ip);
		if(sIp.empty() || !data || n == 0) {
			return;
		}

		sendUdp(sIp, port, data, n);
	});
}

UserDataPtr PluginApiImpl::getUserFromConn(ConnectionDataPtr conn) {
	return pluginGuard("get_user_from_conn", [&]() -> UserDataPtr {
		auto uc = connectionFromData(conn);
		if (!uc) { return nullptr; }

		auto user = uc->getHintedUser();
		if(!user.user) { return nullptr; }

		auto ou = ClientManager::getInstance()->findOnlineUser(user);
		if(!ou) { return nullptr; }
		return ou->copyDetachedPluginObject();
	});
}

// Functions for DCUtils
//
// NOTE: these deliberately reproduce DC++'s exact behavior bit-for-bit: they copy
// str.size() bytes with strncpy (no trailing NUL) and return str.size() (the length,
// not the +1 buffer size the header text implies). Existing compiled DC++ plugins were
// built against this behavior (e.g. sizing a buffer to the return value and treating the
// result as counted, not NUL-terminated). Changing it to a "safer" NUL-terminating
// contract would diverge from DC++ and could break those plugins, so it is left as-is.
//
// The `dst && ` added to each capacity test keeps the two-call sizing idiom working: a
// plugin may legitimately pass dst = NULL to ask only for the required size, and the
// original tests would have written through it whenever the result was empty.
size_t PluginApiImpl::toUtf8(char* dst, const char* src, size_t n) {
	return pluginGuard("to_utf8", [&]() -> size_t {
		string str(Text::toUtf8(safeStr(src)));
		if(dst && n >= str.size()) {
			strncpy(dst, str.c_str(), str.size());
		}
		return str.size();
	});
}

size_t PluginApiImpl::fromUtf8(char* dst, const char* src, size_t n) {
	return pluginGuard("from_utf8", [&]() -> size_t {
		string str(Text::fromUtf8(safeStr(src)));
		if(dst && n >= str.size()) {
			strncpy(dst, str.c_str(), str.size());
		}
		return str.size();
	});
}

size_t PluginApiImpl::Utf8toWide(wchar_t* dst, const char* src, size_t n) {
	return pluginGuard("utf8_to_wcs", [&]() -> size_t {
		wstring str(Text::utf8ToWide(safeStr(src)));
		if(dst && n >= str.size()) {
			wcsncpy(dst, str.c_str(), str.size());
		}
		return str.size();
	});
}

size_t PluginApiImpl::WidetoUtf8(char* dst, const wchar_t* src, size_t n) {
	return pluginGuard("wcs_to_utf8", [&]() -> size_t {
		string str(Text::wideToUtf8(src ? wstring(src) : wstring()));
		if(dst && n >= str.size()) {
			strncpy(dst, str.c_str(), str.size());
		}
		return str.size();
	});
}

size_t PluginApiImpl::toBase32(char* dst, const uint8_t* src, size_t n) {
	return pluginGuard("to_base32", [&]() -> size_t {
		// `n` is the SOURCE byte count -- it has to be, since src is raw bytes with no terminator
		// and the encoder needs a length. The old "n >= str.size()" read it as a destination
		// capacity as well, and because base32 always expands (24 bytes -> 39 chars) that test
		// could never pass: dst was never written at all, so a plugin converting a TTH got its
		// uninitialised buffer back while the return value claimed 39 characters.
		//
		// Sizing dst is the caller's responsibility, as in the upstream API: the output is always
		// ceil(n * 8 / 5) characters, and this writes exactly that many with no terminator.
		// That makes the memcpy below unbounded by construction -- it is the documented DC++
		// contract, so the only thing that can be checked here is that the pointers exist.
		if(!src || n == 0) {
			return 0;
		}

		string str(Encoder::toBase32(src, n));
		if(!dst) {
			return str.size();
		}

		memcpy(dst, str.c_str(), str.size());
		return str.size();
	});
}

size_t PluginApiImpl::toBase32Bounded(char* dst, size_t dstLen, const uint8_t* src, size_t n) {
	return pluginGuard("to_base32_bounded", [&]() -> size_t {
		// The safe counterpart to toBase32 above (DCINTF_DCPP_UTILS_VER 2). Here the
		// destination capacity is explicit, so the write can actually be bounded instead of
		// trusting the caller to have sized dst for ceil(n*8/5).
		if(!src || n == 0) {
			return 0;
		}

		string str(Encoder::toBase32(src, n));

		// Sizing call: dst may be NULL (or too small) -- report what is needed and write
		// nothing more than fits.
		if(dst && dstLen > 0) {
			memcpy(dst, str.c_str(), std::min(dstLen, str.size()));
		}

		return str.size();
	});
}

size_t PluginApiImpl::fromBase32(uint8_t* dst, const char* src, size_t n) {
	return pluginGuard("from_base32", [&]() -> size_t {
		// Encoder::fromBase32 walks src until its NUL regardless of n, so a NULL source is
		// an immediate deref rather than an empty result.
		if(!dst || !src || n == 0) {
			return 0;
		}

		Encoder::fromBase32(src, dst, n);
		return n;
	});
}

// Functions for DCTagger
//
// `object` is a host-owned Tagger that only exists for the duration of the HOOK_UI_CHAT_TAGS
// callback, so as with the hub/user objects the plugin must not stash the TagData. All this
// side can check is that the struct and its object pointer are present.
static Tagger* taggerFromData(TagDataPtr hTags) noexcept {
	if(!hTags || !hTags->object) {
		return nullptr;
	}

	return reinterpret_cast<Tagger*>(hTags->object);
}

const char* PluginApiImpl::getText(TagDataPtr hTags) {
	return pluginGuard("get_text", [&]() -> const char* {
		auto tagger = taggerFromData(hTags);
		return tagger ? tagger->getText().c_str() : nullptr;
	});
}

void PluginApiImpl::addTag(TagDataPtr hTags, size_t start, size_t end, const char* id, const char* attributes) {
	return pluginGuard("add_tag", [&] {
		auto tagger = taggerFromData(hTags);
		if(!tagger) {
			return;
		}

		// The positions are not applied until merge(); an inverted or out-of-range pair
		// would corrupt the merge rather than fail here, so reject it at the boundary.
		auto len = tagger->getText().size();
		if(start > end || end > len) {
			return;
		}

		tagger->addTag(start, end, safeStr(id), safeStr(attributes));
	});
}

void PluginApiImpl::replaceText(TagDataPtr hTags, size_t start, size_t end, const char* replacement) {
	return pluginGuard("replace_text", [&] {
		auto tagger = taggerFromData(hTags);
		if(!tagger) {
			return;
		}

		// Tagger::replaceText does text.replace(start, end - start, ...), which throws
		// std::out_of_range for start > size() and silently misbehaves when end < start
		// (the unsigned subtraction wraps). Either way the throw would unwind back into
		// the plugin's frames, so bound both here.
		auto len = tagger->getText().size();
		if(start > end || end > len) {
			return;
		}

		tagger->replaceText(start, end, safeStr(replacement));
	});
}

// Functions for DCQueue
QueueDataPtr PluginApiImpl::addList(UserDataPtr user, Bool silent) {
	return pluginGuard("add_list", [&]() -> QueueDataPtr {
		if(!user || !user->cid) {
			return NULL;
		}

		auto u = ClientManager::getInstance()->findUser(CID(safeStr(user->cid)));
		if(!u) return NULL;

		QueueData* data = NULL;
		try {
			FilelistAddData listData(HintedUser(u, safeStr(user->hubHint)), PluginManager::getInstance(), ADC_ROOT_STR);
			auto qi = QueueManager::getInstance()->addListHooked(listData, silent ? 0 : QueueItem::FLAG_CLIENT_VIEW);
			if(qi) {
				// Detached, like find_hub/find_user: the plugin keeps this struct, and the managed
				// copy rewrites the item's pod and string cache, which a plugin already holding a
				// borrowed object for the same item would see change underneath it.
				data = qi->copyDetachedPluginObject();
			}
		} catch(const Exception& e) {
			pluginApiLog(e.getError());
		}

		return data;
	});
}

QueueDataPtr PluginApiImpl::addDownload(const char* hash, uint64_t size, const char* target) {
	return pluginGuard("add_download", [&]() -> QueueDataPtr {
		const auto rawTarget = safeStr(target);
		if(!hash || rawTarget.empty()) {
			return NULL;
		}

		QueueData* data = NULL;
		try {
			string sTarget = File::isAbsolutePath(rawTarget) ? rawTarget : SETTING(DOWNLOAD_DIRECTORY) + rawTarget;

			// AirDC's queue is bundle-based: this creates a single-file bundle
			BundleAddOptions options(PathUtil::getFilePath(sTarget), HintedUser(), PluginManager::getInstance());
			BundleFileAddData fileInfo(PathUtil::getFileName(sTarget), TTHValue(safeStr(hash)), size, Priority::DEFAULT, GET_TIME());
			QueueManager::getInstance()->createFileBundleHooked(options, fileInfo, 0);

			data = findDownload(sTarget.c_str());
		} catch(const Exception& e) {
			pluginApiLog(e.getError());
		}

		return data;
	});
}

QueueDataPtr PluginApiImpl::findDownload(const char* target) {
	return pluginGuard("find_download", [&]() -> QueueDataPtr {
		const auto sTarget = safeStr(target);
		if(sTarget.empty()) {
			return NULL;
		}

		auto qi = QueueManager::getInstance()->findFileByTarget(sTarget);
		return qi ? qi->copyDetachedPluginObject() : NULL;
	});
}

void PluginApiImpl::removeDownload(QueueDataPtr qi) {
	return pluginGuard("remove_download", [&] {
		const auto sTarget = qi ? safeStr(qi->target) : string();
		if(sTarget.empty()) {
			return;
		}

		QueueManager::getInstance()->removeFile(sTarget);
	});
}

static Priority convertPrio(QueuePrio priority) {
	// The DCAPI values are one below AirDC's Priority (which adds PAUSED_FORCE/PAUSED in front)
	switch(priority) {
		case PRIO_LOWEST: return Priority::LOWEST;
		case PRIO_LOW: return Priority::LOW;
		case PRIO_NORMAL: return Priority::NORMAL;
		case PRIO_HIGH: return Priority::HIGH;
		case PRIO_HIGHEST: return Priority::HIGHEST;
		case PRIO_DEFAULT:
		default: return Priority::DEFAULT;
	}
}

void PluginApiImpl::setPriority(QueueDataPtr qi, QueuePrio priority) {
	return pluginGuard("set_priority", [&] {
		const auto sTarget = qi ? safeStr(qi->target) : string();
		if(sTarget.empty()) {
			return;
		}

		QueueManager::getInstance()->setQIPriority(sTarget, convertPrio(priority));
	});
}

Bool PluginApiImpl::pause(QueueDataPtr qi) {
	return pluginGuard("pause", [&]() -> Bool {
		const auto sTarget = qi ? safeStr(qi->target) : string();
		if(sTarget.empty()) {
			return False;
		}

		auto item = QueueManager::getInstance()->findFileByTarget(sTarget);
		if(!item) return False;

		bool paused = (item->getPriority() == Priority::PAUSED || item->getPriority() == Priority::PAUSED_FORCE);
		QueueManager::getInstance()->setQIPriority(sTarget, paused ? Priority::DEFAULT : Priority::PAUSED);
		return (!paused ? True : False);
	});
}

QueueDataPtr PluginApiImpl::copyData(const QueueDataPtr qi) {
	return pluginGuard("queue copy", [&]() -> QueueDataPtr {
		if(!qi) {
			return NULL;
		}

		QueueDataPtr copy = (QueueDataPtr)malloc(sizeof(QueueData));
		if(!copy) {
			return NULL;
		}
		memcpy(copy, qi, sizeof(QueueData));

		copy->target = dupPluginStr(qi->target);
		copy->location = dupPluginStr(qi->location);
		copy->hash = dupPluginStr(qi->hash);

		if(!copy->target || !copy->location || !copy->hash) {
			free((char*)copy->target);
			free((char*)copy->location);
			free((char*)copy->hash);
			free(copy);
			return NULL;
		}

		copy->isManaged = False;
		return copy;
	});
}

void PluginApiImpl::releaseData(QueueDataPtr qi) {
	return pluginGuard("queue release", [&] {
		if(!qi) {
			return;
		}

		if(qi->isManaged) {
			pluginApiLog("Plugin trying to free a managed object !");
			return;
		}

		free((char*)qi->target);
		free((char*)qi->location);
		free((char*)qi->hash);

		free(qi);
	});
}

// Functions for DCHub
//
// Every function here resolves the hub by URL rather than by the `object` pointer inside
// the HubData, so a plugin that hands back a stale struct gets a failed lookup instead of a
// call through freed memory. That only works if the URL itself is readable: `hub->url`
// points into the Client's own string cache, which is recycled on the next hook fire, so a
// plugin that stashes a hook-supplied HubData can present a NULL or dangling url here.
// Both were observed in the 2026-08-07 crash reports, in the same strlen. hubUrlFromData()
// is the single choke point for that check.
static bool hubUrlFromData(HubDataPtr hub, string& url_) noexcept {
	if(!hub) {
		return false;
	}

	// safeStr, not a raw construction: the 16:41 bundle's url was not NULL, it was a freed
	// pointer into unmapped memory, and the fault was inside strlen.
	url_ = safeStr(hub->url);
	return !url_.empty();
}

HubDataPtr PluginApiImpl::addHub(const char* url, const char* nick, const char* password) {
	return pluginGuard("add_hub", [&]() -> HubDataPtr {
		const auto sUrl = safeStr(url);
		if(sUrl.empty()) {
			return NULL;
		}

		HubData* data = findHub(sUrl.c_str());

		if(data == NULL && !SETTING(NICK).empty()) {
			auto client = ClientManager::getInstance()->createClient(sUrl);
			if(!client) {
				return NULL;
			}
			// Set as overrides rather than written straight into HubSettings: connect() calls
			// reloadSettings(), which rebuilds those from the global settings and clears the
			// password outright for a hub with no favourite, so both arguments were discarded
			// before the handshake ever ran.
			client->setCredentialOverrides(safeStr(nick), safeStr(password));
			client->connect();

			// Returned whether or not the socket is up yet. connect() only STARTS the connection --
			// the socket runs on its own thread -- so isConnected() is false here essentially
			// always, and add_hub returned NULL for every hub it had just successfully created.
			// The plugin asked for the hub and the hub now exists; when it finishes connecting is
			// what the hub-online hook is for.
			return client->copyDetachedPluginObject();
		}

		return data;
	});
}

HubDataPtr PluginApiImpl::findHub(const char* url) {
	return pluginGuard("find_hub", [&]() -> HubDataPtr {
		const auto sUrl = safeStr(url);
		if(sUrl.empty()) {
			return NULL;
		}

		auto client = ClientManager::getInstance()->findClient(sUrl);
		if(client && client->isConnected()) {
			// Detached copy: a plugin may call this from inside a hook on this very hub,
			// and the ordinary copy path would rewrite the struct it is holding. See
			// PluginEntity::copyPluginObjectDetached.
			return client->copyDetachedPluginObject();
		}

		return NULL;
	});
}

void PluginApiImpl::removeHub(HubDataPtr hub) {
	return pluginGuard("remove_hub", [&] {
		// Re-resolve instead of trusting the plugin-held object pointer
		string url;
		if(!hubUrlFromData(hub, url)) {
			return;
		}

		auto client = ClientManager::getInstance()->findClient(url);
		if(client) {
			ClientManager::getInstance()->putClient(client);
		}
	});
}

void PluginApiImpl::emulateProtocolCmd(HubDataPtr hub, const char* cmd) {
	return pluginGuard("emulate_protocol_cmd", [&] {
		string url;
		if(!hubUrlFromData(hub, url) || !cmd) {
			return;
		}

		auto client = ClientManager::getInstance()->findClient(url);
		if(client) {
			client->emulateCommand(safeStr(cmd));
		}
	});
}

void PluginApiImpl::sendProtocolCmd(HubDataPtr hub, const char* cmd) {
	return pluginGuard("hub send_protocol_cmd", [&] {
		string url;
		if(!hubUrlFromData(hub, url) || !cmd) {
			return;
		}

		auto client = ClientManager::getInstance()->findClient(url);
		if(client) {
			client->send(safeStr(cmd));
		}
	});
}

void PluginApiImpl::sendHubMessage(HubDataPtr hub, const char* message, Bool thirdPerson) {
	return pluginGuard("send_message", [&] {
		string url;
		if(!hubUrlFromData(hub, url)) {
			return;
		}

		auto client = ClientManager::getInstance()->findClient(url);
		if(!client) {
			return;
		}

		// Lets make plugins life easier...
		ParamMap params;
		client->getMyIdentity().getParams(params, "my", true);
		client->getHubIdentity().getParams(params, "hub", false);

		string error;
		client->sendMessageHooked(OutgoingChatMessage(Util::formatParams(safeStr(message), params),
			PluginManager::getInstance(), "plugins", thirdPerson != False), error);
	});
}

void PluginApiImpl::sendLocalMessage(HubDataPtr hub, const char* msg, MsgType type) {
	return pluginGuard("local_message", [&] {
		string url;
		if(!hubUrlFromData(hub, url)) {
			return;
		}

		auto client = ClientManager::getInstance()->findClient(url);
		if(client) {
			// Map the three DCAPI message styles onto AirDC's message model: SYSTEM keeps the
			// system format; STATUS becomes a low-prominence (verbose) status line; CLIENT is a
			// normal server line. AirDC has no separate hub status-bar target, so STATUS is
			// approximated by severity rather than a distinct sink.
			auto msgType = (type == MSG_SYSTEM) ? LogMessage::Type::SYSTEM : LogMessage::Type::SERVER;
			auto sev = (type == MSG_STATUS) ? LogMessage::SEV_VERBOSE : LogMessage::SEV_INFO;
			client->statusMessage(safeStr(msg), sev, msgType);
		}
	});
}

Bool PluginApiImpl::sendPrivateMessage(UserDataPtr user, const char* message, Bool thirdPerson) {
	return pluginGuard("send_private_message", [&]() -> Bool {
		if(!user || !user->cid) {
			return False;
		}

		auto ou = ClientManager::getInstance()->findOnlineUser(CID(safeStr(user->cid)), safeStr(user->hubHint));
		if(!ou) return False;

		// Lets make plugins life easier...
		ParamMap params;
		ou->getIdentity().getParams(params, "user", true);
		ou->getClient()->getMyIdentity().getParams(params, "my", true);
		ou->getClient()->getHubIdentity().getParams(params, "hub", false);

		string error;
		return ClientManager::getInstance()->privateMessageHooked(ou->getHintedUser(),
			OutgoingChatMessage(Util::formatParams(safeStr(message), params), PluginManager::getInstance(), "plugins", thirdPerson != False),
			error) ? True : False;
	});
}

void PluginApiImpl::sendLocalPrivateMessage(UserDataPtr user, const char* msg, MsgType type) {
	return pluginGuard("local_pm_message", [&] {
		if(!user || !user->cid) {
			return;
		}

		auto u = ClientManager::getInstance()->findUser(CID(safeStr(user->cid)));
		if(!u) {
			return;
		}

		// Only writes into a conversation the user already has open -- a local line has
		// nowhere to go otherwise, and silently spawning a PM window from a plugin's echo
		// would be its own surprise. sendPrivateMessage remains the way to actually start one.
		auto chat = PrivateChatManager::getInstance()->getChat(u);
		if(!chat) {
			return;
		}

		// Same mapping as sendLocalMessage: SYSTEM keeps the system format, STATUS is a
		// low-prominence status line, CLIENT is a normal line.
		auto msgType = (type == MSG_SYSTEM) ? LogMessage::Type::SYSTEM : LogMessage::Type::SERVER;
		auto sev = (type == MSG_STATUS) ? LogMessage::SEV_VERBOSE : LogMessage::SEV_INFO;
		chat->statusMessage(safeStr(msg), sev, msgType);
	});
}

HubDataPtr PluginApiImpl::copyData(const HubDataPtr hub) {
	return pluginGuard("hub copy", [&]() -> HubDataPtr {
		if(!hub) {
			return NULL;
		}

		HubDataPtr copy = (HubDataPtr)malloc(sizeof(HubData));
		if(!copy) {
			return NULL;
		}
		memcpy(copy, hub, sizeof(HubData));

		copy->url = dupPluginStr(hub->url);
		copy->ip = dupPluginStr(hub->ip);

		if(!copy->url || !copy->ip) {
			free((char*)copy->url);
			free((char*)copy->ip);
			free(copy);
			return NULL;
		}

		copy->isManaged = False;
		return copy;
	});
}

void PluginApiImpl::releaseData(HubDataPtr hub) {
	return pluginGuard("hub release", [&] {
		if(!hub) {
			return;
		}

		if(hub->isManaged) {
			pluginApiLog("Plugin trying to free a managed object !");
			return;
		}

		free((char*)hub->url);
		free((char*)hub->ip);

		free(hub);
	});
}

UserDataPtr PluginApiImpl::findUser(const char* cid, const char* hubUrl) {
	return pluginGuard("find_user", [&]() -> UserDataPtr {
		if(!cid) {
			return NULL;
		}

		auto ou = ClientManager::getInstance()->findOnlineUser(CID(safeStr(cid)), safeStr(hubUrl));
		if(!ou) return NULL;
		return ou->copyDetachedPluginObject();
	});
}

UserDataPtr PluginApiImpl::copyData(const UserDataPtr user) {
	return pluginGuard("user copy", [&]() -> UserDataPtr {
		if(!user) {
			return NULL;
		}

		UserDataPtr copy = (UserDataPtr)malloc(sizeof(UserData));
		if(!copy) {
			return NULL;
		}
		memcpy(copy, user, sizeof(UserData));

		copy->nick = dupPluginStr(user->nick);
		copy->hubHint = dupPluginStr(user->hubHint);
		copy->cid = dupPluginStr(user->cid);

		if(!copy->nick || !copy->hubHint || !copy->cid) {
			free((char*)copy->nick);
			free((char*)copy->hubHint);
			free((char*)copy->cid);
			free(copy);
			return NULL;
		}

		copy->isManaged = False;
		return copy;
	});
}

void PluginApiImpl::releaseData(UserDataPtr user) {
	return pluginGuard("user release", [&] {
		if(!user) {
			return;
		}

		if(user->isManaged) {
			pluginApiLog("Plugin trying to free a managed object !");
			return;
		}

		free((char*)user->nick);
		free((char*)user->hubHint);
		free((char*)user->cid);

		free(user);
	});
}

/* Functions for DataAccess */

// Drives an HttpConnection directly so HOOK_..._STREAM can fire per received chunk
// (like DC++), and success/failure is distinguished by Complete vs Failed rather than
// by whether the body is empty. Self-deleting: the HttpConnection is created unique and
// self-destructs after Complete/Failed; this listener removes itself and deletes itself then.
class PluginHttpDownloader : private HttpConnectionListener {
public:
	PluginHttpDownloader(const string& aUri, const string& aLocalPath) : url(aUri), localPath(aLocalPath) {
		// Default HttpOptions means allowUntrusted=true and no body cap. This is the HTTP
		// surface a THIRD PARTY controls, so an on-path attacker could substitute the
		// response of any https fetch a plugin makes -- which the plugin then typically
		// feeds straight back into whatever it is updating -- and a hostile server could
		// stream an unbounded body into `body`. The plugin catalogue already sets both
		// (with a comment that anything ending up executed needs a validated chain); that
		// hardening was never carried over here.
		HttpOptions options;
		options.setAllowUntrusted(false);
		options.setMaxBodySize(64 * 1024 * 1024);

		conn = new HttpConnection(true, options);
		conn->addListener(this);
		conn->downloadFile(aUri);
	}

private:
	HttpConnection* conn;
	string url;
	string localPath;
	string body;

	void fireStream(const uint8_t* data, size_t len) {
		DataArray arr = { data, static_cast<uint64_t>(len) };
		PluginManager::getInstance()->runHook(HOOK_DATAACESSOR_HTTP_RESOURCE_STREAM,
			const_cast<char*>(url.c_str()), &arr);
	}

	void finish(bool success) {
		auto pm = PluginManager::getInstance();
		if(success) {
			if(!localPath.empty()) {
				try {
					File f(localPath, File::WRITE, File::CREATE | File::TRUNCATE);
					f.write(body);
				} catch(const Exception& e) {
					pluginApiLog(e.getError());
				}
			}
			pm->runHook(HOOK_DATAACESSOR_HTTP_RESOURCE_NOTIFICATION, const_cast<char*>(url.c_str()));
		} else {
			pm->runHook(HOOK_DATAACESSOR_HTTP_RESOURCE_NOTIFICATION_FAILED, const_cast<char*>(url.c_str()));
		}
		// The unique HttpConnection self-deletes after firing; just drop our listener.
		conn->removeListener(this);
		delete this;
	}

	void on(HttpConnectionListener::Data, HttpConnection*, const uint8_t* buf, size_t len) noexcept override {
		body.append(reinterpret_cast<const char*>(buf), len);
		fireStream(buf, len);
	}
	void on(HttpConnectionListener::Complete, HttpConnection*, const string&) noexcept override {
		finish(true);
	}
	void on(HttpConnectionListener::Failed, HttpConnection*, const string& status) noexcept override {
		pluginApiLog("HTTP resource download failed: " + status);
		finish(false);
	}
};

void PluginApiImpl::getHTTPResource(const char* uri, const char* localPath) {
	return pluginGuard("get_http_resource", [&] {
		if(!uri) {
			return;
		}

		try {
			new PluginHttpDownloader(safeStr(uri), safeStr(localPath));
		} catch(const Exception& e) {
			pluginApiLog(e.getError());
		}
	});
}

DataArrayPtr PluginApiImpl::copyData(const DataArrayPtr val)
{
	return pluginGuard("data copy", [&]() -> DataArrayPtr {
		// `size` is whatever the plugin put in the struct: on a 32-bit host it need not even
		// fit in size_t, and on any host a bogus value pairs an enormous length with a small
		// (or NULL) buffer. Refuse anything that cannot be a real payload rather than
		// memcpy-ing from it.
		if(!val || !val->pData || val->size == 0) {
			return NULL;
		}
		if constexpr (sizeof(size_t) < sizeof(uint64_t)) {
			if(val->size > static_cast<uint64_t>(std::numeric_limits<size_t>::max())) {
				return NULL;
			}
		}

		DataArrayPtr copy = (DataArrayPtr)malloc(sizeof(DataArray));
		if(!copy) {
			return NULL;
		}
		memcpy(copy, val, sizeof(DataArray));

		// The payload is arbitrary binary (HTTP body) and may contain embedded NULs, so
		// copy exactly val->size bytes rather than strlen()-ing a possibly-non-textual buffer.
		void* pData = malloc(static_cast<size_t>(val->size));
		if(!pData) {
			free(copy);
			return NULL;
		}
		memcpy(pData, val->pData, static_cast<size_t>(val->size));
		copy->pData = pData;

		return copy;
	});
}

void PluginApiImpl::releaseData(DataArrayPtr val)
{
	return pluginGuard("data release", [&] {
		if(!val) {
			return;
		}

		free(const_cast<void*>(val->pData));

		free(val);
	});
}

} // namespace dcpp
