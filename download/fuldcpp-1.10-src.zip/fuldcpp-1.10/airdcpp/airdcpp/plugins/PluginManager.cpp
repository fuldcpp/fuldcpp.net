/*
 * Copyright (C) 2001-2025 Jacek Sieka, arnetheduck on gmail point com
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#include "stdinc.h"
#include <airdcpp/plugins/PluginManager.h>

#include <airdcpp/core/classes/Exception.h>
#include <airdcpp/core/classes/ScopedFunctor.h>
#include <airdcpp/core/io/File.h>
#include <airdcpp/core/io/compress/ZipFile.h>
#include <airdcpp/core/io/xml/SimpleXML.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/core/version.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/hub/Client.h>
#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/plugins/PluginGuard.h>
#include <airdcpp/queue/QueueItem.h>
#include <airdcpp/queue/QueueManager.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/user/OnlineUser.h>
#include <airdcpp/util/AppUtil.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/SystemUtil.h>
#include <airdcpp/util/Util.h>
#include <airdcpp/util/ValueGenerator.h>
#include <airdcpp/util/text/StringTokenizer.h>
#include <airdcpp/util/text/Text.h>

#include <utility>

#include <boost/range/adaptor/reversed.hpp>

#ifdef _WIN32
# define PLUGIN_EXT "*.dll"

# define LOAD_LIBRARY(filename) ::LoadLibrary(Text::toT(filename).c_str())
# define FREE_LIBRARY(lib) ::FreeLibrary(lib)
# define GET_ADDRESS(lib, name) ::GetProcAddress(lib, name)
# define GET_ERROR() SystemUtil::translateError(GetLastError())
#else
# include "dlfcn.h"
# define PLUGIN_EXT "*.so"

# define LOAD_LIBRARY(filename) ::dlopen(filename.c_str(), RTLD_LAZY | RTLD_GLOBAL)
# define FREE_LIBRARY(lib) ::dlclose(lib)
# define GET_ADDRESS(lib, name) ::dlsym(lib, name)
# define GET_ERROR() ::dlerror()
#endif

namespace dcpp {

using std::make_unique;
using std::swap;

static const string PLUGIN_LOG_LABEL = "Plugins";

static void pluginLog(const string& msg, LogMessage::Severity severity = LogMessage::SEV_INFO) noexcept {
	LogManager::getInstance()->message(msg, severity, PLUGIN_LOG_LABEL);
}

// Sink for PluginGuard.h, declared there so that the WTL tree can guard its own DCUI
// callbacks without pulling in LogManager. Contained faults are errors, not info: they
// always mean a plugin is misbehaving, and the user needs to be able to tell which.
void pluginGuardLog(const std::string& aMessage) noexcept {
	pluginLog(aMessage, LogMessage::SEV_ERROR);
}

#ifdef _WIN32

// C++ throw codes, by runtime. A catch(...) only ever recognises its own.
static const unsigned long EXCEPTION_MSVC_CPP = 0xE06D7363;	// 'msc' | 0xE0000000
static const unsigned long EXCEPTION_GCC_CPP  = 0x20474343;	// 'GCC '

// See the long comment in PluginGuard.h. Contain foreign C++ exceptions; let real faults
// (AV, stack overflow, ...) through to the crash reporter so they still produce a dump.
static int pluginGuardSehFilter(unsigned long aCode) noexcept {
	return (aCode == EXCEPTION_GCC_CPP || aCode == EXCEPTION_MSVC_CPP)
		? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH;
}

static void pluginGuardReportSeh(const char* aName, unsigned long aCode) noexcept {
	try {
		char code[16];
		snprintf(code, sizeof(code), "0x%08lX", aCode);
		pluginLog("A plugin call failed and was contained (" + string(aName ? aName : "?") +
			"): foreign C++ exception " + code +
			" -- the plugin's own destructors were skipped", LogMessage::SEV_ERROR);
	} catch (...) {
		// The report is best-effort; never let it turn a contained fault into a real one.
	}
}

// Must stay free of locals needing C++ unwinding (MSVC C2712) -- hence the function-pointer
// thunk rather than a std::function or a lambda with captures.
void pluginGuardRunProtected(PluginGuardThunk aThunk, void* aState, const char* aName) noexcept {
	unsigned long code = 0;
	__try {
		aThunk(aState);
	} __except (pluginGuardSehFilter(code = GetExceptionCode())) {
		pluginGuardReportSeh(aName, code);
	}
}

// Nothing a plugin passes across the ABI should be anywhere near this long; the cap only
// exists so that a pointer into a large mapped region cannot make the probe run away.
static const size_t PLUGIN_STR_MAX = 1024 * 1024;

// Bounded, read-only walk. Returns false if the pointer is not readable -- the case a NULL
// check cannot catch and the one that produced the 16:41 crash bundle.
static bool pluginProbeStr(const char* aStr, size_t& len_) noexcept {
	__try {
		size_t n = 0;
		while(n < PLUGIN_STR_MAX && aStr[n] != '\0') {
			++n;
		}
		len_ = n;
		return true;
	} __except(GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
		return false;
	}
}

string safeStr(const char* aStr) noexcept {
	if(!aStr) {
		return string();
	}

	size_t len = 0;
	if(!pluginProbeStr(aStr, len)) {
		pluginLog("A plugin passed an unreadable string across the API boundary; it was ignored", LogMessage::SEV_ERROR);
		return string();
	}

	try {
		return string(aStr, len);
	} catch(...) {
		return string();
	}
}

#else

string safeStr(const char* aStr) noexcept {
	try {
		return aStr ? string(aStr) : string();
	} catch(...) {
		return string();
	}
}

void pluginGuardRunProtected(PluginGuardThunk aThunk, void* aState, const char*) noexcept {
	// No SEH outside Windows; the C++ catch inside the thunk is the whole guard. Mixing
	// runtimes in one process is a Windows-specific hazard in the first place.
	aThunk(aState);
}

#endif

PluginManager::PluginManager() : dcCore(), shutdown(false), secNum(ValueGenerator::rand()) {
}

PluginManager::~PluginManager() {
}

string Plugin::getVersionString() const noexcept {
	return versionStr.empty() ? Util::toString(version) : versionStr;
}

string DcextInfo::getVersionString() const noexcept {
	return versionStr.empty() ? Util::toString(version) : versionStr;
}

int PluginManager::compareVersions(const string& aLeft, const string& aRight) noexcept {
	auto split = [](const string& aVersion) {
		vector<int> ret;
		// Bind the tokenizer to a named local: getTokens() returns a reference into it, so
		// iterating it inline over a temporary walks a destroyed vector.
		StringTokenizer<string> st(aVersion, '.');
		for(auto& token: st.getTokens()) {
			ret.push_back(Util::toInt(token));
		}
		return ret;
	};

	const auto left = split(aLeft);
	const auto right = split(aRight);

	// Missing trailing components count as zero, so "2.4" and "2.4.0" compare equal
	for(size_t i = 0; i < max(left.size(), right.size()); ++i) {
		const auto l = i < left.size() ? left[i] : 0;
		const auto r = i < right.size() ? right[i] : 0;
		if(l != r) {
			return l < r ? -1 : 1;
		}
	}

	return 0;
}

DcextInfo PluginManager::extract(const string& path, bool aAllowReinstall) {
	const auto dir = AppUtil::getPath(AppUtil::PATH_TEMP) + "dcext" PATH_SEPARATOR_STR;
	const auto info_path = dir + "info.xml";
	File::deleteFile(info_path);

	{
		File::ensureDirectory(dir);

		ZipFile zip;
		zip.Open(path);
		if(zip.GoToFirstFile()) {
			do {
				zip.OpenCurrentFile();
				zip.ReadCurrentFile(dir);
				zip.CloseCurrentFile();
			} while(zip.GoToNextFile());
		}
		zip.Close();
	}

	SimpleXML xml;
	xml.fromXML(File(info_path, File::READ, File::OPEN).read());

	DcextInfo info { };

	if(xml.findChild("dcext")) {
		xml.stepIn();

		auto parse = [&xml](string tag, string& out) {
			xml.resetCurrentChild();
			if(xml.findChild(tag)) {
				out = xml.getChildData();
			}
		};

		auto checkPlatform = [&xml](bool emptyAllowed) {
			auto platform = xml.getChildAttrib("Platform");
			if(emptyAllowed && platform.empty()) {
				return true;
			}
#if defined(_WIN32) && defined(_WIN64)
			return platform == "pe-x64";
#elif defined(_WIN32)
			return platform == "pe-x86";
#elif defined(__x86_64__)
			return platform == "elf-x64";
#elif defined(__i386__)
			return platform == "elf-x86";
#else
#error Unknown platform
#endif
		};

		string version;
		parse("ApiVersion", version);
		if(Util::toInt(version) != DCAPI_CORE_VER) {
			throw Exception(PathUtil::getFileName(path) + " is not compatible with " + APPNAME);
		}

		parse("UUID", info.uuid);
		parse("Name", info.name);
		version.clear(); parse("Version", version);
		info.version = Util::toDouble(version);
		info.versionStr = version;
		parse("Author", info.author);
		parse("Description", info.description);
		parse("Website", info.website);

		xml.resetCurrentChild();
		while(xml.findChild("Plugin")) {
			if(checkPlatform(false)) {
				info.plugin = xml.getChildData();
			}
		}

		xml.resetCurrentChild();
		if(xml.findChild("Files")) {
			xml.stepIn();

			while(xml.findChild("File")) {
				if(checkPlatform(true)) {
					info.files.push_back(xml.getChildData());
				}
			}

			xml.stepOut();
		}

		xml.stepOut();
	}

	if(info.uuid.empty() || info.name.empty() || info.version == 0) {
		throw Exception(PathUtil::getFileName(path) + " is not a valid plugin");
	}
	if(info.plugin.empty()) {
		throw Exception(PathUtil::getFileName(path) + " is not compatible with " + APPNAME);
	}

	{
		Lock l(cs);

		auto dupe = findPlugin(info.uuid);
		if(dupe) {
			const auto cmp = compareVersions(dupe->getVersionString(), info.getVersionString());
			if(cmp < 0 || (cmp == 0 && aAllowReinstall)) {
				info.updating = true;
			} else {
				throw Exception(dupe->name + " is already installed");
			}
		}
	}

	return info;
}

void PluginManager::install(const DcextInfo& info) {
	{
		Lock l(cs);

		auto dupe = findPlugin(info.uuid);
		if(dupe) {
			// extract() already decided whether this is an update / reinstall; re-deriving it
			// here would throw away its aAllowReinstall verdict.
			if(!info.updating) {
				throw Exception(dupe->name + " is already installed");
			}

			// disable when updating or the file copy will fail...
			if(dupe->handle) {
				disable(*dupe, false);
			}
		}
	}

	const auto source = AppUtil::getPath(AppUtil::PATH_TEMP) + "dcext" PATH_SEPARATOR_STR;
	const auto target = getInstallPath(info.uuid);
	const auto lib = target + PathUtil::getFileName(info.plugin);

	// The manifest's plugin path is validated the same way the file entries below are, and for the
	// same reason: it comes from the manifest rather than from the archive, so ZipFile's zip-slip
	// guard -- which vets entry names during extraction -- never saw it. The DESTINATION was already
	// safe because it goes through getFileName(), but the SOURCE was used verbatim, so a plugin path
	// of "..\..\something" moved a file from anywhere the user can read into the plugin directory.
	// A rename out of the extraction directory is not a copy: the original is gone.
	{
		const auto pluginIsAbsolute = info.plugin.find(':') != string::npos
			|| (!info.plugin.empty() && (info.plugin[0] == '\\' || info.plugin[0] == '/'));

		const auto pluginSource = source + info.plugin;
		if (info.plugin.empty() || pluginIsAbsolute || info.plugin.find("..") != string::npos
			|| !PathUtil::isSubLocal(pluginSource, source)) {
			throw Exception("Unsafe plugin path in the manifest: " + info.plugin);
		}
	}

	File::ensureDirectory(lib);
	File::renameFile(source + info.plugin, lib);

	for(auto& file: info.files) {
		// Each entry comes from the manifest, a separate channel from the archive itself --
		// so ZipFile's zip-slip guard (which vets ENTRY NAMES during extraction) never saw
		// these. An entry of "..\..\something" gave a second arbitrary-write primitive
		// alongside the UUID one. Require a plain relative path that stays under the
		// install directory.
		// Absolute paths are rejected by looking for a drive spec or a leading separator;
		// PathUtil has no isAbsolutePath helper.
		const auto isAbsolute = file.find(':') != string::npos
			|| file[0] == '\\' || file[0] == '/';

		const auto destFile = target + file;
		if(file.empty() || isAbsolute || file.find("..") != string::npos
			|| !PathUtil::isSubLocal(destFile, target)) {
			pluginLog("Skipping unsafe file entry in " + info.name + ": " + file, LogMessage::SEV_WARNING);
			continue;
		}

		File::ensureDirectory(destFile);
		File::renameFile(source + file, destFile);
	}

	addPlugin(lib, info.versionStr, info.updating);
}

void PluginManager::loadPlugins(function<void (const string&)> f) {
	TimerManager::getInstance()->addListener(this);
	ClientManager::getInstance()->addListener(this);
	QueueManager::getInstance()->addListener(this);
	SettingsManager::getInstance()->addListener(this);

	loadSettings();

	for(auto& plugin: plugins) {
		if(!plugin.dcMain) { continue; } // a little trick to avoid an additonal "bool enabled"
		if(f) { f(plugin.name); }
		// One bad plugin must not abort the loading of the rest, and "bad" is not limited to
		// dcpp::Exception -- enable() runs plugin code, which can raise anything at all.
		try { enable(plugin, false, false); }
		catch(const Exception& e) { pluginLog(e.getError(), LogMessage::SEV_ERROR); }
		catch(const std::exception& e) { pluginLog("Error loading " + plugin.name + ": " + e.what(), LogMessage::SEV_ERROR); }
		catch(...) { pluginLog("Error loading " + plugin.name, LogMessage::SEV_ERROR); }
	}
}

void PluginManager::unloadPlugins() {
	TimerManager::getInstance()->removeListener(this);
	ClientManager::getInstance()->removeListener(this);
	QueueManager::getInstance()->removeListener(this);
	SettingsManager::getInstance()->removeListener(this);

	// Deliver any queued lifecycle hooks (hub/queue events marshalled to the timer thread)
	// before we stop, so the final batch isn't dropped at shutdown (DC++ fires them inline).
	runAsyncTasks();

	Lock l(cs);
	shutdown = true;

	saveSettings();

	// NOTE (inherited from DC++): `shutdown` blocks NEW hook invocations, but a hook
	// already past that check on a network/timer thread keeps running plugin code while
	// FREE_LIBRARY unmaps the DLL below (removeListener does not join in-flight callbacks).
	// This runs at process teardown, so the window is small; a fuller fix would quiesce
	// hook execution before unloading.

	// Off we go...
	for(auto& plugin: plugins | boost::adaptors::reversed) {
		if(plugin.handle) {
			disable(plugin, false);
		}
	}
	plugins.clear();

	// Really unload plugins that have been flagged inactive (ON_UNLOAD returns False)
	for(auto& i: inactive)
		FREE_LIBRARY(i);

	// Destroy hooks that may have not been correctly freed
	hooks.clear();
}

void PluginManager::addPlugin(const string& path, const string& aVersionStr, bool aAllowReinstall) {
	Lock l(cs);

	Plugin plugin { };
	plugin.name = PathUtil::getFileName(path);
	plugin.path = path;
	// The library only reports a double; the dcext manifest is the sole source of the exact version
	plugin.versionStr = aVersionStr;

	enable(plugin, true, true, aAllowReinstall);
}

bool PluginManager::configPlugin(const string& guid, dcptr_t data) {
	Lock l(cs);
	auto p = findPlugin(guid);
	if(p && p->handle) {
		return pluginGuard("ON_CONFIGURE", [&] { return p->dcMain(ON_CONFIGURE, &dcCore, data); }) != False;
	}
	return false;
}

void PluginManager::enablePlugin(const string& guid) {
	Lock l(cs);
	auto p = findPlugin(guid);
	if(p && !p->handle) {
		enable(*p, false, true);
	}
}

void PluginManager::disablePlugin(const string& guid) {
	Lock l(cs);
	auto p = findPlugin(guid);
	if(p && p->handle) {
		disable(*p, false);
	}
}

void PluginManager::movePlugin(const string& guid, int delta) {
	Lock l(cs);
	auto i = findPluginIter(guid);
	if(i != plugins.end()) {
		// Guard against an out-of-range target (the UI clamps, but this is a public API).
		// Compare INDICES: forming "i + delta" first is itself undefined behaviour when it
		// lands outside the vector, and MSVC's debug iterators abort on it before the
		// range test below ever runs.
		auto idx = i - plugins.begin();
		auto target = idx + delta;
		if(target >= 0 && target < static_cast<decltype(idx)>(plugins.size())) {
			swap(*i, *(plugins.begin() + target));
		}
	}
}

void PluginManager::removePlugin(const string& guid) {
	Lock l(cs);
	auto i = findPluginIter(guid);
	if(i == plugins.end()) {
		return;
	}

	if(i->handle) {
		disable(*i, true);
	}

	// Only ever delete files we put there ourselves. A plain dll added through addPlugin()
	// keeps the user's own path and must be left alone.
	const auto installPath = getInstallPath(guid);

	// Belt and braces before a RECURSIVE delete. getInstallPath() now sanitises the uuid,
	// but isSubLocal() is a lexical case-insensitive prefix test with no ".." handling --
	// and i->path necessarily starts with that prefix because install() built it that way,
	// so the check could never reject a traversing path on its own. Require the target to
	// be a real child of the Plugins root, and never the root itself.
	const auto pluginsRoot = getPluginsRoot();
	const auto owned = !guid.empty()
		&& installPath.length() > pluginsRoot.length()
		&& PathUtil::isSubLocal(installPath, pluginsRoot)
		&& PathUtil::isSubLocal(i->path, installPath);

	plugins.erase(i);

	if(owned) {
		try {
			File::removeDirectoryForced(installPath);
		} catch(const FileException& e) {
			// The library can still be mapped when the plugin refused a runtime unload
			pluginLog("Failed to remove the plugin directory " + installPath + ": " + e.getError());
		}
	}
}

bool PluginManager::isLoaded(const string& guid) const {
	Lock l(cs);
	auto p = findPlugin(guid);
	return p ? bool(p->handle) : false;
}

StringList PluginManager::getPluginList() const {
	Lock l(cs);
	StringList ret(plugins.size());
	std::transform(plugins.begin(), plugins.end(), ret.begin(), [](const Plugin& p) { return p.guid; });
	return ret;
};

Plugin PluginManager::getPlugin(const string& guid) const {
	Lock l(cs);
	auto p = findPlugin(guid);
	return p ? *p : Plugin();
}

// Functions that call the plugin
bool PluginManager::onUDP(bool out, const string& ip, const string& port, const string& data) {
	UDPData udp = { ip.c_str(), static_cast<uint16_t>(Util::toUInt(port)) };
	return runHook(out ? HOOK_NETWORK_UDP_OUT : HOOK_NETWORK_UDP_IN, &udp,
		reinterpret_cast<dcptr_t>(const_cast<char*>(data.c_str())));
}

bool PluginManager::onChatTags(Tagger& tagger, OnlineUser* from) {
	TagData data = { reinterpret_cast<dcptr_t>(&tagger), True };
	return runHook(HOOK_UI_CHAT_TAGS, from, &data);
}

bool PluginManager::onChatDisplay(string& htmlMessage, OnlineUser* from) {
	StringData data = { htmlMessage.c_str(), nullptr };
	bool handled = runHook(HOOK_UI_CHAT_DISPLAY, from, &data);

	// StringData::out is documented as "take care to free!" -- the plugin allocates it and
	// the HOST owns it from here. This used to copy the string and return, leaking the
	// buffer once per rewritten chat line, for the whole session. Freed on every path,
	// including when the hook set `out` but returned unhandled.
	ScopedFunctor([&data] {
		if (data.out) {
			free(data.out);
			data.out = nullptr;
		}
	});

	if(handled && data.out) {
		htmlMessage = data.out;
		return true;
	}
	return false;
}

bool PluginManager::onChatCommand(Client* client, const string& line) {
	string cmd, param;
	auto si = line.find(' ');
	if(si != string::npos) {
		param = line.substr(si + 1);
		cmd = line.substr(1, si - 1);
	} else {
		cmd = line.substr(1);
	}

	CommandData data = { cmd.c_str(), param.c_str() };
	return runHook(HOOK_UI_CHAT_COMMAND, client, &data);
}

bool PluginManager::onChatCommandPM(const HintedUser& user, const string& line) {
	bool res = false;
	// The shared_ptr keeps the entity alive for the duration of the hook
	auto ou = ClientManager::getInstance()->findOnlineUser(user);

	if(ou) {
		string cmd, param;
		auto si = line.find(' ');
		if(si != string::npos) {
			param = line.substr(si + 1);
			cmd = line.substr(1, si - 1);
		} else {
			cmd = line.substr(1);
		}

		CommandData data = { cmd.c_str(), param.c_str() };
		res = runHook(HOOK_UI_CHAT_COMMAND_PM, ou.get(), &data);
	}

	return res;
}

// Plugin interface registry
//
// All three of these take cs. They used to touch the std::map with no synchronisation at
// all: query_interface is callable by a plugin from ANY thread (e.g. from a hook proc
// running on a hub socket thread) while a second plugin is being enabled from the settings
// UI thread and registers in its ON_LOAD -- and a concurrent insert/find on std::map is
// undefined behaviour, since a rebalance can hand the reader a node mid-relink.
// cs is recursive, so nesting under enable()/disable() (which already hold it) is fine.
intfHandle PluginManager::registerInterface(const string& guid, dcptr_t funcs) {
	Lock l(cs);

	if(interfaces.find(guid) == interfaces.end())
		interfaces.insert(make_pair(guid, funcs));
	// Following ensures that only the original provider may remove this
	return reinterpret_cast<intfHandle>((uintptr_t)funcs ^ secNum);
}

dcptr_t PluginManager::queryInterface(const string& guid) {
	Lock l(cs);

	auto i = interfaces.find(guid);
	if(i != interfaces.end()) {
		return i->second;
	} else return NULL;
}

bool PluginManager::releaseInterface(intfHandle hInterface) {
	Lock l(cs);

	// Following ensures that only the original provider may remove this
	dcptr_t funcs = reinterpret_cast<dcptr_t>((uintptr_t)hInterface ^ secNum);
	for(auto i = interfaces.begin(); i != interfaces.end(); ++i) {
		if(i->second == funcs) {
			interfaces.erase(i);
			return true;
		}
	}
	return false;
}

// Plugin Hook system
PluginHook* PluginManager::createHook(const string& guid, DCHOOK defProc) {
	Lock l(csHook);

	auto i = hooks.find(guid);
	if(i != hooks.end()) return NULL;

	auto hook = make_unique<PluginHook>();
	auto pHook = hook.get();
	hook->guid = guid;
	hook->defProc = defProc;
	hooks[guid] = std::move(hook);
	return pHook;
}

bool PluginManager::destroyHook(PluginHook* hook) {
	Lock l(csHook);

	auto i = hooks.find(hook->guid);
	if(i != hooks.end()) {
		hooks.erase(i);
		return true;
	}
	return false;
}

HookSubscriber* PluginManager::bindHook(const string& guid, DCHOOK hookProc, void* pCommon) {
	Lock l(csHook);

	auto i = hooks.find(guid);
	if(i == hooks.end()) {
		// Say so. Several hook GUIDs are declared in PluginDefs.h but not implemented by this port
		// (see the deviation list at the top of PluginApiImpl.cpp), and a plugin binding one got a
		// bare NULL with nothing in the log -- so the feature simply never worked and neither the
		// user nor the plugin author had anything to go on.
		pluginLog("A plugin tried to bind the unsupported hook \"" + guid + "\"; it will never fire", LogMessage::SEV_WARNING);
		return NULL;
	}
	auto& hook = i->second;
	{
		Lock l(hook->cs);
		auto subscription = make_unique<HookSubscriber>();
		auto pSub = subscription.get();
		subscription->hookProc = hookProc;
		subscription->common = pCommon;
		subscription->owner = hook->guid;
		hook->subscribers.push_back(std::move(subscription));

		return pSub;
	}
}

bool PluginManager::runHook(PluginHook* hook, dcptr_t pObject, dcptr_t pData) {
	dcassert(hook);

	// Reachable from PluginApiImpl::runHook with a plugin-supplied handle, where dcassert
	// is compiled out.
	if(!hook) {
		return false;
	}

	// Using shared lock (csHook) might be a tad safer, but it is also slower and I prefer not to teach plugins to rely on the effect it creates
	//
	// Iterate a SNAPSHOT of the subscriber procedures rather than the live vector. A hook
	// procedure is free to call release_hook/destroy_hook on its own hook -- a one-shot
	// "fire once then unsubscribe" handler is an ordinary pattern -- and on Windows
	// CriticalSection is std::recursive_mutex, so that re-entry SUCCEEDS rather than
	// deadlocking: the erase then reallocated the vector this loop was walking, and
	// destroy_hook additionally freed the PluginHook (and this very lock) mid-iteration.
	vector<pair<DCHOOK, void*>> handlers;
	bool hadSubscribers = false;
	{
		Lock l(hook->cs);
		hadSubscribers = !hook->subscribers.empty();
		handlers.reserve(hook->subscribers.size());
		for (const auto& sub : hook->subscribers) {
			handlers.emplace_back(sub->hookProc, sub->common);
		}
	}

	// Each subscriber is guarded SEPARATELY, on purpose: a plugin that throws must lose
	// only its own callback, not silence every other subscriber on the hook. The guard is
	// mandatory rather than defensive -- most callers of runHook are noexcept marshalling
	// paths (the TimerManager/QueueManager/ClientManager listener overrides below) or a
	// Win32 window procedure, so an escaping exception is an unconditional terminate. That
	// is how the 2026-08-07 fastfail happened.
	Bool bBreak = False;
	Bool bRes = False;
	for(const auto& [hookProc, common]: handlers) {
		auto fired = pluginGuard("hook subscriber", [&]() -> Bool {
			return hookProc(pObject, pData, common, &bBreak);
		});

		if(fired)
			bRes = True;
		if(bBreak) return (bRes != False);
	}

	// Call default hook procedure for all unused hooks
	if(hook->defProc && !hadSubscribers) {
		auto fired = pluginGuard("hook default procedure", [&]() -> Bool {
			return hook->defProc(pObject, pData, NULL, &bBreak);
		});

		if(fired)
			bRes = True;
	}

	return (bRes != False);
}

size_t PluginManager::releaseHook(HookSubscriber* subscription) {
	Lock l(csHook);

	if(subscription == NULL)
		return 0;

	auto i = hooks.find(subscription->owner);
	if(i == hooks.end()) {
		return 0;
	}
	auto& hook = i->second;
	{
		Lock l(hook->cs);
		hook->subscribers.erase(std::remove_if(hook->subscribers.begin(), hook->subscribers.end(),
			[subscription](const unique_ptr<HookSubscriber>& sub) { return sub.get() == subscription; }), hook->subscribers.end());

		return hook->subscribers.size();
	}
}

// Plugin configuration
void PluginManager::setPluginSetting(const string& guid, const string& setting, const string& value) {
	Lock l(cs);
	auto p = findPlugin(guid);
	if(p) {
		p->settings[setting] = value;
	}
}

const string& PluginManager::getPluginSetting(const string& guid, const string& setting) {
	Lock l(cs);

	auto p = findPlugin(guid);
	if(p) {
		auto i = p->settings.find(setting);
		if(i != p->settings.end()) {
			return i->second;
		}
	}
	return Util::emptyString;
}

void PluginManager::removePluginSetting(const string& guid, const string& setting) {
	Lock l(cs);

	auto p = findPlugin(guid);
	if(p) {
		auto i = p->settings.find(setting);
		if(i != p->settings.end()) {
			p->settings.erase(i);
		}
	}
}

string PluginManager::getPluginsRoot() noexcept {
	return AppUtil::getPath(AppUtil::PATH_USER_LOCAL) + "Plugins" PATH_SEPARATOR_STR;
}

string PluginManager::getInstallPath(const string& uuid) {
	// The UUID comes from the package's own info.xml, which for a manually installed
	// .dcext (drag-and-drop, Add..., or install-from-URL -- the explicitly hash-less path)
	// is entirely attacker-supplied. It used to be concatenated verbatim, so a UUID of
	// "..\..\..\..\Desktop" escaped the Plugins tree: install wrote the DLL there, and
	// Remove then handed that same traversing path to removeDirectoryForced().
	// validateFileName strips separators and other path-significant characters, so the
	// result can only ever name a direct child of the Plugins directory. Normal UUIDs
	// (hex and dashes) are unaffected, so existing installs keep their paths.
	return getPluginsRoot() + PathUtil::validateFileName(uuid) + PATH_SEPARATOR_STR;
}

void PluginManager::enable(Plugin& plugin, bool install, bool runtime, bool allowReinstall) {
	Lock l(cs);

	// The version we are bringing in: the dcext manifest when we have it, the library's double otherwise
	const auto newVersionStr = plugin.versionStr;

	dcassert(dcCore.apiVersion != 0);

	plugin.handle = LOAD_LIBRARY(plugin.path);
	if(!plugin.handle) {
		throw Exception("Error loading " + plugin.name + ": " + GET_ERROR());
	}
	bool unload = true;
	ScopedFunctor(([&plugin, &unload] { if(unload) { FREE_LIBRARY(plugin.handle); plugin.handle = nullptr; plugin.dcMain = nullptr; } }));

	auto pluginInfo = reinterpret_cast<DCMAIN (DCAPI *)(MetaDataPtr)>(GET_ADDRESS(plugin.handle, "pluginInit"));
	MetaData info { };
	plugin.dcMain = pluginInfo ? pluginGuard("pluginInit", [&] { return pluginInfo(&info); }) : nullptr;
	if(!plugin.dcMain) {
		throw Exception(plugin.name + " is not a valid plugin");
	}

	// Validate the out-parameter before using any of it. MetaData is zero-initialised, so
	// every const char* is NULL until the plugin fills it in -- and only the entry point
	// and the returned main function were ever checked. A plugin that returned a valid
	// DCMAIN but left `info` untouched (buggy, truncated, or hostile) crashed in strlen
	// via string(info.name) below, during install of a file the user had just
	// double-clicked. Report against the file name, never the plugin-supplied one.
	if(!info.name || !info.guid) {
		throw Exception(plugin.name + " is not a valid plugin (incomplete metadata)");
	}

	if(info.numDependencies > 0 && !info.dependencies) {
		throw Exception(plugin.name + " is not a valid plugin (bad dependency list)");
	}

	// Check API compatibility (this should only block on absolutely wrecking api changes, which generally should not happen)
	if(info.apiVersion != DCAPI_CORE_VER) {
		throw Exception(string(info.name) + " is not compatible with " + APPNAME);
	}

	// Check that all dependencies are loaded
	for(decltype(info.numDependencies) i = 0; i < info.numDependencies; ++i) {
		if(!info.dependencies[i] || !isLoaded(info.dependencies[i])) {
			throw Exception("Missing dependencies for " + string(info.name));
		}
	}

	auto pluginPtr = &plugin;

	// When installing, check for duplicates and possible updates
	if(install) {
		auto dupe = findPlugin(info.guid);
		if(dupe) {
			const auto incoming = newVersionStr.empty() ? Util::toString(info.version) : newVersionStr;
			const auto cmp = compareVersions(dupe->getVersionString(), incoming);

			// cmp == 0 is a reinstall / repair, which only extract() may authorise
			if(cmp < 0 || (cmp == 0 && allowReinstall)) {
				// in-place updating to keep settings etc. The entry below is pointed at the NEW
				// module, so its handle aliases the caller's copy for the rest of this function; the
				// failure path clears it before that copy is freed.

				if(cmp < 0) {
					pluginLog("Updating the " + dupe->name + " plugin from version " +
						dupe->getVersionString() + " to version " + incoming);
				} else {
					pluginLog("Reinstalling the " + dupe->name + " plugin, version " + incoming);
				}

				if(dupe->handle) {
					disable(*dupe, false);
				}
				dupe->handle = plugin.handle;
				dupe->dcMain = plugin.dcMain;
				dupe->path = plugin.path;
				dupe->versionStr = newVersionStr;
				pluginPtr = dupe;

				install = false;

			} else {
				throw Exception(string(info.name) + " is already installed");
			}

		} else {
			// add to the list before executing dcMain, to guarantee a correct state (eg for settings).
			plugins.push_back(std::move(plugin));
			pluginPtr = &plugins.back();
		}
	}

	{ // scope to change the plugin ref
		auto& plugin = *pluginPtr;

		auto state = install ? ON_INSTALL : runtime ? ON_LOAD_RUNTIME : ON_LOAD;
		auto loaded = pluginGuard("ON_LOAD", [&] { return plugin.dcMain(state, &dcCore, nullptr); });
		if(loaded == False) {

			if(install) {
				// remove from the list.
				FREE_LIBRARY(plugin.handle);
				plugins.pop_back();
				unload = false;
			} else {
				// An in-place update whose new build refused to load. The registered entry was pointed
				// at the new module a moment ago, and the guard on the way out is about to free that
				// module through the caller's copy of the same handle -- so without this the entry was
				// left aliasing memory that had been unmapped, and the next disable, remove or shutdown
				// called into it. The entry stays registered but unloaded, which the rest of this class
				// already copes with: every user of `handle` tests it first.
				plugin.handle = nullptr;
				plugin.dcMain = nullptr;
			}

			throw Exception("Error loading " + plugin.name);
		}

		unload = false;

		// Refresh the info we have on the plugin. Through safeStr, like every other plugin-supplied
		// string in this subsystem: only name and guid are validated above, so author, description
		// and web were still whatever the plugin left them -- NULL for a hand-written or truncated
		// DCAPI 8 plugin, which is std::string::operator=(nullptr) and an access violation inside
		// strlen. The catch blocks around loadPlugins handle exceptions, not an AV, so this crashed
		// the client while installing a .dcext the user had just double-clicked, then again on every
		// subsequent start once the plugin was registered.
		plugin.guid = safeStr(info.guid);
		plugin.name = safeStr(info.name);
		plugin.version = info.version;
		plugin.author = safeStr(info.author);
		plugin.description = safeStr(info.description);
		plugin.website = safeStr(info.web);
	}
}

void PluginManager::disable(Plugin& plugin, bool uninstall) {
	bool isSafe = true;
	auto unloaded = pluginGuard("ON_UNLOAD", [&] {
		return plugin.dcMain(uninstall ? ON_UNINSTALL : ON_UNLOAD, nullptr, nullptr);
	});

	// A plugin that threw on the way out is treated exactly like one that returned False:
	// it never got to clean up, so its DLL must stay mapped rather than be freed under
	// whatever callbacks it left registered.
	if(unloaded == False) {
		// Plugin performs operation critical tasks (runtime unload not possible)
		isSafe = std::find(inactive.begin(), inactive.end(), plugin.handle) != inactive.end();
		if(!isSafe) {
			inactive.push_back(plugin.handle);
		}
	}
	if(isSafe) {
		FREE_LIBRARY(plugin.handle);
		plugin.handle = nullptr;
		plugin.dcMain = nullptr;
	}
}

void PluginManager::loadSettings() noexcept {
	Lock l(cs);

	plugins.clear();

	// Loaded through the shared setting-file recovery: a corrupt file falls
	// back to the .bak copy and is quarantined. A silently swallowed failure
	// here would lose every registered plugin and their settings permanently
	// once saveSettings() overwrites the file at shutdown.
	SettingsManager::loadSettingFile(AppUtil::PATH_USER_CONFIG, "Plugins.xml", [this](SimpleXML& xml) {
		if(xml.findChild("Plugins")) {
			xml.stepIn();

			while(xml.findChild("Plugin")) {
				Plugin plugin { xml.getChildAttrib("Guid"), xml.getChildAttrib("Name"),
					Util::toDouble(xml.getChildAttrib("Version")), xml.getChildAttrib("Author"),
					xml.getChildAttrib("Description"), xml.getChildAttrib("Website"),
					xml.getChildAttrib("Path"),
					// Absent in configs written before exact versions were tracked; the
					// double stays as the fallback until the plugin is next installed.
					xml.getChildAttrib("VersionString"), nullptr,
					reinterpret_cast<DCMAIN>(xml.getBoolChildAttrib("Enabled")) };

				if(plugin.guid.empty() || plugin.path.empty()) { continue; }
				if(plugin.name.empty()) { plugin.name = PathUtil::getFileName(plugin.path); }

				xml.stepIn();
				while(xml.findChild("Setting")) {
					plugin.settings[xml.getChildAttrib("Key")] = xml.getChildAttrib("Value");
				}
				xml.stepOut();

				plugins.push_back(std::move(plugin));
			}

			xml.stepOut();
		}
	});
}

void PluginManager::saveSettings() noexcept {
	Lock l(cs);

	try {
		SimpleXML xml;
		xml.addTag("Plugins");
		xml.stepIn();

		for(auto& plugin: plugins) {
			xml.addTag("Plugin");

			xml.addChildAttrib("Guid", plugin.guid);
			xml.addChildAttrib("Name", plugin.name);
			xml.addChildAttrib("Version", plugin.version);
			xml.addChildAttrib("VersionString", plugin.versionStr);
			xml.addChildAttrib("Author", plugin.author);
			xml.addChildAttrib("Description", plugin.description);
			xml.addChildAttrib("Website", plugin.website);
			xml.addChildAttrib("Path", plugin.path);
			xml.addChildAttrib("Enabled", static_cast<bool>(plugin.handle));

			xml.stepIn();
			for(auto& i: plugin.settings) {
				xml.addTag("Setting");
				xml.addChildAttrib("Key", i.first);
				xml.addChildAttrib("Value", i.second);
			}
			xml.stepOut();
		}

		xml.stepOut();

		// Write-through temp + atomic replace with an empty-file guard
		SettingsManager::saveSettingFile(xml, AppUtil::PATH_USER_CONFIG, "Plugins.xml");
	} catch(const Exception& e) {
		dcdebug("PluginManager::saveSettings: %s\n", e.getError().c_str());
	}
}

const Plugin* PluginManager::findPlugin(const string& guid) const {
	auto it = findPluginIter(guid);
	return it != plugins.end() ? &*it : nullptr;
}

Plugin* PluginManager::findPlugin(const string& guid) {
	auto it = findPluginIter(guid);
	return it != plugins.end() ? &*it : nullptr;
}

vector<Plugin>::const_iterator PluginManager::findPluginIter(const string& guid) const {
	return std::find_if(plugins.begin(), plugins.end(), [&guid](const Plugin& p) { return p.guid == guid; });
}

vector<Plugin>::iterator PluginManager::findPluginIter(const string& guid) {
	return std::find_if(plugins.begin(), plugins.end(), [&guid](const Plugin& p) { return p.guid == guid; });
}

// Async dispatch: AirDC may fire the queue/hub listener events below while holding
// manager locks; the hooks are run from the timer thread instead so plugins can
// safely call back into the API.
void PluginManager::addAsyncTask(std::function<void()> task) noexcept {
	if(shutdown) return;
	Lock l(csAsyncTasks);
	asyncTasks.push_back(std::move(task));
}

void PluginManager::runAsyncTasks() noexcept {
	vector<std::function<void()>> tasks;
	{
		Lock l(csAsyncTasks);
		tasks.swap(asyncTasks);
	}
	for(auto& task: tasks) {
		task();
	}
}

void PluginManager::fireHubOnline(const ClientPtr& aClient) noexcept {
	{
		Lock l(csOnlineHubs);
		if(!onlineHubs.insert(aClient->getHubUrl()).second) {
			return;
		}
	}
	runHook<HubData>(HOOK_HUB_ONLINE, aClient.get());
}

void PluginManager::fireHubOffline(const string& aHubUrl) noexcept {
	{
		Lock l(csOnlineHubs);
		if(onlineHubs.erase(aHubUrl) == 0) {
			return;
		}
	}
	// Re-resolve; the hub may be gone already, in which case the hook is skipped
	// (DC++ note: HUB_OFFLINE may be missed for hubs whose Client is already destroyed)
	auto client = ClientManager::getInstance()->findClient(aHubUrl);
	if(client) {
		runHook<HubData>(HOOK_HUB_OFFLINE, client.get());
	}
}

// Listeners
void PluginManager::on(TimerManagerListener::Second, uint64_t ticks) noexcept {
	runAsyncTasks();
	runHook(HOOK_TIMER_SECOND, NULL, &ticks);
}

void PluginManager::on(ClientManagerListener::ClientConnected, const ClientPtr& aClient) noexcept {
	addAsyncTask([this, aClient] { fireHubOnline(aClient); });
}

void PluginManager::on(ClientManagerListener::ClientDisconnected, const string& aHubUrl) noexcept {
	addAsyncTask([this, aHubUrl] { fireHubOffline(aHubUrl); });
}

void PluginManager::on(ClientManagerListener::ClientRemoved, const ClientPtr& aClient) noexcept {
	// Fallback: a hub may be removed without a preceding ClientDisconnected.
	// Fire while the ClientPtr is still alive instead of re-resolving by url.
	addAsyncTask([this, aClient] {
		{
			Lock l(csOnlineHubs);
			if(onlineHubs.erase(aClient->getHubUrl()) == 0) {
				return;
			}
		}
		runHook<HubData>(HOOK_HUB_OFFLINE, aClient.get());
	});
}

void PluginManager::on(QueueManagerListener::ItemAdded, const QueueItemPtr& qi) noexcept {
	addAsyncTask([this, qi] { runHook<QueueData>(HOOK_QUEUE_ADDED, qi.get()); });
}

void PluginManager::on(QueueManagerListener::ItemRemoved, const QueueItemPtr& qi, bool /*finished*/) noexcept {
	// DC++ fires QUEUE_REMOVED for completed items too (alongside QUEUE_FINISHED), so a
	// plugin watching REMOVED as its "left the queue" signal sees completions as well.
	addAsyncTask([this, qi] { runHook<QueueData>(HOOK_QUEUE_REMOVED, qi.get()); });
}

void PluginManager::on(QueueManagerListener::ItemFinished, const QueueItemPtr& qi, const string& /*dir*/, const HintedUser& /*user*/, int64_t /*speed*/) noexcept {
	addAsyncTask([this, qi] { runHook<QueueData>(HOOK_QUEUE_FINISHED, qi.get()); });
}

void PluginManager::on(SettingsManagerListener::Save, SimpleXML& /*xml*/) noexcept {
	saveSettings();
}

} // namespace dcpp
