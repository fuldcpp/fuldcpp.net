/*
 * Copyright (C) 2001-2025 Jacek Sieka, arnetheduck on gmail point com
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef DCPLUSPLUS_DCPP_PLUGIN_ENTITY_H
#define DCPLUSPLUS_DCPP_PLUGIN_ENTITY_H

#include <list>

#include <airdcpp/core/thread/CriticalSection.h>
#include <airdcpp/plugins/PluginApiImpl.h>

namespace dcpp {

using std::list;

/*
 * Base for the host objects a plugin can be handed a view of: Client (HubData),
 * OnlineUser (UserData), QueueItem (QueueData), UserConnection (ConnectionData).
 *
 * LIFETIME CONTRACT -- the part that has bitten us:
 *
 * getPluginObject() returns a pointer to `pod`, a MEMBER of the entity, whose char* fields
 * point into psCache, a member string cache that is rebuilt on every call. So the struct a
 * hook receives is valid only for the duration of that hook call. A plugin that stashes the
 * pointer and uses it later is reading recycled memory: `isManaged` is True on these, which
 * is exactly the flag telling the plugin it does not own the object and must copy() to keep
 * it. Three crash reports on 2026-08-07 were a plugin doing precisely this, and the client
 * died in strlen on a HubData::url that had been freed out from under it.
 *
 * Two things narrow that window:
 *
 *  - Callers on the DCAPI side re-resolve by value (by hub URL, by CID, by target path)
 *    instead of dereferencing pod.object, so a stale struct produces a failed lookup rather
 *    than a call through freed memory -- provided the strings are still readable.
 *  - The cache below is double-buffered rather than cleared outright, so the strings from
 *    the PREVIOUS generation stay alive and correct until the one after that. A plugin that
 *    is one hook late reads valid data instead of a dangling pointer. Memory stays bounded
 *    at two generations; this is a safety net for plugin bugs, not a licence to keep the
 *    pointer -- two hook fires is still no time at all.
 */
template<typename PluginType>
class PluginEntity
{
public:
	PluginEntity() : pod() {
		pod.isManaged = True;
	}
	virtual ~PluginEntity() { }

	PluginType* copyPluginObject() {
		Lock l(cs);
		return PluginApiImpl::copyData(getPluginObject());
	}

	void freePluginObject(PluginType* pObject) {
		PluginApiImpl::releaseData(pObject);
	}

	/*
	 * Copy built for find_hub/find_user, which resolve an entity by value and hand the
	 * plugin an unmanaged copy to keep. Unlike copyPluginObject() this does NOT go through
	 * getPluginObject()/resetEntity(): a plugin calling find_hub on the very hub it is
	 * currently handling would otherwise re-enter this same (recursive) mutex on the hook
	 * thread and rewrite `pod` and the string cache out from under the pObject it was
	 * handed. The derived filler builds a standalone struct from live state using its own
	 * short-lived string storage; copyData dups those strings before returning, so nothing
	 * of pod is touched and the borrowed hook object stays stable.
	 */
	template<typename Filler>
	PluginType* copyPluginObjectDetached(Filler&& fill) {
		Lock l(cs);
		return fill();
	}

protected:
	// Retire the current generation of strings instead of destroying it -- see the class
	// comment. psPrev holds the previous generation and is only released here, one call
	// later, so any pointer handed out during that generation stays readable until then.
	void resetEntity() {
		psPrev.clear();
		psPrev.swap(psCache);
	}

	const char* pluginString(const string& str) {
		psCache.push_back(str);
		return psCache.back().c_str();
	}

	PluginType pod;

private:
	friend class PluginManager;

	virtual PluginType* getPluginObject() noexcept = 0;

	CriticalSection cs;
	list<string> psCache;
	list<string> psPrev;
};

} // namespace dcpp

#endif // DCPLUSPLUS_DCPP_PLUGIN_ENTITY_H
