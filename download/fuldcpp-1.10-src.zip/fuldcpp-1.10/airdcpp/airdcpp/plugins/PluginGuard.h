/*
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef DCPLUSPLUS_DCPP_PLUGIN_GUARD_H
#define DCPLUSPLUS_DCPP_PLUGIN_GUARD_H

#include <exception>
#include <string>
#include <type_traits>
#include <utility>

namespace dcpp {

/*
 * The DCAPI boundary is a C ABI shared with binaries we did not build, and in the worst
 * case did not review. Nothing may cross it in either direction except plain data:
 *
 *  - Outbound (host -> plugin): a C++ exception unwinding into a plugin frame is
 *    undefined behaviour. The plugin may be compiled by a different toolchain, against a
 *    different runtime, with /EHs- or as plain C, so it may carry no unwind data at all.
 *    In practice the process fail-fasts with STATUS_STACK_BUFFER_OVERRUN (0xC0000409).
 *
 *  - Inbound (plugin -> host): most of the host code that invokes plugin callbacks is
 *    reached from noexcept marshalling paths (the TimerManager/QueueManager/ClientManager
 *    listener overrides) or from a Win32 window procedure. An exception let loose there is
 *    an unconditional std::terminate -- the same 0xC0000409 class.
 *
 * Both failure modes were observed in the wild on 2026-08-07: a third-party plugin threw
 * out of a chat hook, and separately handed sendLocalMessage a HubData whose url was NULL
 * (and, in another incident, dangling). Three crash bundles, three stack hashes, one
 * missing boundary.
 *
 * pluginGuard() is that boundary. Wrap it around the body of every DCAPI entry point and
 * around every call into plugin code. The policy is deliberately "log and continue",
 * mirroring what Async<>::onSpeaker already does for deferred GUI callbacks: a misbehaving
 * plugin degrades itself, not the client.
 */

// Reporting sink. Defined in PluginManager.cpp so that both the core tree and the WTL
// tree get the same "Plugins" log routing without either having to include LogManager.
void pluginGuardLog(const std::string& aMessage) noexcept;

/*
 * catch(...) is NOT enough on its own, and the difference is not academic.
 *
 * On Windows a C++ throw is a RaiseException with a runtime-specific code, and each
 * runtime only recognises its own: MSVC uses 0xE06D7363, GCC/MinG W uses 0x20474343
 * ('GCC '). A catch(...) compiled by MSVC handles the former and is completely blind to
 * the latter -- the exception sails straight past into the unhandled-exception filter.
 *
 * That is not a hypothetical: OUR ENTIRE PLUGIN CATALOGUE IS BUILT WITH MINGW (Squiggle,
 * Protocol Analyzer, the nine ported DC++ plugins). Verified empirically with a MinGW test
 * plugin throwing from a timer hook -- the C++-only guard was on the stack and the client
 * still died. The plugin behind the 2026-08-07 reports threw 0xE06D7363, so that one
 * happens to be MSVC-ABI, but relying on that would leave every plugin we ship unguarded.
 *
 * So the guard is two layers: a C++ try/catch for same-runtime exceptions, wrapped in an
 * SEH __try that contains FOREIGN C++ exceptions specifically.
 *
 * What SEH deliberately does NOT contain: access violations, stack overflow, illegal
 * instruction and friends. Those are genuine faults, not a control-flow choice the plugin
 * author made, and swallowing one would resume on memory we know nothing about while
 * suppressing the minidump that would explain it. They keep going to the crash reporter.
 *
 * Caveat worth knowing: containing a GCC exception via SEH means GCC's personality routine
 * never runs, so destructors in the PLUGIN's frames between the throw and this boundary are
 * skipped and whatever they hold is leaked. A leak in a misbehaving plugin beats killing
 * the client.
 */
using PluginGuardThunk = void (*)(void*);
void pluginGuardRunProtected(PluginGuardThunk aThunk, void* aState, const char* aName) noexcept;

/*
 * Every string crossing the plugin C ABI is untrusted. Route every inbound const char*
 * through this before anything constructs a std::string from it.
 *
 * NULL is the easy half, and constructing a std::string from it is UB that crashes in
 * strlen -- that is how the 18:21 bundle died (RCX = 0).
 *
 * The hard half is a pointer that is neither NULL nor valid. The 16:41 bundle faulted with
 * RCX = 0xB5B9A8B8B9AEADAC: a HubData::url the plugin had held past its lifetime, pointing
 * at memory that was no longer mapped. No null check helps there, and the SEH layer in
 * pluginGuard deliberately does not swallow access violations. So this probes the string
 * with a bounded, read-only walk under SEH first, and treats an unreadable pointer as an
 * empty string. A dangling-but-mapped pointer still yields garbage -- which is fine,
 * because every DCAPI function re-resolves by value and a garbage key simply misses.
 *
 * Defined in PluginManager.cpp: the probe needs __try, which cannot live in a header
 * alongside anything requiring C++ unwinding.
 */
std::string safeStr(const char* aStr) noexcept;

namespace pluginguard_detail {
	inline void report(const char* aName, const char* aWhat) noexcept {
		// The guard runs on the failure path, so it must not be able to fail itself --
		// LogManager allocates, and the reason we are here may well be bad_alloc.
		try {
			std::string msg = "A plugin call failed and was contained (";
			msg += aName ? aName : "?";
			msg += ")";
			if (aWhat && *aWhat) {
				msg += ": ";
				msg += aWhat;
			}
			pluginGuardLog(msg);
		} catch (...) {
			// Nothing left to do; swallowing beats terminating.
		}
	}
}

/*
 * Run aFunc, containing anything it throws.
 *
 * Returns aFunc's result on success and a value-initialised result on failure -- which is
 * the DCAPI convention for "did not work" throughout the API surface: NULL for every
 * handle/pointer-returning function, False (0) for every Bool, 0 for every size_t.
 *
 * aName is a short static label used only for the log line; pass the DCAPI function name
 * ("local_message", "ON_LOAD", ...) rather than the C++ one, since that is what a plugin
 * author reading the log will recognise.
 */
template<typename F>
auto pluginGuard(const char* aName, F&& aFunc) noexcept -> std::invoke_result_t<F> {
	using Ret = std::invoke_result_t<F>;

	// The thunks below are captureless, so they decay to plain function pointers and can be
	// called from inside an SEH __try -- which must not itself hold anything needing C++
	// unwinding. All the C++ machinery lives one frame deeper, inside the thunk.
	if constexpr (std::is_void_v<Ret>) {
		struct State { F* func; const char* name; };
		State state { &aFunc, aName };

		pluginGuardRunProtected([](void* aState) {
			auto& s = *static_cast<State*>(aState);
			try {
				(*s.func)();
			} catch (const std::exception& e) {
				pluginguard_detail::report(s.name, e.what());
			} catch (...) {
				pluginguard_detail::report(s.name, nullptr);
			}
		}, &state, aName);
	} else {
		Ret ret {};
		struct State { F* func; Ret* out; const char* name; };
		State state { &aFunc, &ret, aName };

		pluginGuardRunProtected([](void* aState) {
			auto& s = *static_cast<State*>(aState);
			try {
				*s.out = (*s.func)();
			} catch (const std::exception& e) {
				pluginguard_detail::report(s.name, e.what());
			} catch (...) {
				pluginguard_detail::report(s.name, nullptr);
			}
		}, &state, aName);

		return ret;
	}
}

} // namespace dcpp

#endif // DCPLUSPLUS_DCPP_PLUGIN_GUARD_H
