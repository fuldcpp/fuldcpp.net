/*
 * Copyright (C) 2001-2025 Jacek Sieka, arnetheduck on gmail point com
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

// Port of the DC++ DCAPI v8 native plugin system (dcpp/PluginManager).
// Listener signatures and manager APIs are adapted to the AirDC++ core;
// the plugin-facing ABI (PluginDefs.h) is unchanged.

#ifndef DCPLUSPLUS_DCPP_PLUGIN_MANAGER_H
#define DCPLUSPLUS_DCPP_PLUGIN_MANAGER_H

#include <functional>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <vector>

#include <airdcpp/core/header/typedefs.h>

#include <airdcpp/core/Singleton.h>
#include <airdcpp/core/thread/CriticalSection.h>
#include <airdcpp/core/timer/TimerManagerListener.h>
#include <airdcpp/hub/ClientManagerListener.h>
#include <airdcpp/queue/QueueManagerListener.h>
#include <airdcpp/settings/SettingsManagerListener.h>

#include <airdcpp/plugins/PluginDefs.h>
#include <airdcpp/plugins/PluginEntity.h>
#include <airdcpp/plugins/Tagger.h>

#ifdef _WIN32
typedef HMODULE PluginHandle;
#else
typedef void* PluginHandle;
#endif

namespace dcpp {

using std::function;
using std::map;
using std::set;
using std::string;
using std::unique_ptr;
using std::vector;

// Represents a plugin in hook context
struct HookSubscriber {
	DCHOOK hookProc;
	void* common;
	string owner;
};

// Hookable event
struct PluginHook {
	string guid;
	DCHOOK defProc;

	vector<unique_ptr<HookSubscriber>> subscribers;
	CriticalSection cs;
};

/** Information about a registered plugin. It may or may not be loaded. */
struct Plugin {
	string guid;
	string name;
	double version;
	string author;
	string description;
	string website;
	string path;

	/// Version as authored, kept verbatim next to the double the plugin ABI hands us.
	/// The double cannot express "1.10" or "2.4.1" (it reads them as 1.1 and 2.4), so
	/// anything comparing versions must use this string when it is available.
	string versionStr;

	/// versionStr when we have it, the stringified double otherwise
	string getVersionString() const noexcept;

	PluginHandle handle; /// identifies the state (enabled / disabled) of this plugin.
	DCMAIN dcMain;

	StringMap settings;
};

/** Information about a dcext-packaged plugin that has just been extracted. */
struct DcextInfo {
	string uuid;
	string name;
	double version;
	string versionStr;
	string author;
	string description;
	string website;
	string plugin;
	StringList files;
	bool updating;

	/// versionStr when we have it, the stringified double otherwise
	string getVersionString() const noexcept;
};

class PluginManager : public Singleton<PluginManager>, private TimerManagerListener,
	private ClientManagerListener, private QueueManagerListener, private SettingsManagerListener
{
public:
	PluginManager();
	~PluginManager();

	/** Extract a dcext-packaged plugin. Throws on errors. */
	/// aAllowReinstall lets an identical version overwrite itself (repair / catalog reinstall);
	/// without it an already-installed uuid at the same version is rejected.
	DcextInfo extract(const string& path, bool aAllowReinstall = false);
	void install(const DcextInfo& info);

	void loadPlugins(function<void (const string&)> f);
	void unloadPlugins();

	/** Install a plain plugin (not dcext-packaged). Throws on errors. */
	/// aVersionStr carries the exact version from a dcext manifest; a bare dll has none.
	/// aAllowReinstall carries extract()'s verdict through to the duplicate check in enable().
	void addPlugin(const string& path, const string& aVersionStr = string(), bool aAllowReinstall = false);
	bool configPlugin(const string& guid, dcptr_t data);
	void enablePlugin(const string& guid);
	void disablePlugin(const string& guid);
	void movePlugin(const string& guid, int delta);
	void removePlugin(const string& guid);

	bool isLoaded(const string& guid) const;

	/// Compares dotted numeric versions component by component, so "1.10" sorts above "1.9"
	/// (the plugin ABI's double reads that pair the other way round).
	/// Returns a negative value, zero or a positive value for less / equal / greater.
	static int compareVersions(const string& aLeft, const string& aRight) noexcept;

	StringList getPluginList() const;
	Plugin getPlugin(const string& guid) const;

	DCCorePtr getCore() { return &dcCore; }

	// Functions that call the plugin
	bool onUDP(bool out, const string& ip, const string& port, const string& data);
	bool onChatTags(Tagger& tagger, OnlineUser* from = nullptr);
	bool onChatDisplay(string& htmlMessage, OnlineUser* from = nullptr);
	bool onChatCommand(Client* client, const string& line);
	bool onChatCommandPM(const HintedUser& user, const string& line);

	// runHook wrappers for host calls
	bool runHook(const string& guid, dcptr_t pObject, dcptr_t pData = NULL) {
		if(shutdown) return false;
		PluginHook* hook;
		{
			// Guard the map lookup: host hooks fire from network threads while a
			// plugin may create/destroy hooks (which mutate the map) from its own.
			// The looked-up host hooks are permanent, so the pointer stays valid
			// after the lock is released (csHook is recursive, so runHook nesting is fine).
			Lock l(csHook);
			auto i = hooks.find(guid);
			dcassert(i != hooks.end());
			if(i == hooks.end()) return false;
			hook = i->second.get();
		}
		return runHook(hook, pObject, pData);
	}

	template<class T>
	bool runHook(const string& guid, PluginEntity<T>* entity, dcptr_t pData = NULL) {
		if(entity) {
			Lock l(entity->cs);
			return runHook(guid, entity->getPluginObject(), pData);
		}
		return runHook(guid, nullptr, pData);
	}

	template<class T>
	bool runHook(const string& guid, PluginEntity<T>* entity, const string& data) {
		return runHook<T>(guid, entity, reinterpret_cast<dcptr_t>(const_cast<char*>(data.c_str())));
	}

	// Plugin interface registry
	intfHandle registerInterface(const string& guid, dcptr_t funcs);
	dcptr_t queryInterface(const string& guid);
	bool releaseInterface(intfHandle hInterface);

	// Plugin Hook system
	PluginHook* createHook(const string& guid, DCHOOK defProc);
	bool destroyHook(PluginHook* hook);

	HookSubscriber* bindHook(const string& guid, DCHOOK hookProc, void* pCommon);
	bool runHook(PluginHook* hook, dcptr_t pObject, dcptr_t pData);
	size_t releaseHook(HookSubscriber* subscription);

	// Plugin configuration
	void setPluginSetting(const string& guid, const string& setting, const string& value);
	const string& getPluginSetting(const string& guid, const string& setting);
	void removePluginSetting(const string& guid, const string& setting);

	// Root of the managed plugin tree. Anything we create or recursively delete must live
	// strictly beneath it.
	static string getPluginsRoot() noexcept;

	// Sanitises the uuid: it is manifest-supplied and was previously concatenated raw,
	// which let a crafted .dcext escape the plugin directory on both install and remove.
	static string getInstallPath(const string& uuid);

private:
	void enable(Plugin& plugin, bool install, bool runtime, bool allowReinstall = false);
	void disable(Plugin& plugin, bool uninstall);

	void loadSettings() noexcept;
	void saveSettings() noexcept;

	const Plugin* findPlugin(const string& guid) const;
	Plugin* findPlugin(const string& guid);
	vector<Plugin>::const_iterator findPluginIter(const string& guid) const;
	vector<Plugin>::iterator findPluginIter(const string& guid);

	// AirDC fires queue/hub lifecycle listener events from contexts that may hold
	// manager locks (non-recursive SharedMutex); marshal those hooks to the timer
	// thread so a plugin calling back into the API can't deadlock.
	void addAsyncTask(std::function<void()> task) noexcept;
	void runAsyncTasks() noexcept;

	void fireHubOnline(const ClientPtr& aClient) noexcept;
	void fireHubOffline(const string& aHubUrl) noexcept;

	// Listeners
	void on(TimerManagerListener::Second, uint64_t ticks) noexcept;
	void on(TimerManagerListener::Minute, uint64_t ticks) noexcept { runHook(HOOK_TIMER_MINUTE, NULL, &ticks); }

	void on(ClientManagerListener::ClientConnected, const ClientPtr& aClient) noexcept;
	void on(ClientManagerListener::ClientDisconnected, const string& aHubUrl) noexcept;
	void on(ClientManagerListener::ClientRemoved, const ClientPtr& aClient) noexcept;

	void on(QueueManagerListener::ItemAdded, const QueueItemPtr& qi) noexcept;
	void on(QueueManagerListener::ItemRemoved, const QueueItemPtr& qi, bool finished) noexcept;
	void on(QueueManagerListener::ItemFinished, const QueueItemPtr& qi, const string& dir, const HintedUser& user, int64_t speed) noexcept;

	void on(SettingsManagerListener::Save, SimpleXML& /*xml*/) noexcept;

	vector<Plugin> plugins;
	vector<PluginHandle> inactive;

	map<string, unique_ptr<PluginHook>> hooks;
	map<string, dcptr_t> interfaces;

	// Hubs that HOOK_HUB_ONLINE has been fired for (by url) and not yet HOOK_HUB_OFFLINE;
	// AirDC's ClientDisconnected only carries the url and ClientRemoved may arrive
	// without a preceding ClientDisconnected.
	set<string> onlineHubs;
	mutable CriticalSection csOnlineHubs;

	vector<std::function<void()>> asyncTasks;
	mutable CriticalSection csAsyncTasks;

	DCCore dcCore;
	mutable CriticalSection cs, csHook;
	bool shutdown;

	uintptr_t secNum;
};

} // namespace dcpp

#endif // !defined(DCPLUSPLUS_DCPP_PLUGIN_MANAGER_H)
