/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_LOG_MANAGER_H
#define DCPLUSPLUS_DCPP_LOG_MANAGER_H

#include <deque>
#include <utility>

#include <airdcpp/core/header/typedefs.h>

#include <airdcpp/user/CID.h>
#include <airdcpp/core/queue/DispatcherQueue.h>
#include <airdcpp/events/LogManagerListener.h>
#include <airdcpp/message/Message.h>
#include <airdcpp/message/MessageCache.h>
#include <airdcpp/core/Singleton.h>
#include <airdcpp/core/Speaker.h>

namespace dcpp {

class LogManager : public Singleton<LogManager>, public Speaker<LogManagerListener>
{
public:
	enum Area: uint8_t { CHAT, PM, DOWNLOAD, UPLOAD, SYSTEM, STATUS, LAST };
	enum: uint8_t { FILE, FORMAT };

	void log(Area area, ParamMap& params) noexcept;
	void message(const string& aMsg, LogMessage::Severity aSeverity, const string& aLabel) noexcept;

	string getPath(Area area, ParamMap& params) const noexcept;
	string getPath(Area area) const noexcept;

	// PM functions
	string getPath(const UserPtr& aUser, ParamMap& params, bool addCache = false) noexcept;
	void log(const UserPtr& aUser, ParamMap& params) noexcept;
	void removePmCache(const UserPtr& aUser) noexcept;

	// By value: SettingsManager::get(StrSetting) returns a copy (under its lock), so returning
	// a reference here would bind to the destroyed temporary
	string getSetting(int area, int sel) const noexcept;
	void saveSetting(int area, int sel, const string& setting) const noexcept;

	const MessageCache& getCache() const noexcept {
		return cache;
	}

	// Runtime language change: re-resolve the cached lines (see MessageRetranslator)
	int retranslateCache(const MessageCache::TextRewriteF& aRewriteF) noexcept {
		return cache.retranslate(aRewriteF);
	}

	void clearCache() noexcept;
	void setRead() noexcept;

	static string readFromEnd(const string& aPath, int aMaxLines, int64_t aBufferSize) noexcept;
private:
	MessageCache cache;

	void log(const string& area, const string& msg) noexcept;

	friend class Singleton<LogManager>;

	int options[LAST][2];

	LogManager();
	~LogManager() override;

	// Guards pmPaths. The comment on getPath() claimed it was GUI-thread-only, but
	// PrivateChat::logMessage reaches the mutating variant on the client/hub message
	// thread while UsersFrame and User read it from the GUI thread and PrivateChat's close
	// path erases -- a try_emplace that rehashes while another thread walks a bucket is a
	// use-after-free on the node chain.
	mutable CriticalSection pmPathsCS;
	unordered_map<CID, string> pmPaths;
	static void ensureParam(const string& aParam, string& aFile) noexcept;

	DispatcherQueue tasks;
};

#define LOG(area, msg) LogManager::getInstance()->log(area, msg)

} // namespace dcpp

#endif // !defined(DCPLUSPLUS_DCPP_LOG_MANAGER_H)
