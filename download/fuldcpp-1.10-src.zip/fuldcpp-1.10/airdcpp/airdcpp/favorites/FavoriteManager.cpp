/* 
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/favorites/FavoriteManager.h>

#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/user/HintedUser.h>
#include <airdcpp/core/crypto/CryptoManager.h>
#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/util/LinkUtil.h>
#include <airdcpp/share/ShareManager.h>
#include <airdcpp/share/profiles/ShareProfileManager.h>
#include <airdcpp/core/io/xml/SimpleXML.h>

namespace dcpp {

#define CONFIG_FAV_NAME "Favorites.xml"
#define CONFIG_DIR AppUtil::PATH_USER_CONFIG

using ranges::find_if;

FavoriteManager::FavoriteManager() {
	SettingsManager::getInstance()->addListener(this);
	ClientManager::getInstance()->addListener(this);
	ShareManager::getInstance()->getProfileMgr().addListener(this);
}

FavoriteManager::~FavoriteManager() {
	ClientManager::getInstance()->removeListener(this);
	SettingsManager::getInstance()->removeListener(this);
	ShareManager::getInstance()->getProfileMgr().removeListener(this);
}

void FavoriteManager::shutdown() noexcept {
	TimerManager::getInstance()->removeListener(this);
	save();
}

bool FavoriteManager::hasFavoriteDir(const string& aPath) const noexcept {
	RLock l(cs);
	return favoriteDirectories.contains(aPath);
}

bool FavoriteManager::setFavoriteDir(const string& aPath, const string& aGroupName) noexcept {
	{
		WLock l(cs);
		favoriteDirectories[aPath] = aGroupName;
	}

	setDirty();

	fire(FavoriteManagerListener::FavoriteDirectoriesUpdated());
	return true;
}

bool FavoriteManager::removeFavoriteDir(const string& aPath) noexcept {
	if (!hasFavoriteDir(aPath)) {
		return false;
	}

	{
		WLock l(cs);
		favoriteDirectories.erase(aPath);
	}

	setDirty();

	fire(FavoriteManagerListener::FavoriteDirectoriesUpdated());
	return true;
}

void FavoriteManager::setFavoriteDirs(const FavoriteDirectoryMap& dirs) noexcept {
	{
		WLock l(cs);
		favoriteDirectories = dirs;
	}

	fire(FavoriteManagerListener::FavoriteDirectoriesUpdated());
	setDirty();
}

StringPair FavoriteManager::getFavoriteDirectory(const string& aPath) const noexcept {
	RLock l(cs);
	auto i = favoriteDirectories.find(aPath);
	if (i == favoriteDirectories.end()) {
		return StringPair();
	}

	return *i;
}

GroupedDirectoryMap FavoriteManager::getGroupedFavoriteDirs() const noexcept {
	GroupedDirectoryMap ret;

	{
		RLock l(cs);
		for (const auto& [path, name] : favoriteDirectories) {
			ret[name].insert(path);
		}
	}

	return ret;
}

FavoriteManager::FavoriteDirectoryMap FavoriteManager::getFavoriteDirs() const noexcept {
	RLock l(cs);
	return favoriteDirectories;
}

// FAVORITE HUBS START
bool FavoriteManager::addFavoriteHub(const FavoriteHubEntryPtr& aEntry) noexcept {
	{
		WLock l(cs);
		if (auto i = getFavoriteHubUnsafe(aEntry->getServer()); i != favoriteHubs.end()) {
			return false;
		}

		favoriteHubs.push_back(aEntry);
	}

	setConnectState(aEntry);

	fire(FavoriteManagerListener::FavoriteHubAdded(), aEntry);
	setDirty();
	return true;
}

void FavoriteManager::updateFavoriteHubHooked(const FavoriteHubEntryPtr& aEntry, const std::function<void ()>& aUpdateF) noexcept {
	{
		WLock l(cs);
		aUpdateF();
	}

	// Outside the lock: onFavoriteHubUpdated fires listeners, and a listener that called back into
	// this manager would deadlock on a non-recursive mutex.
	onFavoriteHubUpdated(aEntry);
}

void FavoriteManager::onFavoriteHubUpdated(const FavoriteHubEntryPtr& aEntry) noexcept {
	// Update the connect state in case the address was changed
	setConnectState(aEntry);

	// Re-broadcast our info to the live hub so settings changes that affect what we
	// advertise (e.g. toggling Hide share, which switches the share profile) take effect
	// immediately instead of waiting for the next share refresh or reconnect.
	// info() reloads the hub settings and only sends the parameters that actually changed.
	if (auto client = ClientManager::getInstance()->findClient(aEntry->getServer()); client && client->isConnected()) {
		client->info();
	}

	setDirty();
	fire(FavoriteManagerListener::FavoriteHubUpdated(), aEntry);
}

void FavoriteManager::updateFailovers(FavoriteHubToken aToken, const string& aFailovers) noexcept {
	auto entry = getFavoriteHubEntry(aToken);
	if (!entry) {
		return;
	}

	{
		// This is written from the socket thread on hub INF changes while saveFavoriteHubs
		// may be reading on another thread
		WLock l(cs);
		if (entry->getFailovers() == aFailovers) {
			return;
		}

		entry->setFailovers(aFailovers);
	}

	setDirty();
	fire(FavoriteManagerListener::FavoriteHubUpdated(), entry);
}

void FavoriteManager::autoConnect() noexcept {
	StringList hubs;

	{

		RLock l(cs);
		for (const auto& entry : favoriteHubs) {
			if (entry->getAutoConnect()) {
				hubs.emplace_back(entry->getServer());
			}
		}
	}

	for (const auto& h : hubs) {
		if (!ClientManager::getInstance()->findClient(h))
			ClientManager::getInstance()->createClient(h);
	}
}

bool FavoriteManager::removeFavoriteHub(FavoriteHubToken aToken) noexcept {
	FavoriteHubEntryPtr entry = nullptr;

	{
		WLock l(cs);
		auto i = ranges::find_if(favoriteHubs, [aToken](const FavoriteHubEntryPtr& f) { return f->getToken() == aToken; });
		if (i == favoriteHubs.end()) {
			return false;
		}

		entry = *i;
		favoriteHubs.erase(i);
	}

	fire(FavoriteManagerListener::FavoriteHubRemoved(), entry);
	setDirty();
	return true;
}

bool FavoriteManager::isUnique(const string& url, FavoriteHubToken aExcludedEntryToken) const noexcept {
	RLock l(cs);
	auto i = getFavoriteHubUnsafe(url);
	if (i == favoriteHubs.end())
		return true;

	return aExcludedEntryToken == (*i)->getToken();
}

void FavoriteManager::on(ShareProfileManagerListener::ProfileRemoved, ProfileToken aProfile) noexcept {
	resetProfile(aProfile, HUB_SETTING_DEFAULT_INT);
}

int FavoriteManager::resetProfile(ProfileToken aResetToken, ProfileToken aDefaultProfile) noexcept {
	FavoriteHubEntryList updatedHubs;

	{
		// WLock, not RLock: the loop MUTATES each entry's int array. Under a shared lock
		// the TimerManager thread inside saveFavoriteHubs() or a socket thread inside
		// mergeHubSettings() reads the same array concurrently -- the same reasoning
		// already documented on setHubSetting() and updateFailovers().
		WLock l(cs);
		for (const auto& fh : favoriteHubs) {
			if (fh->get(HubSettings::ShareProfile) == aResetToken) {
				fh->get(HubSettings::ShareProfile) = aDefaultProfile;
				updatedHubs.push_back(fh);
			}
		}
	}

	for (const auto& fh : updatedHubs) {
		fire(FavoriteManagerListener::FavoriteHubUpdated(), fh);
	}


	// Remove later
	fire(FavoriteManagerListener::FavoriteHubsUpdated());
	return static_cast<int>(updatedHubs.size());
}

bool FavoriteManager::hasActiveHubs() const noexcept {
	RLock l(cs);
	return ranges::any_of(favoriteHubs, [](const FavoriteHubEntryPtr& f) { 
		return f->get(HubSettings::Connection) == SettingsManager::INCOMING_ACTIVE || f->get(HubSettings::Connection6) == SettingsManager::INCOMING_ACTIVE; 
	});
}

// FAVORITE HUBS END

void FavoriteManager::save() noexcept {
	if (!xmlDirty)
		return;

	lastXmlSave = GET_TICK();

	// Cleared BEFORE serializing, and re-armed below if the write fails.
	//
	// setDirty() is called from other threads the moment a change is committed, so anything that
	// lands while we are serializing belongs to the NEXT save. Clearing it after a successful write
	// -- which is what this did -- swallows exactly those changes: the same data loss this function
	// exists to prevent, moved from the failure path to the success path. The cost of clearing
	// first is at worst one redundant rewrite, which is the right way round.
	xmlDirty = false;

	try {
		SimpleXML xml;

		xml.addTag("Favorites");
		xml.stepIn();

		{
			xml.addTag("CID", SETTING(PRIVATE_ID));

			saveFavoriteHubs(xml);
			saveFavoriteDirectories(xml);

			fire(FavoriteManagerListener::Save(), xml);
		}

		xml.stepOut();


		// saveSettingFile's bool return used to be discarded. That function catches FileException
		// itself, logs, and returns false -- it never rethrows -- so the catch below could not fire
		// for the failure it was written for. One transient problem (the config directory briefly
		// unwritable, a full disk, an antivirus holding the .tmp) and the manager believed it had
		// saved: nothing set the flag again, so the shutdown save took the early return above and
		// the session's favourite hubs were gone. The favourite USERS list rides in the same file,
		// so that went too.
		if (!SettingsManager::saveSettingFile(xml, CONFIG_DIR, CONFIG_FAV_NAME)) {
			xmlDirty = true;
		}

	} catch(const Exception& e) {
		// Serialization threw, so nothing reached disk and the flag has to go back on.
		xmlDirty = true;
		dcdebug("FavoriteManager::save: %s\n", e.getError().c_str());
	}

}

void FavoriteManager::saveFavoriteDirectories(SimpleXML& aXml) const noexcept {
	aXml.addTag("FavoriteDirs");
	aXml.addChildAttrib("Version", 2);
	aXml.stepIn();

	const auto groupedDirs = getGroupedFavoriteDirs();
	for (const auto& [name, paths]: groupedDirs) {
		aXml.addTag("Directory", name);
		aXml.addChildAttrib("Name", name);
		aXml.stepIn();
		for (const auto& t: paths) {
			aXml.addTag("Target", t);
		}
		aXml.stepOut();
	}

	aXml.stepOut();
}

void FavoriteManager::saveFavoriteHubs(SimpleXML& aXml) const noexcept {
	aXml.addTag("Hubs");
	aXml.stepIn();

	{
		RLock l(cs);
		for (const auto& [name, group] : favHubGroups) {
			aXml.addTag("Group");
			aXml.addChildAttrib("Name", name);
			group.save(aXml);
		}

		for (const auto& i : favoriteHubs) {
			aXml.addTag("Hub");
			aXml.addChildAttrib("Name", i->getName());
			aXml.addChildAttrib("Connect", i->getAutoConnect());
			aXml.addChildAttrib("Description", i->getDescription());
			aXml.addChildAttrib("Password", i->getPassword());
			aXml.addChildAttrib("Server", i->getServer());
			if (!i->getFailovers().empty())
				aXml.addChildAttrib("Failovers", i->getFailovers());
			aXml.addChildAttrib("Group", i->getGroup());
			if (i->getLastConnected() > 0)
				aXml.addChildAttrib("LastConnected", Util::toString(i->getLastConnected()));
			if (i->getShareInDfav())
				aXml.addChildAttrib("ShareInDfav", i->getShareInDfav());
			aXml.addChildAttrib("ChatUserSplit", i->getChatUserSplit());
			aXml.addChildAttrib("UserListState", i->getUserListState());
#ifdef HAVE_GUI
			aXml.addChildAttrib("HubFrameOrder", i->getHeaderOrder());
			aXml.addChildAttrib("HubFrameWidths", i->getHeaderWidths());
			aXml.addChildAttrib("HubFrameVisible", i->getHeaderVisible());
			aXml.addChildAttrib("Bottom", Util::toString(i->getBottom()));
			aXml.addChildAttrib("Top", Util::toString(i->getTop()));
			aXml.addChildAttrib("Right", Util::toString(i->getRight()));
			aXml.addChildAttrib("Left", Util::toString(i->getLeft()));
			if (i->getCustomTabColor() != -1)
				aXml.addChildAttrib("TabColor", i->getCustomTabColor());
			if (i->getChatBgImageOverride()) {
				aXml.addChildAttrib("ChatBgOverride", true);
				aXml.addChildAttrib("ChatBgImage", i->getChatBgImage());
			}
			if (i->getUserlistSide() != 0)
				aXml.addChildAttrib("UserlistSide", i->getUserlistSide());
#endif
			i->save(aXml);
		}
	}

	aXml.stepOut();
}

void FavoriteManager::loadCID() noexcept {
	SettingsManager::loadSettingFile(CONFIG_DIR, CONFIG_FAV_NAME, [](SimpleXML& xml) {
		if (xml.findChild("Favorites")) {
			xml.stepIn();
			if (xml.findChild("CID")) {
				xml.stepIn();
				SettingsManager::getInstance()->set(SettingsManager::PRIVATE_ID, xml.getData());
				xml.stepOut();
			}

			xml.stepOut();
		}
	});
}

void FavoriteManager::load() noexcept {
	SettingsManager::loadSettingFile(CONFIG_DIR, CONFIG_FAV_NAME, [this](SimpleXML& xml) {
		if(xml.findChild("Favorites")) {
			xml.stepIn();

			loadFavoriteHubs(xml);
			loadFavoriteDirectories(xml);

			fire(FavoriteManagerListener::Load(), xml);

			xml.stepOut();
		}
	});

	lastXmlSave = GET_TICK();
	TimerManager::getInstance()->addListener(this);
}

void FavoriteManager::loadFavoriteHubs(SimpleXML& aXml) {
	if (aXml.findChild("Hubs")) {
		aXml.stepIn();

		while (aXml.findChild("Group")) {
			string name = aXml.getChildAttrib("Name");
			if (name.empty())
				continue;

			HubSettings settings;
			settings.load(aXml);
			favHubGroups[name] = std::move(settings);
		}

		aXml.resetCurrentChild();
		while (aXml.findChild("Hub")) {
			auto e = std::make_shared<FavoriteHubEntry>();
			e->setName(aXml.getChildAttrib("Name"));
			e->setAutoConnect(aXml.getBoolChildAttrib("Connect"));
			e->setDescription(aXml.getChildAttrib("Description"));
			e->setPassword(aXml.getChildAttrib("Password"));

			auto server = aXml.getChildAttrib("Server");
			if (server.empty()) {
				dcdebug("A favorite hub with an empty address wasn't loaded: %s\n", e->getName().c_str());
				continue;
			}

			// Remove legacy ;-encoded failovers from the primary address (current
			// failovers live in the separate Failovers attribute)
			if (auto p = server.find(';'); p != string::npos) {
				server = server.substr(0, p);
			}

			e->setServer(server);
			e->setFailovers(aXml.getChildAttrib("Failovers"));

			e->setChatUserSplit(aXml.getIntChildAttrib("ChatUserSplit"));
			e->setUserListState(aXml.getBoolChildAttrib("UserListState"));
#ifdef HAVE_GUI
			e->setHeaderOrder(aXml.getChildAttrib("HubFrameOrder", SETTING(HUBFRAME_ORDER)));
			e->setHeaderWidths(aXml.getChildAttrib("HubFrameWidths", SETTING(HUBFRAME_WIDTHS)));
			e->setHeaderVisible(aXml.getChildAttrib("HubFrameVisible", SETTING(HUBFRAME_VISIBLE)));
			e->setBottom((uint16_t)aXml.getIntChildAttrib("Bottom"));
			e->setTop((uint16_t)aXml.getIntChildAttrib("Top"));
			e->setRight((uint16_t)aXml.getIntChildAttrib("Right"));
			e->setLeft((uint16_t)aXml.getIntChildAttrib("Left"));
			// Not getIntChildAttrib: it has no default parameter, so a missing attribute would read
			// as 0 (= black, a valid colour) instead of "no custom colour".
			e->setCustomTabColor(Util::toInt(aXml.getChildAttrib("TabColor", "-1")));
			e->setChatBgImageOverride(aXml.getBoolChildAttrib("ChatBgOverride"));
			e->setChatBgImage(aXml.getChildAttrib("ChatBgImage"));
			e->setUserlistSide(Util::toInt(aXml.getChildAttrib("UserlistSide", "0")));
#endif
			e->setGroup(aXml.getChildAttrib("Group"));
			e->setLastConnected(aXml.getTimeChildAttrib("LastConnected"));
			e->setShareInDfav(aXml.getBoolChildAttrib("ShareInDfav"));
			if (aXml.getBoolChildAttrib("HideShare")) {
				// For compatibility with very old favorites
				e->get(HubSettings::ShareProfile) = SP_HIDDEN;
			}

			e->load(aXml);

			// Check for profiles that no longer exist.
			if (e->get(HubSettings::ShareProfile) != SP_HIDDEN &&
				e->get(HubSettings::ShareProfile) != HUB_SETTING_DEFAULT_INT &&
				!ShareManager::getInstance()->getShareProfile(e->get(HubSettings::ShareProfile))) {
				e->get(HubSettings::ShareProfile) = HUB_SETTING_DEFAULT_INT;
			}

			favoriteHubs.push_back(e);
		}

		aXml.stepOut();
	}

	aXml.resetCurrentChild();
}

void FavoriteManager::loadFavoriteDirectories(SimpleXML& aXml) {
	if (aXml.findChild("FavoriteDirs")) {
		string version = aXml.getChildAttrib("Version");
		aXml.stepIn();
		if (version.empty() || Util::toInt(version) < 2) {
			// Convert old directories
			while (aXml.findChild("Directory")) {
				auto groupName = aXml.getChildAttrib("Name");

				const auto& dir = aXml.getChildData();
				if (!dir.empty()) {
					favoriteDirectories[dir] = groupName;
				}
			}
		} else {
			while (aXml.findChild("Directory")) {
				auto groupName = aXml.getChildAttrib("Name");
				if (!groupName.empty()) {
					aXml.stepIn();
					while (aXml.findChild("Target")) {
						aXml.stepIn();

						auto path = aXml.getData();
						favoriteDirectories[path] = groupName;

						aXml.stepOut();
					}

					aXml.stepOut();
				}
			}
		}
		aXml.stepOut();
	}

	aXml.resetCurrentChild();
}

FavoriteHubEntryList FavoriteManager::getFavoriteHubs(const string& group) const noexcept {
	RLock l(cs);
	FavoriteHubEntryList ret;
	copy_if(favoriteHubs.begin(), favoriteHubs.end(), back_inserter(ret), [&group](const FavoriteHubEntryPtr& f) { return Util::stricmp(f->getGroup(), group) == 0; });
	return ret;
}

FavoriteHubEntryList FavoriteManager::getFavoriteHubs() const noexcept {
	RLock l(cs);
	return favoriteHubs;
}

// The hubs we are willing to hand out in a DFAV response (ADC-EXT 4.6), as address / last login
// pairs. Sharing is opt-in per entry, and a password-protected hub is never shareable regardless:
// the point of the extension is a public hublist, and nobody else can use a hub they can't enter.
vector<pair<string, time_t>> FavoriteManager::getShareableFavoriteHubs() const noexcept {
	vector<pair<string, time_t>> ret;

	RLock l(cs);
	for (const auto& entry : favoriteHubs) {
		if (!entry->getShareInDfav() || !entry->getPassword().empty() || entry->getServer().empty())
			continue;

		ret.emplace_back(entry->getServer(), entry->getLastConnected());
	}

	return ret;
}

// The RFA half of ADC-EXT 4.6: a peer answering our GFA tells us about one hub. Everything
// here is deliberately conservative - a remote user chose this content, so it is stored as a
// suggestion, kept in memory only, and never acted on without the user asking.
bool FavoriteManager::addDiscoveredHub(const string& aUrl, time_t aLastLogin, const string& aSourceHubUrl, const CID& aReporter) noexcept {
	auto url = aUrl;
	LinkUtil::sanitizeUrl(url);
	if (url.empty() || !LinkUtil::isSupportedHubScheme(url, CryptoManager::getInstance()->TLSOk())) {
		return false;
	}

	// A future timestamp is a lie (or a clock skew); clamp rather than display it
	auto now = GET_TIME();
	auto lastLogin = (aLastLogin > 0 && aLastLogin <= now) ? aLastLogin : 0;

	auto key = Text::toLower(url);

	{
		WLock l(cs);
		auto i = discoveredHubs.find(key);
		if (i == discoveredHubs.end()) {
			if (discoveredHubs.size() >= MAX_DISCOVERED_HUBS) {
				return false;
			}

			i = discoveredHubs.try_emplace(key).first;
			i->second.entry.url = url;
			i->second.entry.sourceHubUrl = aSourceHubUrl;
		}

		auto& hub = i->second;
		if (hub.reporters.insert(aReporter).second) {
			hub.entry.reporters = static_cast<int>(hub.reporters.size());
		}

		hub.entry.lastLogin = max(hub.entry.lastLogin, lastLogin);
	}

	fire(FavoriteManagerListener::DiscoveredHubsUpdated());
	return true;
}

FavoriteManager::DiscoveredHubList FavoriteManager::getDiscoveredHubs() const noexcept {
	DiscoveredHubList ret;

	RLock l(cs);
	ret.reserve(discoveredHubs.size());
	for (const auto& hub : discoveredHubs | views::values) {
		ret.push_back(hub.entry);
	}

	return ret;
}

void FavoriteManager::setFavHubGroups(const FavHubGroups& favHubGroups_) noexcept {
	WLock l(cs);
	favHubGroups = favHubGroups_; 
}

void FavoriteManager::setHubSetting(const string& aUrl, HubSettings::HubBoolSetting aSetting, bool aNewValue) noexcept {
	FavoriteHubEntryPtr hub;

	{
		// WLock: this writes the entry's setting. Under a shared lock the TimerManager thread
		// inside saveFavoriteHubs() or a socket thread inside mergeHubSettings() could read the
		// same tribool/int array concurrently. updateFailovers() above already takes a WLock and
		// documents exactly this.
		WLock l(cs);
		auto p = getFavoriteHubUnsafe(aUrl);
		if (p == favoriteHubs.end()) {
			return;
		}

		hub = *p;
		(*p)->get(aSetting) = aNewValue;
	}

	ClientManager::getInstance()->myInfoUpdated();
	fire(FavoriteManagerListener::FavoriteHubUpdated(), hub);
}

void FavoriteManager::on(SettingsManagerListener::Load, SimpleXML&) noexcept {
	loadCID();
}

FavoriteHubEntryPtr FavoriteManager::getFavoriteHubEntry(const string& aServer) const noexcept {
	RLock l(cs);
	auto p = getFavoriteHubUnsafe(aServer);
	return p != favoriteHubs.end() ? *p : nullptr;
}

FavoriteHubEntryPtr FavoriteManager::getFavoriteHubEntry(FavoriteHubToken aToken) const noexcept {
	RLock l(cs);
	auto p = getFavoriteHubUnsafe(aToken);
	return p != favoriteHubs.end() ? *p : nullptr;
}

void FavoriteManager::mergeHubSettings(const FavoriteHubEntryPtr& entry, HubSettings& settings) const noexcept {
	RLock l(cs);
	// apply group settings first.
	if (const auto& name = entry->getGroup(); !name.empty()) {
		auto group = favHubGroups.find(name);
		if(group != favHubGroups.end())
			settings.merge(group->second);
	}

	// apply fav entry settings next.
	settings.merge(*entry);
}

FavoriteHubEntryList::const_iterator FavoriteManager::getFavoriteHubUnsafe(const string& aServer) const noexcept {
	//find by the primary address
	return ranges::find_if(favoriteHubs, [&aServer](const FavoriteHubEntryPtr& f) { return Util::stricmp(f->getServer(), aServer) == 0; });
}

FavoriteHubEntryList::const_iterator FavoriteManager::getFavoriteHubUnsafe(FavoriteHubToken aToken) const noexcept {
	return ranges::find_if(favoriteHubs, [aToken](const FavoriteHubEntryPtr& f) { return f->getToken() == aToken; });
}

void FavoriteManager::on(TimerManagerListener::Second, uint64_t aTick) noexcept {
	if (xmlDirty && aTick > (lastXmlSave + 15 * 1000)) {
		save();
	}
}

void FavoriteManager::on(ClientManagerListener::ClientCreated, const ClientPtr& aClient) noexcept {
	onConnectStateChanged(aClient, FavoriteHubEntry::STATE_CONNECTING);
}

void FavoriteManager::on(ClientManagerListener::ClientConnected, const ClientPtr& aClient) noexcept {
	onConnectStateChanged(aClient, FavoriteHubEntry::STATE_CONNECTED);
}

void FavoriteManager::on(ClientManagerListener::ClientRemoved, const ClientPtr& aClient) noexcept {
	onConnectStateChanged(aClient, FavoriteHubEntry::STATE_DISCONNECTED);
}

void FavoriteManager::on(ClientManagerListener::ClientRedirected, const ClientPtr& aOldClient, const ClientPtr& aNewClient) noexcept {
	onConnectStateChanged(aOldClient, FavoriteHubEntry::STATE_DISCONNECTED);
	onConnectStateChanged(aNewClient, FavoriteHubEntry::STATE_CONNECTING);
}

void FavoriteManager::setConnectState(const FavoriteHubEntryPtr& aEntry) noexcept {
	auto client = ClientManager::getInstance()->findClient(aEntry->getServer());
	if (client) {
		aEntry->setConnectState(client->isConnected() ? FavoriteHubEntry::STATE_CONNECTED : FavoriteHubEntry::STATE_CONNECTING);
		aEntry->setCurrentHubToken(client->getToken());
	} else {
		aEntry->setCurrentHubToken(0);
		aEntry->setConnectState(FavoriteHubEntry::STATE_DISCONNECTED);
	}
}

void FavoriteManager::onConnectStateChanged(const ClientPtr& aClient, FavoriteHubEntry::ConnectState aState) noexcept {
	auto hub = getFavoriteHubEntry(aClient->getHubUrl());
	if (hub) {
		hub->setConnectState(aState);
		if (aState == FavoriteHubEntry::STATE_DISCONNECTED) {
			hub->setCurrentHubToken(0);
		} else {
			hub->setCurrentHubToken(aClient->getToken());
			if (aState == FavoriteHubEntry::STATE_CONNECTED) {
				hub->setLastConnected(time(nullptr));
				setDirty();
			}
		}

		fire(FavoriteManagerListener::FavoriteHubUpdated(), hub);
	}
}

} // namespace dcpp
