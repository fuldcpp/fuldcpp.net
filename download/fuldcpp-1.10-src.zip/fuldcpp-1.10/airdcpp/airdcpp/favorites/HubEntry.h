/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_HUBENTRY_H_
#define DCPLUSPLUS_DCPP_HUBENTRY_H_

#include <airdcpp/core/types/GetSet.h>
#include <airdcpp/core/header/typedefs.h>

#include <airdcpp/settings/HubSettings.h>

namespace dcpp {

	using std::string;


	class ShareProfile;
	class FavoriteHubEntry : public HubSettings {
	public:
		using Ptr = FavoriteHubEntry *;
		using List = vector<Ptr>;

		enum ConnectState {
			STATE_DISCONNECTED,
			STATE_CONNECTING,
			STATE_CONNECTED
		};

		FavoriteHubEntry() noexcept;

		GETSET(string, name, Name);
		GETSET(string, description, Description);
		GETSET(string, password, Password);
		GETSET(string, server, Server);
		// Comma-separated failover hub addresses advertised by the hub (ADC-EXT 4.21)
		GETSET(string, failovers, Failovers);

		// GUI settings
		GETSET(string, headerOrder, HeaderOrder);
		GETSET(string, headerWidths, HeaderWidths);
		GETSET(string, headerVisible, HeaderVisible);
		IGETSET(uint16_t, bottom, Bottom, 0);
		IGETSET(uint16_t, top, Top, 0);
		IGETSET(uint16_t, left, Left, 0);
		IGETSET(uint16_t, right, Right, 0);
		IGETSET(int, customTabColor, CustomTabColor, -1); // COLORREF stored as int; -1 = no custom tab colour
		// Per-hub chat background image. The flag is what distinguishes "this hub has no
		// background" from "this hub follows the global setting"; placement and the
		// readability wash stay global.
		IGETSET(bool, chatBgImageOverride, ChatBgImageOverride, false);
		GETSET(string, chatBgImage, ChatBgImage);
		// Which side of the hub window the userlist pane sits on. Persisted - never renumber:
		// 0 = follow the global setting, 1 = left, 2 = right.
		IGETSET(int, userlistSide, UserlistSide, 0);

		IGETSET(int, chatUserSplit, ChatUserSplit, 0);
		IGETSET(bool, userliststate, UserListState, true);

		IGETSET(ConnectState, connectState, ConnectState, STATE_DISCONNECTED);
		IGETSET(ClientToken, currentHubToken, CurrentHubToken, 0);

		IGETSET(bool, autoConnect, AutoConnect, true);
		// Time of the last successful connect to this hub (persisted; 0 = never)
		IGETSET(time_t, lastConnected, LastConnected, 0);
		// Opt-in to answering GFA requests with this hub (ADC-EXT 4.6 DFAV). Off by default:
		// the extension exists to publish hubs others can actually join, and a private hub
		// must never leak just because it is in the list.
		IGETSET(bool, shareInDfav, ShareInDfav, false);
		GETSET(string, group, Group);
		GETSET(FavoriteHubToken, token, Token);

		bool isAdcHub() const noexcept;
		string getShareProfileName() const noexcept;
	};
}
#endif /*DCPLUSPLUS_DCPP_HUBENTRY_H_*/
