/*
* Copyright (C) 2011-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/
#include "stdinc.h"

#include <airdcpp/private_chat/PrivateChat.h>

#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/connection/ConnectionManager.h>
#include <airdcpp/core/crypto/CryptoManager.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/message/Message.h>


namespace dcpp {

PrivateChat::PrivateChat(const HintedUser& aUser, UserConnection* aUc) :
	cache(SettingsManager::PM_MESSAGE_CACHE), replyTo(aUser), uc(aUc), 
	online(aUser.user->isOnline()), 
	hubName(ClientManager::getInstance()->getHubName(aUser.hint)) 
{
	initConnectState();

	ClientManager::getInstance()->addListener(this);

	readLastLog();
	checkIgnored();
}

void PrivateChat::initConnectState() {
	if (auto conn = uc.load()) {
		// Seed the same snapshot CCPMConnected() takes: an inbound PM adopts a connection the
		// peer already opened, so this path - not CCPMConnected() - is the common one, and
		// leaving the cache default would report "no rich text" for the connection's whole life.
		ccpmRichText = conn->supportsRichText();
		ccpmState = CCPMState::CONNECTED;
		conn->addListener(this);
	} else {
		delayEvents.addEvent(CCPM_AUTO, [this] { checkAlwaysCCPM(); }, 1000);
		checkCCPMHubBlocked();
	}
}

void PrivateChat::readLastLog() {
	auto lastLogLines = LogManager::readFromEnd(getLogPath(), SETTING(MAX_PM_HISTORY_LINES), Util::convertSize(16, Util::KB));
	if (!lastLogLines.empty()) {
		auto logMessage = std::make_shared<LogMessage>(
			lastLogLines,
			LogMessage::SEV_INFO,
			LogMessage::Type::HISTORY,
			Util::emptyString,
			LogMessage::InitFlags::INIT_DISABLE_TIMESTAMP | LogMessage::InitFlags::INIT_READ
		);
		cache.addMessage(logMessage);
	}
}

void PrivateChat::shutdown() noexcept {
	// Called by PrivateChatManager::removeChat while the manager still holds a reference,
	// so this object cannot be destroyed underneath any of the teardown below.
	//
	// The destructor alone was not enough. This object is owned by the UI frame as well as
	// the manager, so it is typically destroyed later, on the UI thread, with nothing
	// coordinating three separate escape routes:
	//  - ClientManager listener callbacks (Speaker::fire snapshots its listener vector and
	//    releases the lock before dispatching, so removeListener() is not a barrier),
	//  - delayEvents, whose dispatcher collects due tasks under its own lock, releases it,
	//    and only then runs them -- ~DelayedEvents does not wait for one already running,
	//  - callAsyncCCPM lambdas posted onto the UserConnection's task queue, which close()
	//    itself adds to immediately before the manager erases the chat.
	// Detaching and clearing here shrinks all three to the window where the manager still
	// owns us.
	ClientManager::getInstance()->removeListener(this);

	// Take the pointer atomically: once the manager erases this chat from its map,
	// ConnectionManagerListener::Removed can no longer reach CCPMDisconnected() for it,
	// so nothing would null `uc` when the connection deletes itself on the socket
	// thread -- and the destructor (which runs later, when the UI frame drops its
	// reference) would otherwise be left holding freed memory. The exchange also
	// guarantees a concurrent CCPMDisconnected()/closeCC() cannot detach the same
	// connection twice.
	if (auto conn = takeUc()) {
		ccpmRichText = false;
		ccpmState = CCPMState::DISCONNECTED;
		conn->removeListener(this);
	}

	delayEvents.clear();
}

PrivateChat::~PrivateChat() {
	// Idempotent; shutdown() is normally called by the manager first.
	ClientManager::getInstance()->removeListener(this);

	// Deliberately no uc detach here: shutdown() owns that. A connection pointer that is
	// still set at destruction time was leaked by the state machine and may already be
	// freed -- walking its listener list from here is exactly the crash this replaces
	// (report cc006129, stack hash RS5ICCZR5LR77UHEPS5RFUBMFM).
	dcassert(!uc.load());
}

void PrivateChat::checkIgnored() noexcept {
	if (replyTo.user->isIgnored()) {
		statusMessage(STRING(PM_IGNORE_INFO), LogMessage::SEV_INFO, LogMessage::Type::SYSTEM);
	}
}

bool PrivateChat::allowCCPM() const noexcept {
	if (!CryptoManager::getInstance()->TLSOk())
		return false;

	if (!getUser()->isSet(User::CCPM) || !getUser()->isSet(User::TLS))
		return false;

	return true;
}

void PrivateChat::checkCCPMHubBlocked() noexcept {
	if (replyTo.user->isSet(User::NMDC)) {
		return;
	}

	// Auto connecting?
	if (ccReady() || (allowCCPM() && SETTING(ALWAYS_CCPM))) {
		return;
	}

	auto ou = ClientManager::getInstance()->findOnlineUser(replyTo, false);
	if (!ou) {
		return;
	}

	// We are not connecting, check the current hub only
	if (ou->supportsCCPM()) {
		return;
	}

	//Encryption disabled...
	if (!getUser()->isSet(User::TLS) || !CryptoManager::getInstance()->TLSOk())
		return;

	// Only report if the client is known to support CCPM
	auto app = ou->getIdentity().getApplication();
	if (app.find("AirDC++") == string::npos && app.find("FulDC++") == string::npos) {
		return;
	}

	auto msg = boost::str(boost::format(
"%s\r\n\r\n\
%s")

% STRING_F(CCPM_BLOCKED_WARNING, hubName)
% (getUser()->isSet(User::CCPM) ? STRING(OTHER_CCPM_SUPPORTED) : STRING(OTHER_MEANS_COMMUNICATION))
);

	statusMessage(msg, LogMessage::SEV_WARNING, LogMessage::Type::SYSTEM);
}

const string& PrivateChat::ccpmStateToString(CCPMState aState) noexcept {
	switch (aState) {
	case CCPMState::CONNECTING: return STRING(CONNECTING);
	case CCPMState::CONNECTED: return STRING(CONNECTED);
	case CCPMState::DISCONNECTED: return STRING(DISCONNECTED);
	}

	return Util::emptyString;
}


void PrivateChat::CCPMConnected(UserConnection* aUc) {
	// A previous connection should always have been detached by now. The recovery below
	// only helps in the duplicate-connect edge where `old` is still alive (a second
	// connection displacing a healthy first one); it cannot make a genuinely leaked,
	// already-freed pointer safe -- the exchange merely stops it from lingering further.
	auto old = uc.exchange(aUc);
	dcassert(!old);
	if (old) {
		old->removeListener(this);
	}

	// RTF0 over CCPM is negotiated once, in the CSUP exchange, and the connection keeps that
	// answer for its lifetime (UserConnection deliberately snapshots what it offered). Cache
	// it here so reporting the answer later never has to walk the connection pointer, whose
	// detach protocol exists precisely because walking it raced with deletion (cc006129).
	ccpmRichText = aUc->supportsRichText();
	ccpmState = CCPMState::CONNECTED;
	aUc->addListener(this);
	statusMessage(STRING(CCPM_ESTABLISHED), LogMessage::SEV_INFO, LogMessage::Type::SERVER);
	fire(PrivateChatListener::CCPMStatusUpdated(), this);
}

void PrivateChat::CCPMDisconnected() {
	// Clean up whenever a connection is actually held, regardless of ccpmState: the old
	// ccReady() gate silently skipped the detach when the state had desynced from the
	// pointer (e.g. the connect-timeout race), leaving `uc` dangling after the connection
	// deleted itself -- the use-after-free behind crash report cc006129.
	auto conn = takeUc();
	ccpmRichText = false;
	if (!conn) {
		// No connection to detach. Drop a desynced CONNECTED state (and let the UI know),
		// but never clobber a CONNECTING attempt (this also fires when an unrelated orphan
		// connection for the same user dies while our own connect is in flight).
		auto expected = CCPMState::CONNECTED;
		if (ccpmState.compare_exchange_strong(expected, CCPMState::DISCONNECTED)) {
			fire(PrivateChatListener::CCPMStatusUpdated(), this);
		}
		return;
	}

	ccpmState = CCPMState::DISCONNECTED;
	conn->removeListener(this);
	statusMessage(STRING(CCPM_DISCONNECTED), LogMessage::SEV_INFO, LogMessage::Type::SERVER);
	fire(PrivateChatListener::CCPMStatusUpdated(), this);
	delayEvents.addEvent(CCPM_AUTO, [this] { checkAlwaysCCPM(); }, 1000);
}

// Whether a message sent with 'rich' would actually go out as markdown to THIS recipient.
// Follows the same two gates the send paths use, which live apart because the routes differ:
//  - CCPM (UserConnection::sendMessage): the connection's own negotiated answer
//  - hub  (AdcHub::privateMessage):      the hub carrying RTF0 *and* the recipient
//                                        advertising it in their SU field
// Deliberately a shade more conservative than the wire: the hub gate also honours the
// RICH_TEXT_ENABLED kill switch (Client::supportsRichText), which AdcHub::privateMessage
// does not re-check. Claiming less than the wire delivers is the safe direction.
// Kept here so a caller does not have to know which route a PM will take.
bool PrivateChat::supportsRichText() const noexcept {
	if (auto conn = uc.load(); ccReady() && conn) {
		// Frozen for the connection's lifetime by design: turning the kill switch off stops
		// advertising RTF0 on NEW connections, it does not renegotiate this one, and the send
		// path does not re-read the setting either. Reporting anything else would promise
		// behaviour the sender does not actually have.
		return ccpmRichText;
	}

	// ClientManager::privateMessageHooked resolves the recipient WITH the hub fallback and
	// then sends through whatever hub that found, so answering from the hinted hub alone
	// would say "no" while the message still went out rich over the fallback hub.
	const auto ou = ClientManager::getInstance()->findOnlineUser(replyTo, true);
	if (!ou || !ou->getIdentity().hasSupport(OnlineUser::RTF0_FEATURE)) {
		return false;
	}

	const auto c = ou->getClient();
	return c && c->supportsRichText();
}

bool PrivateChat::sendMessageHooked(const OutgoingChatMessage& aMessage, string& error_) {
	if (Util::isChatCommand(aMessage.text)) {
		fire(PrivateChatListener::ChatCommand(), this, aMessage);
		// TODO: don't continue and run hooks after this with API v2
	}

	if (auto conn = uc.load(); ccReady() && conn) {
		return conn->sendPrivateMessageHooked(aMessage, error_);
	}

	return ClientManager::getInstance()->privateMessageHooked(replyTo, aMessage, error_);
}

void PrivateChat::closeCC(bool aNow, bool aNoAutoConnect) {
	auto conn = uc.load();
	if (!ccReady() || !conn) {
		return;
	}

	if (aNoAutoConnect) {
		allowAutoCCPM = false;
	}

	// Do the ownership hand-off here, on the caller's thread: every caller keeps this chat
	// alive for the duration of this call, while the posted task below may run after the
	// chat is gone (window closed -> connection adopted by the manager -> chat destroyed
	// before the connection's queue drains). The task must therefore capture only the
	// connection -- which does outlive it: its async tasks only run while the socket is
	// still up -- and never touch `this`. takeUcIf(conn) also pins the detach to this
	// exact connection, so a concurrently established replacement is left alone.
	if (aNow && takeUcIf(conn)) {
		ccpmRichText = false;
		ccpmState = CCPMState::DISCONNECTED;
		conn->removeListener(this);
	}

	conn->callAsync([conn, aNow, aNoAutoConnect] {
		if (aNoAutoConnect && conn->getSupports().includes(UserConnection::FEATURE_ADC_CPMI)) {
			// Tell the other side not to auto-reconnect (CPMI AC0)
			AdcCommand c(AdcCommand::CMD_PMI);
			c.addParam("AC", "0");
			conn->sendHooked(c);
		}

		//Don't disconnect graceless so the last command can be transferred successfully.
		conn->disconnect(aNow && !aNoAutoConnect);
	});
}

void PrivateChat::handleMessage(const ChatMessagePtr& aMessage) noexcept {
	if (aMessage->getReplyTo()->getHubUrl() != replyTo.hint) {
		setHubUrl(aMessage->getReplyTo()->getHubUrl());

		if (!ccReady()) {
			statusMessage(STRING_F(MESSAGES_SENT_THROUGH_REMOTE, hubName), LogMessage::SEV_INFO, LogMessage::Type::SERVER);
		}
	}

	if (SETTING(LOG_PRIVATE_CHAT)) {
		logMessage(aMessage->format());
	}

	cache.addMessage(aMessage);
	fire(PrivateChatListener::PrivateMessage(), this, aMessage);
}

void PrivateChat::setRead() noexcept {
	auto unreadInfo = cache.setRead();
	
	if (unreadInfo.chatMessages > 0) {
		callAsyncCCPM([this] {
			sendPMInfoHooked(PrivateChat::MSG_SEEN);
		});
	}

	if (unreadInfo.hasMessages()) {
		fire(PrivateChatListener::MessagesRead(), this);
	}
}

int PrivateChat::clearCache() noexcept {
	auto ret = cache.clear();
	if (ret > 0) {
		fire(PrivateChatListener::MessagesCleared(), this);
	}

	return ret;
}

void PrivateChat::statusMessage(const string& aMessage, LogMessage::Severity aSeverity, LogMessage::Type aType, const string& aLabel, const string& aOwner) noexcept {
	auto message = std::make_shared<LogMessage>(aMessage, aSeverity, aType, aLabel);

	if (aOwner.empty() && aType != LogMessage::Type::SPAM && aType != LogMessage::Type::PRIVATE) {
		cache.addMessage(message);
	}
	fire(PrivateChatListener::StatusMessage(), this, message, aOwner);
}

void PrivateChat::close() {
	fire(PrivateChatListener::Close(), this);

	//PM window closed, signal it if the user supports CPMI
	//
	// Both branches capture the connection instead of re-reading `uc` (or using `this`) on
	// the socket thread: close() is only called from PrivateChatManager::removeChat, whose
	// following shutdown() call clears the member (making a re-read a silent no-op), and
	// this chat may even be destroyed before the task runs. The captures cannot dangle
	// because ASYNC_CALL tasks only execute while the socket is RUNNING, and the connection
	// is only deleted after its socket has failed. Listener detach and pointer cleanup are
	// shutdown()'s job.
	if (auto conn = uc.load(); ccReady() && conn) {
		if (conn->getSupports().includes(UserConnection::FEATURE_ADC_CPMI)) {
			conn->callAsync([conn] {
				AdcCommand c(AdcCommand::CMD_PMI);
				c.addParam("QU", "1");
				conn->sendHooked(c);
			});
		} else {
			// The manager keeps the connection alive in ccpms; drop it for peers that
			// cannot be told about the closed window.
			conn->callAsync([conn] {
				conn->disconnect(true);
			});
		}
	}

	LogManager::getInstance()->removePmCache(getUser());
}

void PrivateChat::startCC() {
	if (!replyTo.user->isOnline() || ccpmState != CCPMState::DISCONNECTED) {
		return;
	}

	ccpmState = CCPMState::CONNECTING;

	auto token = ConnectionManager::getInstance()->tokens.createToken(CONNECTION_TYPE_PM);
	auto connectResult = ClientManager::getInstance()->connect(replyTo, token, true, CONNECTION_TYPE_PM);
	if (replyTo.hint != connectResult.getHubHint()) {
		setHubUrl(connectResult.getHubHint());
	}

	allowAutoCCPM = !connectResult.getIsProtocolError();

	if (!connectResult.getIsSuccess()) {
		ccpmState = CCPMState::DISCONNECTED;
		if (!connectResult.getError().empty()) {
			statusMessage(connectResult.getError(), LogMessage::SEV_ERROR, LogMessage::Type::SERVER);
		}
	} else {
		statusMessage(STRING(CCPM_ESTABLISHING), LogMessage::SEV_INFO, LogMessage::Type::SERVER);
		fire(PrivateChatListener::CCPMStatusUpdated(), this);
		delayEvents.addEvent(CCPM_TIMEOUT, [this] { checkCCPMTimeout(); }, 30000); // 30 seconds, completely arbitrary amount of time.
	}
	
}

void PrivateChat::checkAlwaysCCPM() {
	if (!SETTING(ALWAYS_CCPM) || !allowCCPM())
		return;

	if (allowAutoCCPM && ccpmState == CCPMState::DISCONNECTED) {
		startCC();
		allowAutoCCPM = allowAutoCCPM && ccpmAttempts++ < 3;
	} else if (ccReady()){
		allowAutoCCPM = true;
	}
}

void PrivateChat::checkCCPMTimeout() {
	// CAS, not read-then-write: this runs on the timer thread and used to race
	// CCPMConnected() on the socket thread -- reading CONNECTING, losing the CPU while the
	// connection completed (CONNECTED + uc set), then stamping DISCONNECTED over it. That
	// desynced state made every later cleanup path skip the detach (dangling `uc`).
	auto expected = CCPMState::CONNECTING;
	if (ccpmState.compare_exchange_strong(expected, CCPMState::DISCONNECTED)) {
		statusMessage(STRING(CCPM_TIMEOUT), LogMessage::SEV_WARNING, LogMessage::Type::SERVER);
		fire(PrivateChatListener::CCPMStatusUpdated(), this);
	}
}

string PrivateChat::getLastCCPMError() const noexcept {

	if (!allowCCPM()) {
		if (!replyTo.user->isOnline()) {
			return STRING(USER_OFFLINE);
		} else if (replyTo.user->isNMDC()) {
			return STRING(CCPM_NOT_SUPPORTED_NMDC);
		} else if (!replyTo.user->isSet(User::TLS)) {
			return STRING(SOURCE_NO_ENCRYPTION);
		} else if (!CryptoManager::getInstance()->TLSOk()) {
				return STRING(ENCRYPTION_DISABLED);
		} else {
			return STRING(CCPM_NOT_SUPPORTED);
		}
	}
	return Util::emptyString;
}

void PrivateChat::onUserUpdated(const OnlineUser& aUser) noexcept {
	if (aUser.getUser() != replyTo.user)
		return;

	delayEvents.addEvent(USER_UPDATE, [this] {
		if (!online) {
			auto hubNames = ClientManager::getInstance()->getFormattedHubNames(replyTo);
			auto nicks = ClientManager::getInstance()->getFormattedNicks(replyTo);
			statusMessage(
				STRING(USER_WENT_ONLINE) + " [" + nicks + " - " + hubNames + "]",
				LogMessage::SEV_INFO,
				LogMessage::Type::SERVER
			);

			// online from a different hub?
			checkUserHub(false);
			online = true;
		}

		fire(PrivateChatListener::UserUpdated(), this);
	}, 1000);

	delayEvents.addEvent(CCPM_AUTO, [this] { checkAlwaysCCPM(); }, 3000);
}

void PrivateChat::on(ClientManagerListener::UserConnected, const OnlineUser& aUser, bool /*wasOffline*/) noexcept {
	onUserUpdated(aUser);
}

void PrivateChat::on(ClientManagerListener::UserUpdated, const OnlineUser& aUser) noexcept {
	onUserUpdated(aUser);
}

void PrivateChat::on(ClientManagerListener::UserDisconnected, const UserPtr& aUser, bool wentOffline) noexcept{
	if (aUser != replyTo.user)
		return;

	if (wentOffline) {
		delayEvents.removeEvent(USER_UPDATE);
		// CAS like checkCCPMTimeout: this runs on a ClientManager fire thread and must not
		// stamp DISCONNECTED over a CONNECTED that CCPMConnected() is setting concurrently
		// (that desync would leave a live, unowned connection behind).
		auto expected = CCPMState::CONNECTING;
		if (ccpmState.compare_exchange_strong(expected, CCPMState::DISCONNECTED)) {
			delayEvents.removeEvent(CCPM_TIMEOUT);
		}

		closeCC(true, false);
		allowAutoCCPM = true;
		online = false;
		fire(PrivateChatListener::UserUpdated(), this);
		statusMessage(STRING(USER_WENT_OFFLINE), LogMessage::SEV_INFO, LogMessage::Type::SERVER);
	} else {
		delayEvents.addEvent(USER_UPDATE, [this] {
			checkUserHub(true);
			fire(PrivateChatListener::UserUpdated(), this);
		}, 1000);
	}
}

void PrivateChat::checkUserHub(bool aWentOffline) noexcept {
	auto ou = ClientManager::getInstance()->findOnlineUser(replyTo, true);
	if (!ou)
		return;

	if (ou->getHubUrl() != replyTo.hint) {
		auto hubNameNew = ou->getClient()->getHubName();
		if (!ccReady()) {
			auto statusText = aWentOffline ? STRING_F(USER_OFFLINE_PM_CHANGE, hubName % hubNameNew) :
				STRING_F(MESSAGES_SENT_THROUGH, hubNameNew);

			statusMessage(statusText, LogMessage::SEV_INFO, LogMessage::Type::SERVER);
		}

		setHubUrl(ou->getHubUrl());
		hubName = hubNameNew;
	}
}

ClientPtr PrivateChat::getClient() const noexcept {
	return ClientManager::getInstance()->findClient(replyTo.hint);
}

void PrivateChat::setHubUrl(const string& aHubUrl) noexcept { 
	replyTo.hint = aHubUrl;
	hubName = ClientManager::getInstance()->getHubName(replyTo.hint);

	fire(PrivateChatListener::UserUpdated(), this);
}

void PrivateChat::setTypingState(bool aTyping) noexcept {
	if (!ccReady()) {
		// No client-to-client connection: route it through the hub as a TPN instead
		// (ADC-EXT 4.18), which needs no connection of its own
		sendTypingNotificationHooked(aTyping);
		return;
	}

	callAsyncCCPM([this, aTyping] {
		sendPMInfoHooked(aTyping ? PrivateChat::TYPING_ON : PrivateChat::TYPING_OFF);
	});
}

// TPN <code>, sent directly to the other party through the hub. Codes 11 (composing) and
// 10 (active) are the two we can tell apart from a text field.
void PrivateChat::sendTypingNotificationHooked(bool aTyping) noexcept {
	auto ou = ClientManager::getInstance()->findOnlineUser(replyTo, false);
	if (!ou || !ou->getIdentity().hasSupport(OnlineUser::TYPE_FEATURE)) {
		return;
	}

	AdcCommand c(AdcCommand::CMD_TPN, ou->getIdentity().getSID(), AdcCommand::TYPE_DIRECT);
	c.addParam(aTyping ? "11" : "10");

	string error;
	ou->getClient()->sendHooked(c, this, error);
}

void PrivateChat::onTypingNotification(bool aTyping) noexcept {
	fire(PrivateChatListener::PMStatus(), this, aTyping ? PrivateChat::TYPING_ON : PrivateChat::TYPING_OFF);
}

void PrivateChat::sendPMInfoHooked(uint8_t aType) {
	auto conn = uc.load();
	if (ccReady() && conn && conn->getSupports().includes(UserConnection::FEATURE_ADC_CPMI)) {
		AdcCommand c(AdcCommand::CMD_PMI);
		switch (aType) {
		case MSG_SEEN:
			c.addParam("SN", "1");
			break;
		case TYPING_ON:
			c.addParam("TP", "1");
			break;
		case TYPING_OFF:
			c.addParam("TP", "0");
			break;
		case NO_AUTOCONNECT:
			c.addParam("AC", "0");
			break;
		case QUIT:
			c.addParam("QU", "1");
			break;
		default:
			c.addParam("\n");
		}

		conn->sendHooked(c);
	}
}

void PrivateChat::on(AdcCommand::PMI, UserConnection*, const AdcCommand& cmd) noexcept{

	auto type = PMINFO_LAST;
	string tmp;

	//We only send one flag at a time so we can do it like this.
	if (cmd.hasFlag("SN", 0)) {
		type = MSG_SEEN;
	} else if (cmd.getParam("TP", 0, tmp)) {
		type = (tmp == "1") ? TYPING_ON : TYPING_OFF;
	} else if (cmd.getParam("AC", 0, tmp)) {
		allowAutoCCPM = tmp == "1" ? true : false;
		type = NO_AUTOCONNECT;
	} else if (cmd.hasFlag("QU", 0)) {
		type = QUIT;
	}

	if (type != PMINFO_LAST)
		fire(PrivateChatListener::PMStatus(), this, type);
}

void PrivateChat::logMessage(const string& aMessage) const noexcept {
	if (SETTING(LOG_PRIVATE_CHAT)) {
		ParamMap params;
		params["message"] = aMessage;
		fillLogParams(params);
		LogManager::getInstance()->log(getUser(), params);
	}
}

void PrivateChat::fillLogParams(ParamMap& params) const noexcept {
	const CID& cid = getUser()->getCID();;
	params["hubNI"] = [&] { return Util::listToString(ClientManager::getInstance()->getHubNames(cid)); };
	params["hubURL"] = [&] { return getHubUrl(); };
	params["userCID"] = [&cid] { return cid.toBase32(); };
	params["userNI"] = [&] { return ClientManager::getInstance()->getNick(getUser(), getHubUrl()); };
	params["myCID"] = [] { return ClientManager::getInstance()->getMyCID().toBase32(); };
}

string PrivateChat::getLogPath() const noexcept {
	ParamMap params;
	fillLogParams(params);
	return LogManager::getInstance()->getPath(getUser(), params);
}

}