/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_FINISHED_MANAGER_LISTENER_H
#define DCPLUSPLUS_DCPP_FINISHED_MANAGER_LISTENER_H

#include "FinishedItem.h"

namespace dcpp {

class FinishedManagerListener {
public:
	virtual ~FinishedManagerListener() { }
	template<int I>	struct X { enum { TYPE = I }; };

	typedef X<0> AddedUl;
	typedef X<1> RemovedUl;
	typedef X<2> RemovedAllUl;

	typedef X<3> AddedDl;
	typedef X<4> RemovedDl;
	typedef X<5> RemovedAllDl;

	virtual void on(AddedUl, const FinishedItemPtr&) noexcept { }
	virtual void on(RemovedUl, const FinishedItemPtr&) noexcept { }
	virtual void on(RemovedAllUl) noexcept { }

	virtual void on(AddedDl, const FinishedItemPtr&) noexcept { }
	virtual void on(RemovedDl, const FinishedItemPtr&) noexcept { }
	virtual void on(RemovedAllDl) noexcept { }

};

} // namespace dcpp

#endif // !defined(DCPLUSPLUS_DCPP_FINISHED_MANAGER_LISTENER_H)
