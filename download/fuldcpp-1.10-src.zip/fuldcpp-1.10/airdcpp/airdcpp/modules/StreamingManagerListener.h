/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_STREAMING_MANAGER_LISTENER_H
#define DCPLUSPLUS_DCPP_STREAMING_MANAGER_LISTENER_H

#include <airdcpp/core/header/typedefs.h>

namespace dcpp {

// Value snapshot of a stream, safe to hand to the GUI thread
struct StreamSnapshot {
	enum Phase {
		PHASE_ANALYZING,	// waiting for enough data to parse the container
		PHASE_BUFFERING,	// registered, waiting for the initial buffer
		PHASE_PLAYING,		// buffered; the player has been (or can be) launched
		PHASE_STOPPED,		// stopped (idle timeout or user action), the URL is dead
		PHASE_FAILED,
	};

	string token;
	QueueToken bundleToken = 0;
	string bundleName;
	string fileName;		// inner/served file
	string url;
	Phase phase = PHASE_ANALYZING;
	int64_t size = -1;
	int64_t buffered = 0;	// contiguous bytes available from the start
	string error;
	uint64_t addedTick = 0;
	string castTargetUdn;	// empty = local player; otherwise the DLNA device to push the URL to
	string castTargetName;	// friendly name of the cast target, for display
};

class StreamingManagerListener {
public:
	virtual ~StreamingManagerListener() { }
	template<int I>	struct X { enum { TYPE = I }; };

	typedef X<0> StreamAdded;
	typedef X<1> StreamUpdated;
	typedef X<2> StreamRemoved;
	typedef X<3> StreamStarted;		// buffered and ready: launch the player against the URL
	typedef X<4> StreamFailed;

	virtual void on(StreamAdded, const StreamSnapshot&) noexcept { }
	virtual void on(StreamUpdated, const StreamSnapshot&) noexcept { }
	virtual void on(StreamRemoved, const StreamSnapshot&) noexcept { }
	virtual void on(StreamStarted, const StreamSnapshot&) noexcept { }
	virtual void on(StreamFailed, const StreamSnapshot&) noexcept { }
};

} // namespace dcpp

#endif
