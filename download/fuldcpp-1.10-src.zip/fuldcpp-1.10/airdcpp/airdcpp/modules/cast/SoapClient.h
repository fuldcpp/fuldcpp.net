/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_SOAP_CLIENT_H
#define DCPLUSPLUS_DCPP_SOAP_CLIENT_H

#include <airdcpp/core/header/typedefs.h>

namespace dcpp {

// Minimal synchronous HTTP/1.1 client for UPnP control: a GET for device-description
// XML and a SOAP POST for AVTransport actions. The shared HttpConnection can't do the
// POST (its request line is hardcoded to GET, no Content-Type/Content-Length), and a
// small self-contained plain-http client keeps this feature easy to audit. Blocking;
// call from a worker thread. http:// only (UPnP control endpoints are never https).
class SoapClient {
public:
	struct Result {
		bool ok = false;
		int httpStatus = 0;
		string body;		// response body (description XML, SOAP result, or a UPnPError fault)
		string error;		// human-readable failure reason (network/parse/fault)
	};

	// GET an absolute http:// URL.
	static Result get(const string& aUrl) noexcept;

	// Send a SOAP action to an absolute http:// control URL.
	// aServiceType e.g. "urn:schemas-upnp-org:service:AVTransport:1", aAction e.g. "Play".
	// aBodyXml is the inner action element (<u:Action ...>...</u:Action>).
	static Result invoke(const string& aControlUrl, const string& aServiceType, const string& aAction, const string& aBodyXml) noexcept;

	/*
	 * Split an absolute http:// URL into host / port / path. False if it is not a
	 * usable http URL.
	 *
	 * Rejects control characters anywhere in the URL. Every component below is
	 * interpolated straight into a request line or a header, and control URLs come
	 * from device-description XML - which SimpleXMLReader passes through verbatim,
	 * newlines included - so without this a hostile descriptor could inject headers
	 * or a second request.
	 *
	 * Public so callers can validate a URL's host against the address that
	 * advertised it without re-implementing the parse (see CastManager).
	 */
	static bool parseUrl(const string& aUrl, string& host_, string& port_, string& path_) noexcept;
};

} // namespace dcpp

#endif
