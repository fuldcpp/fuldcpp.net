/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include "CastManager.h"

#include "SoapClient.h"
#include "SsdpDiscovery.h"

#include <airdcpp/modules/StreamSource.h>
#include <airdcpp/modules/StreamingManager.h>

#include <airdcpp/core/classes/ScopedFunctor.h>
#include <airdcpp/core/io/xml/SimpleXML.h>
#include <airdcpp/core/io/xml/SimpleXMLReader.h>
#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/util/NetworkUtil.h>
#include <airdcpp/util/text/Text.h>
#include <airdcpp/util/Util.h>

namespace dcpp {

namespace {
	const string AVTRANSPORT = "urn:schemas-upnp-org:service:AVTransport:1";
	const uint64_t DEVICE_TTL = 5 * 60 * 1000;	// forget devices not seen for 5 min
	const uint64_t SSDP_TIMEOUT = 3000;

	// Bounds on hostile input: a description fetch costs seconds, and the device
	// list is deep-copied on the UI thread every time the cast menu opens.
	const size_t MAX_DEVICES = 16;
	const size_t MAX_NAME_LEN = 64;

	// A LAN attacker can forge the SOURCE ADDRESS of an SSDP reply, so "the URL matches
	// whoever answered" is only as strong as the network's anti-spoofing: spoofing the
	// router's IP and pointing LOCATION at a state-changing path on it still passes, and
	// the client then issues that GET from the user's machine. These two extra checks cost
	// nothing against real renderers, which live on the LAN and speak HTTP on a high port.
	bool isAllowedDevicePort(const string& aPort) noexcept {
		const auto port = Util::toInt(aPort);
		if (port <= 0 || port > 65535) {
			return false;
		}

		// Well-known service ports are never where a MediaRenderer listens, but they are
		// exactly what an attacker would aim a forged LOCATION at.
		static const int blocked[] = { 21, 22, 23, 25, 53, 110, 135, 139, 143, 389, 445, 465,
			587, 993, 995, 1433, 3306, 3389, 5432, 5900, 6379, 11211, 27017 };
		for (auto b : blocked) {
			if (port == b) {
				return false;
			}
		}

		return true;
	}

	/*
	 * True when aUrl is an http URL whose host is exactly aAddress.
	 *
	 * Everything in a UPnP discovery is attacker-supplied: the SSDP reply is an
	 * unauthenticated UDP packet, and the description XML comes from whatever it
	 * named. Without this the client can be pointed at 127.0.0.1, a router admin
	 * page or any internal service - and both LOCATION and the descriptor's own
	 * URLBase/controlURL are separate ways to do it, so every URL is checked
	 * against the address that actually answered.
	 *
	 * Hostnames are refused rather than resolved: real renderers advertise IP
	 * literals, and resolving would hand the attacker a DNS-rebinding lever.
	 */
	bool isFromDevice(const string& aUrl, const string& aAddress) noexcept {
		string host, port, path;
		if (!SoapClient::parseUrl(aUrl, host, port, path)) {
			return false;
		}

		// Compared as addresses, not as text. The address that answered comes from
		// getnameinfo, which attaches a zone to a link-local IPv6 one ("fe80::1%14"),
		// while the LOCATION URL carries the same address without it - so an IPv6
		// renderer failed this check every time even though the two were identical.
		if (aAddress.empty() || !NetworkUtil::isSameAddress(host, aAddress)) {
			return false;
		}

		// A renderer lives on the local network. Requiring that rules out being pointed
		// at loopback or at some host on the internet, and a global IPv6 address is no
		// loss: a reply to a link-local scoped search carries a link-local source, and
		// the URL has to name that same address, so one could never get this far.
		return NetworkUtil::isLanAddress(host) && isAllowedDevicePort(port);
	}

	// Resolve a possibly-relative service URL against the description location / URLBase
	string resolveUrl(const string& aBase, const string& aRef) noexcept {
		if (aRef.empty()) {
			return Util::emptyString;
		}

		// Case-insensitive: an "HTTP://..." or "https://..." ref would otherwise be
		// treated as relative and concatenated onto the base.
		const auto lowerRef = Text::toLower(aRef);
		if (lowerRef.compare(0, 7, "http://") == 0 || lowerRef.compare(0, 8, "https://") == 0) {
			return aRef;
		}

		// origin = scheme://host:port of the base
		auto schemeEnd = aBase.find("://");
		if (schemeEnd == string::npos) {
			return aRef;
		}

		auto authStart = schemeEnd + 3;
		auto pathStart = aBase.find('/', authStart);
		auto origin = pathStart == string::npos ? aBase : aBase.substr(0, pathStart);

		if (!aRef.empty() && aRef[0] == '/') {
			return origin + aRef;
		}

		// relative to the base directory
		auto dirEnd = aBase.rfind('/');
		auto dir = dirEnd == string::npos || dirEnd < authStart ? origin + "/" : aBase.substr(0, dirEnd + 1);
		return dir + aRef;
	}

	/*
	 * friendlyName is attacker-controlled text that ends up as a menu item label.
	 * Bound it and strip anything that isn't printable: the raw value is limited
	 * only by the XML value/response caps (tens of KB), and embedded control
	 * characters render as garbage in a menu.
	 */
	string sanitizeName(const string& aName) noexcept {
		string ret;
		ret.reserve(std::min<size_t>(aName.size(), MAX_NAME_LEN));
		for (auto c : aName) {
			if (ret.size() >= MAX_NAME_LEN) {
				break;
			}

			const auto uc = static_cast<unsigned char>(c);
			// Keep UTF-8 continuation bytes; drop C0/DEL.
			if (uc < 0x20 || uc == 0x7f) {
				continue;
			}
			ret += c;
		}

		return ret.empty() ? string("Unnamed device") : ret;
	}

	// XML entity-escape for building DIDL / SOAP text
	string xmlEscape(const string& aStr) noexcept {
		string ret;
		ret.reserve(aStr.size());
		for (auto c : aStr) {
			switch (c) {
				case '&': ret += "&amp;"; break;
				case '<': ret += "&lt;"; break;
				case '>': ret += "&gt;"; break;
				case '"': ret += "&quot;"; break;
				case '\'': ret += "&apos;"; break;
				default: ret += c;
			}
		}
		return ret;
	}
}

// SAX walker: grab the first friendlyName and the controlURL paired with an AVTransport service
class DescriptionParser : public SimpleXMLReader::CallBack {
public:
	string friendlyName;
	string urlBase;
	string avControlUrl;

	void startTag(const string& aName, StringPairList&, bool) override {
		current = Text::toLower(aName);
		if (current == "service") {
			svcType.clear();
			svcControl.clear();
			inService = true;
		}
	}

	void data(const string& aData) override {
		// Keep only the first friendlyName (the root device's), but accumulate all of its
		// chunks - SAX may deliver the text of one element across several data() callbacks.
		if (current == "friendlyname" && !haveFriendlyName) {
			friendlyName += aData;
		} else if (current == "urlbase") {
			urlBase += aData;
		} else if (inService && current == "servicetype") {
			svcType += aData;
		} else if (inService && current == "controlurl") {
			svcControl += aData;
		}
	}

	void endTag(const string& aName) override {
		auto name = Text::toLower(aName);
		if (name == "friendlyname") {
			haveFriendlyName = !friendlyName.empty();
		} else if (name == "service") {
			if (avControlUrl.empty() && svcType.find("AVTransport") != string::npos) {
				avControlUrl = svcControl;
			}
			inService = false;
		}
		current.clear();
	}

private:
	string current;
	string svcType;
	string svcControl;
	bool inService = false;
	bool haveFriendlyName = false;
};

bool CastManager::parseDescription(const string& aXml, const string& aLocation, const string& aAddress, DlnaDevice& device_) noexcept {
	DescriptionParser parser;
	try {
		SimpleXMLReader(&parser).parse(aXml);
	} catch (const Exception&) {
		return false;
	}

	if (parser.avControlUrl.empty()) {
		return false;
	}

	// URLBase comes from the same untrusted document as controlURL and can move the
	// origin somewhere else entirely, so the *resolved* URL is what gets checked -
	// validating LOCATION alone would leave this second path wide open.
	const auto base = parser.urlBase.empty() ? aLocation : parser.urlBase;
	device_.controlUrl = resolveUrl(base, parser.avControlUrl);
	if (device_.controlUrl.empty() || !isFromDevice(device_.controlUrl, aAddress)) {
		return false;
	}

	device_.serviceType = AVTRANSPORT;
	device_.friendlyName = sanitizeName(parser.friendlyName.empty() ? aLocation : parser.friendlyName);
	return true;
}

void CastManager::refreshDevices() noexcept {
	if (!SETTING(CAST_ENABLED)) {
		return;
	}

	// Counted for the whole function: it runs on a threaded task and keeps touching this
	// object (joining `previous`, then re-locking) after the member pointer has been
	// nulled, which is precisely the window shutdown() used to miss.
	++activeOperations;
	ScopedFunctor([this] { --activeOperations; });

	unique_ptr<DiscoveryThread> previous;
	{
		Lock l(cs);

		// Re-checked under the lock. Testing it outside only was a race with
		// shutdown(): the flag could be set, shutdown() could find no thread to
		// join, and this could then start one that outlives the object -
		// Thread's destructor closes the handle but does not join.
		if (shuttingDown || discovering) {
			return;
		}

		// Move the finished predecessor out and join it *after* releasing cs.
		// Joining under the lock deadlocks against anything the worker does that
		// needs cs on its way out.
		previous = std::move(discovery);
		discovering = true;
	}

	if (previous) {
		previous->join();
		previous.reset();
	}

	Lock l(cs);
	if (shuttingDown) {
		discovering = false;
		return;
	}

	try {
		discovery = make_unique<DiscoveryThread>(this);
	} catch (const ThreadException& e) {
		// Thread::start() throws; this function is noexcept, so letting it escape
		// would terminate. Leaving `discovering` true would also disable discovery
		// for the rest of the session.
		discovering = false;
		dcdebug("CastManager: could not start discovery: %s\n", e.getError().c_str());
	}
}

int CastManager::DiscoveryThread::run() noexcept {
	owner->runDiscovery();
	return 0;
}

void CastManager::runDiscovery() noexcept {
	// Counted for the whole run, including the trailing fire() below -- which happens
	// AFTER `discovering` has been cleared, so that flag alone never proved the thread had
	// finished touching this object (or its Speaker).
	++activeOperations;
	ScopedFunctor([this] { --activeOperations; });

	auto responses = SsdpDiscovery::search(AVTRANSPORT, SSDP_TIMEOUT);

	vector<DlnaDevice> found;
	for (const auto& r : responses) {
		if (shuttingDown || found.size() >= MAX_DEVICES) {
			break;
		}

		// The reply is unauthenticated UDP, so LOCATION is whatever the sender chose.
		// Fetching it blind is a server-side request forgery: 127.0.0.1, a router
		// admin page, any internal host. Only talk to the address that answered.
		if (!isFromDevice(r.location, r.address)) {
			dcdebug("CastManager: ignoring SSDP reply from %s advertising %s\n",
				r.address.c_str(), r.location.c_str());
			continue;
		}

		auto res = SoapClient::get(r.location);
		if (!res.ok) {
			continue;
		}

		DlnaDevice d;
		d.udn = r.usn.empty() ? r.location : r.usn;
		d.location = r.location;
		d.lastSeen = GET_TICK();
		if (parseDescription(res.body, r.location, r.address, d)) {
			found.push_back(std::move(d));
		}
	}

	{
		Lock l(cs);
		const auto now = GET_TICK();

		// Merge: refresh/replace found devices, drop expired ones
		for (auto& f : found) {
			auto i = ranges::find_if(devices, [&](const DlnaDevice& e) { return e.udn == f.udn; });
			if (i != devices.end()) {
				*i = f;
			} else {
				devices.push_back(f);
			}
		}

		devices.erase(std::remove_if(devices.begin(), devices.end(), [&](const DlnaDevice& e) {
			return now - e.lastSeen > DEVICE_TTL;
		}), devices.end());

		discovering = false;
	}

	if (!shuttingDown) {
		fire(CastManagerListener::DevicesUpdated());
	}
}

vector<DlnaDevice> CastManager::getDevices() const noexcept {
	Lock l(cs);
	const auto now = GET_TICK();
	vector<DlnaDevice> ret;
	for (const auto& d : devices) {
		if (now - d.lastSeen <= DEVICE_TTL) {
			ret.push_back(d);
		}
	}

	return ret;
}

optional<DlnaDevice> CastManager::findDevice(const string& aUdn) const noexcept {
	Lock l(cs);
	auto i = ranges::find_if(devices, [&](const DlnaDevice& e) { return e.udn == aUdn; });
	return i != devices.end() ? optional(*i) : nullopt;
}

void CastManager::cast(const string& aUdn, const string& aStreamUrl, const string& aTitle) noexcept {
	if (!SETTING(CAST_ENABLED)) {
		return;
	}

	auto device = findDevice(aUdn);
	if (!device) {
		// Logged as well as fired: nothing currently subscribes to the listener, so
		// firing alone means the user clicks "Cast to..." and gets no feedback at all.
		LogManager::getInstance()->message(STRING(CAST_DEVICE_GONE),
			LogMessage::SEV_ERROR, STRING(STREAMING));
		fire(CastManagerListener::CastFailed(), STRING(CAST_DEVICE_GONE));
		return;
	}

	// The stream URL was built when the stream started, before this device was chosen, so
	// it names one address of one family. Swap in one this device can actually open - an
	// IPv6-only renderer has no way to reach an IPv4 URL, and it would simply report a
	// failure of its own that says nothing about the cause.
	string deviceHost, devicePort, devicePath;
	if (!SoapClient::parseUrl(device->controlUrl, deviceHost, devicePort, devicePath)) {
		fire(CastManagerListener::CastFailed(), STRING(CAST_DEVICE_GONE));
		return;
	}

	const auto streamUrl = StreamingManager::getInstance()->adaptStreamUrlForPeer(aStreamUrl, deviceHost);
	if (streamUrl.empty()) {
		LogManager::getInstance()->message(STRING(CAST_NO_MATCHING_ADDRESS),
			LogMessage::SEV_ERROR, STRING(STREAMING));
		fire(CastManagerListener::CastFailed(), STRING(CAST_NO_MATCHING_ADDRESS));
		return;
	}

	// DLNA content advertisement: OP=01 (range seek allowed), streaming flags
	const auto mime = StreamSource::getMimeType(aTitle);
	const auto protocolInfo = "http-get:*:" + mime + ":DLNA.ORG_OP=01;DLNA.ORG_FLAGS=01700000000000000000000000000000";
	const auto escapedUrl = xmlEscape(streamUrl);
	const auto didl =
		"<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" "
		"xmlns:dc=\"http://purl.org/dc/elements/1.1/\" "
		"xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">"
		"<item id=\"0\" parentID=\"-1\" restricted=\"1\">"
		"<dc:title>" + xmlEscape(aTitle) + "</dc:title>"
		"<upnp:class>object.item.videoItem</upnp:class>"
		"<res protocolInfo=\"" + xmlEscape(protocolInfo) + "\">" + escapedUrl + "</res>"
		"</item></DIDL-Lite>";

	const auto setUri =
		"<u:SetAVTransportURI xmlns:u=\"" + device->serviceType + "\">"
		"<InstanceID>0</InstanceID>"
		"<CurrentURI>" + escapedUrl + "</CurrentURI>"
		"<CurrentURIMetaData>" + xmlEscape(didl) + "</CurrentURIMetaData>"
		"</u:SetAVTransportURI>";

	auto r1 = SoapClient::invoke(device->controlUrl, device->serviceType, "SetAVTransportURI", setUri);
	if (!r1.ok) {
		const auto msg = device->friendlyName + ": " + r1.error;
		LogManager::getInstance()->message(STRING_F(CAST_FAILED, msg), LogMessage::SEV_ERROR, STRING(STREAMING));
		fire(CastManagerListener::CastFailed(), msg);
		return;
	}

	const auto play =
		"<u:Play xmlns:u=\"" + device->serviceType + "\">"
		"<InstanceID>0</InstanceID><Speed>1</Speed></u:Play>";

	auto r2 = SoapClient::invoke(device->controlUrl, device->serviceType, "Play", play);
	if (!r2.ok) {
		const auto msg = device->friendlyName + ": " + r2.error;
		LogManager::getInstance()->message(STRING_F(CAST_FAILED, msg), LogMessage::SEV_ERROR, STRING(STREAMING));
		fire(CastManagerListener::CastFailed(), msg);
		return;
	}

	LogManager::getInstance()->message(STRING_F(CAST_STARTED, device->friendlyName), LogMessage::SEV_INFO, STRING(STREAMING));
	fire(CastManagerListener::CastSucceeded(), device->friendlyName);
}

void CastManager::stopDevice(const string& aUdn) noexcept {
	if (!SETTING(CAST_ENABLED)) {
		return;
	}

	auto device = findDevice(aUdn);
	if (!device) {
		return;
	}

	const auto stop =
		"<u:Stop xmlns:u=\"" + device->serviceType + "\">"
		"<InstanceID>0</InstanceID></u:Stop>";

	SoapClient::invoke(device->controlUrl, device->serviceType, "Stop", stop);
}

void CastManager::shutdown() noexcept {
	// Deliberately not exchange-and-return-early: this is called from both
	// WinClient's unload step and the destructor, and a discovery thread can be
	// started between the two. Returning early on the second call would leave that
	// thread running against a destroyed object.
	shuttingDown = true;

	for (;;) {
		unique_ptr<DiscoveryThread> t;
		{
			Lock l(cs);
			t = std::move(discovery);
			if (!t) {
				// Nothing outstanding in the MEMBER. That is not the same as nothing
				// running: refreshDevices() moves the previous thread into a local before
				// releasing cs, and runDiscovery() clears `discovering` before its closing
				// fire() -- so both leave windows where the member is null while code is
				// still executing against this object. Wait on the operation counter
				// instead of inferring liveness from the pointer.
				discovering = false;
				break;
			}
		}

		// Bounded by the SSDP window plus at most one in-flight description fetch;
		// runDiscovery checks shuttingDown between fetches so it stops early.
		t->join();
	}

	// Bounded, like the other shutdown waits: a wedged responder must not hang exit.
	for (int i = 0; activeOperations > 0 && i < 100; ++i) {
		Thread::sleep(100);
	}

	dcassert(activeOperations == 0);
}

} // namespace dcpp
