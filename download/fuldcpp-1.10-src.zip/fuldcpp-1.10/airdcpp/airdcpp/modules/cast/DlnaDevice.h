/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_DLNA_DEVICE_H
#define DCPLUSPLUS_DCPP_DLNA_DEVICE_H

#include <airdcpp/core/header/typedefs.h>

namespace dcpp {

// A discovered UPnP-AV MediaRenderer we can push a stream to
struct DlnaDevice {
	string udn;				// unique device name (USN), the stable id used by the UI/cast calls
	string friendlyName;	// human-readable name shown in the menu
	string controlUrl;		// absolute URL of the AVTransport service control endpoint
	string serviceType;		// AVTransport service type (for the SOAPAction header)
	string location;		// the description URL the device advertised
	uint64_t lastSeen = 0;	// GET_TICK of the last SSDP reply, for TTL expiry
};

} // namespace dcpp

#endif
