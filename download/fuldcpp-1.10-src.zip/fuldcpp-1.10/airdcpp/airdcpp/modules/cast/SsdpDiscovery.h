/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_SSDP_DISCOVERY_H
#define DCPLUSPLUS_DCPP_SSDP_DISCOVERY_H

#include <airdcpp/core/header/typedefs.h>

namespace dcpp {

// SSDP M-SEARCH discovery of UPnP-AV MediaRenderers. Sends the search to the SSDP
// multicast group and collects the unicast replies; blocking, run it on a worker thread.
class SsdpDiscovery {
public:
	struct Response {
		string location;	// device description URL (SSDP LOCATION header)
		string usn;			// unique service name (SSDP USN header)
		// Address the reply actually came from. LOCATION is attacker-chosen - anyone
		// on the LAN can answer an M-SEARCH - so a caller must check that the URL it
		// is about to fetch points back at the responder rather than at, say,
		// 127.0.0.1 or an internal service.
		string address;
	};

	// Search for aSearchTarget (an SSDP ST value) for roughly aTimeoutMs. Returns the
	// unique (by USN) responses. Never throws.
	static vector<Response> search(const string& aSearchTarget, uint64_t aTimeoutMs) noexcept;
};

} // namespace dcpp

#endif
