/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include "SoapClient.h"

#include <airdcpp/connection/socket/AddressInfo.h>
#include <airdcpp/connection/socket/Socket.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/util/text/Text.h>
#include <airdcpp/util/NetworkUtil.h>
#include <airdcpp/util/Util.h>

namespace dcpp {

namespace {
	const uint64_t CONNECT_TIMEOUT = 5000;
	const uint64_t IO_TIMEOUT = 8000;
	const size_t MAX_RESPONSE = 256 * 1024;

	// Anything the HTTP layer would treat as structure. A control URL arrives inside
	// device-description XML, which SimpleXMLReader hands over verbatim (it does not
	// normalize newlines), so a CR or LF here becomes a header break on the wire.
	bool hasControlChars(const string& aStr) noexcept {
		return ranges::any_of(aStr, [](char c) {
			const auto uc = static_cast<unsigned char>(c);
			return uc < 0x20 || uc == 0x7f;
		});
	}

	// Perform a fully-formed HTTP request against the host/port parsed from aUrl.
	SoapClient::Result send(const string& aUrl, const std::function<string(const string& aHost, const string& aPort, const string& aPath)>& aBuildRequest) noexcept {
		SoapClient::Result res;

		string host, port, path;
		if (!SoapClient::parseUrl(aUrl, host, port, path)) {
			res.error = "Invalid or unsafe URL";
			return res;
		}

		const auto request = aBuildRequest(host, port, path);

		try {
			Socket sock(Socket::TYPE_TCP);
			sock.setBlocking(false);
			sock.connect(AddressInfo(host, AddressInfo::TYPE_URL), port);
			if (!sock.waitConnected(CONNECT_TIMEOUT)) {
				res.error = "Connection timed out";
				return res;
			}

			size_t sent = 0;
			const auto sendStart = GET_TICK();
			while (sent < request.size()) {
				if (GET_TICK() - sendStart > IO_TIMEOUT) {
					res.error = "Timed out sending the request";
					return res;
				}

				auto [_, canWrite] = sock.wait(500, false, true);
				if (!canWrite) {
					continue;
				}

				auto n = sock.write(request.data() + sent, request.size() - sent);
				if (n > 0) {
					sent += static_cast<size_t>(n);
				}
			}

			string response;
			const auto readStart = GET_TICK();
			char buf[4096];
			// -1 until the headers have been seen; then the exact body length, so a
			// renderer that ignores "Connection: close" doesn't cost the full IO
			// timeout on every call (two calls per cast, so 16s of dead wait).
			int64_t expectedTotal = -1;
			while (response.size() < MAX_RESPONSE) {
				if (expectedTotal >= 0 && static_cast<int64_t>(response.size()) >= expectedTotal) {
					break;
				}

				if (GET_TICK() - readStart > IO_TIMEOUT) {
					break;
				}

				auto [canRead, _] = sock.wait(500, true, false);
				if (!canRead) {
					continue;
				}

				auto n = sock.read(buf, sizeof(buf));
				if (n == 0) {
					break; // peer closed (we always ask for Connection: close)
				}

				if (n > 0) {
					response.append(buf, static_cast<size_t>(n));
				}

				if (expectedTotal < 0) {
					if (auto headerEnd = response.find("\r\n\r\n"); headerEnd != string::npos) {
						// Header names are case-insensitive, but the search must run over the
						// ORIGINAL buffer. Locating the offset in a Text::toLower copy and then
						// indexing the original is unsafe: toLower is not length-preserving (each
						// invalid UTF-8 byte expands to a 3-byte U+FFFD), so the copy can be
						// longer and the offset can drift past the value -- or past the end of
						// the original entirely, throwing out of this noexcept function.
						static const string needle = "\r\ncontent-length:";
						const auto headEnd = response.begin() + static_cast<ptrdiff_t>(headerEnd);
						const auto it = std::search(
							response.begin(), headEnd, needle.begin(), needle.end(),
							[](char a, char b) {
								return std::tolower(static_cast<unsigned char>(a)) == std::tolower(static_cast<unsigned char>(b));
							}
						);

						if (it != headEnd) {
							const auto valueStart = static_cast<size_t>(std::distance(response.begin(), it)) + needle.size();
							const auto valueEnd = response.find("\r\n", valueStart);
							const auto len = Util::toInt64(response.substr(valueStart,
								valueEnd == string::npos ? string::npos : valueEnd - valueStart));
							if (len >= 0) {
								expectedTotal = static_cast<int64_t>(headerEnd + 4) + len;
							}
						}
					}
				}
			}

			if (response.empty()) {
				res.error = "No response";
				return res;
			}

			if (auto lineEnd = response.find("\r\n"); lineEnd != string::npos) {
				auto statusLine = response.substr(0, lineEnd);
				if (auto sp = statusLine.find(' '); sp != string::npos) {
					res.httpStatus = Util::toInt(statusLine.substr(sp + 1));
				}
			}

			if (auto bodyPos = response.find("\r\n\r\n"); bodyPos != string::npos) {
				res.body = response.substr(bodyPos + 4);
			}

			res.ok = res.httpStatus == 200;
			if (!res.ok && res.error.empty()) {
				res.error = "HTTP " + Util::toString(res.httpStatus);
			}

			// A renderer may refuse an action and still answer 200 with a SOAP fault
			// body. Treating that as success made the client log "playing on <device>"
			// when nothing was playing, which is worse than a plain failure.
			if (res.ok && res.body.find("UPnPError") != string::npos) {
				res.ok = false;
				auto code = res.body.find("<errorCode>");
				res.error = code == string::npos
					? string("The device rejected the request")
					: "The device rejected the request (UPnP error "
						+ Util::toString(Util::toInt(res.body.substr(code + 11))) + ")";
			}
		} catch (const Exception& e) {
			res.error = e.getError();
		}

		return res;
	}
}

bool SoapClient::parseUrl(const string& aUrl, string& host_, string& port_, string& path_) noexcept {
	static const string scheme = "http://";
	if (aUrl.compare(0, scheme.size(), scheme) != 0) {
		return false;
	}

	// Checked on the whole URL first, so nothing hostile survives in any component.
	if (hasControlChars(aUrl)) {
		return false;
	}

	auto rest = aUrl.substr(scheme.size());
	auto slash = rest.find('/');
	auto authority = slash == string::npos ? rest : rest.substr(0, slash);
	path_ = slash == string::npos ? "/" : rest.substr(slash);

	// Userinfo would let "evil.com@10.0.0.1" read as one host to a human and another
	// to the parser; UPnP never uses it, so refuse rather than guess.
	if (authority.find('@') != string::npos) {
		return false;
	}

	if (!authority.empty() && authority[0] == '[') {
		// Bracketed IPv6 literal, "[::1]" or "[::1]:8080". Previously this fell into
		// the multiple-colons branch below and became a host of "[::1]:8080" with
		// port 80, so IPv6 renderers could never work at all.
		const auto close = authority.find(']');
		if (close == string::npos) {
			return false;
		}

		host_ = authority.substr(1, close - 1);
		const auto after = authority.substr(close + 1);
		if (after.empty()) {
			port_ = "80";
		} else if (after[0] == ':') {
			port_ = after.substr(1);
		} else {
			return false;
		}
	} else if (const auto colon = authority.rfind(':');
			colon != string::npos && authority.find(':') == colon) {
		host_ = authority.substr(0, colon);
		port_ = authority.substr(colon + 1);
	} else if (authority.find(':') != string::npos) {
		// Multiple colons and no brackets: an unbracketed IPv6 literal, which is not
		// a legal authority. Refuse rather than guess where the port ends.
		return false;
	} else {
		host_ = authority;
		port_ = "80";
	}

	if (host_.empty() || port_.empty()) {
		return false;
	}

	// A non-numeric port would end up in the Host header verbatim.
	if (!ranges::all_of(port_, [](char c) { return c >= '0' && c <= '9'; })) {
		return false;
	}

	return true;
}

SoapClient::Result SoapClient::get(const string& aUrl) noexcept {
	return send(aUrl, [](const string& aHost, const string& aPort, const string& aPath) {
		return "GET " + aPath + " HTTP/1.1\r\n"
			"HOST: " + NetworkUtil::formatAuthority(aHost, aPort) + "\r\n"
			"USER-AGENT: FulDC++ UPnP/1.0\r\n"
			"CONNECTION: close\r\n\r\n";
	});
}

SoapClient::Result SoapClient::invoke(const string& aControlUrl, const string& aServiceType, const string& aAction, const string& aBodyXml) noexcept {
	const auto envelope =
		"<?xml version=\"1.0\" encoding=\"utf-8\"?>"
		"<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" "
		"s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
		"<s:Body>" + aBodyXml + "</s:Body></s:Envelope>";

	return send(aControlUrl, [&](const string& aHost, const string& aPort, const string& aPath) {
		return "POST " + aPath + " HTTP/1.1\r\n"
			"HOST: " + NetworkUtil::formatAuthority(aHost, aPort) + "\r\n"
			"CONTENT-TYPE: text/xml; charset=\"utf-8\"\r\n"
			"SOAPACTION: \"" + aServiceType + "#" + aAction + "\"\r\n"
			"CONTENT-LENGTH: " + Util::toString(envelope.size()) + "\r\n"
			"USER-AGENT: FulDC++ UPnP/1.0\r\n"
			"CONNECTION: close\r\n\r\n" + envelope;
	});
}

} // namespace dcpp
