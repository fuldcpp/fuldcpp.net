/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_CAST_MANAGER_LISTENER_H
#define DCPLUSPLUS_DCPP_CAST_MANAGER_LISTENER_H

#include <airdcpp/core/header/typedefs.h>

namespace dcpp {

class CastManagerListener {
public:
	virtual ~CastManagerListener() { }
	template<int I>	struct X { enum { TYPE = I }; };

	typedef X<0> DevicesUpdated;	// the discovered-device list changed
	typedef X<1> CastSucceeded;		// SetAVTransportURI + Play accepted (aData = friendly name)
	typedef X<2> CastFailed;		// aData = error text

	virtual void on(DevicesUpdated) noexcept { }
	virtual void on(CastSucceeded, const string& /*aDeviceName*/) noexcept { }
	virtual void on(CastFailed, const string& /*aError*/) noexcept { }
};

} // namespace dcpp

#endif
