/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_CAST_MANAGER_H
#define DCPLUSPLUS_DCPP_CAST_MANAGER_H

#include <airdcpp/core/Singleton.h>
#include <airdcpp/core/Speaker.h>
#include <airdcpp/core/thread/CriticalSection.h>
#include <airdcpp/core/thread/Thread.h>

#include "CastManagerListener.h"
#include "DlnaDevice.h"

namespace dcpp {

// Discovers UPnP-AV MediaRenderers on the LAN and pushes a stream URL to a chosen one
// (SetAVTransportURI + Play). Casting is gated by SETTING(CAST_ENABLED); nothing here runs
// SSDP or exposes anything unless the user opted in.
class CastManager : public Singleton<CastManager>, public Speaker<CastManagerListener> {
public:
	// Kick off a background SSDP discovery (no-op if one is already running or casting is off).
	// Fires DevicesUpdated when the device list changes.
	void refreshDevices() noexcept;

	// Snapshot of the currently-known, non-expired devices (safe for the UI thread).
	vector<DlnaDevice> getDevices() const noexcept;

	// Push aStreamUrl to the renderer identified by aUdn (SetAVTransportURI + Play).
	// The MIME type is derived from aTitle. Blocking network I/O - call from a worker thread.
	// Fires CastSucceeded / CastFailed.
	void cast(const string& aUdn, const string& aStreamUrl, const string& aTitle) noexcept;

	// Ask the renderer to stop. Blocking; best-effort.
	void stopDevice(const string& aUdn) noexcept;

	void shutdown() noexcept;

private:
	friend class Singleton<CastManager>;
	CastManager() { }
	~CastManager() override { shutdown(); }

	// Worker that runs one SSDP + description-fetch pass
	class DiscoveryThread : public Thread {
	public:
		explicit DiscoveryThread(CastManager* aOwner) : owner(aOwner) { start(); }
		int run() noexcept override;
	private:
		CastManager* owner;
	};

	void runDiscovery() noexcept;
	optional<DlnaDevice> findDevice(const string& aUdn) const noexcept;

	// Parse a UPnP device-description XML; fills friendlyName + absolute AVTransport controlUrl.
	// Returns false if no AVTransport service is present.
	// aAddress is the IP the SSDP reply came from; the resolved control URL must
	// point back at it (URLBase in the document can otherwise redirect it anywhere).
	static bool parseDescription(const string& aXml, const string& aLocation, const string& aAddress, DlnaDevice& device_) noexcept;

	mutable CriticalSection cs;
	vector<DlnaDevice> devices;
	unique_ptr<DiscoveryThread> discovery;
	bool discovering = false;
	std::atomic<bool> shuttingDown { false };

	// Operations currently executing against this object (refreshDevices and the discovery
	// run itself). Neither the `discovery` pointer nor the `discovering` flag is a reliable
	// liveness signal: refreshDevices moves the pointer into a local before releasing cs,
	// and runDiscovery clears the flag before its final fire(). shutdown() waits on this.
	std::atomic<int> activeOperations { 0 };
};

} // namespace dcpp

#endif
