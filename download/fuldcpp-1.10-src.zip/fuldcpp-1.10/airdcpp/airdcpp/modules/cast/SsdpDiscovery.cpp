/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include "SsdpDiscovery.h"

#include <airdcpp/connection/socket/Socket.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/util/NetworkUtil.h>
#include <airdcpp/util/text/Text.h>
#include <airdcpp/util/Util.h>

namespace dcpp {

namespace {
	const string SSDP_ADDR = "239.255.255.250";
	// SSDP is defined for both families. A renderer reachable only over IPv6 answers on
	// the link-local scope group and never on the IPv4 one, so searching v4 alone cannot
	// find it. ff05::c (site scope) is deliberately not searched: renderers are on the
	// local link, and the wider scope only invites replies from further away.
	const string SSDP_ADDR6 = "ff02::c";
	const string SSDP_PORT = "1900";

	// Far more renderers than any real network has. Bounds the work the caller does
	// afterwards (one HTTP fetch per response) when the replies are hostile.
	const size_t MAX_RESPONSES = 32;

	/*
	 * Every address an M-SEARCH has to be sent to: the IPv4 group, plus the IPv6
	 * link-local group once per interface that has IPv6 enabled.
	 *
	 * Link-local multicast has to name the interface it leaves through - there is no
	 * route to ff02::c, so an unscoped send either fails outright or picks one
	 * arbitrary interface. Every interface with IPv6 enabled has a link-local address,
	 * and getnameinfo returns those with the zone already attached ("fe80::1%14"), so
	 * the zone ids are in the adapter list and need not be looked up separately.
	 */
	StringList getSearchTargets() noexcept {
		StringList ret { SSDP_ADDR };

		unordered_set<string> zones;
		for (const auto& adapter : NetworkUtil::getNetworkAdapters(true)) {
			const auto sep = adapter.ip.find('%');
			if (sep != string::npos && sep + 1 < adapter.ip.size() && Text::toLower(adapter.ip).starts_with("fe80")) {
				zones.insert(adapter.ip.substr(sep + 1));
			}
		}

		for (const auto& zone: zones) {
			ret.push_back(SSDP_ADDR6 + "%" + zone);
		}

		return ret;
	}

	// The M-SEARCH for one target. The HOST header has to name the group the datagram
	// actually goes to, and an IPv6 group has to be bracketed there; the zone is a
	// purely local label and means nothing to the receiver, so it is left off.
	string buildSearch(const string& aTarget, const string& aSearchTarget) noexcept {
		const auto group = aTarget.substr(0, aTarget.find('%'));
		return "M-SEARCH * HTTP/1.1\r\n"
			"HOST: " + NetworkUtil::formatAuthority(group, SSDP_PORT) + "\r\n"
			"MAN: \"ssdp:discover\"\r\n"
			"MX: 2\r\n"
			"ST: " + aSearchTarget + "\r\n"
			"USER-AGENT: FulDC++ UPnP/1.0\r\n\r\n";
	}

	string trimCopy(const string& aStr) noexcept {
		auto first = aStr.find_first_not_of(" \t\r\n");
		if (first == string::npos) {
			return Util::emptyString;
		}

		auto last = aStr.find_last_not_of(" \t\r\n");
		return aStr.substr(first, last - first + 1);
	}

	// Case-insensitively read a single-line SSDP/HTTP header value.
	//
	// The search runs directly over aResponse rather than over a lowercased copy. Text::toLower
	// is NOT length-preserving: on Windows it round-trips through MultiByteToWideChar without
	// MB_ERR_INVALID_CHARS, so every invalid UTF-8 byte becomes a 3-byte U+FFFD and the copy
	// grows. An offset found in that copy could therefore point past the end of the original,
	// and aResponse.substr() would throw std::out_of_range out of this noexcept function --
	// std::terminate, triggerable by one unauthenticated UDP datagram to our SSDP port.
	// Header names are ASCII, so a byte-wise ASCII comparison is the correct one here.
	string getHeader(const string& aResponse, const string& aName) noexcept {
		const auto needle = "\r\n" + aName + ":";
		const auto it = std::search(
			aResponse.begin(), aResponse.end(), needle.begin(), needle.end(),
			[](char a, char b) {
				return std::tolower(static_cast<unsigned char>(a)) == std::tolower(static_cast<unsigned char>(b));
			}
		);

		if (it == aResponse.end()) {
			return Util::emptyString;
		}

		const auto valueStart = static_cast<size_t>(std::distance(aResponse.begin(), it)) + needle.size();
		const auto valueEnd = aResponse.find("\r\n", valueStart);
		auto value = aResponse.substr(valueStart, valueEnd == string::npos ? string::npos : valueEnd - valueStart);
		return trimCopy(value);
	}
}

vector<SsdpDiscovery::Response> SsdpDiscovery::search(const string& aSearchTarget, uint64_t aTimeoutMs) noexcept {
	vector<Response> ret;
	unordered_set<string> seen;

	const auto targets = getSearchTargets();

	try {
		Socket sock(Socket::TYPE_UDP);

		// Dual stack. listen() creates one socket per family on the same port, and both
		// wait() and read() already select across the two, so a single socket object and
		// a single receive loop serve IPv4 and IPv6 alike.
		sock.setV4only(false);

		// Honour the configured bind address. Without this the M-SEARCH - which
		// advertises the client - leaves via the default route, which on a
		// multi-homed or VPN machine is not the network the user is on, so real
		// renderers are never found and the search is announced somewhere it
		// shouldn't be.
		if (const auto& bindAddr = SETTING(BIND_ADDRESS);
				!bindAddr.empty() && bindAddr != "0.0.0.0") {
			sock.setLocalIp4(bindAddr);
		}

		if (const auto& bindAddr6 = SETTING(BIND_ADDRESS6);
				!bindAddr6.empty() && bindAddr6 != "::") {
			sock.setLocalIp6(bindAddr6);
		}

		// Bind before sending. writeTo() creates the socket lazily and never binds, and
		// v4only/localIp4 are only consulted by listen() and connect() - so setting them
		// above did nothing at all and the datagram still left via the default route.
		// Port 0 asks for an ephemeral one, which is where the unicast replies arrive
		// (no multicast group join is needed to receive them).
		try {
			sock.listen("0");
		} catch (const SocketException& e) {
			// A bind address that no longer resolves to a live interface must not turn
			// discovery off altogether - that would be a worse regression than the bug
			// being fixed, since this setting was simply ignored until now. Fall back to
			// the default route, which is exactly what used to happen.
			dcdebug("SsdpDiscovery: could not bind to the configured address (%s), using the default route\n", e.getError().c_str());
			sock.setLocalIp4(Util::emptyString);
			sock.setLocalIp6(Util::emptyString);
			sock.listen("0");
		}

		// One family failing - no IPv6 on this host, an interface that went away between
		// the adapter scan and the send - must not stop the other from being searched, so
		// each target is sent on its own. False only if every one of them failed.
		const auto sendAll = [&]() {
			auto anySent = false;
			for (const auto& target: targets) {
				try {
					sock.writeTo(target, SSDP_PORT, buildSearch(target, aSearchTarget));
					anySent = true;
				} catch (const SocketException& e) {
					dcdebug("SsdpDiscovery: sending to %s failed: %s\n", target.c_str(), e.getError().c_str());
				}
			}

			return anySent;
		};

		// Send a few times: SSDP is UDP and lossy, and some renderers answer slowly.
		if (!sendAll()) {
			return ret;
		}

		sendAll();

		const auto deadline = GET_TICK() + aTimeoutMs;
		auto lastResend = GET_TICK();
		char buf[4096];

		while (GET_TICK() < deadline) {
			auto [canRead, _] = sock.wait(400, true, false);

			// Re-send once mid-window to catch stragglers
			if (GET_TICK() - lastResend > aTimeoutMs / 2) {
				lastResend = GET_TICK();
				sendAll();
			}

			if (!canRead) {
				continue;
			}

			string fromIp, fromPort;
			auto n = sock.read(buf, sizeof(buf), fromIp, fromPort);
			if (n <= 0) {
				continue;
			}

			string response(buf, static_cast<size_t>(n));
			// Only care about success replies to our M-SEARCH
			if (Text::toLower(response).compare(0, 15, "http/1.1 200 ok") != 0) {
				continue;
			}

			Response r;
			r.location = getHeader(response, "LOCATION");
			r.usn = getHeader(response, "USN");
			r.address = fromIp;
			if (r.location.empty() || r.address.empty()) {
				continue;
			}

			auto key = r.usn.empty() ? r.location : r.usn;
			if (seen.insert(key).second) {
				ret.push_back(std::move(r));
			}

			// Anyone who can reach this socket can answer, and each accepted reply
			// costs a description fetch later (seconds apiece). Without a cap a
			// flood of unique USNs turns discovery into hours of work.
			if (ret.size() >= MAX_RESPONSES) {
				break;
			}
		}
	} catch (const SocketException& e) {
		dcdebug("SsdpDiscovery: %s\n", e.getError().c_str());
	}

	return ret;
}

} // namespace dcpp
