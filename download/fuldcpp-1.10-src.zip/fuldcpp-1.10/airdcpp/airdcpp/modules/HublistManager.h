/*
* Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_HUBLIST_MANAGER_H
#define DCPLUSPLUS_DCPP_HUBLIST_MANAGER_H

#include <airdcpp/forward.h>

#include "HublistManagerListener.h"
#include "HublistEntry.h"

#include <airdcpp/connection/http/HttpConnection.h>
#include <airdcpp/core/Singleton.h>
#include <airdcpp/core/Speaker.h>

#include <atomic>
#include <mutex>


namespace dcpp {

	/**
	* Assumed to be called only by UI thread.
	*/
	class HublistManager : public Speaker<HublistManagerListener>, private HttpConnectionListener, public Singleton<HublistManager>
	{
	public:
		HublistManager();
		~HublistManager() override;

		// Public Hubs
		enum HubTypes {
			TYPE_NORMAL,
			TYPE_BZIP2
		};

		// const: only reads SETTING(HUBLIST_SERVERS), never takes cs. That matters --
		// getMergedPublicHubs() calls it while holding cs, and SharedMutex is not recursive.
		StringList getHubLists() const noexcept;
		void setHubList(int aHubList) noexcept;
		// Normalised against the configured list count; a failed download advances
		// lastServer, and callers (the GUI dropdown) must never see an out-of-range index.
		int getSelectedHubList() const noexcept;
		void refresh(bool forceDownload = false) noexcept;
		// Download/load every configured list, then serve them merged. Serial: one
		// HTTP request at a time, queued.
		void refreshAll(bool forceDownload = false) noexcept;
		// Drop whatever is still queued for a merge. The in-flight request is left to
		// finish normally and releases the slot through the usual popNextDownload() path.
		void cancelMerge() noexcept;
		HubTypes getHubListType() const noexcept { return listType; }
		HublistEntry::List getPublicHubs() const noexcept;
		// All configured lists de-duplicated by address (case-insensitive); per-field,
		// the first non-empty string wins and numerics take the max.
		HublistEntry::List getMergedPublicHubs() const noexcept;
		bool isDownloading() const noexcept { return (useHttp && running); }
		bool isMerging() const noexcept { return mergeMode; }
		size_t getMergeCompletedCount() const noexcept { return mergeProcessed; }
		size_t getMergeTotalCount() const noexcept { return mergeTotal; }

		mutable SharedMutex cs;
	private:
		static string getHublistPath() noexcept;
		static bool isHublistUrl(const string& aServer) noexcept;
		static HubTypes getHubListType(const string& aPath) noexcept;
		static int normalizeHubListIndex(int aIndex, size_t aCount) noexcept;

		// Public Hubs
		using PubListMap = unordered_map<string, HublistEntry::List>;
		PubListMap publicListMatrix;
		// The list the user has selected -- what getPublicHubs() serves. Distinct from
		// downloadingServer so a merge never changes what the single-list view (or the
		// web API's entries endpoint) returns. Guarded by cs.
		string publicListServer;
		std::atomic<bool> useHttp{ false };
		// The single-download-slot token. Claimed by claimDownloadSlot(), released only
		// by releaseDownloadSlot() or by popNextDownload() draining the queue -- it stays
		// set across a hand-off so nothing can barge into the middle of a merge.
		std::atomic<bool> running{ false };
		HttpConnection* c = nullptr;
		// Advanced by advanceHubList() on the HttpConnection worker thread, read by the GUI.
		std::atomic<int> lastServer{ 0 };
		std::atomic<HubTypes> listType{ TYPE_NORMAL };

		// Merge progress. Written on the worker thread, read by the GUI on every status
		// repaint; atomic rather than mutex-guarded so a status read never blocks and never
		// has to be taken inside a fire(). processed <= total always holds, so a torn pair
		// is not observable.
		std::atomic<bool> mergeMode{ false };
		std::atomic<size_t> mergeProcessed{ 0 };
		std::atomic<size_t> mergeTotal{ 0 };
		// Remaining auto-failover budget for single-list mode, bounded by the number of
		// configured lists so a run of dead servers terminates.
		std::atomic<int> failoverRemaining{ 0 };

		// downloadBuf is accessed from both the UI thread (refresh/onHttpFinished)
		// and the HttpConnection worker thread (on(Data)). A std::string cannot be
		// atomic, so guard every access with this dedicated, non-recursive mutex.
		// Never hold it across a fire()/callback.
		mutable std::mutex downloadBufCS;
		string downloadBuf;

		// Guards the serial download queue and the URL of the in-flight request.
		// Non-recursive, and under the same contract as downloadBufCS: never held across
		// a fire(), an HttpConnection call, or file I/O. startNextDownload() runs on the
		// HttpConnection worker thread from inside on(Complete)/on(Failed), so both of
		// these are cross-thread state.
		mutable std::mutex downloadCS;
		StringList downloadQueue;
		string downloadingServer;

		// HttpConnectionListener
		void on(HttpConnectionListener::Data, HttpConnection*, const uint8_t*, size_t) noexcept override;
		void on(HttpConnectionListener::Failed, HttpConnection*, const string&) noexcept override;
		void on(HttpConnectionListener::Complete, HttpConnection*, const string&) noexcept override;
		void on(HttpConnectionListener::Redirected, HttpConnection*, const string&) noexcept override;

		bool onHttpFinished(bool fromHttp, const string& aServer) noexcept;
		bool loadFromCache(const string& aServer) noexcept;
		void startDownload(const string& aServer) noexcept;
		bool popNextDownload(string& server_) noexcept;
		bool claimDownloadSlot() noexcept;
		void releaseDownloadSlot() noexcept;
		void advanceHubList() noexcept;
	};

} // namespace dcpp

#endif // !defined(FAVORITE_MANAGER_H)