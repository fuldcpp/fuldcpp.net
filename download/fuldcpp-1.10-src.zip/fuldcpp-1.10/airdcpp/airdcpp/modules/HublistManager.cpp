/*
* Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include "HublistManager.h"
#include "HublistEntry.h"

#include <airdcpp/util/AppUtil.h>
#include <airdcpp/core/io/compress/BZUtils.h>
#include <airdcpp/core/io/stream/FilteredFile.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/core/io/stream/Streams.h>
#include <airdcpp/util/text/StringTokenizer.h>
#include <airdcpp/core/io/xml/SimpleXML.h>


namespace dcpp {

HublistManager::HublistManager() {
	File::ensureDirectory(getHublistPath());
}

HublistManager::~HublistManager() {
	if (c) {
		c->removeListener(this);
		delete c;
		c = nullptr;
	}
}

string HublistManager::getHublistPath() noexcept {
	return AppUtil::getPath(AppUtil::PATH_USER_LOCAL) + "HubLists" + PATH_SEPARATOR_STR;
}

HublistEntry::List HublistManager::getPublicHubs() const noexcept {
	RLock l(cs);
	auto i = publicListMatrix.find(publicListServer);
	return i != publicListMatrix.end() ? i->second : HublistEntry::List();
}

class XmlListLoader : public SimpleXMLReader::CallBack {
public:
	explicit XmlListLoader(HublistEntry::List& lst) : publicHubs(lst) { }
	~XmlListLoader() = default;
	void startTag(const string& aName, StringPairList& attribs, bool) override final {
		if (aName == "Hub") {
			const string& name = getAttrib(attribs, "Name", 0);
			const string& server = getAttrib(attribs, "Address", 1);
			const string& description = getAttrib(attribs, "Description", 2);
			const string& users = getAttrib(attribs, "Users", 3);
			const string& country = getAttrib(attribs, "Country", 4);
			const string& shared = getAttrib(attribs, "Shared", 5);
			const string& minShare = getAttrib(attribs, "Minshare", 5);
			const string& minSlots = getAttrib(attribs, "Minslots", 5);
			const string& maxHubs = getAttrib(attribs, "Maxhubs", 5);
			const string& maxUsers = getAttrib(attribs, "Maxusers", 5);
			const string& reliability = getAttrib(attribs, "Reliability", 5);
			const string& rating = getAttrib(attribs, "Rating", 5);
			publicHubs.push_back(HublistEntry(name, server, description, users, country, shared, minShare, minSlots, maxHubs, maxUsers, reliability, rating));
		}
	}
private:
	HublistEntry::List& publicHubs;
};

namespace {
	// A hub can appear in several lists with different amounts of detail. Take the
	// richest of each field: the first non-empty string wins, numerics take the max.
	// `server` is the merge key and is never overwritten.
	void mergeHublistEntry(HublistEntry& aTarget, const HublistEntry& aSource) noexcept {
		if (aTarget.getName().empty() && !aSource.getName().empty())
			aTarget.setName(aSource.getName());
		if (aTarget.getDescription().empty() && !aSource.getDescription().empty())
			aTarget.setDescription(aSource.getDescription());
		if (aTarget.getCountry().empty() && !aSource.getCountry().empty())
			aTarget.setCountry(aSource.getCountry());
		if (aTarget.getRating().empty() && !aSource.getRating().empty())
			aTarget.setRating(aSource.getRating());

		aTarget.setReliability(std::max(aTarget.getReliability(), aSource.getReliability()));
		aTarget.setShared(std::max(aTarget.getShared(), aSource.getShared()));
		aTarget.setMinShare(std::max(aTarget.getMinShare(), aSource.getMinShare()));
		aTarget.setUsers(std::max(aTarget.getUsers(), aSource.getUsers()));
		aTarget.setMinSlots(std::max(aTarget.getMinSlots(), aSource.getMinSlots()));
		aTarget.setMaxHubs(std::max(aTarget.getMaxHubs(), aSource.getMaxHubs()));
		aTarget.setMaxUsers(std::max(aTarget.getMaxUsers(), aSource.getMaxUsers()));
	}
}

HublistEntry::List HublistManager::getMergedPublicHubs() const noexcept {
	// Safe to call getHubLists() under the lock: it only reads the setting.
	RLock l(cs);

	unordered_map<string, HublistEntry, noCaseStringHash, noCaseStringEq> merged;
	// Driven by the configured lists rather than by publicListMatrix, so lists the
	// user has since removed from settings drop out even if still cached in memory.
	for (const auto& server : getHubLists()) {
		auto i = publicListMatrix.find(server);
		if (i == publicListMatrix.end())
			continue;

		for (const auto& entry : i->second) {
			if (entry.getServer().empty())
				continue;

			auto res = merged.emplace(entry.getServer(), entry);
			if (!res.second)
				mergeHublistEntry(res.first->second, entry);
		}
	}

	HublistEntry::List ret;
	ret.reserve(merged.size());
	for (auto& i : merged)
		ret.push_back(std::move(i.second));

	// Unordered-map order; callers sort for display anyway.
	return ret;
}

bool HublistManager::onHttpFinished(bool fromHttp, const string& aServer) noexcept {
	// Snapshot the shared buffer under its own mutex, then operate on the local
	// copy so we never touch downloadBuf while holding cs / while firing.
	string buf;
	{
		std::lock_guard<std::mutex> bl(downloadBufCS);
		buf.swap(downloadBuf);
	}

	MemoryInputStream mis(buf);
	bool success = true;

	// Ceiling on the DECOMPRESSED hublist. setMaxBodySize below bounds only the bytes on the
	// wire; behind FilteredInputStream<UnBZFilter> those 32 MB expand without limit, and every
	// <Hub/> in the result becomes a HubEntry in publicListMatrix -- all under the WLock taken
	// below, so the GUI blocks for the duration. The server is a user-configurable third-party
	// URL, i.e. the same trust level as a peer's file list. Unlike the file list this stays a
	// constant: real hublists are single-digit MB, so there is no legitimate case to tune for.
	static const size_t MAX_HUBLIST_XML_SIZE = 256ull * 1024ull * 1024ull; // 256 MiB

	// Scope the exclusive lock to the container mutation only. It used to be held across
	// the fire() below AND the cache write -- which contradicts this class's own
	// documented "never hold cs across a fire()" contract: any listener that synchronously
	// called getPublicHubs()/getMergedPublicHubs() would take RLock on the same
	// NON-RECURSIVE shared_mutex already held exclusively on this thread, i.e. a guaranteed
	// deadlock. Both current listeners happen to marshal, so nothing deadlocks today. The
	// disk write also blocked every GUI read for its duration.
	string corruptedError;
	bool corrupted = false;

	{
		WLock l(cs);
		auto& list = publicListMatrix[aServer];
		list.clear();

		try {
			XmlListLoader loader(list);

			if ((listType == TYPE_BZIP2) && (!buf.empty())) {
				FilteredInputStream<UnBZFilter, false> f(&mis);
				SimpleXMLReader(&loader).parse(f, MAX_HUBLIST_XML_SIZE);
			}
			else {
				SimpleXMLReader(&loader).parse(mis, MAX_HUBLIST_XML_SIZE);
			}
		}
		catch (const Exception& e) {
			dcdebug("HublistManager::onHttpFinished: %s\n", e.getError().c_str());

			success = false;
			corrupted = true;

			// The empty string is a contract marker: listeners render it as the
			// cache-corruption message (vs. a corrupt download)
			corruptedError = fromHttp ? aServer + ", " + e.getError() : Util::emptyString;
		}
	}

	if (corrupted && !fromHttp) {
		// A corrupt cached list would fail identically on every open;
		// remove it so the next attempt downloads a fresh copy
		File::deleteFile(getHublistPath() + PathUtil::validateFileName(aServer));
	}

	if (fromHttp) {
		try {
			File f(getHublistPath() + PathUtil::validateFileName(aServer), File::WRITE, File::CREATE | File::TRUNCATE);
			f.write(buf);
		}
		catch (const FileException&) {}
	}

	// Fired after the lock is released, as the class contract requires
	if (corrupted) {
		fire(HublistManagerListener::Corrupted(), corruptedError);
	}

	return success;
}

StringList HublistManager::getHubLists() const noexcept {
	StringTokenizer<string> lists(SETTING(HUBLIST_SERVERS), ';');
	return lists.getTokens();
}

bool HublistManager::isHublistUrl(const string& aServer) noexcept {
	return Util::findSubString(aServer, "http://") == 0 || Util::findSubString(aServer, "https://") == 0;
}

HublistManager::HubTypes HublistManager::getHubListType(const string& aPath) noexcept {
	return (aPath.size() >= 4 && Util::stricmp(aPath.substr(aPath.size() - 4), ".bz2") == 0) ? TYPE_BZIP2 : TYPE_NORMAL;
}

int HublistManager::normalizeHubListIndex(int aIndex, size_t aCount) noexcept {
	if (aCount == 0)
		return 0;
	const auto count = static_cast<int>(aCount);
	return ((aIndex % count) + count) % count;
}

int HublistManager::getSelectedHubList() const noexcept {
	return normalizeHubListIndex(lastServer, getHubLists().size());
}

void HublistManager::advanceHubList() noexcept {
	const auto count = getHubLists().size();
	lastServer = count > 0 ? normalizeHubListIndex(lastServer + 1, count) : 0;
}

bool HublistManager::claimDownloadSlot() noexcept {
	bool expected = false;
	return running.compare_exchange_strong(expected, true);
}

void HublistManager::releaseDownloadSlot() noexcept {
	running = false;
}

bool HublistManager::popNextDownload(string& server_) noexcept {
	std::lock_guard<std::mutex> l(downloadCS);
	if (downloadQueue.empty()) {
		// The only place the slot is released after a hand-off chain ends.
		running = false;
		// The queue draining *is* the end of a merge; leaving mergeMode set would keep
		// the frame offering "Cancel merge" for a merge that already finished. The
		// merged view itself is the frame's own mergedView flag, so this does not
		// disturb what is on screen, and the [n/m] counters are left intact.
		mergeMode = false;
		return false;
	}

	server_ = std::move(downloadQueue.front());
	downloadQueue.erase(downloadQueue.begin());
	// `running` deliberately stays set across the hand-off, so nothing can start a
	// competing download between two items of the queue.
	return true;
}

bool HublistManager::loadFromCache(const string& aServer) noexcept {
	const auto path = getHublistPath() + PathUtil::validateFileName(aServer);
	if (File::getSize(path) <= 0)
		return false;

	useHttp = false;
	string fileDate;
	{
		WLock l(cs);
		publicListMatrix[aServer].clear();
	}
	listType = getHubListType(path);

	bool haveData = false;
	try {
		File cached(path, File::READ, File::OPEN);
		{
			std::lock_guard<std::mutex> bl(downloadBufCS);
			downloadBuf = cached.read();
			haveData = !downloadBuf.empty();
		}
		char buf[20];
		time_t fd = cached.getLastModified();
		std::tm fdTm{};
#ifdef _WIN32
		auto fdOk = localtime_s(&fdTm, &fd) == 0;
#else
		auto fdOk = localtime_r(&fd, &fdTm) != nullptr;
#endif
		if (fdOk && strftime(buf, 20, "%x", &fdTm)) {
			fileDate = string(buf);
		}
	}
	catch (const FileException&) {
		std::lock_guard<std::mutex> bl(downloadBufCS);
		downloadBuf = Util::emptyString;
		haveData = false;
	}

	if (!haveData)
		return false;

	// onHttpFinished() consumes downloadBuf under downloadBufCS; do not
	// hold the buffer lock here (it is non-recursive).
	if (!onHttpFinished(false, aServer))
		return false;

	fire(HublistManagerListener::LoadedFromCache(), aServer, fileDate);
	return true;
}

void HublistManager::startDownload(const string& aServer) noexcept {
	// Caller must already hold the download slot.
	{
		std::lock_guard<std::mutex> l(downloadCS);
		downloadingServer = aServer;
	}

	useHttp = true;
	// Reset per-download, otherwise a previous .bz2 cache load leaves TYPE_BZIP2
	// sticky and a later plain-XML download gets fed through UnBZFilter.
	listType = getHubListType(aServer);
	{
		WLock l(cs);
		publicListMatrix[aServer].clear();
	}

	fire(HublistManagerListener::DownloadStarting(), aServer);

	if (!c) {
		// Cap the response body. The default HttpOptions leaves maxBodySize at -1, so a
		// hostile or misconfigured hublist server could stream an endless body into
		// downloadBuf -- which is then copied again into a MemoryInputStream and, when
		// fromHttp is set, written to the on-disk cache. Hublists are bz2-compressed XML;
		// 32 MB is far above any real one. HttpConnection::options is const, so this has
		// to be supplied at construction; the connection is reused for every server.
		HttpOptions options;
		options.setMaxBodySize(32 * 1024 * 1024);
		// An https feed URL is verified. The default leaves allowUntrusted at true, so the
		// certificate was not checked at all and the scheme bought nothing: this content drives
		// auto-search and auto-download, and the URL is user-configurable third-party, which is
		// exactly the case where a forged answer matters. A server with a self-signed certificate
		// now fails rather than being accepted silently; an http:// URL is unaffected.
		//
		// Note the interaction with an HTTP proxy: the request reaches a proxy in the clear, so
		// there is no certificate to verify and HttpConnection refuses it rather than pretending.
		// That is a visible change for proxy users, and the honest one -- it was never verified.
		options.setAllowUntrusted(false);
		c = new HttpConnection(false, options);
	}

	c->addListener(this);

	// HttpConnection::prepareRequest() can fire Failed synchronously on this thread
	// from its catch block, which re-enters on(Failed) -> popNextDownload -> startDownload.
	// The recursion is bounded by the queue length, and `running` is already true so
	// nothing else can claim the slot meanwhile. It must be set BEFORE this call --
	// setting it afterwards would overwrite the on(Failed) release and wedge the manager.
	c->downloadFile(aServer);
}

void HublistManager::setHubList(int aHubList) noexcept {
	lastServer = aHubList;
	refresh();
}

void HublistManager::refresh(bool forceDownload /* = false */) noexcept {
	if (!claimDownloadSlot())
		return;

	mergeMode = false;
	{
		std::lock_guard<std::mutex> l(downloadCS);
		downloadQueue.clear();
	}
	mergeProcessed = 0;
	mergeTotal = 0;

	const auto sl = getHubLists();
	if (sl.empty()) {
		releaseDownloadSlot();
		return;
	}

	const auto server = sl[normalizeHubListIndex(lastServer, sl.size())];
	if (!isHublistUrl(server)) {
		advanceHubList();
		releaseDownloadSlot();
		return;
	}

	{
		WLock l(cs);
		publicListServer = server;
	}
	mergeTotal = 1;

	if (!forceDownload && loadFromCache(server)) {
		mergeProcessed = 1;
		releaseDownloadSlot();
		return;
	}

	failoverRemaining = static_cast<int>(sl.size()) - 1;
	startDownload(server);
}

void HublistManager::refreshAll(bool forceDownload /* = false */) noexcept {
	if (!claimDownloadSlot())
		return;

	StringList validServers;
	for (const auto& s : getHubLists()) {
		if (isHublistUrl(s))
			validServers.push_back(s);
	}

	if (validServers.empty()) {
		mergeMode = false;
		releaseDownloadSlot();
		return;
	}

	mergeMode = true;
	mergeProcessed = 0;
	mergeTotal = validServers.size();
	// A merge visits every list already, so there is nothing to fail over to.
	failoverRemaining = 0;

	if (forceDownload) {
		WLock l(cs);
		for (const auto& s : validServers)
			publicListMatrix[s].clear();
	}

	StringList pending;
	for (const auto& s : validServers) {
		if (!forceDownload && loadFromCache(s)) {
			++mergeProcessed;
		} else {
			pending.push_back(s);
		}
	}

	{
		std::lock_guard<std::mutex> l(downloadCS);
		downloadQueue = std::move(pending);
	}

	// Deliberately leaves lastServer/publicListServer alone, so leaving merged view
	// restores exactly the list the user had selected.
	string next;
	if (popNextDownload(next))
		startDownload(next);
}

void HublistManager::cancelMerge() noexcept {
	{
		std::lock_guard<std::mutex> l(downloadCS);
		downloadQueue.clear();
	}
	mergeMode = false;
	// The in-flight request is left alone; its on(Complete)/on(Failed) finds an empty
	// queue and releases the slot through popNextDownload().
}

// HttpConnectionListener
void HublistManager::on(Data, HttpConnection*, const uint8_t* buf, size_t len) noexcept {
	if (useHttp) {
		std::lock_guard<std::mutex> bl(downloadBufCS);
		downloadBuf.append((const char*)buf, len);
	}
}

void HublistManager::on(Failed, HttpConnection*, const string& aLine) noexcept {
	c->removeListener(this);
	++mergeProcessed;

	if (useHttp) {
		std::lock_guard<std::mutex> bl(downloadBufCS);
		downloadBuf = Util::emptyString;
	}

	// Auto-failover, single-list mode only: try the next configured list instead of
	// leaving the user with an empty window. Reuses the same serial queue as a merge.
	if (!mergeMode && failoverRemaining > 0) {
		--failoverRemaining;
		advanceHubList();

		const auto sl = getHubLists();
		if (!sl.empty()) {
			const auto next = sl[normalizeHubListIndex(lastServer, sl.size())];
			if (isHublistUrl(next)) {
				{
					WLock l(cs);
					publicListServer = next;
				}
				{
					std::lock_guard<std::mutex> l(downloadCS);
					downloadQueue.push_back(next);
				}
				// Keep processed <= total; the retry is an extra unit of work.
				++mergeTotal;
			}
		}
	}

	string next;
	const bool haveNext = popNextDownload(next);

	// Fire before starting the next one, so the user never sees "Downloading B"
	// ahead of "Failed A".
	if (useHttp)
		fire(HublistManagerListener::DownloadFailed(), aLine);

	if (haveNext)
		startDownload(next);
}

void HublistManager::on(Complete, HttpConnection*, const string& aLine) noexcept {
	c->removeListener(this);

	string server;
	{
		std::lock_guard<std::mutex> l(downloadCS);
		server = downloadingServer;
	}

	bool parseSuccess = false;
	if (useHttp) {
		if (c->getMimeType() == "application/x-bzip2")
			listType = TYPE_BZIP2;
		parseSuccess = onHttpFinished(true, server);
	}

	++mergeProcessed;
	// Got a list; stop failing over.
	failoverRemaining = 0;

	string next;
	const bool haveNext = popNextDownload(next);

	if (parseSuccess)
		fire(HublistManagerListener::DownloadFinished(), aLine);

	if (haveNext)
		startDownload(next);
}

void HublistManager::on(Redirected, HttpConnection*, const string& aLine) noexcept {
	if (useHttp)
		fire(HublistManagerListener::DownloadStarting(), aLine);
}

} // namespace dcpp
