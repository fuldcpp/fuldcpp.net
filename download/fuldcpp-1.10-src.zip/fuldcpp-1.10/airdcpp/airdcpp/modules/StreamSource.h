/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_STREAM_SOURCE_H
#define DCPLUSPLUS_DCPP_STREAM_SOURCE_H

#include <airdcpp/core/types/GetSet.h>

#include <airdcpp/core/classes/Segment.h>
#include <airdcpp/core/io/File.h>
#include <airdcpp/core/thread/CriticalSection.h>
#include <airdcpp/queue/QueueManager.h>

#include "RarReader.h"

namespace dcpp {

// A virtual, byte-addressable view of a (possibly still downloading) video file
// for the streaming HTTP server: either a plain file or the stored payload
// spanning a multi-volume RAR set.
//
// Queue access goes through injected callbacks so sources can be exercised
// against completed files without a running queue.
class StreamSource {
public:
	using Ptr = std::shared_ptr<StreamSource>;

	struct Callbacks {
		std::function<QueueManager::StreamingFileInfo(const string& aTarget)> fileInfo;
		std::function<int64_t(const string& aTarget, int64_t aOffset)> availability;
		std::function<bool(const string& aTarget, const vector<Segment>& aRanges)> requestRanges;
	};

	enum class PrepareResult {
		READY,
		PENDING,			// not enough data yet, call again later
		ERROR_ENCRYPTED,
		ERROR_COMPRESSED,
		ERROR_UNSUPPORTED,
		ERROR_CORRUPT,
	};

	explicit StreamSource(Callbacks aCallbacks) : callbacks(std::move(aCallbacks)) { }
	virtual ~StreamSource() = default;

	// Attempt to make the source servable (parse archive headers etc.)
	virtual PrepareResult prepare() noexcept = 0;

	// Total size of the served (inner) file, -1 until prepared
	virtual int64_t getSize() const noexcept = 0;

	// Name of the served (inner) file, for the URL and the mime type
	virtual const string& getName() const noexcept = 0;

	// Bytes that can be read at the offset right now (0 = nothing yet, -1 = permanent failure)
	virtual int64_t available(int64_t aOffset) noexcept = 0;

	// Read up to aLen bytes at the offset; may return less (e.g. at a volume boundary). Throws FileException.
	virtual size_t read(int64_t aOffset, void* aBuf, size_t aLen) = 0;

	// Ask the queue to fetch this range of the served file ahead of the sequential order (player seeks/probes).
	// Safe to call repeatedly with the same range.
	virtual void requestRange(int64_t aOffset, int64_t aLen) noexcept = 0;

	void invalidate() noexcept { valid = false; }
	bool isValid() const noexcept { return valid; }

	static bool isVideoFile(const string& aFileName) noexcept;

	// MIME type for a video file name (video/* or application/octet-stream); shared by the HTTP
	// server response and the DLNA cast metadata so the two never disagree.
	static string getMimeType(const string& aFileName) noexcept;

protected:
	// Availability of a single underlying file, falling back to the disk file when it has left the queue.
	// Returns -1 when the file is gone for good.
	int64_t fileAvailability(const string& aTarget, int64_t aOffset) noexcept;

	const Callbacks callbacks;
	std::atomic<bool> valid { true };
};

// A single (non-archived) video file
class PlainStreamSource : public StreamSource {
public:
	PlainStreamSource(const string& aTarget, Callbacks aCallbacks);

	PrepareResult prepare() noexcept override;
	int64_t getSize() const noexcept override { return size; }
	const string& getName() const noexcept override { return name; }
	int64_t available(int64_t aOffset) noexcept override;
	size_t read(int64_t aOffset, void* aBuf, size_t aLen) override;
	void requestRange(int64_t aOffset, int64_t aLen) noexcept override;

private:
	const string target;
	const string name;
	int64_t size = -1;

	CriticalSection cs;
	unique_ptr<File> file;
	string openPath;
};

// The stored payload of one file inside a multi-volume RAR set
class RarStreamSource : public StreamSource {
public:
	// aVolumeTargets must be in volume order (see RarReader::getVolumeSeq)
	RarStreamSource(const StringList& aVolumeTargets, Callbacks aCallbacks);

	PrepareResult prepare() noexcept override;
	int64_t getSize() const noexcept override { return innerSize; }
	const string& getName() const noexcept override { return innerName; }
	int64_t available(int64_t aOffset) noexcept override;
	size_t read(int64_t aOffset, void* aBuf, size_t aLen) override;
	void requestRange(int64_t aOffset, int64_t aLen) noexcept override;

private:
	struct Volume {
		string target;
		bool mapped = false;
		int64_t dataOffset = 0;		// payload start within the volume file
		int64_t dataLen = 0;		// payload length (this volume's slice of the inner file)
		int64_t innerStart = 0;		// inner-file offset of the first payload byte
	};

	// All below require cs to be held

	// Parse volumes until the one containing the inner offset is mapped (best effort)
	bool ensureMapped(int64_t aOffset) noexcept;
	// Parse the next unmapped volume; false if it can't be done yet
	bool mapNextVolume() noexcept;
	const Volume* findVolume(int64_t aOffset) const noexcept;
	int64_t mappedBytes() const noexcept;

	vector<Volume> volumes;
	size_t mappedCount = 0;
	bool mapFailed = false;

	string innerName;		// display name (path stripped)
	string innerRarName;	// raw in-archive name, for matching continuation entries
	int64_t innerSize = -1;
	PrepareResult state = PrepareResult::PENDING;

	CriticalSection cs;
	unique_ptr<File> file;
	string openPath;
};

} // namespace dcpp

#endif
