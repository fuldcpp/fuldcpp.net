/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include "StreamSource.h"

#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/text/Text.h>

namespace dcpp {

namespace {
	const StringList VIDEO_EXTENSIONS = {
		"avi", "divx", "flv", "m2ts", "m4v", "mkv", "mov", "mp4", "mpeg", "mpg", "ogm", "ts", "vob", "webm", "wmv"
	};

	// In-archive names may use either separator regardless of the host OS
	string stripArchivePath(const string& aName) noexcept {
		auto pos = aName.find_last_of("\\/");
		return pos != string::npos ? aName.substr(pos + 1) : aName;
	}

	int openFileMode() noexcept {
		// Full sharing: the queue keeps writing the file and renames it to the final target on completion
		return File::OPEN | File::SHARED_WRITE | File::SHARED_DELETE;
	}
}

bool StreamSource::isVideoFile(const string& aFileName) noexcept {
	auto ext = Text::toLower(PathUtil::getFileExt(aFileName));
	if (!ext.empty() && ext[0] == '.') {
		ext.erase(0, 1);
	}

	return ranges::find(VIDEO_EXTENSIONS, ext) != VIDEO_EXTENSIONS.end();
}

string StreamSource::getMimeType(const string& aFileName) noexcept {
	auto ext = Text::toLower(PathUtil::getFileExt(aFileName));
	if (!ext.empty() && ext[0] == '.') {
		ext.erase(0, 1);
	}

	if (ext == "mkv") return "video/x-matroska";
	if (ext == "avi" || ext == "divx") return "video/x-msvideo";
	if (ext == "mp4" || ext == "m4v") return "video/mp4";
	if (ext == "webm") return "video/webm";
	if (ext == "mpg" || ext == "mpeg" || ext == "vob") return "video/mpeg";
	if (ext == "ts" || ext == "m2ts") return "video/mp2t";
	if (ext == "mov") return "video/quicktime";
	if (ext == "wmv") return "video/x-ms-wmv";
	if (ext == "ogm") return "video/ogg";
	if (ext == "flv") return "video/x-flv";
	return "application/octet-stream";
}

int64_t StreamSource::fileAvailability(const string& aTarget, int64_t aOffset) noexcept {
	auto avail = callbacks.availability(aTarget, aOffset);
	if (avail >= 0) {
		return avail;
	}

	// Not in the queue (anymore) - serve the completed file from disk if it's there
	auto info = callbacks.fileInfo(aTarget);
	if (info.downloaded && info.size >= 0) {
		return max<int64_t>(0, info.size - aOffset);
	}

	return -1;
}

/* PlainStreamSource */

PlainStreamSource::PlainStreamSource(const string& aTarget, Callbacks aCallbacks) :
	StreamSource(std::move(aCallbacks)), target(aTarget), name(PathUtil::getFileName(aTarget)) { }

StreamSource::PrepareResult PlainStreamSource::prepare() noexcept {
	if (size >= 0) {
		return PrepareResult::READY;
	}

	auto info = callbacks.fileInfo(target);
	if (info.size < 0) {
		return PrepareResult::PENDING;
	}

	size = info.size;
	return PrepareResult::READY;
}

int64_t PlainStreamSource::available(int64_t aOffset) noexcept {
	if (!valid) {
		return -1;
	}

	if (size < 0) {
		return 0;
	}

	if (aOffset >= size) {
		return 0;
	}

	return fileAvailability(target, aOffset);
}

size_t PlainStreamSource::read(int64_t aOffset, void* aBuf, size_t aLen) {
	Lock l(cs);

	for (auto attempt = 0; attempt < 2; ++attempt) {
		if (!file) {
			auto info = callbacks.fileInfo(target);
			if (info.currentPath.empty()) {
				throw FileException(STRING(TARGET_REMOVED));
			}

			file = make_unique<File>(info.currentPath, File::READ, openFileMode(), File::BUFFER_RANDOM);
			openPath = info.currentPath;
		}

		try {
			file->setPos(aOffset);
			auto len = aLen;
			return file->read(aBuf, len);
		} catch (const FileException&) {
			// The path may have changed (temp file renamed on completion), resolve and retry once
			file.reset();
			if (attempt == 1) {
				throw;
			}
		}
	}

	return 0;
}

void PlainStreamSource::requestRange(int64_t aOffset, int64_t aLen) noexcept {
	callbacks.requestRanges(target, { Segment(aOffset, aLen) });
}

/* RarStreamSource */

RarStreamSource::RarStreamSource(const StringList& aVolumeTargets, Callbacks aCallbacks) : StreamSource(std::move(aCallbacks)) {
	for (const auto& t: aVolumeTargets) {
		volumes.push_back(Volume({ t }));
	}
}

StreamSource::PrepareResult RarStreamSource::prepare() noexcept {
	Lock l(cs);
	if (state != PrepareResult::PENDING) {
		return state;
	}

	if (volumes.empty()) {
		state = PrepareResult::ERROR_CORRUPT;
		return state;
	}

	auto info = callbacks.fileInfo(volumes[0].target);
	if (info.currentPath.empty() || info.contiguousAvailable <= 0) {
		return PrepareResult::PENDING;
	}

	RarVolumeInfo vi;
	switch (RarReader::parseVolume(info.currentPath, info.contiguousAvailable, vi)) {
		case RarParseResult::NEED_MORE_DATA: return PrepareResult::PENDING;
		case RarParseResult::ENCRYPTED: state = PrepareResult::ERROR_ENCRYPTED; return state;
		case RarParseResult::UNSUPPORTED: state = PrepareResult::ERROR_UNSUPPORTED; return state;
		case RarParseResult::CORRUPT: state = PrepareResult::ERROR_CORRUPT; return state;
		case RarParseResult::OK: break;
	}

	// Pick the file to stream: prefer video extensions, then the largest entry
	const RarFileEntry* best = nullptr;
	for (const auto& e: vi.files) {
		if (e.directory || e.unpackedSize <= 0) {
			continue;
		}

		if (!best) {
			best = &e;
			continue;
		}

		const auto bestVideo = isVideoFile(best->name);
		const auto eVideo = isVideoFile(e.name);
		if ((eVideo && !bestVideo) || (eVideo == bestVideo && e.unpackedSize > best->unpackedSize)) {
			best = &e;
		}
	}

	if (!best) {
		// No file entries parsed so far; more headers may still be on the way
		if (!vi.complete) {
			return PrepareResult::PENDING;
		}

		state = PrepareResult::ERROR_CORRUPT;
		return state;
	}

	if (!best->stored) {
		state = PrepareResult::ERROR_COMPRESSED;
		return state;
	}

	if (best->packedSize > best->unpackedSize) {
		state = PrepareResult::ERROR_CORRUPT;
		return state;
	}

	innerRarName = best->name;
	innerName = stripArchivePath(best->name);
	innerSize = best->unpackedSize;

	auto& vol = volumes[0];
	vol.dataOffset = best->dataOffset;
	vol.dataLen = best->packedSize;
	vol.innerStart = 0;
	vol.mapped = true;
	mappedCount = 1;

	state = PrepareResult::READY;
	return state;
}

int64_t RarStreamSource::mappedBytes() const noexcept {
	if (mappedCount == 0) {
		return 0;
	}

	const auto& v = volumes[mappedCount - 1];
	return v.innerStart + v.dataLen;
}

bool RarStreamSource::mapNextVolume() noexcept {
	if (mapFailed || mappedCount >= volumes.size() || mappedBytes() >= innerSize) {
		return false;
	}

	auto& vol = volumes[mappedCount];
	auto info = callbacks.fileInfo(vol.target);
	if (info.currentPath.empty() || info.contiguousAvailable <= 0) {
		return false;
	}

	RarVolumeInfo vi;
	auto res = RarReader::parseVolume(info.currentPath, info.contiguousAvailable, vi);
	if (res != RarParseResult::OK && res != RarParseResult::NEED_MORE_DATA) {
		mapFailed = true;
		return false;
	}

	// Find the continuation entry of our file
	auto entry = ranges::find_if(vi.files, [this](const RarFileEntry& e) {
		return e.splitBefore && e.name == innerRarName;
	});

	if (entry == vi.files.end()) {
		if (res == RarParseResult::OK && vi.complete) {
			// This volume provably doesn't continue our file - the set is inconsistent
			mapFailed = true;
		}

		return false;
	}

	if (!entry->stored || mappedBytes() + entry->packedSize > innerSize) {
		mapFailed = true;
		return false;
	}

	vol.dataOffset = entry->dataOffset;
	vol.dataLen = entry->packedSize;
	vol.innerStart = mappedBytes();
	vol.mapped = true;
	mappedCount++;
	return true;
}

bool RarStreamSource::ensureMapped(int64_t aOffset) noexcept {
	while (aOffset >= mappedBytes() && mappedCount < volumes.size() && !mapFailed) {
		if (!mapNextVolume()) {
			break;
		}
	}

	return aOffset < mappedBytes();
}

const RarStreamSource::Volume* RarStreamSource::findVolume(int64_t aOffset) const noexcept {
	for (size_t i = 0; i < mappedCount; ++i) {
		const auto& v = volumes[i];
		if (aOffset >= v.innerStart && aOffset < v.innerStart + v.dataLen) {
			return &v;
		}
	}

	return nullptr;
}

int64_t RarStreamSource::available(int64_t aOffset) noexcept {
	if (!valid) {
		return -1;
	}

	Lock l(cs);
	if (state != PrepareResult::READY) {
		return state == PrepareResult::PENDING ? 0 : -1;
	}

	if (aOffset >= innerSize) {
		return 0;
	}

	ensureMapped(aOffset);

	auto v = findVolume(aOffset);
	if (!v) {
		return mapFailed ? -1 : 0;
	}

	auto volOffset = v->dataOffset + (aOffset - v->innerStart);
	auto avail = fileAvailability(v->target, volOffset);
	if (avail < 0) {
		return -1;
	}

	return min(avail, v->innerStart + v->dataLen - aOffset);
}

size_t RarStreamSource::read(int64_t aOffset, void* aBuf, size_t aLen) {
	Lock l(cs);

	ensureMapped(aOffset);
	auto v = findVolume(aOffset);
	if (!v) {
		throw FileException(STRING(TARGET_REMOVED));
	}

	auto volOffset = v->dataOffset + (aOffset - v->innerStart);
	auto maxLen = static_cast<size_t>(min<int64_t>(static_cast<int64_t>(aLen), v->innerStart + v->dataLen - aOffset));

	for (auto attempt = 0; attempt < 2; ++attempt) {
		if (!file || openPath != v->target) {
			auto info = callbacks.fileInfo(v->target);
			if (info.currentPath.empty()) {
				throw FileException(STRING(TARGET_REMOVED));
			}

			file = make_unique<File>(info.currentPath, File::READ, openFileMode(), File::BUFFER_RANDOM);
			openPath = v->target;
		}

		try {
			file->setPos(volOffset);
			auto len = maxLen;
			return file->read(aBuf, len);
		} catch (const FileException&) {
			// The path may have changed (temp file renamed on completion), resolve and retry once
			file.reset();
			if (attempt == 1) {
				throw;
			}
		}
	}

	return 0;
}

void RarStreamSource::requestRange(int64_t aOffset, int64_t aLen) noexcept {
	Lock l(cs);
	if (state != PrepareResult::READY) {
		return;
	}

	auto end = min(aOffset + aLen, innerSize);
	ensureMapped(aOffset);

	for (size_t i = 0; i < mappedCount && aOffset < end; ++i) {
		const auto& v = volumes[i];
		if (v.dataLen == 0 || v.innerStart + v.dataLen <= aOffset) {
			continue;
		}

		if (v.innerStart >= end) {
			break;
		}

		auto sliceStart = max(aOffset, v.innerStart);
		auto sliceEnd = min(end, v.innerStart + v.dataLen);
		callbacks.requestRanges(v.target, { Segment(v.dataOffset + (sliceStart - v.innerStart), sliceEnd - sliceStart) });
		aOffset = sliceEnd;
	}
}

} // namespace dcpp
