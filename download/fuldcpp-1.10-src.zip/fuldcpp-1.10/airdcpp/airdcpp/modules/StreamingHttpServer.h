/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_STREAMING_HTTP_SERVER_H
#define DCPLUSPLUS_DCPP_STREAMING_HTTP_SERVER_H

#include <airdcpp/connection/socket/Socket.h>
#include <airdcpp/core/thread/CriticalSection.h>
#include <airdcpp/core/thread/Thread.h>

#include "StreamSource.h"

namespace dcpp {

// A minimal localhost-only HTTP/1.1 server for streaming registered sources to
// a local media player: GET/HEAD, single Range, Connection: close. Registered
// sources are addressed by an unguessable token; nothing else is served.
//
// Deliberately independent of the (optional, auth-gated, user-configurable)
// web server so the Play feature works without it.
class StreamingHttpServer : private Thread {
public:
	// Binds to an ephemeral 127.0.0.1 port and starts accepting; throws SocketException
	StreamingHttpServer();
	~StreamingHttpServer() override;

	// Returns the URL to hand to the player
	string registerSource(const string& aToken, const StreamSource::Ptr& aSource) noexcept;
	void unregisterSource(const string& aToken) noexcept;

	/*
	 * The same stream URL with its host replaced by one a peer at aPeerAddress can
	 * reach, or empty when this server serves nothing of that peer's family.
	 *
	 * A stream URL is built when the stream starts, before any cast target has been
	 * chosen, so it necessarily names one address of one family. A renderer on the
	 * other protocol cannot use that URL at all - not a routing problem it can work
	 * around, simply an address it has no way to talk to.
	 */
	string adaptUrlForPeer(const string& aUrl, const string& aPeerAddress) const noexcept;

	// Last tick when a connection for the token was active (0 = never)
	uint64_t getLastActivity(const string& aToken) const noexcept;

	bool hasStreams() const noexcept;

	// Stop accepting, close all connections and join the threads
	void shutdown() noexcept;

private:
	int run() noexcept override;

	class Connection : public Thread {
	public:
		Connection(StreamingHttpServer* aServer, unique_ptr<Socket>&& aSocket) : server(aServer), sock(std::move(aSocket)) {
			start();
		}

		int run() noexcept override;

		bool isDone() const noexcept { return done; }
		void stop() noexcept { stopping = true; }
		const string& getToken() const noexcept { return token; }

	private:
		void handleRequest();
		bool readRequest(string& request_);
		bool sendAll(const void* aBuf, size_t aLen);
		bool isClientGone() noexcept;
		void serveBody(const StreamSource::Ptr& aSource, int64_t aPos, int64_t aRemaining);

		StreamingHttpServer* server;
		unique_ptr<Socket> sock;

		// Written only through StreamingHttpServer::setConnectionToken(), i.e. under the
		// server's lock, because unregisterSource() reads it via getToken() while holding
		// that lock. It cannot be atomic (it is a std::string), so the lock is the
		// synchronisation -- unlike the two flags below.
		string token;
		friend class StreamingHttpServer;

		std::atomic<bool> stopping { false };
		std::atomic<bool> done { false };
	};

	void setConnectionToken(Connection& aConnection, const string& aToken) noexcept;
	StreamSource::Ptr findSource(const string& aToken) const noexcept;
	void touchActivity(const string& aToken) noexcept;
	void reapConnections() noexcept;

	Socket listener { Socket::TYPE_TCP };
	string port;
	string advertisedHost;	// host embedded in stream URLs (127.0.0.1, or the LAN IP when casting is enabled)
	string advertisedHost6;	// the same for IPv6, empty when nothing IPv6 is being served
	std::atomic<bool> die { false };

	mutable CriticalSection cs;
	map<string, StreamSource::Ptr> sources;
	map<string, uint64_t> activity;
	vector<unique_ptr<Connection>> connections;
};

} // namespace dcpp

#endif
