/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_RAR_READER_H
#define DCPLUSPLUS_DCPP_RAR_READER_H

#include <airdcpp/core/header/typedefs.h>

namespace dcpp {

// Minimal read-only RAR4/RAR5 volume header parser for streaming playback of
// stored (uncompressed) multi-volume archives. Payload data is never read.
enum class RarParseResult {
	OK,				// all headers up to the end block (or the end of the parseable region) were read
	NEED_MORE_DATA,	// the headers extend beyond the currently available bytes
	ENCRYPTED,		// encrypted headers or an encrypted file entry
	UNSUPPORTED,	// unknown signature (SFX and other non-RAR containers included)
	CORRUPT,		// malformed or hostile header data
};

struct RarFileEntry {
	string name;				// inner file name (RAR4 unicode names are truncated to the ASCII part)
	int64_t packedSize = 0;		// payload bytes stored in this volume
	int64_t unpackedSize = 0;	// total size of the inner file
	int64_t dataOffset = 0;		// payload start offset within this volume
	bool stored = false;		// compression method is "store" (only such entries can be streamed)
	bool splitBefore = false;
	bool splitAfter = false;
	bool directory = false;
};

struct RarVolumeInfo {
	bool rar5 = false;
	bool complete = false;		// the end-of-archive block (or physical EOF) was reached
	vector<RarFileEntry> files;
};

class RarReader {
public:
	static bool isRarVolume(const string& aFileName) noexcept;
	static bool isFirstVolume(const string& aFileName) noexcept;

	// Download/playback sequence key within a set: .rar = 0, .r00 = 1, ... / .partN.rar = N-1 (-1 for non-volumes)
	static int getVolumeSeq(const string& aFileName) noexcept;

	// Name without the volume extension, for grouping volumes into sets (lowercase)
	static string getVolumeBase(const string& aFileName) noexcept;

	// Parse the file headers of a single volume, reading at most aAvailableBytes from the beginning of the file.
	// aAvailableBytes should be the verified contiguously downloaded byte count (or the file size when complete).
	static RarParseResult parseVolume(const string& aPath, int64_t aAvailableBytes, RarVolumeInfo& info_) noexcept;
};

} // namespace dcpp

#endif
