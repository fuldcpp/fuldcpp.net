/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_STREAMING_MANAGER_H
#define DCPLUSPLUS_DCPP_STREAMING_MANAGER_H

#include <airdcpp/core/Singleton.h>
#include <airdcpp/core/Speaker.h>
#include <airdcpp/core/thread/CriticalSection.h>
#include <airdcpp/core/timer/TimerManagerListener.h>
#include <airdcpp/queue/QueueManagerListener.h>

#include "StreamingHttpServer.h"
#include "StreamingManagerListener.h"
#include "StreamSource.h"

namespace dcpp {

// Orchestrates "play while downloading": picks the playable content of a
// bundle, switches the bundle to sequential streaming order, prefetches
// container headers/tails, builds a StreamSource and serves it through
// StreamingHttpServer. The GUI launches the media player on StreamStarted.
class StreamingManager : public Singleton<StreamingManager>, public Speaker<StreamingManagerListener>,
	private QueueManagerListener, private TimerManagerListener
{
public:
	// Start streaming playback of a queued (or finished) bundle.
	// A non-empty aCastUdn casts to that DLNA device instead of launching the local player.
	void playBundle(QueueToken aBundleToken, const string& aCastUdn = Util::emptyString, const string& aCastName = Util::emptyString) noexcept;

	// Start streaming playback of a single queued (or finished) file.
	// RAR volumes are routed to the owning bundle's set.
	void playFile(const string& aTarget, const string& aCastUdn = Util::emptyString, const string& aCastName = Util::emptyString) noexcept;

	// Play a bundle that is about to be created under the given target path
	// (search/filelist "Download & play"); expires if nothing shows up.
	void playWhenAdded(const string& aTargetPathPrefix) noexcept;

	// Stop the stream: closes connections and drops the URL (the download continues)
	void stopStream(const string& aToken) noexcept;

	// Stop the stream and drop it from the list
	void removeStream(const string& aToken) noexcept;

	vector<StreamSnapshot> getStreams() const noexcept;
	optional<StreamSnapshot> getStream(const string& aToken) const noexcept;

	// A stream URL a peer at aPeerAddress can actually open, or empty when nothing of
	// that peer's address family is being served. See
	// StreamingHttpServer::adaptUrlForPeer - the URL is built before any cast target is
	// known, so it names one address of one family.
	string adaptStreamUrlForPeer(const string& aUrl, const string& aPeerAddress) const noexcept;

	void shutdown() noexcept;

private:
	friend class Singleton<StreamingManager>;
	StreamingManager();
	~StreamingManager() override;

	// Priority of a queue file before streaming raised it, so it can be put back on stop
	struct PriorityBackup {
		string target;
		Priority priority = Priority::DEFAULT;
		bool autoPriority = false;
	};

	struct Stream {
		string token;
		QueueToken bundleToken = 0;
		string bundleName;
		StringList targets;			// served file(s), RAR sets in volume order
		vector<PriorityBackup> priorityBackups;
		StreamSource::Ptr source;
		string url;
		StreamSnapshot::Phase phase = StreamSnapshot::PHASE_ANALYZING;
		string error;
		uint64_t addedTick = 0;
		uint64_t lastStallLog = 0;
		int64_t lastBuffered = 0;
		uint64_t lastBufferedTick = 0;
		bool tailRequested = false;
		string castTargetUdn;	// empty = local player
		string castTargetName;
	};

	struct PendingPlay {
		string targetPrefix;
		uint64_t expireTick = 0;
	};

	// Select what to stream from the bundle: a RAR set (volume order) or the largest video file.
	// Empty list = nothing playable.
	static StringList selectPlayableContent(const QueueItemList& aItems, const string& aBundleTarget) noexcept;

	static StreamSource::Callbacks getQueueCallbacks() noexcept;

	void addStream(const BundlePtr& aBundle, const StringList& aTargets, vector<PriorityBackup>&& aPriorityBackups = {}, const string& aCastUdn = Util::emptyString, const string& aCastName = Util::emptyString) noexcept;

	// Put the file priorities streaming raised back the way they were (runs once per stream)
	void restoreStreamPriorities(const string& aToken) noexcept;
	void failStream(Stream& aStream, const string& aError) noexcept;
	// Source I/O results gathered by onTimer BEFORE it takes cs. prepare()/available() open
	// files and parse RAR headers, so doing them under the lock stalled every UI read of
	// the stream list; updateStream() now consumes these instead of touching the source.
	struct StreamIoResult {
		StreamSource::Ptr source;
		StreamSnapshot::Phase phase = StreamSnapshot::PHASE_ANALYZING;
		StreamSource::PrepareResult prepareResult = StreamSource::PrepareResult::PENDING;
		int64_t size = -1;
		int64_t available = -1;
	};

	void updateStream(Stream& aStream, const StreamIoResult& aIo) noexcept; // phase progression on timer ticks; cs must be held
	StreamSnapshot toSnapshot(const Stream& aStream) const noexcept;

	// aStableKey (bundle token or file path) makes the token deterministic across sessions for player resume;
	// pass empty for a one-off random token
	string generateToken(const string& aStableKey) const noexcept;
	void checkIdleServer() noexcept;

	// QueueManagerListener
	void on(QueueManagerListener::BundleAdded, const BundlePtr& aBundle) noexcept override;
	void on(QueueManagerListener::BundleRemoved, const BundlePtr& aBundle) noexcept override;

	// TimerManagerListener
	void on(TimerManagerListener::Second, uint64_t aTick) noexcept override;

	mutable CriticalSection cs;
	map<string, Stream> streams;
	vector<PendingPlay> pendingPlays;
	vector<QueueToken> pendingStarts;	// matched pending plays, started on the next timer tick
	unique_ptr<StreamingHttpServer> server;
	bool shutdownCalled = false;
};

} // namespace dcpp

#endif
