/*
* Copyright (C) 2003-2005 Pär Björklund, per.bjorklund@gmail.com
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include "ColorSettings.h"

namespace dcpp {

ColorSettings::ColorSettings() : bTimestamps(false), bUsers(false), bMyNick(false), bUsingRegexp(false),
	bWholeWord(false),
	bWholeLine(false), bIncludeNickList(false), bCaseSensitive(false), bPopup(false), bTab(false),
	bPlaySound(false), bBold(false), bUnderline(false), bItalic(false), bStrikeout(false),
	/*bLastLog(false),*/ bFlashWindow(false), iMatchType(1), iBgColor(0), iFgColor(0), bHasBgColor(false),
	bHasFgColor(false), bContext(0), bMatchColumn(0) {
}

#ifdef _WIN32

void ColorSettings::setMatch(const tstring& match) {
	// These flags are derived purely from the match string, so reset them first;
	// otherwise editing an existing "$Re:" rule into a plain (non-regex) one leaves
	// bUsingRegexp set and setRegexp() then tries to compile the plain text as a
	// regex and throws "Badly formatted regular expression" (LP #1891075).
	bTimestamps = bUsers = bMyNick = bUsingRegexp = false;
	if (match.compare(_T("$ts$")) == 0) {
		bTimestamps = true;
	} else if (match.compare(_T("$users$")) == 0) {
		bUsers = true;
	} else if (match.find(_T("$mynick$")) != tstring::npos) {
		bMyNick = true;
	} else if (match.find(_T("$Re:")) == 0) {
		bUsingRegexp = true;
	}
	strMatch = match;
}
void ColorSettings::setRegexp() {
	if (!bUsingRegexp) {
		return;
	}

	// On a bad pattern the rule is demoted to a plain-text one before the error is re-thrown, so a
	// caller that keeps the rule anyway (HighlightManager::load does, to avoid silently erasing the
	// user's config) is never left with bUsingRegexp set over an unassigned boost::wregex -- every
	// match site would then run regex_search against an empty expression. Callers that report the
	// error to the user still see the exception.
	try {
		regexp.assign(strMatch.substr(4), getCaseSensitive() ? boost::match_default : boost::regex_constants::icase);
	} catch (...) {
		bUsingRegexp = false;
		throw;
	}
}

#else

void ColorSettings::setMatch(const tstring& match) {

}
void ColorSettings::setRegexp() {

}

#endif

}