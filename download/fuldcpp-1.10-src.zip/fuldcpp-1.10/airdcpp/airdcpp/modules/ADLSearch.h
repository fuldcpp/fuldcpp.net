/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*
 * Automatic Directory Listing Search
 * Henrik Engström, henrikengstrom at home se
 */

#ifndef DCPLUSPLUS_DCPP_A_D_L_SEARCH_H
#define DCPLUSPLUS_DCPP_A_D_L_SEARCH_H

#include <airdcpp/filelist/DirectoryListingDirectory.h>
#include <airdcpp/message/Message.h>
#include <airdcpp/core/Singleton.h>
#include <airdcpp/util/text/StringMatch.h>

namespace dcpp {

class AdlSearchManager;

///	Class that represent an ADL search
class ADLSearch
{
public:

	ADLSearch();								 

	// Active search
	bool isActive = true;

	// Some Comment
	string adlsComment;

	// Name of the group (category) this rule belongs to; empty = the default group.
	// Persisted as an optional per-rule <Group> tag in ADLSearch.xml (a <SearchGroup>
	// Name attribute is also honored on load as a fallback).
	string group;

	// Auto Queue Results
	bool isAutoQueue = false;

	// Search source type
	enum SourceType {
		TypeFirst = 0,
		OnlyFile = TypeFirst,
		OnlyDirectory,
		FullPath,
		TTHType,
		TypeLast
	};
	
	SourceType sourceType = OnlyFile;

	SourceType StringToSourceType(const string& s);

	string SourceTypeToString(SourceType t);

	tstring SourceTypeToDisplayString(SourceType t);

	// Maximum & minimum file sizes (in bytes). 
	// Negative values means do not check.
	int64_t minFileSize = -1;
	int64_t maxFileSize = -1;

	enum SizeType {
		SizeBytes     = TypeFirst,
		SizeKiloBytes,
		SizeMegaBytes,
		SizeGigaBytes
	};

	SizeType typeFileSize = SizeBytes;

	SizeType StringToSizeType(const string& s);
	string SizeTypeToString(SizeType t);
	tstring SizeTypeToDisplayString(SizeType t);
	int64_t GetSizeBase();

	// Name of the destination directory (empty = 'ADLSearch') and its index
	//string destDir;
	unsigned long ddIndex = 0;

	bool isRegEx() const;
	void setRegEx(bool b);
	string getPattern();
	void setPattern(const string& aPattern);

	void setDestDir(const string& aDestDir) noexcept;
	const string& getDestDir() const noexcept { return name; }
private:
	string name;

	friend class ADLSearchManager;

	StringMatch match;

	/// Prepare search
	void prepare();

	/// Search for file match
	bool matchesFile(const string& f, const string& fp, int64_t size, const string& aTTH = Util::emptyString);
	/// Search for directory match
	bool matchesDirectory(const string& d);

	bool searchAll(const string& s);
};


class ADLSearchManager : public Singleton<ADLSearchManager>
{
public:
	// Destination directory indexing
	struct DestDir {
		DestDir(const string& aName, const DirectoryListing::Directory::Ptr& aDir) :
			name(aName), dir(aDir) { }

		const string name;
		DirectoryListing::Directory::Ptr dir = nullptr;
		DirectoryListing::Directory* subdir = nullptr;
		bool fileAdded = false;
	};
	using DestDirList = vector<DestDir>;

	ADLSearchManager();
	~ADLSearchManager();

	// Search collections
	using SearchCollection = vector<ADLSearch>;

	// `collection` is private: it used to be a public member that the ADL frame and
	// AdlSearchApi indexed directly, so every one of those reads raced matchListing's walk
	// (which runs on a filelist dispatcher thread) and the mutators below. These
	// accessors all copy under the lock -- an ADLSearch is a handful of strings and a
	// compiled matcher, and these paths are user-driven, so the copy is not on any hot
	// path.
	SearchCollection getCollection() const noexcept {
		RLock l(cs);
		return collection;
	}

	size_t getCollectionSize() const noexcept {
		RLock l(cs);
		return collection.size();
	}

	// nullopt when the index no longer exists -- callers used to index straight in, which
	// is exactly what made a concurrent removal an out-of-bounds read.
	optional<ADLSearch> getSearch(size_t aIndex) const noexcept {
		RLock l(cs);
		if (aIndex >= collection.size()) {
			return nullopt;
		}

		return collection[aIndex];
	}


	// Load/save search collection to XML file
	void load() noexcept;
	void save(bool forced = false) noexcept;

	// Per-match state, threaded through the recursion instead of parked on the singleton.
	//
	// These two used to be GETSET members. matchListing() runs on each filelist's OWN
	// dispatcher thread, so two lists finishing at once had both threads writing the same
	// `user` -- a HintedUser is a shared_ptr plus a string, and shared_ptr assignment is
	// not atomic, so a concurrent read could copy a half-updated control block (refcount
	// corruption, then a double free) or a torn hint. The benign outcome was queueing an
	// ADL hit against the wrong user. Nothing outside this class ever used the accessors.
	struct MatchContext {
		HintedUser user;
		bool breakOnFirst = false;
	};

	// @remarks Used to add ADLSearch directories to an existing DirectoryListing
	// Throws AbortException
	void matchListing(DirectoryListing& aList);
	bool addCollection(ADLSearch& search, int index) noexcept;
	bool removeCollection(int index) noexcept;
	bool changeState(int index, bool enabled) noexcept;
	bool updateCollection(ADLSearch& search, int index) noexcept;
	int8_t getRunning() const noexcept { return running; }

	static void log(const string& aMsg, LogMessage::Severity aSeverity) noexcept;
private:
	ADLSearch loadSearch(SimpleXML& xml);

	ADLSearch::SourceType StringToSourceType(const string& s);

	// Atomic: set by the mutators on the UI/web threads and read-then-cleared by save() on
	// ConfigBackupManager's backup worker.
	std::atomic<bool> dirty { false };

	// @internal
	// Throws AbortException
	void matchRecurse(DestDirList& /*aDestList*/, const DirectoryListing::Directory::Ptr& /*aDir*/, const string& aAdcPath, DirectoryListing& /*aDirList*/, const MatchContext& aContext);
	// Search for file match
	void MatchesFile(DestDirList& destDirVector, const DirectoryListing::File::Ptr& currentFile, const string& aAdcPath, const MatchContext& aContext) noexcept;
	// Search for directory match
	void MatchesDirectory(DestDirList& destDirVector, const DirectoryListing::Directory::Ptr& currentDir, const string& aAdcPath, const MatchContext& aContext) noexcept;
	// Step up directory
	void stepUpDirectory(DestDirList& destDirVector) noexcept;

	// Prepare destination directory indexing
	void PrepareDestinationDirectories(DestDirList& destDirVector, DirectoryListing::Directory::Ptr& root) noexcept;
	static void addRootDirectory(const string& aName, DestDirList& destDirs_, DirectoryListing::Directory::Ptr& root) noexcept;
	// Finalize destination directories
	void FinalizeDestinationDirectories(DestDirList& destDirVector, DirectoryListing::Directory::Ptr& root) noexcept;

	std::atomic<int8_t> running = 0;

	SearchCollection collection;

	// Guards `collection`. `running` is only an advisory hint for the UI (it deliberately
	// allows >1 and is a check-then-act), so it cannot serialise anything on its own.
	// Everything that touches the collection -- the mutators, matchListing's walk, and the
	// accessors above -- goes through this.
	mutable SharedMutex cs;
};

} // namespace dcpp

#endif // !defined(DCPLUSPLUS_DCPP_A_D_L_SEARCH_H)