/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include "RarReader.h"

#include <airdcpp/core/classes/Exception.h>
#include <airdcpp/core/io/File.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/text/Text.h>
#include <airdcpp/util/Util.h>

#include <cctype>
#include <cstring>

namespace dcpp {

namespace {
	const uint8_t RAR4_SIG[] = { 0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x00 };
	const uint8_t RAR5_SIG[] = { 0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x01, 0x00 };

	// Total header bytes parsed per volume before giving up (hostile/corrupt file guard)
	const int64_t MAX_HEADER_BYTES = 1024 * 1024;

	// RAR4 block types
	const uint8_t R4_BLOCK_MAIN = 0x73;
	const uint8_t R4_BLOCK_FILE = 0x74;
	const uint8_t R4_BLOCK_END = 0x7b;

	// RAR4 flags
	const uint16_t R4_MHD_PASSWORD = 0x0080;
	const uint16_t R4_LHD_SPLIT_BEFORE = 0x0001;
	const uint16_t R4_LHD_SPLIT_AFTER = 0x0002;
	const uint16_t R4_LHD_PASSWORD = 0x0004;
	const uint16_t R4_LHD_LARGE = 0x0100;
	const uint16_t R4_LHD_UNICODE = 0x0200;
	const uint16_t R4_LHD_DIRECTORY = 0x00e0;
	const uint16_t R4_LONG_BLOCK = 0x8000;
	const uint8_t R4_METHOD_STORE = 0x30;

	// RAR5 block types
	const uint64_t R5_BLOCK_MAIN = 1;
	const uint64_t R5_BLOCK_FILE = 2;
	const uint64_t R5_BLOCK_SERVICE = 3;
	const uint64_t R5_BLOCK_ENCRYPTION = 4;
	const uint64_t R5_BLOCK_END = 5;

	// RAR5 flags
	const uint64_t R5_HFL_EXTRA = 0x01;
	const uint64_t R5_HFL_DATA = 0x02;
	const uint64_t R5_HFL_SPLIT_BEFORE = 0x08;
	const uint64_t R5_HFL_SPLIT_AFTER = 0x10;
	const uint64_t R5_FHFL_DIRECTORY = 0x01;
	const uint64_t R5_FHFL_MTIME = 0x02;
	const uint64_t R5_FHFL_CRC = 0x04;
	const uint64_t R5_FEXTRA_ENCRYPTION = 0x01;

	uint16_t readU16(const uint8_t* p) noexcept {
		return static_cast<uint16_t>(p[0]) | (static_cast<uint16_t>(p[1]) << 8);
	}

	uint32_t readU32(const uint8_t* p) noexcept {
		return static_cast<uint32_t>(p[0]) | (static_cast<uint32_t>(p[1]) << 8) |
			(static_cast<uint32_t>(p[2]) << 16) | (static_cast<uint32_t>(p[3]) << 24);
	}

	// Reader limited to the verified byte range of a (possibly still downloading) volume
	class BoundedReader {
	public:
		BoundedReader(const string& aPath, int64_t aAvailableBytes) :
			f(aPath, File::READ, File::OPEN | File::SHARED_WRITE | File::SHARED_DELETE, File::BUFFER_RANDOM),
			avail(min(aAvailableBytes, f.getSize())), fileSize(f.getSize()) { }

		// The length is int64_t, not size_t, on purpose. A caller computing a length from
		// getAvailable() - pos can produce a negative value when the parse position has run past
		// the downloaded prefix; as size_t that becomes astronomically large, and converting it
		// back for the bounds check below reproduced the original negative -- so the check passed
		// and the huge length reached ::ReadFile. Keeping one signed type end to end means a
		// negative length is simply rejected here.
		bool read(int64_t aPos, void* aBuf, int64_t aLen) noexcept {
			// Written as (aLen > avail - aPos) rather than (aPos + aLen > avail) so a large aLen
			// cannot overflow the addition.
			if (aPos < 0 || aLen <= 0 || aPos > avail || aLen > avail - aPos) {
				return false;
			}

			f.setPos(aPos);
			auto len = static_cast<size_t>(aLen);
			try {
				return f.read(aBuf, len) == static_cast<size_t>(aLen);
			} catch (const FileException&) {
				return false;
			}
		}

		int64_t getAvailable() const noexcept { return avail; }
		int64_t getFileSize() const noexcept { return fileSize; }
	private:
		File f;
		const int64_t avail;
		const int64_t fileSize;
	};

	// RAR5 variable-length integer; returns the number of bytes consumed (0 = malformed/truncated)
	size_t readVint(const uint8_t* p, size_t aLen, uint64_t& value_) noexcept {
		value_ = 0;
		for (size_t i = 0; i < aLen && i < 10; ++i) {
			value_ |= static_cast<uint64_t>(p[i] & 0x7f) << (i * 7);
			if (!(p[i] & 0x80)) {
				return i + 1;
			}
		}

		return 0;
	}

	RarParseResult parseRar4(BoundedReader& reader, RarVolumeInfo& info_) noexcept {
		int64_t pos = sizeof(RAR4_SIG);
		int64_t headerBytes = 0;

		while (true) {
			if (pos >= reader.getFileSize()) {
				info_.complete = true;
				return RarParseResult::OK;
			}

			uint8_t head[7];
			if (!reader.read(pos, head, sizeof(head))) {
				return RarParseResult::NEED_MORE_DATA;
			}

			const auto type = head[2];
			const auto flags = readU16(head + 3);
			const auto headSize = readU16(head + 5);
			if (headSize < 7) {
				return RarParseResult::CORRUPT;
			}

			headerBytes += headSize;
			if (headerBytes > MAX_HEADER_BYTES) {
				return RarParseResult::CORRUPT;
			}

			int64_t addSize = 0;
			if (flags & R4_LONG_BLOCK) {
				uint8_t buf[4];
				if (!reader.read(pos + 7, buf, sizeof(buf))) {
					return RarParseResult::NEED_MORE_DATA;
				}
				addSize = readU32(buf);
			}

			if (type == R4_BLOCK_MAIN) {
				if (flags & R4_MHD_PASSWORD) {
					return RarParseResult::ENCRYPTED;
				}
			} else if (type == R4_BLOCK_FILE) {
				if (flags & R4_LHD_PASSWORD) {
					return RarParseResult::ENCRYPTED;
				}

				uint8_t fixed[25];
				if (!reader.read(pos + 7, fixed, sizeof(fixed))) {
					return RarParseResult::NEED_MORE_DATA;
				}

				RarFileEntry entry;
				int64_t packSize = readU32(fixed);
				int64_t unpSize = readU32(fixed + 4);
				const auto method = fixed[18];
				const auto nameSize = readU16(fixed + 19);

				int64_t nameOffset = pos + 32;
				if (flags & R4_LHD_LARGE) {
					uint8_t high[8];
					if (!reader.read(pos + 32, high, sizeof(high))) {
						return RarParseResult::NEED_MORE_DATA;
					}

					packSize |= static_cast<int64_t>(readU32(high)) << 32;
					unpSize |= static_cast<int64_t>(readU32(high + 4)) << 32;
					nameOffset += 8;
				}

				if (nameSize > 0 && nameSize < 4096 && nameOffset + nameSize <= pos + headSize) {
					string name(nameSize, '\0');
					if (!reader.read(nameOffset, &name[0], nameSize)) {
						return RarParseResult::NEED_MORE_DATA;
					}

					// Unicode names store the ASCII part before a NUL separator; that part is all we need
					if (auto nul = name.find('\0'); nul != string::npos) {
						name.erase(nul);
					}

					entry.name = name;
				}

				entry.packedSize = packSize;
				entry.unpackedSize = unpSize;
				entry.dataOffset = pos + headSize;
				entry.stored = method == R4_METHOD_STORE;
				entry.splitBefore = (flags & R4_LHD_SPLIT_BEFORE) > 0;
				entry.splitAfter = (flags & R4_LHD_SPLIT_AFTER) > 0;
				entry.directory = (flags & R4_LHD_DIRECTORY) == R4_LHD_DIRECTORY;
				info_.files.push_back(std::move(entry));
			} else if (type == R4_BLOCK_END) {
				info_.complete = true;
				return RarParseResult::OK;
			}

			pos += headSize + addSize;
		}
	}

	RarParseResult parseRar5(BoundedReader& reader, RarVolumeInfo& info_) noexcept {
		int64_t pos = sizeof(RAR5_SIG);
		int64_t headerBytes = 0;

		while (true) {
			if (pos >= reader.getFileSize()) {
				info_.complete = true;
				return RarParseResult::OK;
			}

			// CRC32 + the header size vint.
			//
			// availableFromPos stays signed and is range-checked before any narrowing: the
			// archive's own dataSize vint drives pos, so a hostile volume can push it past the
			// bytes actually downloaded, making this negative. Casting that to size_t previously
			// produced a ~2^64 length that sailed through the "< 6" test.
			uint8_t sizeBuf[14];
			const int64_t availableFromPos = reader.getAvailable() - pos;
			if (availableFromPos < 6) {
				return RarParseResult::NEED_MORE_DATA;
			}

			const auto sizeBufLen = static_cast<size_t>(min<int64_t>(sizeof(sizeBuf), availableFromPos));
			if (!reader.read(pos, sizeBuf, static_cast<int64_t>(sizeBufLen))) {
				return RarParseResult::NEED_MORE_DATA;
			}

			uint64_t headerSize = 0;
			const auto sizeLen = readVint(sizeBuf + 4, sizeBufLen - 4, headerSize);
			if (sizeLen == 0) {
				return RarParseResult::CORRUPT;
			}

			if (headerSize == 0 || headerSize > static_cast<uint64_t>(MAX_HEADER_BYTES)) {
				return RarParseResult::CORRUPT;
			}

			headerBytes += static_cast<int64_t>(headerSize);
			if (headerBytes > MAX_HEADER_BYTES) {
				return RarParseResult::CORRUPT;
			}

			const auto headerStart = pos + 4 + static_cast<int64_t>(sizeLen);
			ByteVector header(headerSize);
			if (!reader.read(headerStart, header.data(), header.size())) {
				return RarParseResult::NEED_MORE_DATA;
			}

			const uint8_t* p = header.data();
			size_t remaining = header.size();
			auto get = [&](uint64_t& value_) noexcept {
				const auto len = readVint(p, remaining, value_);
				p += len;
				remaining -= len;
				return len > 0;
			};

			auto skip = [&](size_t aBytes) noexcept {
				if (remaining < aBytes) {
					return false;
				}
				p += aBytes;
				remaining -= aBytes;
				return true;
			};

			uint64_t type = 0, flags = 0, extraSize = 0, dataSize = 0;
			if (!get(type) || !get(flags)) {
				return RarParseResult::CORRUPT;
			}

			if ((flags & R5_HFL_EXTRA) && !get(extraSize)) {
				return RarParseResult::CORRUPT;
			}

			if ((flags & R5_HFL_DATA) && !get(dataSize)) {
				return RarParseResult::CORRUPT;
			}

			if (type == R5_BLOCK_ENCRYPTION) {
				return RarParseResult::ENCRYPTED;
			} else if (type == R5_BLOCK_END) {
				info_.complete = true;
				return RarParseResult::OK;
			} else if (type == R5_BLOCK_FILE) {
				uint64_t fileFlags = 0, unpSize = 0, attr = 0, compInfo = 0, hostOS = 0, nameLen = 0;
				if (!get(fileFlags) || !get(unpSize) || !get(attr)) {
					return RarParseResult::CORRUPT;
				}

				if ((fileFlags & R5_FHFL_MTIME) && !skip(4)) {
					return RarParseResult::CORRUPT;
				}

				if ((fileFlags & R5_FHFL_CRC) && !skip(4)) {
					return RarParseResult::CORRUPT;
				}

				if (!get(compInfo) || !get(hostOS) || !get(nameLen)) {
					return RarParseResult::CORRUPT;
				}

				if (nameLen == 0 || nameLen > remaining || nameLen > 4096) {
					return RarParseResult::CORRUPT;
				}

				RarFileEntry entry;
				entry.name.assign(reinterpret_cast<const char*>(p), static_cast<size_t>(nameLen));
				entry.packedSize = static_cast<int64_t>(dataSize);
				entry.unpackedSize = static_cast<int64_t>(unpSize);
				entry.dataOffset = headerStart + static_cast<int64_t>(headerSize);
				entry.stored = ((compInfo >> 7) & 0x07) == 0;
				entry.splitBefore = (flags & R5_HFL_SPLIT_BEFORE) > 0;
				entry.splitAfter = (flags & R5_HFL_SPLIT_AFTER) > 0;
				entry.directory = (fileFlags & R5_FHFL_DIRECTORY) > 0;

				// Extra records live at the end of the header data; an encryption record means we can't stream
				if (extraSize > 0 && extraSize <= header.size()) {
					const uint8_t* ep = header.data() + (header.size() - static_cast<size_t>(extraSize));
					size_t eRemaining = static_cast<size_t>(extraSize);
					while (eRemaining > 0) {
						uint64_t recSize = 0, recType = 0;
						const auto sl = readVint(ep, eRemaining, recSize);
						// readVint bounds sl by eRemaining, so eRemaining - sl can't underflow;
						// compare this way to avoid sl + recSize overflowing with a hostile vint
						if (sl == 0 || recSize == 0 || recSize > eRemaining - sl) {
							break;
						}

						const auto tl = readVint(ep + sl, static_cast<size_t>(recSize), recType);
						if (tl == 0) {
							break;
						}

						if (recType == R5_FEXTRA_ENCRYPTION) {
							return RarParseResult::ENCRYPTED;
						}

						ep += sl + static_cast<size_t>(recSize);
						eRemaining -= sl + static_cast<size_t>(recSize);
					}
				}

				info_.files.push_back(std::move(entry));
			}

			// Service and unknown blocks are skipped via their data size.
			// dataSize is an attacker-controlled vint and was never range-checked before
			// this addition: a crafted volume encoding INT64_MAX overflowed int64_t, which
			// is UB (and traps under /RTCc or UBSan) even though MSVC happens to wrap to a
			// negative value that BoundedReader::read then rejects. Every other field here
			// is bounds-checked; this one only fed the seek position, so it was missed.
			const auto base = headerStart + static_cast<int64_t>(headerSize);
			if (static_cast<uint64_t>(dataSize) > static_cast<uint64_t>(std::numeric_limits<int64_t>::max() - base)) {
				return RarParseResult::CORRUPT;
			}

			pos = base + static_cast<int64_t>(dataSize);
		}
	}
}

bool RarReader::isRarVolume(const string& aFileName) noexcept {
	return getVolumeSeq(aFileName) >= 0;
}

bool RarReader::isFirstVolume(const string& aFileName) noexcept {
	return getVolumeSeq(aFileName) == 0;
}

int RarReader::getVolumeSeq(const string& aFileName) noexcept {
	auto name = Text::toLower(PathUtil::getFileName(aFileName));
	if (name.length() < 5) {
		return -1;
	}

	if (name.ends_with(".rar")) {
		// New-style .partN.rar?
		auto base = name.substr(0, name.length() - 4);
		if (auto partPos = base.rfind(".part"); partPos != string::npos) {
			auto digits = base.substr(partPos + 5);
			if (!digits.empty() && ranges::all_of(digits, [](char c) { return isdigit(static_cast<unsigned char>(c)); })) {
				auto num = Util::toInt(digits);
				return num > 0 ? num - 1 : -1;
			}
		}

		return 0;
	}

	// Old-style continuation: .r00 ... .r99, .s00 ...
	if (name[name.length() - 4] == '.') {
		const auto c = name[name.length() - 3];
		const auto d1 = name[name.length() - 2];
		const auto d2 = name[name.length() - 1];
		if (c >= 'r' && c <= 'z' && isdigit(static_cast<unsigned char>(d1)) && isdigit(static_cast<unsigned char>(d2))) {
			return (c - 'r') * 100 + (d1 - '0') * 10 + (d2 - '0') + 1;
		}
	}

	return -1;
}

string RarReader::getVolumeBase(const string& aFileName) noexcept {
	auto path = Text::toLower(aFileName);
	if (getVolumeSeq(aFileName) < 0) {
		return path;
	}

	if (path.ends_with(".rar")) {
		path.erase(path.length() - 4);
		if (auto partPos = path.rfind(".part"); partPos != string::npos) {
			auto digits = path.substr(partPos + 5);
			if (!digits.empty() && ranges::all_of(digits, [](char c) { return isdigit(static_cast<unsigned char>(c)); })) {
				path.erase(partPos);
			}
		}

		return path;
	}

	return path.substr(0, path.length() - 4);
}

RarParseResult RarReader::parseVolume(const string& aPath, int64_t aAvailableBytes, RarVolumeInfo& info_) noexcept {
	try {
		BoundedReader reader(aPath, aAvailableBytes);

		uint8_t sig[8];
		if (!reader.read(0, sig, sizeof(sig))) {
			// Even the signature isn't fully there yet (unless the file really is this tiny)
			return reader.getFileSize() < static_cast<int64_t>(sizeof(sig)) ? RarParseResult::UNSUPPORTED : RarParseResult::NEED_MORE_DATA;
		}

		if (memcmp(sig, RAR5_SIG, sizeof(RAR5_SIG)) == 0) {
			info_.rar5 = true;
			return parseRar5(reader, info_);
		}

		if (memcmp(sig, RAR4_SIG, sizeof(RAR4_SIG)) == 0) {
			return parseRar4(reader, info_);
		}

		return RarParseResult::UNSUPPORTED;
	} catch (const FileException&) {
		return RarParseResult::NEED_MORE_DATA;
	}
}

} // namespace dcpp
