/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include "StreamingHttpServer.h"

#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/util/NetworkUtil.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/text/Text.h>
#include <airdcpp/util/Util.h>

namespace dcpp {

namespace {
	const uint32_t POLL_TIMEOUT = 250;
	const size_t MAX_REQUEST_SIZE = 8 * 1024;
	const uint64_t REQUEST_TIMEOUT = 10 * 1000;
	const uint64_t WRITE_STALL_TIMEOUT = 120 * 1000;	// drop a client that stops accepting data
	const size_t SEND_BUF_SIZE = 256 * 1024;
	const size_t MAX_CONNECTIONS = 8;
	const uint64_t SEEK_FETCH_INTERVAL = 5 * 1000;
	const int64_t READ_AHEAD_WINDOW = 24 * 1024 * 1024;	// keep this much prioritized ahead of the playhead

	const string CRLF = "\r\n";

	string encodeUrlName(const string& aName) noexcept {
		string ret;
		ret.reserve(aName.size());
		for (const auto c: aName) {
			if (isalnum(static_cast<unsigned char>(c)) || c == '.' || c == '-' || c == '_' || c == '~') {
				ret += c;
			} else {
				char buf[4];
				snprintf(buf, sizeof(buf), "%%%02X", static_cast<unsigned char>(c));
				ret += buf;
			}
		}

		return ret;
	}

	bool isValidToken(const string& aToken) noexcept {
		return aToken.length() == 32 && ranges::all_of(aToken, [](char c) {
			return isdigit(static_cast<unsigned char>(c)) || (c >= 'a' && c <= 'f');
		});
	}

	string trimCopy(const string& aStr) noexcept {
		const auto first = aStr.find_first_not_of(" \t\r\n");
		if (first == string::npos) {
			return string();
		}

		const auto last = aStr.find_last_not_of(" \t\r\n");
		return aStr.substr(first, last - first + 1);
	}

	// Single "bytes=a-b" / "bytes=a-" / "bytes=-n" range; false = no (usable) range header
	bool parseRange(const string& aHeaders, int64_t aTotal, int64_t& start_, int64_t& end_) noexcept {
		auto pos = aHeaders.find("\r\nrange:");
		if (pos == string::npos) {
			return false;
		}

		auto lineEnd = aHeaders.find("\r\n", pos + 2 + 6);
		auto value = aHeaders.substr(pos + 8, lineEnd == string::npos ? string::npos : lineEnd - (pos + 8));

		auto eq = value.find("bytes=");
		if (eq == string::npos) {
			return false;
		}

		value = value.substr(eq + 6);
		if (auto comma = value.find(','); comma != string::npos) {
			// Multi-range: serve the full content instead (legal)
			return false;
		}

		auto dash = value.find('-');
		if (dash == string::npos) {
			return false;
		}

		auto first = trimCopy(value.substr(0, dash));
		auto last = trimCopy(value.substr(dash + 1));

		if (first.empty()) {
			// Suffix range: the last N bytes
			if (last.empty()) {
				return false;
			}

			auto suffixLen = Util::toInt64(last);
			if (suffixLen <= 0) {
				return false;
			}

			start_ = max<int64_t>(0, aTotal - suffixLen);
			end_ = aTotal - 1;
			return true;
		}

		// Commit to the out-params only on success. Writing them first and then returning
		// false left the caller's pre-seeded defaults overwritten while its `ranged` flag
		// stayed false -- so the "start >= total" 416 check was skipped and the response
		// went out as 200 OK with a NEGATIVE Content-Length (e.g. "bytes=999-5").
		const auto start = Util::toInt64(first);
		const auto end = last.empty() ? aTotal - 1 : min(Util::toInt64(last), aTotal - 1);
		if (start < 0 || start > end) {
			return false;
		}

		start_ = start;
		end_ = end;
		return true;
	}
}

StreamingHttpServer::StreamingHttpServer() {
	// Casting requires a LAN-reachable URL, so when the user has opted in bind to the LAN
	// adapter (or the configured bind address) instead of loopback. Default stays localhost-only:
	// the token is the only capability, so exposing it beyond this machine is opt-in.
	advertisedHost = "127.0.0.1";
	if (SETTING(CAST_ENABLED)) {
		auto lanIp = SETTING(BIND_ADDRESS);
		if (lanIp.empty() || lanIp == "0.0.0.0") {
			// Deliberately NOT NetworkUtil::getLocalIp(): that prefers a *publicly
			// routable* address, so on a directly-connected machine it would bind the
			// stream to the internet. The setting says "your LAN" and the only
			// protection is a bearer token, so restrict this to a private range.
			lanIp.clear();
			try {
				for (const auto& adapter : NetworkUtil::getNetworkAdapters(false)) {
					if (NetworkUtil::isPrivateIp(adapter.ip, false)) {
						lanIp = adapter.ip;
						break;
					}
				}
			} catch (const Exception&) {
				// No adapters enumerable; stay on loopback.
			}
		} else if (!NetworkUtil::isPrivateIp(lanIp, false)) {
			// An explicitly configured public bind address is the user's choice for
			// hub traffic, but it is not something to silently reuse here.
			lanIp.clear();
		}

		if (!lanIp.empty() && lanIp != "0.0.0.0") {
			advertisedHost = lanIp;
		} else {
			LogManager::getInstance()->message(STRING(CAST_NO_LAN_ADDRESS),
				LogMessage::SEV_WARNING, STRING(STREAMING));
		}
	}

	// A renderer that is only reachable over IPv6 cannot use an IPv4 URL at all, so when
	// casting is on look for a private IPv6 address to serve on as well. Same rule as
	// above - unique-local or link-local only, never a global address, because the URL is
	// protected by nothing but its token.
	string bindHost6;
	if (SETTING(CAST_ENABLED)) {
		if (const auto& configured = SETTING(BIND_ADDRESS6);
				!configured.empty() && configured != "::" && NetworkUtil::isLanAddress(configured)) {
			bindHost6 = configured;
		} else {
			try {
				for (const auto& adapter: NetworkUtil::getNetworkAdapters(true)) {
					if (NetworkUtil::isLanAddress(adapter.ip)) {
						bindHost6 = adapter.ip;
						break;
					}
				}
			} catch (const Exception&) {
				// No adapters enumerable; IPv4 only.
			}
		}
	}

	listener.setLocalIp4(advertisedHost);

	if (!bindHost6.empty()) {
		// Bound with the zone id it was enumerated with, because a link-local address
		// cannot be bound without naming its interface. It is advertised without one:
		// the zone is this machine's label for the interface and means nothing to the
		// renderer, which reaches a link-local address over its own link.
		listener.setLocalIp6(bindHost6);
		listener.setV4only(false);
		advertisedHost6 = NetworkUtil::stripZoneId(bindHost6);
	} else {
		listener.setV4only(true);
	}

	port = listener.listen("0");

	// listen() binds IPv6 first and reuses its port for IPv4, so a v6 address that
	// resolves but cannot be bound would leave nothing serving it.
	if (!advertisedHost6.empty() && !listener.isV6Valid()) {
		advertisedHost6.clear();
	}

	start();
}

StreamingHttpServer::~StreamingHttpServer() {
	shutdown();
}

int StreamingHttpServer::run() noexcept {
	while (!die) {
		try {
			auto [read, _] = listener.wait(POLL_TIMEOUT, true, false);
			if (read && !die) {
				auto sock = make_unique<Socket>(Socket::TYPE_TCP);
				sock->accept(listener);

				Lock l(cs);
				reapConnections();
				if (connections.size() < MAX_CONNECTIONS) {
					connections.push_back(make_unique<Connection>(this, std::move(sock)));
				}
			}
		} catch (const SocketException& e) {
			dcdebug("StreamingHttpServer::run error: %s\n", e.getError().c_str());
		}

		Lock l(cs);
		reapConnections();
	}

	return 0;
}

void StreamingHttpServer::reapConnections() noexcept {
	// cs must be held. Only finished threads are joined here: a done thread has
	// returned from run() and no longer takes cs, so join() can't deadlock.
	connections.erase(std::remove_if(connections.begin(), connections.end(), [](const unique_ptr<Connection>& c) {
		if (c->isDone()) {
			c->join();
			return true;
		}

		return false;
	}), connections.end());
}

string StreamingHttpServer::registerSource(const string& aToken, const StreamSource::Ptr& aSource) noexcept {
	Lock l(cs);
	sources[aToken] = aSource;
	activity[aToken] = GET_TICK();
	return "http://" + NetworkUtil::formatAuthority(advertisedHost, port) + "/stream/" + aToken + "/" + encodeUrlName(aSource->getName());
}

string StreamingHttpServer::adaptUrlForPeer(const string& aUrl, const string& aPeerAddress) const noexcept {
	// The families have to match. An IPv6 peer cannot open an IPv4 URL and the reverse
	// is equally true, so the answer is either an address of the peer's own family or
	// nothing at all.
	const auto wantsV6 = NetworkUtil::stripZoneId(aPeerAddress).find(':') != string::npos;
	const auto& host = wantsV6 ? advertisedHost6 : advertisedHost;
	if (host.empty()) {
		return Util::emptyString;
	}

	// Only the authority is replaced; the path carries the token and the file name.
	const auto schemeEnd = aUrl.find("://");
	if (schemeEnd == string::npos) {
		return aUrl;
	}

	const auto authorityStart = schemeEnd + 3;
	const auto pathStart = aUrl.find('/', authorityStart);
	if (pathStart == string::npos) {
		return aUrl;
	}

	return aUrl.substr(0, authorityStart) + NetworkUtil::formatAuthority(host, port) + aUrl.substr(pathStart);
}

void StreamingHttpServer::unregisterSource(const string& aToken) noexcept {
	Lock l(cs);
	sources.erase(aToken);
	activity.erase(aToken);
	for (const auto& c: connections) {
		if (c->getToken() == aToken) {
			c->stop();
		}
	}
}

void StreamingHttpServer::setConnectionToken(Connection& aConnection, const string& aToken) noexcept {
	// See the call site: the token must be published under the same lock that
	// unregisterSource() holds while reading it.
	Lock l(cs);
	aConnection.token = aToken;
}

StreamSource::Ptr StreamingHttpServer::findSource(const string& aToken) const noexcept {
	Lock l(cs);
	auto i = sources.find(aToken);
	return i != sources.end() ? i->second : nullptr;
}

uint64_t StreamingHttpServer::getLastActivity(const string& aToken) const noexcept {
	Lock l(cs);
	auto i = activity.find(aToken);
	return i != activity.end() ? i->second : 0;
}

void StreamingHttpServer::touchActivity(const string& aToken) noexcept {
	Lock l(cs);
	if (auto i = activity.find(aToken); i != activity.end()) {
		i->second = GET_TICK();
	}
}

bool StreamingHttpServer::hasStreams() const noexcept {
	Lock l(cs);
	return !sources.empty();
}

void StreamingHttpServer::shutdown() noexcept {
	if (die.exchange(true)) {
		return;
	}

	listener.disconnect();
	join();

	// Move the connections out under cs, then stop/join them OUTSIDE the lock:
	// a serving thread takes cs in touchActivity/findSource, so joining under cs would deadlock.
	vector<unique_ptr<Connection>> pending;
	{
		Lock l(cs);
		pending.swap(connections);
		sources.clear();
		activity.clear();
	}

	for (auto& c: pending) {
		c->stop();
		c->join();
	}
}

/* Connection */

int StreamingHttpServer::Connection::run() noexcept {
	try {
		sock->setBlocking(false);
		handleRequest();
	} catch (const Exception& e) {
		dcdebug("StreamingHttpServer connection error: %s\n", e.getError().c_str());
	} catch (...) {
		// Never take the client down for one connection
	}

	try {
		sock->disconnect();
	} catch (...) { }

	done = true;
	return 0;
}

bool StreamingHttpServer::Connection::readRequest(string& request_) {
	const auto start = GET_TICK();
	char buf[1024];

	while (!stopping) {
		if (GET_TICK() - start > REQUEST_TIMEOUT || request_.size() > MAX_REQUEST_SIZE) {
			return false;
		}

		auto [canRead, _] = sock->wait(POLL_TIMEOUT, true, false);
		if (!canRead) {
			continue;
		}

		auto received = sock->read(buf, sizeof(buf));
		if (received == 0) {
			return false; // disconnected
		}

		if (received > 0) {
			request_.append(buf, static_cast<size_t>(received));
			if (request_.find("\r\n\r\n") != string::npos) {
				return true;
			}
		}
	}

	return false;
}

bool StreamingHttpServer::Connection::sendAll(const void* aBuf, size_t aLen) {
	auto p = static_cast<const uint8_t*>(aBuf);
	auto lastProgress = GET_TICK();

	while (aLen > 0 && !stopping) {
		auto [_, canWrite] = sock->wait(POLL_TIMEOUT, false, true);
		if (!canWrite) {
			// Give up on a client that accepts nothing, so it can't pin a connection slot forever
			if (GET_TICK() - lastProgress > WRITE_STALL_TIMEOUT) {
				return false;
			}
			continue;
		}

		auto written = sock->write(p, aLen);
		if (written <= 0) {
			continue;
		}

		p += written;
		aLen -= static_cast<size_t>(written);
		lastProgress = GET_TICK();
	}

	return aLen == 0;
}

bool StreamingHttpServer::Connection::isClientGone() noexcept {
	try {
		auto [canRead, _] = sock->wait(0, true, false);
		if (!canRead) {
			return false;
		}

		char buf[256];
		return sock->read(buf, sizeof(buf)) == 0;
	} catch (const Exception&) {
		return true;
	}
}

void StreamingHttpServer::Connection::handleRequest() {
	string request;
	if (!readRequest(request)) {
		return;
	}

	const auto sendError = [this](const string& aStatus, const string& aExtraHeader = Util::emptyString) {
		auto response = "HTTP/1.1 " + aStatus + CRLF
			+ (aExtraHeader.empty() ? Util::emptyString : aExtraHeader + CRLF)
			+ "Content-Length: 0" + CRLF
			+ "Connection: close" + CRLF + CRLF;
		sendAll(response.data(), response.size());
	};

	// Request line
	const auto lineEnd = request.find(CRLF);
	const auto line = request.substr(0, lineEnd);
	const auto methodEnd = line.find(' ');
	const auto pathEnd = line.find(' ', methodEnd + 1);
	if (methodEnd == string::npos || pathEnd == string::npos) {
		sendError("400 Bad Request");
		return;
	}

	const auto method = line.substr(0, methodEnd);
	const auto path = line.substr(methodEnd + 1, pathEnd - methodEnd - 1);
	if (method != "GET" && method != "HEAD") {
		sendError("405 Method Not Allowed");
		return;
	}

	// Only /stream/<token>[/<name>] exists; the token is the only capability, paths never touch the filesystem
	static const string PREFIX = "/stream/";
	if (path.compare(0, PREFIX.size(), PREFIX) != 0) {
		sendError("404 Not Found");
		return;
	}

	auto requestToken = path.substr(PREFIX.size());
	if (auto slash = requestToken.find('/'); slash != string::npos) {
		requestToken.erase(slash);
	}

	if (!isValidToken(requestToken)) {
		sendError("404 Not Found");
		return;
	}

	auto source = server->findSource(requestToken);
	if (!source) {
		sendError("404 Not Found");
		return;
	}

	// Assigned under the server lock: unregisterSource() holds it and compares
	// c->getToken(), which returns a const reference to this member. A 32-character token
	// exceeds MSVC's SSO buffer, so the assignment is a heap allocation plus a separate
	// pointer/size publish -- a reader interleaving there read past the buffer. Every other
	// cross-thread Connection field is already atomic; this one was missed.
	server->setConnectionToken(*this, requestToken);
	server->touchActivity(requestToken);

	const auto total = source->getSize();
	if (total < 0) {
		sendError("503 Service Unavailable");
		return;
	}

	int64_t start = 0;
	int64_t end = total - 1;
	const auto headers = Text::toLower(request);
	const auto ranged = parseRange(headers, total, start, end);
	if (ranged && start >= total) {
		sendError("416 Range Not Satisfiable", "Content-Range: bytes */" + Util::toString(total));
		return;
	}

	auto response = string("HTTP/1.1 ") + (ranged ? "206 Partial Content" : "200 OK") + CRLF
		+ "Content-Type: " + StreamSource::getMimeType(source->getName()) + CRLF
		+ "Content-Length: " + Util::toString(end - start + 1) + CRLF
		+ "Accept-Ranges: bytes" + CRLF
		// DLNA renderers (TVs) require these to accept and seek an HTTP stream; harmless to local players.
		// OP=01 = byte-range seek supported; the flags advertise a streaming, seekable source.
		+ "transferMode.dlna.org: Streaming" + CRLF
		+ "contentFeatures.dlna.org: DLNA.ORG_OP=01;DLNA.ORG_FLAGS=01700000000000000000000000000000" + CRLF
		+ "Server: FulDC++ DLNA/1.0" + CRLF
		+ "Connection: close" + CRLF;
	if (ranged) {
		response += "Content-Range: bytes " + Util::toString(start) + "-" + Util::toString(end) + "/" + Util::toString(total) + CRLF;
	}
	response += CRLF;

	if (!sendAll(response.data(), response.size())) {
		return;
	}

	if (method == "HEAD") {
		return;
	}

	serveBody(source, start, end - start + 1);
}

void StreamingHttpServer::Connection::serveBody(const StreamSource::Ptr& aSource, int64_t aPos, int64_t aRemaining) {
	ByteVector buf(SEND_BUF_SIZE);
	uint64_t lastFetchRequest = 0;
	const int64_t responseEnd = aPos + aRemaining;	// fixed end of this response
	int64_t readAheadEdge = aPos;	// inner offset up to which we've asked the queue to prioritize

	// Keep the region just ahead of the playhead prioritized so the download follows the player
	// (this is also what makes a far-forward seek responsive: the new position is fetched first).
	const auto pumpReadAhead = [&](int64_t aFrom) {
		// Nothing to do once the whole remainder is requested, or while enough is still buffered ahead
		if (readAheadEdge >= responseEnd || aFrom + READ_AHEAD_WINDOW / 2 < readAheadEdge) {
			return;
		}

		const auto want = min(responseEnd - aFrom, READ_AHEAD_WINDOW);
		if (want > 0) {
			aSource->requestRange(aFrom, want);
			readAheadEdge = max(readAheadEdge, aFrom + want);
		}
	};

	while (aRemaining > 0 && !stopping && aSource->isValid()) {
		const auto avail = aSource->available(aPos);
		if (avail < 0) {
			return;
		}

		if (avail == 0) {
			// Not downloaded yet: ask the queue to fetch it ahead of order (seeks/probes), then stall.
			// Players treat a stalling body as buffering.
			const auto tick = GET_TICK();
			if (tick - lastFetchRequest > SEEK_FETCH_INTERVAL) {
				lastFetchRequest = tick;
				readAheadEdge = aPos;	// re-anchor to the stalled position
				pumpReadAhead(aPos);
			}

			if (isClientGone()) {
				return;
			}

			server->touchActivity(token);
			sleep(POLL_TIMEOUT);
			continue;
		}

		pumpReadAhead(aPos);

		const auto chunk = static_cast<size_t>(min({ avail, aRemaining, static_cast<int64_t>(buf.size()) }));
		size_t got = 0;
		try {
			got = aSource->read(aPos, buf.data(), chunk);
		} catch (const FileException&) {
			return;
		}

		if (got == 0) {
			sleep(POLL_TIMEOUT);
			continue;
		}

		if (!sendAll(buf.data(), got)) {
			return;
		}

		server->touchActivity(token);
		aPos += got;
		aRemaining -= got;
	}
}

} // namespace dcpp
