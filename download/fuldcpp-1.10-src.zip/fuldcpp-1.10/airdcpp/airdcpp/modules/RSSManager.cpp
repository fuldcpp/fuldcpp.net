
/*
* Copyright (C) 2012-2024 AirDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include "AutoSearchManager.h"
#include "RSSManager.h"

#include <airdcpp/connection/http/HttpConnection.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/StateRecovery.h>
#include <airdcpp/share/ShareManager.h>
#include <airdcpp/queue/QueueManager.h>
#include <airdcpp/search/SearchTypes.h>
#include <airdcpp/hub/ClientManager.h>

#include <airdcpp/core/classes/ScopedFunctor.h>
#include <airdcpp/core/io/xml/SimpleXML.h>
#include <airdcpp/core/io/xml/SimpleXMLReader.h>
#include <airdcpp/core/io/stream/Streams.h>

#include <boost/algorithm/string/trim.hpp>

namespace dcpp {

#define CONFIG_NAME "RSS.xml"
#define CONFIG_DIR AppUtil::PATH_USER_CONFIG
#define DATABASE_DIR AppUtil::getPath(CONFIG_DIR) + "RSS" PATH_SEPARATOR_STR
#define DATABASE_VERSION "1"

RSSManager::RSSManager() : tasks(true) {
	File::ensureDirectory(DATABASE_DIR);
}

void RSSManager::shutdown() noexcept {
	// Stop new work first. dcpp::shutdown() calls BufferedSocket::waitShutdown() BEFORE
	// deleting this manager, but waitShutdown() is a one-shot poll, not a barrier -- a
	// downloadFeed task already queued (last timer tick, the frame's threaded Update, or
	// the web API) could still run in that window and start a fresh BufferedSocket.
	shuttingDown = true;
	TimerManager::getInstance()->removeListener(this);

	// The flag above is what actually stops queued work: DispatcherQueue::stop() only
	// signals and returns (it does not join), so a task already on the queue still runs --
	// it now sees shuttingDown and returns without creating a socket.
	//
	// Then drop the in-flight downloads while `cs` is still alive. Without this,
	// ~RSSManager destroys the mutex before rssList destroys the live HttpDownloads, so a
	// completion landing in that gap would lock a destroyed recursive_mutex.
	{
		Lock l(cs);
		for (const auto& feed : rssList) {
			feed->rssDownload.reset();
		}
	}
}

RSSManager::~RSSManager()
{
	// Idempotent; shutdown() is normally called first from unloadModules().
	TimerManager::getInstance()->removeListener(this);
}

void RSSManager::clearRSSData(const RSSPtr& aFeed) noexcept {
	
	{
		Lock l(cs);
		aFeed->getFeedData().clear(); 
		aFeed->setDirty(true);
	}
	fire(RSSManagerListener::RSSDataCleared(), aFeed);

}

RSSPtr RSSManager::getFeedByName(const string& aName) const noexcept {
	Lock l(cs);
	auto r = find_if(rssList.begin(), rssList.end(), [aName](const RSSPtr& a) { return aName == a->getFeedName(); });
	if (r != rssList.end())
		return *r;

	return nullptr;
}

RSSPtr RSSManager::getFeedByUrl(const string& aUrl) const noexcept {
	Lock l(cs);
	auto r = find_if(rssList.begin(), rssList.end(), [aUrl](const RSSPtr& a) { return aUrl == a->getUrl(); });
	if (r != rssList.end())
		return *r;

	return nullptr;
}

RSSPtr RSSManager::getFeedByToken(int aToken) const noexcept {
	Lock l(cs);
	auto r = find_if(rssList.begin(), rssList.end(), [aToken](const RSSPtr& a) { return aToken == a->getToken(); });
	if (r != rssList.end())
		return *r;

	return nullptr;
}


void RSSManager::parseAtomFeed(SimpleXML& xml, RSSPtr& aFeed) {
	xml.stepIn();
		while (xml.findChild("entry")) {
			xml.stepIn();
			bool newdata = false;
			string title;
			string link;
			string date;

			if (xml.findChild("link")) {
				link = xml.getChildAttrib("href");
			}
			xml.resetCurrentChild();
			if (xml.findChild("title")) {
				title = xml.getChildData();
				newdata = checkTitle(aFeed, title);
			}
			xml.resetCurrentChild();
			if (xml.findChild("updated"))
				date = xml.getChildData();

			if (newdata) {
				addData(title, link, date, aFeed);
			}

			xml.resetCurrentChild();
			xml.stepOut();
		}
	xml.stepOut();
}

void RSSManager::parseRSSFeed(SimpleXML& xml, RSSPtr& aFeed) {
	xml.stepIn();
	if (xml.findChild("channel")) {
		xml.stepIn();
		while (xml.findChild("item")) {
			xml.stepIn();
			bool newdata = false;
			string title;
			string link;
			string date;
			if (xml.findChild("title")) {
				title = xml.getChildData();
				newdata = checkTitle(aFeed, title);
			}
			xml.resetCurrentChild();

			if (newdata) {
				if (xml.findChild("link")) {
					link = xml.getChildData();
					//temp fix for some urls
					if (strncmp(link.c_str(), "//", 2) == 0)
						link = "https:" + link;
				}

				xml.resetCurrentChild();
				if (xml.findChild("pubDate"))
					date = xml.getChildData();

				addData(title, link, date, aFeed);
				xml.resetCurrentChild();
			}

			xml.stepOut();
		}
		xml.stepOut();
	}
	xml.stepOut();
}

void RSSManager::downloadComplete(const string& aUrl) {
	auto feed = getFeedByUrl(aUrl);
	if (!feed) {
		// Feed removed or renamed while the download was in flight. Nothing to clean up
		// here: the completion lambda now holds a WEAK reference (see downloadFeed), so
		// there is no ownership cycle for this early return to leak.
		return;
	}

	// Destroy the HttpDownload at function exit (after all uses of its buffer below, and after
	// fire()). This runs while the HttpConnection is still on the fire() stack (it self-deletes
	// only after this callback returns), so ~HttpDownload's removeListener() acts on a live
	// connection. Do NOT defer this past the connection's self-delete (that causes a UAF).
	ScopedFunctor([&] { feed->rssDownload.reset(); });

	// getFeedByUrl() resolves the URL to A feed; it does not prove that feed still owns a
	// download. The only previous guard was the null check on the feed itself, so a
	// concurrent reset left this dereferencing an empty unique_ptr.
	if (!feed->rssDownload) {
		return;
	}

	if (feed->rssDownload->buf.empty()) {
		log(feed->rssDownload->status, LogMessage::SEV_ERROR);
		return;
	}

	try {
		SimpleXML xml;
		xml.fromXML(feed->rssDownload->buf);
		if(xml.findChild("rss")) {
			parseRSSFeed(xml, feed);
		}
		xml.resetCurrentChild();
		if (xml.findChild("feed")) {
			parseAtomFeed(xml, feed);
		}
	} catch(const Exception& e) {
		log(STRING_F(ERROR_UPDATING_FEED, aUrl) + " : " + e.getError().c_str(), LogMessage::SEV_ERROR);
	}

	fire(RSSManagerListener::RSSFeedUpdated(), feed);
}


void RSSManager::log(const string& aMsg, LogMessage::Severity aSeverity) noexcept {
	LogManager::getInstance()->message(aMsg, aSeverity, STRING(RSS_FEEDS));
}

bool RSSManager::checkTitle(const RSSPtr& aFeed, string& aTitle) {
	if (aTitle.empty())
		return false;
	boost::algorithm::trim_if(aTitle, boost::is_space() || boost::is_any_of("\r\n"));
	Lock l(cs);
	return aFeed->getFeedData().find(aTitle) == aFeed->getFeedData().end();
}

// ADC-EXT 4.19 FEED: an item pushed by a hub. Only feeds the user is already subscribed to are
// accepted (a hub must not be able to add subscriptions), and the item is never run through the
// auto-download filters - otherwise a hub could choose what we search for and queue.
bool RSSManager::addHubFeedItem(const string& aUrl, const string& aTitle, const string& aLink, const string& aDate) noexcept {
	if (aUrl.empty() || aTitle.empty())
		return false;

	auto feed = getFeedByUrl(aUrl);
	if (!feed)
		return false;

	addData(aTitle, aLink, aDate, feed, false);
	return true;
}

void RSSManager::addData(const string& aTitle, const string& aLink, const string& aDate, RSSPtr& aFeed, bool aMatchFilters) {
	auto data = make_shared<RSSData>(aTitle, aLink, aDate, aFeed);
	{
		// Do the duplicate-title check and the insert together under a single lock.
		// checkTitle() does the same lookup, but it releases the lock before we reach here,
		// so a concurrent addData() for the same title could slip in between. emplace() only
		// inserts when the key is absent; if it reports no insertion, another thread already
		// added this title and we must not fire/match a second time.
		Lock l(cs);
		if (!aFeed->getFeedData().emplace(data->getTitle(), data).second)
			return;
	}
	aFeed->setDirty(true);
	// Fire outside the lock; listeners must not re-enter this object's CS while we hold it.
	fire(RSSManagerListener::RSSDataAdded(), data);

	if (!aMatchFilters)
		return;

	Lock l(cs);
	matchFilters(aFeed, data);
}

void RSSManager::matchFilters(const RSSPtr& aFeed) {
	if (aFeed) {
		Lock l(cs);
		ranges::for_each(aFeed->getFeedData() | views::values, [&](const RSSDataPtr& data) { matchFilters(aFeed, data); });
	}
}

void RSSManager::matchFilters(const RSSPtr& aFeed, const RSSDataPtr& aData) {
	
	//Match remove filters first, so it works kind of as a skiplist also
	bool remove = find_if(aFeed->getRssFilterList().begin(), aFeed->getRssFilterList().end(), [&](const RSSFilter& a)
		{ return a.getFilterAction() == RSSFilter::REMOVE && a.match(aData->getTitle()); }) != aFeed->getRssFilterList().end();

	if (remove) {
		tasks.addTask([=] { removeFeedData(aFeed, aData); });
		return;
	}

	for (auto& aF : aFeed->getRssFilterList()) {
		if (aF.match(aData->getTitle())) {
			if (aF.skipDupes) {
				if (ShareManager::getInstance()->getAdcDirectoryDupe(aData->getTitle(), 0) != DUPE_NONE)
					break; //Need to match other filters?
				if (QueueManager::getInstance()->getAdcDirectoryDupe(aData->getTitle(), 0) != DUPE_NONE)
					break; //Need to match other filters?
			}
			if (aF.getFilterAction() == RSSFilter::DOWNLOAD || aF.getFilterAction() == RSSFilter::ADD_AUTOSEARCH) {
				addAutoSearchItem(aF, aData);
			} 
			break; //One match is enough
		}
	}
}

bool RSSManager::addAutoSearchItem(const RSSFilter& aFilter, const RSSDataPtr& aData) noexcept {
	if (!AutoSearchManager::getInstance()->validateAutoSearchStr(aData->getTitle())) {
		return false;
	}

	time_t expireTime = aFilter.getExpireDays() > 0 ? GET_TIME() + aFilter.getExpireDays() * 24 * 60 * 60 : 0;

	AutoSearchPtr as = std::make_shared<AutoSearch>(aFilter.getFilterAction() == RSSFilter::DOWNLOAD, aData->getTitle(), SEARCH_TYPE_DIRECTORY, AutoSearch::ACTION_DOWNLOAD, true, aFilter.getDownloadTarget(),
		aFilter.getAsExactMatch() ? StringMatch::EXACT : StringMatch::PARTIAL, Util::emptyString, Util::emptyString, expireTime, true, true, false, Util::emptyString, AutoSearch::RSS_DOWNLOAD, false);

	//format time params, befora adding to autosearch, so we can use RSS date for folder
	if(aFilter.getFormatTimeParams())
		as->setTarget(Util::formatTime(aFilter.getDownloadTarget(), GET_TIME()));

	as->setGroup(aFilter.getAutosearchGroup());

	/*
	a hack, try to avoid growing autosearch list, allow adding max 5 items to internal searchqueue directly... will result in ~2 minute searchqueue time.
	Hopefylly most of these will get hits so we dont need to search them again.
	*/
	bool search = (aFilter.getFilterAction() == RSSFilter::DOWNLOAD) && ClientManager::getInstance()->getMaxSearchQueueSize() < 5;
	AutoSearchManager::getInstance()->addAutoSearch(as, search, false);
	return true;
}

void RSSManager::updateFeedItem(RSSPtr& aFeed, const string& aUrl, const string& aName, int aUpdateInterval, bool aEnable) noexcept {
	bool added = false;
	{
		Lock l(cs);
		aFeed->setUrl(aUrl);
		aFeed->setFeedName(aName);
		aFeed->setUpdateInterval(aUpdateInterval);
		aFeed->setEnable(aEnable);

		auto r = find_if(rssList.begin(), rssList.end(), [aFeed](const RSSPtr& a) { return aFeed->getToken() == a->getToken(); });
		if (r == rssList.end()) {
			added = true;
			rssList.emplace_back(aFeed);
		}
	}

	if(added)
		fire(RSSManagerListener::RSSFeedAdded(), aFeed);
	else
		fire(RSSManagerListener::RSSFeedChanged(), aFeed);

}

void RSSManager::updateFilterList(const RSSPtr& aFeed, vector<RSSFilter>& aNewList) {
	Lock l(cs);
	aFeed->rssFilterList = aNewList;
	for_each(aFeed->rssFilterList.begin(), aFeed->rssFilterList.end(), [&](RSSFilter& i) { i.prepare(); });
}

void RSSManager::enableFeedUpdate(const RSSPtr& aFeed, bool enable) noexcept {
	{
		Lock l(cs);
		aFeed->setEnable(enable);
	}
	// Fired outside the lock so that listeners can safely read the state back
	fire(RSSManagerListener::RSSFeedChanged(), aFeed);
}

void RSSManager::removeFeedItem(const RSSPtr& aFeed) noexcept {
	{
		Lock l(cs);
		//Delete database file?
		auto [first, last] = ranges::remove_if(rssList, [aFeed](const RSSPtr& a) { return aFeed->getToken() == a->getToken(); });
		rssList.erase(first, last);
	}
	fire(RSSManagerListener::RSSFeedRemoved(), aFeed);
}

void RSSManager::removeFeedData(const RSSPtr& aFeed, const RSSDataPtr& aData) {
	{
		Lock l(cs);
		aFeed->getFeedData().erase(aData->getTitle());
		aFeed->setDirty(true);
	}
	// Fired after the erase, outside the lock
	fire(RSSManagerListener::RSSDataRemoved(), aData);
}

void RSSManager::downloadFeed(const RSSPtr& aFeed, bool verbose/*false*/) noexcept {
	if (!aFeed)
		return;

	aFeed->setLastUpdate(GET_TIME());

	tasks.addTask([=] {
		if (shuttingDown) {
			// Queued before shutdown() ran; starting a socket now would outlive
			// BufferedSocket::waitShutdown().
			return;
		}

		{
			// Never reset() a download that is still running: the socket thread may be
			// inside HttpDownload::on(Data) appending to its buffer, and ~HttpDownload
			// would free that buffer underneath it. Two refreshes land here back to back
			// easily -- the frame's threaded "Update", the web API, and the scheduled tick
			// (which re-arms because setLastUpdate is stamped at start, above).
			Lock l(cs);
			if (aFeed->rssDownload) {
				return;
			}
		}

		HttpOptions options;
		// A feed served by a hostile or broken server otherwise streams an endless body
		// into memory: the default HttpOptions leaves maxBodySize at -1 (uncapped), and
		// SimpleXMLReader's own limits bound a token, not the transport buffer -- so the
		// allocation fails before parsing ever starts. Every other remote fetch in the tree
		// sets a cap; this one never opted in.
		options.setMaxBodySize(8 * 1024 * 1024);
		// An https feed URL is verified. The default leaves allowUntrusted at true, so the
		// certificate was not checked at all and the scheme bought nothing: this content drives
		// auto-search and auto-download, and the URL is user-configurable third-party, which is
		// exactly the case where a forged answer matters. A server with a self-signed certificate
		// now fails rather than being accepted silently; an http:// URL is unaffected.
		//
		// Note the interaction with an HTTP proxy: the request reaches a proxy in the clear, so
		// there is no certificate to verify and HttpConnection refuses it rather than pretending.
		// That is a visible change for proxy users, and the honest one -- it was never verified.
		options.setAllowUntrusted(false);

		// WEAK capture, deliberately. The RSS owns its HttpDownload, the HttpDownload owns
		// this completion function, and capturing aFeed by value closed that into a
		// reference cycle -- so any path that dropped out of downloadComplete() before the
		// ScopedFunctor reset (notably the feed-not-found early return, hit whenever a
		// feed is removed or renamed mid-download) leaked the RSS, its entire rssData map
		// and the download, for the lifetime of the process. The feed is kept alive by
		// rssList, so the weak_ptr resolves for as long as the feed still exists.
		std::weak_ptr<RSS> weakFeed = aFeed;
		aFeed->rssDownload.reset(new HttpDownload(aFeed->getUrl(),
			[this, weakFeed] {
				if (auto f = weakFeed.lock(); f) {
					downloadComplete(f->getUrl());
				}
			}, options));
		aFeed->rssDownload->start();

		if(verbose)
			log(STRING(UPDATING) + " " + aFeed->getUrl(), LogMessage::SEV_INFO);
	});

	//Lets resort the list to get a better chance for all other items to update and not end up updating the same one.
	Lock l(cs);
	sort(rssList.begin(), rssList.end(), [](const RSSPtr& a, const RSSPtr& b) { return a->getLastUpdate() < b->getLastUpdate(); });
}

RSSPtr RSSManager::getUpdateItem() const noexcept {
	for (auto i : rssList) {
		if (i->allowUpdate())
			return i;
	}
	return nullptr;
}


void RSSManager::on(TimerManagerListener::Second, uint64_t aTick) noexcept {
	{
		Lock l(cs);
		if (rssList.empty())
			return;
	}

	if (nextUpdate < aTick) {
		Lock l(cs);
		downloadFeed(getUpdateItem());
		nextUpdate = GET_TICK() + 1 * 60 * 1000; //Minute between item updates for now, TODO: handle intervals smartly :)
	} else if ((lastXmlSave + 15000) < aTick) {
		Lock l(cs);
		for_each(rssList.begin(), rssList.end(), [&](RSSPtr r) { if (r->getDirty()) tasks.addTask([=] { savedatabase(r); }); });
		lastXmlSave = aTick;
	}
}

class RSSLoader : public SimpleXMLReader::CallBack {
public:
	RSSLoader(){ }
	~RSSLoader() { }
	void startTag(const string& aName, StringPairList& attribs, bool) {
		if (aName == "Data") {
			int version = Util::toInt(getAttrib(attribs, "Version", 0));
			if (version == 0 || version > Util::toInt(DATABASE_VERSION))
				throw Exception("Non-supported RSS database version");
			
			const string& token = getAttrib(attribs, "Token", 1);
			aFeed = RSSManager::getInstance()->getFeedByToken(Util::toInt(token));
			if (!aFeed)
				throw Exception("No Feed associated with data");
			
		} else if (aName == "item") {
			if (!aFeed)
				throw Exception("RSS item without an associated feed");

			const string& title = getAttrib(attribs, "title", 0);
			const string& link = getAttrib(attribs, "link", 1);
			const string& pubdate = getAttrib(attribs, "pubdate", 2);
			const string& dateadded = getAttrib(attribs, "dateadded", 3);

			Lock l(RSSManager::getInstance()->getCS());
			auto rd = make_shared<RSSData>(title, link, pubdate, aFeed, Util::toInt64(dateadded));
			aFeed->getFeedData().emplace(rd->getTitle(), rd);
		}
	}

private:
	RSSPtr aFeed;
};

void RSSManager::load() {
	SettingsManager::loadSettingFile(CONFIG_DIR, CONFIG_NAME, [this](SimpleXML& xml) {
		if (xml.findChild("RSS")) {
			xml.stepIn();

			while (xml.findChild("Settings"))
			{
				auto feed = std::make_shared<RSS>(xml.getChildAttrib("Url"),
					xml.getChildAttrib("Name"),
					xml.getBoolChildAttrib("Enable"),
					Util::toInt64(xml.getChildAttrib("LastUpdate")),
					xml.getIntChildAttrib("UpdateInterval"),
					xml.getIntChildAttrib("Token"));
				xml.stepIn();

				loadFilters(xml, feed->rssFilterList);

				xml.resetCurrentChild();
				xml.stepOut();

				Lock l(cs);
				for_each(feed->rssFilterList.begin(), feed->rssFilterList.end(), [&](RSSFilter& i) { i.prepare(); });
				rssList.emplace_back(feed);
			}
			xml.resetCurrentChild();
			xml.stepOut();
		}
	});

	try {
		StringList fileList = File::findFiles(DATABASE_DIR, "RSSDataBase*", File::TYPE_FILE);

		// Map .bak orphans (crash between the save's two renames) back to their
		// main path so the backup promotion can restore them
		StringList loadPaths;
		for (const auto& p: fileList) {
			if (PathUtil::getFileExt(p) == ".xml") {
				loadPaths.push_back(p);
			} else if (p.ends_with(".xml.bak")) {
				auto mainPath = p.substr(0, p.size() - 4);
				if (!PathUtil::fileExists(mainPath)) {
					loadPaths.push_back(std::move(mainPath));
				}
			}
		}

		parallel_for_each(loadPaths.begin(), loadPaths.end(), [&](const string& path) {
			{
				// Feed items are keyed maps, so a partially parsed main file
				// followed by a .bak retry cannot create duplicates
				const auto parseDatabase = [this](const string& aPath) {
					try {
						RSSLoader loader;

						File f(aPath, File::READ, File::OPEN, File::BUFFER_SEQUENTIAL, true);
						SimpleXMLReader(&loader).parse(f);
					}
					catch (const Exception& e) {
						log(e.getError(), LogMessage::SEV_INFO);
						return false;
					}

					return true;
				};

				StateRecovery::loadWithBackupFallback(path, parseDatabase, nullptr, "RSS", StateRecovery::BackupMode::BACKFILL_ONLY);
			}
		});
	} catch (...) { }

	nextUpdate = GET_TICK() + 120 * 1000; //start after 120 seconds
	TimerManager::getInstance()->addListener(this);

}

void RSSManager::loadFilters(SimpleXML& xml, vector<RSSFilter>& aList) {
	if (xml.findChild("Filters")) {
		xml.stepIn();
		while (xml.findChild("Filter")) {
			aList.emplace_back(
				xml.getChildAttrib("FilterPattern"),
				xml.getChildAttrib("DownloadTarget"),
				Util::toInt(xml.getChildAttrib("Method", "1")),
				xml.getChildAttrib("AutoSearchGroup"),
				xml.getBoolChildAttrib("SkipDupes"),
				Util::toInt(xml.getChildAttrib("FilterAction", "0")),
				Util::toInt(xml.getChildAttrib("ExpireDays", "3")),
				xml.getBoolChildAttrib("FormatTimeParams"),
				Util::toInt(xml.getChildAttrib("AsExactMatch", "1")) > 0); // SoporEDIT
		}
		xml.stepOut();
	}
}

void RSSManager::save(bool aSaveDatabase/*false*/) {
	SimpleXML xml;
	xml.addTag("RSS");
	xml.stepIn();
	Lock l(cs);
	vector<RSSPtr> saveList;
	for (auto r : rssList) {
		xml.addTag("Settings");
		xml.addChildAttrib("Url", r->getUrl());
		xml.addChildAttrib("Name", r->getFeedName());
		xml.addChildAttrib("Enable", r->getEnable());
		xml.addChildAttrib("LastUpdate", Util::toString(r->getLastUpdate()));
		xml.addChildAttrib("UpdateInterval", Util::toString(r->getUpdateInterval()));
		xml.addChildAttrib("Token", Util::toString(r->getToken()));
		
		xml.stepIn();
		saveFilters(xml, r->getRssFilterList());
		xml.stepOut();
		if (aSaveDatabase && r->getDirty())
			saveList.push_back(r);
	}
	xml.stepOut();
	SettingsManager::saveSettingFile(xml, CONFIG_DIR, CONFIG_NAME);
	for_each(saveList.begin(), saveList.end(), [&](RSSPtr r) { savedatabase(r); });

}

void RSSManager::saveFilters(SimpleXML& aXml, const vector<RSSFilter>& aList) {
	if (!aList.empty()) {
		aXml.addTag("Filters");
		aXml.stepIn();
		for (auto f : aList) {
			aXml.addTag("Filter");
			aXml.addChildAttrib("FilterPattern", f.getFilterPattern());
			aXml.addChildAttrib("DownloadTarget", f.getDownloadTarget());
			aXml.addChildAttrib("Method", f.getMethod());
			aXml.addChildAttrib("AutoSearchGroup", f.getAutosearchGroup());
			aXml.addChildAttrib("SkipDupes", f.skipDupes);
			aXml.addChildAttrib("FilterAction", f.getFilterAction());
			aXml.addChildAttrib("ExpireDays", f.getExpireDays());
			aXml.addChildAttrib("FormatTimeParams", f.getFormatTimeParams());
			aXml.addChildAttrib("AsExactMatch", f.getAsExactMatch()); // SoporEDIT
		}
		aXml.stepOut();
	}
}

#define LITERAL(n) n, sizeof(n)-1

void RSSManager::savedatabase(const RSSPtr& aFeed) {
	
	aFeed->setDirty(false);

	string path = DATABASE_DIR + "RSSDataBase" + Util::toString(aFeed->getToken()) + ".xml";
	try {
		{
			string indent, tmp;

			File ff(path + ".tmp", File::WRITE, File::TRUNCATE | File::CREATE, File::BUFFER_WRITE_THROUGH);
			BufferedOutputStream<false> xmlFile(&ff);

			xmlFile.write(SimpleXML::utf8Header);
			xmlFile.write(LITERAL("<Data Version=\"" DATABASE_VERSION));
			xmlFile.write(LITERAL("\" Token=\""));
			xmlFile.write(SimpleXML::escape(Util::toString(aFeed->getToken()), tmp, true));
			xmlFile.write(LITERAL("\">\r\n"));
			indent += '\t';

			Lock l(cs);
			for (const auto& r : aFeed->getFeedData() | views::values) {
				//Don't save more than 3 days old entries... Todo: setting?
				if ((r->getDateAdded() + 3 * 24 * 60 * 60) > GET_TIME()) {
					xmlFile.write(indent);
					xmlFile.write(LITERAL("<item title=\""));
					xmlFile.write(SimpleXML::escape(r->getTitle(), tmp, true));

					xmlFile.write(LITERAL("\" link=\""));
					xmlFile.write(SimpleXML::escape(r->getLink(), tmp, true));

					xmlFile.write(LITERAL("\" pubdate=\""));
					xmlFile.write(SimpleXML::escape(r->getPubDate(), tmp, true));

					xmlFile.write(LITERAL("\" dateadded=\""));
					xmlFile.write(SimpleXML::escape(Util::toString(r->getDateAdded()), tmp, true));

					xmlFile.write(LITERAL("\"/>\r\n"));

				}
			}
			xmlFile.write(LITERAL("</Data>"));
		}

		// A torn write must never destroy both copies: verify the new file
		// before rotating the previous good one to .bak
		if (File::getSize(path + ".tmp") <= 0) {
			throw FileException("Empty database file " + path + ".tmp");
		}

		if (PathUtil::fileExists(path)) {
			try {
				File::renameFile(path, path + ".bak");
			} catch (const FileException&) {
				// The replace below overwrites atomically even without the rotation
			}
		}

		File::renameFile(path + ".tmp", path);
	}
	catch (Exception& e) {
		// Put the dirty flag back. It is cleared at the top so that an item arriving while the
		// write runs still marks the feed dirty, but that also meant a failed write left the feed
		// looking saved: the 20-second saver had nothing to do, and the items were gone at exit.
		aFeed->setDirty(true);
		log("Saving RSSDatabase failed: " + e.getError(), LogMessage::SEV_WARNING);
	}
	
}

}
