/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"

#include "StreamingManager.h"

#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/queue/Bundle.h>
#include <airdcpp/queue/QueueItem.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/util/DupeUtil.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/text/Text.h>
#include <airdcpp/util/Util.h>

#include <openssl/rand.h>
#include <openssl/sha.h>

namespace dcpp {

namespace {
	const int64_t HEADER_PREFETCH_SIZE = 64 * 1024;
	const int64_t TAIL_PREFETCH_SIZE = 16 * 1024 * 1024;

	const uint64_t ANALYZE_TIMEOUT = 10 * 60 * 1000;	// give up if the container can't be parsed in this time
	const uint64_t IDLE_TIMEOUT = 10 * 60 * 1000;		// stop the stream when the player has been gone this long
	const uint64_t STALL_LOG_INTERVAL = 5 * 60 * 1000;
	const uint64_t STALL_THRESHOLD = 60 * 1000;
	const uint64_t PENDING_PLAY_TIMEOUT = 10 * 60 * 1000;

	void log(const string& aMsg, LogMessage::Severity aSeverity) noexcept {
		LogManager::getInstance()->message(aMsg, aSeverity, STRING(STREAMING));
	}

	bool isSubtitleFile(const string& aTarget) noexcept {
		static const StringList SUBTITLE_EXTENSIONS = { "srt", "sub", "idx", "ass", "ssa", "smi", "vtt" };
		auto ext = Text::toLower(PathUtil::getFileExt(aTarget));
		if (!ext.empty() && ext[0] == '.') {
			ext.erase(0, 1);
		}

		return ranges::find(SUBTITLE_EXTENSIONS, ext) != SUBTITLE_EXTENSIONS.end();
	}
}

StreamingManager::StreamingManager() {
	QueueManager::getInstance()->addListener(this);
	TimerManager::getInstance()->addListener(this);

	/*
	 * The HTTP server decides loopback-vs-LAN in its constructor, and it is only
	 * built when a streaming session starts and torn down when the last stream
	 * ends. So toggling this setting has no effect on a session already running -
	 * in either direction, and both are surprising:
	 *
	 *   enabling  - the renderer is handed a 127.0.0.1 URL and fails to fetch it
	 *   disabling - the LAN-reachable listener stays up until the stream ends
	 *
	 * Restarting the server mid-stream would disconnect the player, so say so
	 * instead of doing it silently.
	 */
	SettingsManager::getInstance()->registerChangeHandler({ SettingsManager::CAST_ENABLED },
		[this](auto...) {
			Lock l(cs);
			if (server && !streams.empty()) {
				log(STRING(CAST_SETTING_PENDING), LogMessage::SEV_INFO);
			}
		});
}

StreamingManager::~StreamingManager() {
	shutdown();
}

void StreamingManager::shutdown() noexcept {
	{
		Lock l(cs);
		if (shutdownCalled) {
			return;
		}

		shutdownCalled = true;
	}

	TimerManager::getInstance()->removeListener(this);
	QueueManager::getInstance()->removeListener(this);

	vector<PriorityBackup> backups;

	{
		Lock l(cs);
		for (auto& [_, s]: streams) {
			if (s.source) {
				s.source->invalidate();
			}

			backups.insert(backups.end(), s.priorityBackups.begin(), s.priorityBackups.end());
		}

		streams.clear();
		pendingPlays.clear();
	}

	// Put the raised priorities back before going down. They are written to the queue file, so
	// leaving them would keep the streamed files pinned to HIGH in every later session.
	// QueueManager is still alive here (we only dropped our listener above).
	auto qm = QueueManager::getInstance();
	for (const auto& b: backups) {
		qm->setQIPriority(b.target, b.autoPriority ? Priority::DEFAULT : b.priority);
	}

	if (server) {
		server->shutdown();
		server.reset();
	}
}

StreamSource::Callbacks StreamingManager::getQueueCallbacks() noexcept {
	return {
		[](const string& aTarget) { return QueueManager::getInstance()->getStreamingFileInfo(aTarget); },
		[](const string& aTarget, int64_t aOffset) { return QueueManager::getInstance()->getStreamingAvailability(aTarget, aOffset); },
		[](const string& aTarget, const vector<Segment>& aRanges) { return QueueManager::getInstance()->requestStreamingRanges(aTarget, aRanges); }
	};
}

namespace {
	string toHex(const uint8_t* aData, size_t aLen) noexcept {
		string ret;
		ret.reserve(aLen * 2);
		for (size_t i = 0; i < aLen; ++i) {
			char buf[3];
			snprintf(buf, sizeof(buf), "%02x", aData[i]);
			ret += buf;
		}

		return ret;
	}

	// Lazily created, persisted per-install secret behind the stable stream tokens
	string getUrlSecret() noexcept {
		auto secret = SETTING(STREAM_URL_SECRET);
		if (secret.length() == 64) {
			return secret;
		}

		uint8_t bytes[32];
		if (RAND_bytes(bytes, sizeof(bytes)) != 1) {
			return Util::emptyString;
		}

		secret = toHex(bytes, sizeof(bytes));
		// set() only (session-stable immediately); persisted by the normal settings save on shutdown.
		// Avoids calling the heavy save() from a worker/timer thread.
		SettingsManager::getInstance()->set(SettingsManager::STREAM_URL_SECRET, secret);
		return secret;
	}
}

string StreamingManager::generateToken(const string& aStableKey) const noexcept {
	// A stable key (bundle token / file path) yields the same 128-bit token across sessions, so the
	// media player recognizes the URL and can resume where it left off. The token stays unguessable
	// because it is keyed by a secret unknown to anything outside this install.
	if (!aStableKey.empty()) {
		if (const auto secret = getUrlSecret(); !secret.empty()) {
			string input = secret;
			input += '\0';	// real separator (secret + "\x00" would append an empty C-string)
			input += aStableKey;
			uint8_t digest[SHA256_DIGEST_LENGTH];
			SHA256(reinterpret_cast<const uint8_t*>(input.data()), input.size(), digest);
			return toHex(digest, 16);
		}
		// fall through to a random token if the secret couldn't be created
	}

	uint8_t bytes[16];
	if (RAND_bytes(bytes, sizeof(bytes)) != 1) {
		// The token is the only capability guarding the HTTP server; never hand out a weak one
		return Util::emptyString;
	}

	return toHex(bytes, sizeof(bytes));
}

StringList StreamingManager::selectPlayableContent(const QueueItemList& aItems, const string& aBundleTarget) noexcept {
	const auto inSkippedSubDir = [&](const string& aTarget) {
		if (aTarget.size() <= aBundleTarget.size()) {
			return false;
		}

		// Check every directory component below the bundle root (Sample, Subs, Proof, ...)
		const auto rel = aTarget.substr(aBundleTarget.size());
		size_t start = 0;
		while (true) {
			const auto sep = rel.find(PATH_SEPARATOR, start);
			if (sep == string::npos) {
				return false;
			}

			if (boost::regex_match(rel.substr(start, sep - start), DupeUtil::subDirRegPlain)) {
				return true;
			}

			start = sep + 1;
		}
	};

	// Group RAR volumes into sets, track the largest plain video file
	struct VolumeSet {
		int64_t totalSize = 0;
		vector<pair<int, string>> volumes; // seq, target
	};
	map<string, VolumeSet> sets;

	string bestVideo;
	int64_t bestVideoSize = -1;

	for (const auto& qi: aItems) {
		const auto& target = qi->getTarget();
		if (inSkippedSubDir(target)) {
			continue;
		}

		if (RarReader::isRarVolume(target)) {
			auto& set = sets[RarReader::getVolumeBase(target)];
			set.totalSize += qi->getSize();
			set.volumes.emplace_back(RarReader::getVolumeSeq(target), target);
		} else if (StreamSource::isVideoFile(target) && qi->getSize() > bestVideoSize) {
			bestVideo = target;
			bestVideoSize = qi->getSize();
		}
	}

	const VolumeSet* bestSet = nullptr;
	for (const auto& [_, set]: sets) {
		if (!bestSet || set.totalSize > bestSet->totalSize) {
			bestSet = &set;
		}
	}

	if (bestSet && bestSet->totalSize >= bestVideoSize) {
		auto volumes = bestSet->volumes;
		ranges::sort(volumes);
		StringList ret;
		for (auto& [_, target]: volumes) {
			ret.push_back(std::move(target));
		}

		return ret;
	}

	if (!bestVideo.empty()) {
		return { bestVideo };
	}

	return StringList();
}

void StreamingManager::playBundle(QueueToken aBundleToken, const string& aCastUdn, const string& aCastName) noexcept {
	auto bundle = QueueManager::getInstance()->findBundle(aBundleToken);
	if (!bundle) {
		return;
	}

	{
		auto exists = false;
		optional<StreamSnapshot> relaunch;

		{
			Lock l(cs);
			for (auto& [_, s]: streams) {
				if (s.bundleToken == aBundleToken && s.phase != StreamSnapshot::PHASE_STOPPED && s.phase != StreamSnapshot::PHASE_FAILED) {
					exists = true;
					// Redirect an already-running stream to the new target (local player or a device)
					s.castTargetUdn = aCastUdn;
					s.castTargetName = aCastName;
					if (s.phase == StreamSnapshot::PHASE_PLAYING) {
						relaunch = toSnapshot(s);
					}

					break;
				}
			}
		}

		if (exists) {
			// Already streaming: re-fire so the GUI can relaunch the player / (re)cast
			if (relaunch) {
				fire(StreamingManagerListener::StreamStarted(), *relaunch);
			}

			return;
		}
	}

	auto items = QueueManager::getInstance()->getBundlePlaybackOrder(bundle);
	auto targets = selectPlayableContent(items, bundle->getTarget());
	if (targets.empty()) {
		log(STRING_F(STREAM_NOT_PLAYABLE, bundle->getName()), LogMessage::SEV_WARNING);
		return;
	}

	auto qm = QueueManager::getInstance();

	// Sizes for the tail prefetch
	map<string, int64_t> sizes;
	StringList subtitles;
	map<string, PriorityBackup> priorities;
	for (const auto& qi: items) {
		sizes[qi->getTarget()] = qi->getSize();
		priorities[qi->getTarget()] = { qi->getTarget(), qi->getPriority(), qi->getAutoPriority() };
		if (isSubtitleFile(qi->getTarget())) {
			subtitles.push_back(qi->getTarget());
		}
	}

	// Enforce the exact download sequence (.rar before .r00, .partN ascending). Alphabetical
	// ordering alone puts .rar last, which stalls playback until the whole set is in.
	// Subtitles lead: they are tiny, so getting them out of the way first costs no playback
	// delay and guarantees they are present when the player starts.
	StringList streamingOrder = subtitles;
	streamingOrder.insert(streamingOrder.end(), targets.begin(), targets.end());
	qm->setBundleStreamingMode(bundle, true, streamingOrder);

	for (const auto& target: targets) {
		qm->setQIPriority(target, Priority::HIGH);

		// Container/volume headers sit at the start of each file - fetch them ahead of order
		// so the full volume map (and the exact content length) is known early
		qm->requestStreamingRanges(target, { Segment(0, HEADER_PREFETCH_SIZE) });
	}

	// Players probe the end of the file on open (moov atom, AVI index, MKV cues) - fetch the tail ahead of order
	const auto& lastTarget = targets.back();
	if (auto i = sizes.find(lastTarget); i != sizes.end() && i->second > 0) {
		qm->requestStreamingRanges(lastTarget, { Segment(max<int64_t>(0, i->second - TAIL_PREFETCH_SIZE), TAIL_PREFETCH_SIZE) });
	}

	// Get subtitles in early so they're there when playback starts (they're small; fetch whole).
	// These may live in a Subs/ subdir that the video selection skips - grab them anyway.
	for (const auto& target: subtitles) {
		qm->setQIPriority(target, Priority::HIGH);
		if (auto i = sizes.find(target); i != sizes.end() && i->second > 0) {
			qm->requestStreamingRanges(target, { Segment(0, i->second) });
		}
	}

	// Remember what the raised files looked like so stopping the stream can put them back
	vector<PriorityBackup> priorityBackups;
	priorityBackups.reserve(streamingOrder.size());
	for (const auto& target: streamingOrder) {
		if (auto i = priorities.find(target); i != priorities.end()) {
			priorityBackups.push_back(i->second);
		}
	}

	addStream(bundle, targets, std::move(priorityBackups), aCastUdn, aCastName);
}

void StreamingManager::playFile(const string& aTarget, const string& aCastUdn, const string& aCastName) noexcept {
	auto qi = QueueManager::getInstance()->findFileByTarget(aTarget);
	auto bundle = qi ? qi->getBundle() : nullptr;

	if (RarReader::isRarVolume(aTarget)) {
		if (bundle) {
			// Stream the whole set
			playBundle(bundle->getToken(), aCastUdn, aCastName);
		}

		return;
	}

	if (bundle) {
		playBundle(bundle->getToken(), aCastUdn, aCastName);
		return;
	}

	// Not queued: play a finished file from disk
	auto info = QueueManager::getInstance()->getStreamingFileInfo(aTarget);
	if (!info.downloaded) {
		return;
	}

	addStream(nullptr, { aTarget }, {}, aCastUdn, aCastName);
}

void StreamingManager::playWhenAdded(const string& aTargetPathPrefix) noexcept {
	// An existing bundle with this target?
	if (auto bundle = QueueManager::getInstance()->findDirectoryBundle(aTargetPathPrefix); bundle) {
		playBundle(bundle->getToken());
		return;
	}

	{
		Lock l(cs);
		pendingPlays.push_back({ Text::toLower(aTargetPathPrefix), GET_TICK() + PENDING_PLAY_TIMEOUT });
	}

	log(STRING_F(STREAM_QUEUED, aTargetPathPrefix), LogMessage::SEV_INFO);
}

void StreamingManager::addStream(const BundlePtr& aBundle, const StringList& aTargets, vector<PriorityBackup>&& aPriorityBackups, const string& aCastUdn, const string& aCastName) noexcept {
	dcassert(!aTargets.empty());

	Stream s;
	s.priorityBackups = std::move(aPriorityBackups);
	s.castTargetUdn = aCastUdn;
	s.castTargetName = aCastName;
	// Stable key = bundle token (or file path) so the player gets the same URL and can resume
	s.token = generateToken(aBundle ? aBundle->getStringToken() : aTargets.front());
	if (s.token.empty()) {
		log(STRING_F(STREAM_FAILED, (aBundle ? aBundle->getName() : aTargets.front()) % string("RNG failure")), LogMessage::SEV_ERROR);

		// The priorities were already raised, so undo them instead of dropping the backups here
		auto qm = QueueManager::getInstance();
		for (const auto& b: s.priorityBackups) {
			qm->setQIPriority(b.target, b.autoPriority ? Priority::DEFAULT : b.priority);
		}

		return;
	}

	s.bundleToken = aBundle ? aBundle->getToken() : 0;
	s.bundleName = aBundle ? aBundle->getName() : PathUtil::getFileName(aTargets.front());
	s.targets = aTargets;
	s.addedTick = GET_TICK();

	auto callbacks = getQueueCallbacks();
	if (aTargets.size() > 1 || RarReader::isRarVolume(aTargets.front())) {
		s.source = make_shared<RarStreamSource>(aTargets, std::move(callbacks));
	} else {
		s.source = make_shared<PlainStreamSource>(aTargets.front(), std::move(callbacks));
	}

	StreamSnapshot snapshot;
	{
		Lock l(cs);
		auto& inserted = streams[s.token];
		inserted = std::move(s);
		snapshot = toSnapshot(inserted);
	}

	fire(StreamingManagerListener::StreamAdded(), snapshot);
	log(STRING_F(STREAM_ADDED, snapshot.bundleName), LogMessage::SEV_INFO);
}

StreamSnapshot StreamingManager::toSnapshot(const Stream& aStream) const noexcept {
	StreamSnapshot ret;
	ret.token = aStream.token;
	ret.bundleToken = aStream.bundleToken;
	ret.bundleName = aStream.bundleName;
	ret.fileName = aStream.source && !aStream.source->getName().empty() ? aStream.source->getName() : PathUtil::getFileName(aStream.targets.front());
	ret.url = aStream.url;
	ret.phase = aStream.phase;
	ret.size = aStream.source ? aStream.source->getSize() : -1;
	// Report the cached value: source->available(0) can do file I/O (RAR header parsing) and
	// toSnapshot runs on the UI thread via getStreams(); the timer thread refreshes lastBuffered.
	ret.buffered = aStream.lastBuffered;
	ret.error = aStream.error;
	ret.addedTick = aStream.addedTick;
	ret.castTargetUdn = aStream.castTargetUdn;
	ret.castTargetName = aStream.castTargetName;
	return ret;
}

void StreamingManager::failStream(Stream& aStream, const string& aError) noexcept {
	// cs must be held; the caller fires the events afterwards
	aStream.phase = StreamSnapshot::PHASE_FAILED;
	aStream.error = aError;
	if (aStream.source) {
		aStream.source->invalidate();
	}

	if (server && !aStream.url.empty()) {
		server->unregisterSource(aStream.token);
		aStream.url.clear();
	}
}

void StreamingManager::restoreStreamPriorities(const string& aToken) noexcept {
	vector<PriorityBackup> backups;

	{
		Lock l(cs);
		auto i = streams.find(aToken);
		if (i == streams.end() || i->second.priorityBackups.empty()) {
			return;
		}

		// Swap out so the restore happens exactly once per stream
		backups.swap(i->second.priorityBackups);
	}

	auto qm = QueueManager::getInstance();
	for (const auto& b: backups) {
		// DEFAULT puts auto priority back on; files removed from the queue meanwhile are a no-op
		qm->setQIPriority(b.target, b.autoPriority ? Priority::DEFAULT : b.priority);
	}
}

void StreamingManager::stopStream(const string& aToken) noexcept {
	QueueToken bundleToken = 0;
	optional<StreamSnapshot> snapshot;

	{
		Lock l(cs);
		auto i = streams.find(aToken);
		if (i == streams.end()) {
			return;
		}

		auto& s = i->second;
		if (s.phase == StreamSnapshot::PHASE_STOPPED || s.phase == StreamSnapshot::PHASE_FAILED) {
			return;
		}

		s.phase = StreamSnapshot::PHASE_STOPPED;
		if (s.source) {
			s.source->invalidate();
		}

		if (server && !s.url.empty()) {
			server->unregisterSource(s.token);
			s.url.clear();
		}

		bundleToken = s.bundleToken;
		snapshot = toSnapshot(s);
	}

	// Return the bundle to normal swarming (sequential order stays)
	if (bundleToken != 0) {
		if (auto bundle = QueueManager::getInstance()->findBundle(bundleToken); bundle) {
			QueueManager::getInstance()->setBundleStreamingMode(bundle, false);
		}
	}

	restoreStreamPriorities(aToken);

	fire(StreamingManagerListener::StreamUpdated(), *snapshot);
}

void StreamingManager::removeStream(const string& aToken) noexcept {
	stopStream(aToken);

	// Covers streams that were already stopped/failed without a restore (e.g. the bundle was
	// removed), and the window where the timer hasn't restored yet. A no-op if already done.
	restoreStreamPriorities(aToken);

	optional<StreamSnapshot> snapshot;
	{
		Lock l(cs);
		auto i = streams.find(aToken);
		if (i == streams.end()) {
			return;
		}

		snapshot = toSnapshot(i->second);
		streams.erase(i);
	}

	fire(StreamingManagerListener::StreamRemoved(), *snapshot);
}

vector<StreamSnapshot> StreamingManager::getStreams() const noexcept {
	Lock l(cs);
	vector<StreamSnapshot> ret;
	ret.reserve(streams.size());
	for (const auto& [_, s]: streams) {
		ret.push_back(toSnapshot(s));
	}

	return ret;
}

optional<StreamSnapshot> StreamingManager::getStream(const string& aToken) const noexcept {
	Lock l(cs);
	auto i = streams.find(aToken);
	return i != streams.end() ? optional(toSnapshot(i->second)) : nullopt;
}

string StreamingManager::adaptStreamUrlForPeer(const string& aUrl, const string& aPeerAddress) const noexcept {
	Lock l(cs);
	// No server means no stream is running, so there is no URL to adapt either.
	return server ? server->adaptUrlForPeer(aUrl, aPeerAddress) : Util::emptyString;
}

void StreamingManager::updateStream(Stream& s, const StreamIoResult& aIo) noexcept {
	// cs must be held; phase-change events are collected by the caller.
	// All source I/O was performed by the caller BEFORE taking the lock (see onTimer) --
	// nothing in here may touch the source directly.
	const auto tick = GET_TICK();

	if (s.phase == StreamSnapshot::PHASE_ANALYZING) {
		switch (aIo.prepareResult) {
			case StreamSource::PrepareResult::PENDING:
				if (tick - s.addedTick > ANALYZE_TIMEOUT) {
					failStream(s, STRING(STREAM_ANALYZE_TIMEOUT));
				}
				return;
			case StreamSource::PrepareResult::ERROR_ENCRYPTED: failStream(s, STRING(STREAM_RAR_ENCRYPTED)); return;
			case StreamSource::PrepareResult::ERROR_COMPRESSED: failStream(s, STRING(STREAM_RAR_COMPRESSED)); return;
			case StreamSource::PrepareResult::ERROR_UNSUPPORTED: failStream(s, STRING(STREAM_UNSUPPORTED_ARCHIVE)); return;
			case StreamSource::PrepareResult::ERROR_CORRUPT: failStream(s, STRING(STREAM_CORRUPT_ARCHIVE)); return;
			case StreamSource::PrepareResult::READY: break;
		}

		try {
			if (!server) {
				server = make_unique<StreamingHttpServer>();
			}
		} catch (const SocketException& e) {
			failStream(s, e.getError());
			return;
		}

		s.url = server->registerSource(s.token, s.source);
		s.phase = StreamSnapshot::PHASE_BUFFERING;

		// Now that the inner size is known, prefetch the exact inner-file tail as well
		if (!s.tailRequested && s.source->getSize() > 0) {
			s.tailRequested = true;
			s.source->requestRange(max<int64_t>(0, s.source->getSize() - TAIL_PREFETCH_SIZE), TAIL_PREFETCH_SIZE);
		}

		return;
	}

	if (s.phase == StreamSnapshot::PHASE_BUFFERING) {
		const auto size = aIo.size;
		const auto available = aIo.available;
		if (available < 0) {
			failStream(s, STRING(TARGET_REMOVED));
			return;
		}

		s.lastBuffered = available;	// cached for toSnapshot (UI thread must not do source I/O)

		const auto bufferTarget = min(size, static_cast<int64_t>(SETTING(STREAM_MIN_BUFFER_KB)) * 1024);
		if (available >= bufferTarget) {
			s.phase = StreamSnapshot::PHASE_PLAYING;
			s.lastBufferedTick = tick;
		}

		return;
	}

	if (s.phase == StreamSnapshot::PHASE_PLAYING) {
		// Idle player: stop the stream and return the bundle to normal swarming
		const auto lastActivity = server ? server->getLastActivity(s.token) : 0;
		if (lastActivity > 0 && tick - lastActivity > IDLE_TIMEOUT) {
			s.phase = StreamSnapshot::PHASE_STOPPED;
			s.error = STRING(STREAM_STOPPED_IDLE);
			s.source->invalidate();
			if (server && !s.url.empty()) {
				server->unregisterSource(s.token);
				s.url.clear();
			}

			return;
		}

		// Download stall hint
		const auto size = aIo.size;
		const auto available = aIo.available;
		if (available > s.lastBuffered) {
			s.lastBuffered = available;
			s.lastBufferedTick = tick;
		} else if (available >= 0 && available < size && tick - s.lastBufferedTick > STALL_THRESHOLD && tick - s.lastStallLog > STALL_LOG_INTERVAL) {
			s.lastStallLog = tick;
			log(STRING_F(STREAM_STALLED, s.bundleName), LogMessage::SEV_WARNING);
		}
	}
}

void StreamingManager::checkIdleServer() noexcept {
	if (server && !server->hasStreams()) {
		server->shutdown();
		server.reset();
	}
}

void StreamingManager::on(TimerManagerListener::Second, uint64_t aTick) noexcept {
	// Bundles that showed up for a pending "download & play"
	vector<QueueToken> startBundles;
	StringList expiredPlays;

	{
		Lock l(cs);
		startBundles.swap(pendingStarts);
		pendingPlays.erase(std::remove_if(pendingPlays.begin(), pendingPlays.end(), [&](const PendingPlay& p) {
			if (aTick > p.expireTick) {
				expiredPlays.push_back(p.targetPrefix);
				return true;
			}

			return false;
		}), pendingPlays.end());
	}

	for (const auto& prefix: expiredPlays) {
		// Last chance: the bundle may have been merged into an existing one without a BundleAdded event
		if (auto bundle = QueueManager::getInstance()->findDirectoryBundle(prefix); bundle) {
			startBundles.push_back(bundle->getToken());
		} else {
			log(STRING_F(STREAM_PENDING_EXPIRED, prefix), LogMessage::SEV_WARNING);
		}
	}

	// Do the source I/O OUTSIDE cs, then apply the results under it.
	//
	// updateStream() calls StreamSource::prepare() and available(), which open files and
	// parse up to 1 MB of RAR headers per volume. Running that inside the lock blocked the
	// UI thread's getStreams() for the whole duration, once per second per stream -- and a
	// hostile archive widens it. Only the source pointer is needed for the I/O, and it is
	// a shared_ptr, so it can be used safely once the lock is dropped. Streams that
	// disappear in the gap simply have no entry to apply.
	map<string, StreamIoResult> ioResults;
	{
		Lock l(cs);
		for (const auto& [token, s]: streams) {
			if (s.source) {
				ioResults.try_emplace(token, StreamIoResult{ s.source, s.phase });
			}
		}
	}

	for (auto& [_, io]: ioResults) {
		io.prepareResult = io.source->prepare();
		io.size = io.source->getSize();
		io.available = io.source->available(0);
	}

	// Progress the streams; collect phase changes and fire outside the lock
	vector<pair<StreamSnapshot::Phase, StreamSnapshot>> events;
	{
		Lock l(cs);
		for (auto& [token, s]: streams) {
			auto io = ioResults.find(token);
			if (io == ioResults.end() || io->second.source != s.source) {
				// Added, or its source replaced, while the lock was down -- pick it up on
				// the next tick rather than acting on stale I/O.
				continue;
			}

			const auto oldPhase = s.phase;
			updateStream(s, io->second);
			if (s.phase != oldPhase) {
				events.emplace_back(s.phase, toSnapshot(s));
			}
		}
	}

	for (const auto& [phase, snapshot]: events) {
		switch (phase) {
			case StreamSnapshot::PHASE_PLAYING:
				log(STRING_F(STREAM_STARTED, snapshot.fileName), LogMessage::SEV_INFO);
				fire(StreamingManagerListener::StreamStarted(), snapshot);
				break;
			case StreamSnapshot::PHASE_FAILED:
				log(STRING_F(STREAM_FAILED, snapshot.bundleName % snapshot.error), LogMessage::SEV_ERROR);
				fire(StreamingManagerListener::StreamFailed(), snapshot);
				break;
			case StreamSnapshot::PHASE_STOPPED:
				if (!snapshot.error.empty()) {
					log(snapshot.error, LogMessage::SEV_INFO);
				}
				fire(StreamingManagerListener::StreamUpdated(), snapshot);
				break;
			default:
				fire(StreamingManagerListener::StreamUpdated(), snapshot);
				break;
		}

		// Idle-stopped streams also release the bundle back to normal swarming
		if (phase == StreamSnapshot::PHASE_STOPPED && snapshot.bundleToken != 0) {
			if (auto bundle = QueueManager::getInstance()->findBundle(snapshot.bundleToken); bundle) {
				QueueManager::getInstance()->setBundleStreamingMode(bundle, false);
			}
		}

		// A stream that stopped or failed must not leave the files pinned to HIGH
		if (phase == StreamSnapshot::PHASE_STOPPED || phase == StreamSnapshot::PHASE_FAILED) {
			restoreStreamPriorities(snapshot.token);
		}
	}

	for (const auto token: startBundles) {
		playBundle(token);
	}

	checkIdleServer();
}

void StreamingManager::on(QueueManagerListener::BundleAdded, const BundlePtr& aBundle) noexcept {
	const auto target = Text::toLower(aBundle->getTarget());

	Lock l(cs);
	auto matched = false;
	pendingPlays.erase(std::remove_if(pendingPlays.begin(), pendingPlays.end(), [&](const PendingPlay& p) {
		if (target.compare(0, p.targetPrefix.size(), p.targetPrefix) == 0 || p.targetPrefix.compare(0, target.size(), target) == 0) {
			matched = true;
			return true;
		}

		return false;
	}), pendingPlays.end());

	if (matched) {
		// Don't call back into QueueManager from its own listener; start on the next timer tick
		pendingStarts.push_back(aBundle->getToken());
	}
}

void StreamingManager::on(QueueManagerListener::BundleRemoved, const BundlePtr& aBundle) noexcept {
	vector<StreamSnapshot> failed;

	{
		Lock l(cs);
		for (auto& [_, s]: streams) {
			if (s.bundleToken == aBundle->getToken() && s.phase != StreamSnapshot::PHASE_STOPPED && s.phase != StreamSnapshot::PHASE_FAILED) {
				failStream(s, STRING(STREAM_BUNDLE_REMOVED));
				failed.push_back(toSnapshot(s));
			}
		}
	}

	for (const auto& snapshot: failed) {
		log(STRING_F(STREAM_FAILED, snapshot.bundleName % snapshot.error), LogMessage::SEV_WARNING);
		fire(StreamingManagerListener::StreamFailed(), snapshot);
	}
}

} // namespace dcpp
