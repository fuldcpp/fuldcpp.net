/* 
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"

#include "FinishedManager.h"

#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/transfer/download/Download.h>
#include <airdcpp/transfer/upload/Upload.h>
#include <airdcpp/queue/QueueManager.h>
#include <airdcpp/queue/QueueItem.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/transfer/upload/UploadManager.h>

#include <airdcpp/events/LogManager.h>
#include <airdcpp/core/localization/ResourceManager.h>

namespace dcpp {


IncrementingIdCounter<FinishedItemToken> FinishedItem::idCounter;

FinishedItem::FinishedItem(string const& aTarget, const HintedUser& aUser, int64_t aSize, int64_t aSpeed, time_t aTime, const TTHValue& aTTH) :
	target(aTarget), user(aUser), size(aSize), avgSpeed(aSpeed), time(aTime), tth(aTTH), token(idCounter.next())
{
}

FinishedManager::FinishedManager() { 
	QueueManager::getInstance()->addListener(this);
	UploadManager::getInstance()->addListener(this);
}
	
FinishedManager::~FinishedManager() {
	QueueManager::getInstance()->removeListener(this);
	UploadManager::getInstance()->removeListener(this);
}

void FinishedManager::remove(const FinishedItemPtr& aItem) {
	{
		Lock l(cs);
		auto listptr = &uploads;
		auto it = find(listptr->begin(), listptr->end(), aItem);

		if(it != listptr->end())
			listptr->erase(it);
		else
			return;
	}

	fire(FinishedManagerListener::RemovedUl(), aItem);
}

void FinishedManager::removeAll() {
	{
		Lock l(cs);
		auto listptr = &uploads;
		listptr->clear();
	}

	fire(FinishedManagerListener::RemovedAllUl());
}

void FinishedManager::removeDownload(const FinishedItemPtr& aItem) {
	{
		Lock l(cs);
		auto it = find(downloads.begin(), downloads.end(), aItem);

		if(it != downloads.end())
			downloads.erase(it);
		else
			return;
	}

	fire(FinishedManagerListener::RemovedDl(), aItem);
}

void FinishedManager::removeAllDownloads() {
	{
		Lock l(cs);
		downloads.clear();
	}

	fire(FinishedManagerListener::RemovedAllDl());
}

FinishedItemList FinishedManager::trimOverflow(FinishedItemList& aList, int aMax) noexcept {
	// Caller must hold cs; aMax <= 0 means unlimited
	FinishedItemList removed;
	if (aMax > 0 && aList.size() > static_cast<size_t>(aMax)) {
		auto overflow = aList.begin() + (aList.size() - static_cast<size_t>(aMax));
		removed.assign(aList.begin(), overflow);
		aList.erase(aList.begin(), overflow);
	}

	return removed;
}

void FinishedManager::on(QueueManagerListener::ItemFinished, const QueueItemPtr& aQI, const string& /*dir*/, const HintedUser& aUser, int64_t aSpeed) noexcept
{
	// LOG_FINISHED_DOWNLOADS was declared and defaulted but never read, so the Finished Downloads
	// list could not be turned off the way its upload counterpart can
	if (!SETTING(LOG_FINISHED_DOWNLOADS)) {
		return;
	}

	// Record only real file downloads; filelists mirror the upload path's LOG_FILELIST_TRANSFERS gate
	if (aQI->isFilelist() && !SETTING(LOG_FILELIST_TRANSFERS)) {
		return;
	}

	auto item = std::make_shared<FinishedItem>(aQI->getTarget(), aUser, aQI->getSize(), aSpeed, GET_TIME(), aQI->getTTH());

	FinishedItemList trimmed;
	{
		Lock l(cs);
		downloads.push_back(item);
		trimmed = trimOverflow(downloads, SETTING(MAX_FINISHED_DOWNLOADS));
	}

	for (const auto& removed: trimmed)
		fire(FinishedManagerListener::RemovedDl(), removed);
	fire(FinishedManagerListener::AddedDl(), item);
}

void FinishedManager::on(UploadManagerListener::Complete, const Upload* u) noexcept
{
	if(u->getType() == Transfer::TYPE_FILE || (u->getType() == Transfer::TYPE_FULL_LIST && SETTING(LOG_FILELIST_TRANSFERS))) {
		auto item = std::make_shared<FinishedItem>(u->getPath(), u->getHintedUser(), u->getFileSize(), static_cast<int64_t>(u->getAverageSpeed()), GET_TIME(), u->getTTH());

		FinishedItemList trimmed;
		{
			Lock l(cs);
			uploads.push_back(item);
			trimmed = trimOverflow(uploads, SETTING(MAX_FINISHED_UPLOADS));
		}

		for (const auto& removed: trimmed)
			fire(FinishedManagerListener::RemovedUl(), removed);
		fire(FinishedManagerListener::AddedUl(), item);
		if(SETTING(SYSTEM_SHOW_UPLOADS)) {
			LogManager::getInstance()->message(
				STRING_F(FINISHED_UPLOAD, u->getPath() % ClientManager::getInstance()->getFormattedNicks(u->getHintedUser())), 
				LogMessage::SEV_INFO, 
				STRING(MENU_TRANSFERS)
			);		
		}
	}
}

} // namespace dcpp