/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#ifndef DCPLUSPLUS_DCPP_SCAN_MANAGER_H
#define DCPLUSPLUS_DCPP_SCAN_MANAGER_H

#include <airdcpp/forward.h>

#include <airdcpp/core/ActionHook.h>
#include <airdcpp/core/header/typedefs.h>
#include <airdcpp/core/Singleton.h>

#include <atomic>

namespace dcpp {

// Inspects finished downloads before they are added to the share: integrity checks
// (SFV/CRC, obvious structural fakes) plus an on-demand antivirus scan. Subscribes to
// QueueManager::bundleCompletionHook, so a problem can keep the bundle out of the share
// (the user can always override with "share, skip validation" in the queue).
class ScanManager : public Singleton<ScanManager> {
public:
	// SCAN_ACTION
	enum Action {
		ACTION_WARN = 0,       // log + notify, share the bundle anyway
		ACTION_BLOCK = 1,      // keep the bundle out of the share
		ACTION_QUARANTINE = 2, // move the files away, then block
	};

	// SCAN_ENGINE
	enum Engine {
		ENGINE_AUTO = 0,   // Windows Defender (MpCmdRun)
		ENGINE_CUSTOM = 1, // user-supplied scanner command
	};

	struct Result {
		enum class Problem {
			NONE,
			THREAT,
			CRC,
			STRUCTURE,
		};

		Problem problem = Problem::NONE;

		// Localized description of the problem ("malware detected in x (y)"), without
		// the bundle name — callers compose the final message.
		string detail;

		bool ok() const noexcept { return problem == Problem::NONE; }
		const char* getRejectId() const noexcept;
	};

	// Runs the enabled checks for a finished file or directory, cheapest first, and
	// stops at the first problem. Safe to call from any thread; a scan in progress is
	// aborted by shutdown().
	Result scanPath(const string& aPath) noexcept;

	// True when scanning is enabled and aPath isn't covered by SCAN_EXCLUDED_PATHS.
	bool isScanEnabled(const string& aPath) const noexcept;

	// Aborts running scans and stops new ones from starting (called before the
	// managers are torn down).
	void shutdown() noexcept;

private:
	friend class Singleton<ScanManager>;

	ScanManager() noexcept;
	~ScanManager() noexcept;

	ActionHookResult<nullptr_t> onBundleCompleted(const BundlePtr& aBundle, const ActionHookResultGetter<nullptr_t>& aResultGetter) noexcept;

	struct ScanFile {
		string path; // full path
		string name; // file name only
		int64_t size = 0;
	};

	using ScanFileList = vector<ScanFile>;

	// Recursive; bounded by MAX_DEPTH so a symlink loop can't hang the scan.
	void collectFiles(const string& aPath, ScanFileList& files_, int aDepth = 0) const noexcept;

	// aRootPath is the bundle being scanned: a release directory, or the file itself for a
	// single-file bundle. Needed so the sample test can tell a directory inside the release from
	// the directory the release was downloaded into.
	Result checkStructure(const ScanFileList& aFiles, const string& aRootPath) const noexcept;
	Result checkSFV(const string& aPath) const noexcept;
	Result runEngineScan(const string& aPath, const ScanFileList& aFiles) noexcept;

	// Moves aPath into SCAN_QUARANTINE_PATH. Returns the new location, or nullopt with
	// error_ set — a failed move must not look like a successful one.
	optional<string> quarantine(const string& aPath, string& error_) const noexcept;

	// A media download is one where the bulk of the content is video/audio; the
	// executable rule only applies to those, or every game download would be flagged.
	static bool looksLikeMedia(const ScanFileList& aFiles) noexcept;

	static StringList splitList(const string& aSetting) noexcept;
	static bool isMediaExtension(const string& aExt) noexcept;
	static bool isDisguisableExtension(const string& aExt) noexcept;

	// Runs aExecutable with aArgs (never through a shell) and returns the exit code,
	// with stdout/stderr in output_. nullopt = the process couldn't be run, timed out
	// or was aborted.
	optional<int> runProcess(const string& aExecutable, const StringList& aArgs, string& output_) noexcept;

	static string getDefenderPath() noexcept;

	static constexpr int MAX_DEPTH = 16;

	std::atomic<bool> stopping{ false };

	// In-flight hook callbacks. ActionHook copies its handler list under the lock and then
	// invokes the callbacks AFTER releasing it, so removeSubscriber() is not a barrier --
	// and the hook runs on QueueManager's dispatcher, which is only stopped at
	// QueueManager::deleteInstance(), i.e. AFTER destroyModules() has deleted this object.
	// shutdown() waits on this so a callback cannot still be running (the abort path can
	// sit in WaitForSingleObject for up to five seconds) when the destructor runs.
	std::atomic<int> activeCallbacks{ 0 };

	// Set once the configured engine has been found unusable, so we don't retry (and
	// log) for every finished bundle in the session.
	std::atomic<bool> engineUnavailable{ false };
};

} // namespace dcpp

#endif // DCPLUSPLUS_DCPP_SCAN_MANAGER_H
