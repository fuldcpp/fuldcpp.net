/*
* Copyright (C) 2026 FulDC++ Project
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 3 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
*/

#include "stdinc.h"
#include <airdcpp/modules/scan/ScanManager.h>

#include <airdcpp/core/classes/ScopedFunctor.h>
#include <airdcpp/core/header/format.h>
#include <airdcpp/core/io/File.h>
#include <airdcpp/core/io/SFVReader.h>
#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/core/thread/Thread.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/queue/Bundle.h>
#include <airdcpp/queue/QueueManager.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/Util.h>
#include <airdcpp/util/text/Text.h>

#include <boost/algorithm/string/predicate.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/classification.hpp>
#include <boost/algorithm/string/trim.hpp>

namespace dcpp {

static const string SCAN_HOOK_ID = "download_scan";

// Reject ids; ActionHookRejection::matches() is used elsewhere to tell scan rejections
// apart from other validation failures (see AutoSearch)
static const char* REJECT_THREAT = "scan_threat";
static const char* REJECT_CRC = "scan_crc";
static const char* REJECT_STRUCTURE = "scan_structure";

// Extensions whose bytes count as "media content" when deciding whether a download is a
// media download. Archives are deliberately absent: they are just as common in software
// releases, and counting them would make every installer look like a movie.
static const char* mediaExtensions[] = {
	"mkv", "mp4", "avi", "m4v", "mov", "wmv", "mpg", "mpeg", "ts", "m2ts", "vob", "flv", "webm", "ogm",
	"mp3", "flac", "m4a", "ogg", "opus", "wav", "ape", "wv", "aac", "wma"
};

ScanManager::ScanManager() noexcept {
	QueueManager::getInstance()->bundleCompletionHook.addSubscriber(
		ActionHookSubscriber(SCAN_HOOK_ID, STRING(SETTINGS_DOWNLOAD_SCAN), nullptr),
		HOOK_CALLBACK(ScanManager::onBundleCompleted)
	);
}

ScanManager::~ScanManager() noexcept {
	QueueManager::getInstance()->bundleCompletionHook.removeSubscriber(SCAN_HOOK_ID);
}

void ScanManager::shutdown() noexcept {
	stopping = true;

	// Wait for any hook callback that is already running. `stopping` only shortens a
	// callback, it does not join one -- and the abort path inside a running scan can sit
	// in WaitForSingleObject for up to five seconds, well past the point where
	// destroyModules() would otherwise have deleted this object out from under it.
	// Bounded so a wedged external scanner cannot block shutdown indefinitely; the same
	// spin-and-sleep shape BufferedSocket::waitShutdown() uses.
	for (int i = 0; activeCallbacks > 0 && i < 100; ++i) {
		Thread::sleep(100);
	}

	dcassert(activeCallbacks == 0);
}

const char* ScanManager::Result::getRejectId() const noexcept {
	switch (problem) {
		case Problem::THREAT: return REJECT_THREAT;
		case Problem::CRC: return REJECT_CRC;
		case Problem::STRUCTURE: return REJECT_STRUCTURE;
		case Problem::NONE:
		default: return "";
	}
}


// SETTINGS HELPERS
StringList ScanManager::splitList(const string& aSetting) noexcept {
	StringList ret;
	if (aSetting.empty()) {
		return ret;
	}

	boost::split(ret, aSetting, boost::is_any_of("|;"), boost::token_compress_on);
	for (auto& s : ret) {
		boost::trim(s);
		s = Text::toLower(s);
	}

	ret.erase(ranges::remove_if(ret, [](const string& aStr) { return aStr.empty(); }).begin(), ret.end());
	return ret;
}

bool ScanManager::isMediaExtension(const string& aExt) noexcept {
	return ranges::any_of(mediaExtensions, [&aExt](const char* aKnown) { return aExt == aKnown; });
}

bool ScanManager::isDisguisableExtension(const string& aExt) noexcept {
	// Content extensions a hostile file name pretends to carry ("movie.mkv.exe")
	static const char* disguises[] = { "pdf", "doc", "docx", "xls", "xlsx", "txt", "nfo",
		"jpg", "jpeg", "png", "gif", "rar", "zip", "7z", "iso", "srt", "sub" };

	return isMediaExtension(aExt) || ranges::any_of(disguises, [&aExt](const char* aKnown) { return aExt == aKnown; });
}

bool ScanManager::isScanEnabled(const string& aPath) const noexcept {
	if (!SETTING(SCAN_DOWNLOADS) || stopping) {
		return false;
	}

	const auto lowerPath = Text::toLower(aPath);
	for (const auto& excluded : splitList(SETTING(SCAN_EXCLUDED_PATHS))) {
		if (lowerPath.find(excluded) != string::npos) {
			return false;
		}
	}

	return true;
}


// SCANNING
void ScanManager::collectFiles(const string& aPath, ScanFileList& files_, int aDepth) const noexcept {
	if (aDepth > MAX_DEPTH || stopping) {
		return;
	}

	try {
		File::forEachFile(aPath, "*", [&](const FilesystemItem& aInfo) {
			if (stopping) {
				return;
			}

			const auto fullPath = aInfo.getPath(aPath);
			if (aInfo.isDirectory) {
				collectFiles(fullPath, files_, aDepth + 1);
			} else {
				files_.push_back({ fullPath, aInfo.name, aInfo.size });
			}
		});
	} catch (const FileException&) {
		// A directory we can't enumerate can't be checked either; the engine scan
		// still covers the path as a whole
	}
}

bool ScanManager::looksLikeMedia(const ScanFileList& aFiles) noexcept {
	int64_t mediaBytes = 0, totalBytes = 0;
	for (const auto& f : aFiles) {
		const auto ext = Text::toLower(PathUtil::getFileExt(f.name));
		if (ext.empty()) {
			continue;
		}

		const auto bareExt = ext.substr(1); // getFileExt() keeps the dot
		if (isMediaExtension(bareExt)) {
			mediaBytes += f.size;
			totalBytes += f.size;
		} else if (bareExt == "rar" || bareExt == "zip" || bareExt == "7z" || bareExt == "r00" ||
			(bareExt.length() == 3 && bareExt[0] == 'r' && isdigit(static_cast<unsigned char>(bareExt[1])) && isdigit(static_cast<unsigned char>(bareExt[2])))) {
			// Neutral: archives say nothing about the content type
		} else {
			totalBytes += f.size;
		}
	}

	return mediaBytes > 0 && mediaBytes * 2 >= totalBytes;
}

ScanManager::Result ScanManager::checkStructure(const ScanFileList& aFiles, const string& aRootPath) const noexcept {
	const auto badExtensions = splitList(SETTING(SCAN_EXTENSIONS));
	const auto isMediaDownload = looksLikeMedia(aFiles);

	/*
	 * Nothing but a sample is the classic "fake release" shape.
	 *
	 * Matched against the file name and against directories INSIDE the release -- not the absolute
	 * path, and not the directory the release was downloaded into. An earlier fix narrowed this
	 * from f.path to the immediate parent, which stopped a deep path from matching on some
	 * ancestor, but left the case that actually bites: a SINGLE-FILE bundle has no release
	 * directory, so its "immediate parent" is the download directory itself. Anyone whose download
	 * directory is named (say) D:\Samples\ had every finished single-file bundle judged
	 * sample-only, and with SCAN_ACTION = ACTION_QUARANTINE every one of them moved into
	 * quarantine.
	 *
	 * A release FOLDER named "sample" still counts, because that is the release's own name rather
	 * than where it happens to have been saved.
	 */
	const auto rootIsDir = PathUtil::isDirectoryPath(aRootPath);
	const auto rootDir = rootIsDir ? aRootPath : PathUtil::getFilePath(aRootPath);
	const auto rootIsSample = rootIsDir &&
		Text::toLower(PathUtil::getLastDir(rootDir)).find("sample") != string::npos;

	if (aFiles.size() > 0 && ranges::all_of(aFiles, [&](const ScanFile& aFile) {
		if (Text::toLower(aFile.name).find("sample") != string::npos) {
			return true;
		}

		const auto filePath = PathUtil::getFilePath(aFile.path);
		if (filePath.length() <= rootDir.length()) {
			// Directly in the release root, so only the release's own name can say anything.
			return rootIsSample;
		}

		const auto parent = PathUtil::getLastDir(filePath);
		return Text::toLower(parent).find("sample") != string::npos;
	})) {
		return { Result::Problem::STRUCTURE, STRING(SCAN_SAMPLE_ONLY) };
	}

	for (const auto& f : aFiles) {
		if (stopping) {
			break;
		}

		if (f.size == 0) {
			return { Result::Problem::STRUCTURE, STRING_F(SCAN_EMPTY_FILE, f.name) };
		}

		const auto lowerName = Text::toLower(f.name);
		const auto ext = PathUtil::getFileExt(lowerName);
		if (ext.empty()) {
			continue;
		}

		const auto bareExt = ext.substr(1);
		if (!ranges::any_of(badExtensions, [&bareExt](const string& aBad) { return aBad == bareExt; })) {
			continue;
		}

		// "movie.mkv.exe": the name carries a second, harmless-looking extension in
		// front of the real one, which is deception rather than a mislabel. The inner
		// part must be a known content extension — scene names are dot-separated, so
		// "Some.Release.2024.exe" must not count as disguised.
		const auto stem = lowerName.substr(0, lowerName.length() - ext.length());
		const auto innerExt = PathUtil::getFileExt(stem);
		if (innerExt.length() > 1 && isDisguisableExtension(innerExt.substr(1))) {
			return { Result::Problem::STRUCTURE, STRING_F(SCAN_DOUBLE_EXTENSION, f.name) };
		}

		if (isMediaDownload) {
			return { Result::Problem::STRUCTURE, STRING_F(SCAN_EXECUTABLE_IN_MEDIA, f.name) };
		}
	}

	return {};
}

ScanManager::Result ScanManager::checkSFV(const string& aPath) const noexcept {
	DirSFVReader reader(aPath);
	if (!reader.hasSFV()) {
		return {};
	}

	Result ret;
	reader.read([&](const string& aFileName) {
		if (!ret.ok() || stopping) {
			return;
		}

		try {
			if (!reader.isCrcValid(aFileName)) {
				ret = { Result::Problem::CRC, STRING_F(SCAN_CRC_FAILED, aFileName) };
			}
		} catch (const Exception&) {
			// The file is gone or unreadable: the SFV can't say anything about it
		}
	});

	return ret;
}

ScanManager::Result ScanManager::scanPath(const string& aPath) noexcept {
	if (stopping) {
		return {};
	}

	ScanFileList files;
	if (PathUtil::isDirectoryPath(aPath)) {
		collectFiles(aPath, files);
	} else {
		const auto size = File::getSize(aPath);
		if (size < 0) {
			return {}; // already gone (real-time protection may have removed it)
		}

		files.push_back({ aPath, PathUtil::getFileName(aPath), size });
	}

	if (files.empty()) {
		return {};
	}

	if (SETTING(SCAN_CHECK_STRUCTURE)) {
		auto res = checkStructure(files, aPath);
		if (!res.ok()) {
			return res;
		}
	}

	if (SETTING(SCAN_CHECK_SFV) && PathUtil::isDirectoryPath(aPath)) {
		auto res = checkSFV(aPath);
		if (!res.ok()) {
			return res;
		}
	}

	return runEngineScan(aPath, files);
}


// ANTIVIRUS ENGINE

// Scanner output is only used for classification and a short log line
static constexpr size_t MAX_OUTPUT_SIZE = 64 * 1024;

// Collapses the scanner's multi-line output into a single loggable line
static string flattenOutput(const string& aOutput) noexcept {
	string ret;
	bool lastWasSpace = true;
	for (auto c : aOutput) {
		const auto isSpace = c == '\r' || c == '\n' || c == '\t' || c == ' ';
		if (isSpace) {
			if (!lastWasSpace) {
				ret += ' ';
			}
		} else {
			ret += c;
		}

		lastWasSpace = isSpace;
	}

	boost::trim(ret);
	return ret;
}

// Splits a user-entered command into its executable and arguments, honoring double
// quotes. Deliberately not a shell: no expansion, no operators, no pipes.
static StringList tokenizeCommand(const string& aCommand) noexcept {
	StringList ret;
	string current;
	bool inQuotes = false, hasToken = false;

	for (auto c : aCommand) {
		if (c == '"') {
			inQuotes = !inQuotes;
			hasToken = true;
			continue;
		}

		if (!inQuotes && (c == ' ' || c == '\t')) {
			if (hasToken) {
				ret.push_back(current);
				current.clear();
				hasToken = false;
			}

			continue;
		}

		current += c;
		hasToken = true;
	}

	if (hasToken) {
		ret.push_back(current);
	}

	return ret;
}

#ifdef _WIN32

string ScanManager::getDefenderPath() noexcept {
	// The install location moves with the platform version, so ask Defender itself first
	wchar_t buf[MAX_PATH] = { 0 };
	DWORD size = sizeof(buf);
	if (::RegGetValueW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows Defender", L"InstallLocation",
		RRF_RT_REG_SZ | RRF_SUBKEY_WOW6464KEY, nullptr, buf, &size) == ERROR_SUCCESS) {
		auto path = PathUtil::validateDirectoryPath(Text::fromT(buf)) + "MpCmdRun.exe";
		if (PathUtil::fileExists(path)) {
			return path;
		}
	}

	const auto programFiles = ::getenv("ProgramFiles");
	if (programFiles) {
		auto fallback = string(programFiles) + "\\Windows Defender\\MpCmdRun.exe";
		if (PathUtil::fileExists(fallback)) {
			return fallback;
		}
	}

	return Util::emptyString;
}

// Quotes one argument the way CommandLineToArgvW parses it back, so a path with spaces
// or quotes can't inject extra arguments
static string quoteArgument(const string& aArg) noexcept {
	string ret = "\"";
	size_t backslashes = 0;
	for (auto c : aArg) {
		if (c == '\\') {
			backslashes++;
			ret += c;
			continue;
		}

		if (c == '"') {
			// Escape the run of backslashes that precedes the quote, and the quote itself
			ret.append(backslashes + 1, '\\');
		}

		backslashes = 0;
		ret += c;
	}

	ret.append(backslashes, '\\'); // trailing backslashes must not escape the closing quote
	ret += "\"";
	return ret;
}

optional<int> ScanManager::runProcess(const string& aExecutable, const StringList& aArgs, string& output_) noexcept {
	// The executable is passed as lpApplicationName (so nothing is resolved through a
	// shell or the PATH) and repeated as argv[0] in the hand-quoted command line
	string commandLine = quoteArgument(aExecutable);
	for (const auto& arg : aArgs) {
		commandLine += " " + quoteArgument(arg);
	}

	SECURITY_ATTRIBUTES sa = { sizeof(sa), nullptr, TRUE };
	HANDLE readPipe = nullptr, writePipe = nullptr;
	if (!::CreatePipe(&readPipe, &writePipe, &sa, 0)) {
		return nullopt;
	}

	::SetHandleInformation(readPipe, HANDLE_FLAG_INHERIT, 0);

	STARTUPINFOW si = { sizeof(si) };
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdOutput = writePipe;
	si.hStdError = writePipe;
	si.hStdInput = ::GetStdHandle(STD_INPUT_HANDLE);

	PROCESS_INFORMATION pi = { nullptr };

	auto executableT = Text::toT(aExecutable);
	auto commandLineT = Text::toT(commandLine);

	if (!::CreateProcessW(executableT.c_str(), commandLineT.data(), nullptr, nullptr, TRUE,
		CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi)) {
		::CloseHandle(readPipe);
		::CloseHandle(writePipe);
		return nullopt;
	}

	// Our copy of the write end must go, or the read below would never see EOF
	::CloseHandle(writePipe);
	::CloseHandle(pi.hThread);

	const auto timeout = SETTING(SCAN_TIMEOUT);
	const auto deadline = timeout > 0 ? GET_TICK() + static_cast<uint64_t>(timeout) * 1000 : 0;

	bool aborted = false;
	char buf[4096];
	for (;;) {
		// Checked before draining as well: a chatty scanner keeps the read path busy, and
		// the abort must not depend on the process going quiet
		if (stopping || (deadline > 0 && GET_TICK() > deadline)) {
			aborted = true;
			::TerminateProcess(pi.hProcess, 1);
			::WaitForSingleObject(pi.hProcess, 5000);
			break;
		}

		DWORD available = 0;
		if (::PeekNamedPipe(readPipe, nullptr, 0, nullptr, &available, nullptr) && available > 0) {
			DWORD read = 0;
			if (::ReadFile(readPipe, buf, min<DWORD>(available, sizeof(buf)), &read, nullptr) && read > 0) {
				if (output_.length() < MAX_OUTPUT_SIZE) {
					output_.append(buf, read);
				}
				continue; // drain what's buffered before waiting again
			}
		}

		auto waitRes = ::WaitForSingleObject(pi.hProcess, 250);
		if (waitRes == WAIT_OBJECT_0) {
			// Pick up whatever was written just before the process exited
			DWORD read = 0;
			while (::PeekNamedPipe(readPipe, nullptr, 0, nullptr, &available, nullptr) && available > 0 &&
				::ReadFile(readPipe, buf, min<DWORD>(available, sizeof(buf)), &read, nullptr) && read > 0) {
				if (output_.length() >= MAX_OUTPUT_SIZE) {
					break;
				}

				output_.append(buf, read);
			}
			break;
		}
	}

	DWORD exitCode = 0;
	auto haveExitCode = ::GetExitCodeProcess(pi.hProcess, &exitCode) != FALSE;

	::CloseHandle(pi.hProcess);
	::CloseHandle(readPipe);

	if (aborted || !haveExitCode) {
		return nullopt;
	}

	return static_cast<int>(exitCode);
}

ScanManager::Result ScanManager::runEngineScan(const string& aPath, const ScanFileList& aFiles) noexcept {
	if (engineUnavailable || stopping) {
		return {};
	}

	const auto maxSizeMB = SETTING(SCAN_MAX_SIZE_MB);
	if (maxSizeMB > 0) {
		int64_t totalSize = 0;
		for (const auto& f : aFiles) {
			totalSize += f.size;
		}

		if (totalSize > static_cast<int64_t>(maxSizeMB) * 1024 * 1024) {
			return {}; // too big to be worth scanning, per the user's own limit
		}
	}

	string executable;
	StringList args;
	const auto isDefender = SETTING(SCAN_ENGINE) == ENGINE_AUTO;

	// Defender scans a directory in one pass; -DisableRemediation keeps it from deleting
	// the user's files behind our back (we only report)
	const auto scanTarget = PathUtil::isDirectoryPath(aPath) ? aPath.substr(0, aPath.length() - 1) : aPath;

	if (isDefender) {
		executable = getDefenderPath();
		args = { "-Scan", "-ScanType", "3", "-File", scanTarget, "-DisableRemediation" };
	} else {
		auto command = SETTING(SCAN_COMMAND);
		boost::trim(command);
		if (command.empty()) {
			engineUnavailable = true;
			LogManager::getInstance()->message(STRING(SCAN_ENGINE_MISSING), LogMessage::SEV_WARNING, STRING(SETTINGS_DOWNLOAD_SCAN));
			return {};
		}

		// The first token (optionally quoted) is the scanner, the rest are its arguments
		auto tokens = tokenizeCommand(command);
		if (tokens.empty()) {
			engineUnavailable = true;
			LogManager::getInstance()->message(STRING(SCAN_ENGINE_MISSING), LogMessage::SEV_WARNING, STRING(SETTINGS_DOWNLOAD_SCAN));
			return {};
		}

		// A command with no placeholder never learns what to scan. It was run anyway, typically
		// exited 0 on its own arguments, and 0 maps to "clean" -- so a misconfigured command let
		// every download through while the client reported a successful scan. Refuse it instead.
		if (command.find("%[file]") == string::npos && command.find("%[dir]") == string::npos) {
			engineUnavailable = true;
			LogManager::getInstance()->message(STRING(SCAN_ENGINE_MISSING), LogMessage::SEV_WARNING, STRING(SETTINGS_DOWNLOAD_SCAN));
			return {};
		}

		executable = tokens.front();
		for (auto i = tokens.begin() + 1; i != tokens.end(); ++i) {
			auto arg = *i;
			// Placeholders are substituted after tokenizing, so a path containing spaces
			// (or quotes) can never split into extra arguments
			Util::replace(arg, string("%[file]"), scanTarget);
			Util::replace(arg, string("%[dir]"), scanTarget);
			args.push_back(arg);
		}
	}

	if (executable.empty() || !PathUtil::fileExists(executable)) {
		engineUnavailable = true;
		LogManager::getInstance()->message(STRING(SCAN_ENGINE_MISSING), LogMessage::SEV_WARNING, STRING(SETTINGS_DOWNLOAD_SCAN));
		return {};
	}

	string output;
	auto exitCode = runProcess(executable, args, output);
	if (!exitCode) {
		if (!stopping) {
			LogManager::getInstance()->message(
				STRING_F(SCAN_ENGINE_FAILED, PathUtil::getFileName(scanTarget) % STRING(SCAN_TIMED_OUT)),
				LogMessage::SEV_WARNING, STRING(SETTINGS_DOWNLOAD_SCAN));
		}

		return {}; // could not scan: never treated as a detection
	}

	const auto lowerOutput = Text::toLower(output);
	const auto saysClean = lowerOutput.find("found no threat") != string::npos || lowerOutput.find("no threats") != string::npos;

	if (*exitCode == 0 || saysClean) {
		return {};
	}

	// MpCmdRun returns 2 both for "threat found" and for some engine errors, so the
	// output has the deciding vote; anything we can't read is a non-detection
	if (isDefender && *exitCode == 2 && !saysClean) {
		return { Result::Problem::THREAT, STRING_F(SCAN_THREAT_FOUND, PathUtil::getFileName(scanTarget) % Util::truncate(flattenOutput(output), 200)) };
	}

	if (!isDefender && *exitCode == 1) {
		return { Result::Problem::THREAT, STRING_F(SCAN_THREAT_FOUND, PathUtil::getFileName(scanTarget) % Util::truncate(flattenOutput(output), 200)) };
	}

	LogManager::getInstance()->message(
		STRING_F(SCAN_ENGINE_FAILED, PathUtil::getFileName(scanTarget) % Util::toString(*exitCode)),
		LogMessage::SEV_WARNING, STRING(SETTINGS_DOWNLOAD_SCAN));
	return {};
}

#else

string ScanManager::getDefenderPath() noexcept {
	return Util::emptyString;
}

optional<int> ScanManager::runProcess(const string&, const StringList&, string&) noexcept {
	return nullopt;
}

ScanManager::Result ScanManager::runEngineScan(const string&, const ScanFileList&) noexcept {
	return {}; // integrity checks only outside Windows
}

#endif


// HOOK
ActionHookResult<nullptr_t> ScanManager::onBundleCompleted(const BundlePtr& aBundle, const ActionHookResultGetter<nullptr_t>& aResultGetter) noexcept {
	// Register as in-flight for the whole callback, so shutdown() cannot return -- and the
	// object cannot be destroyed -- while this is still running. Incremented before the
	// stopping check so there is no window between the two.
	++activeCallbacks;
	ScopedFunctor([this] { --activeCallbacks; });

	if (stopping) {
		return {};
	}

	const auto& target = aBundle->getTarget();
	if (!isScanEnabled(target)) {
		return {};
	}

	auto res = scanPath(target);
	if (res.ok()) {
		return {};
	}

	auto message = STRING_F(SCAN_PROBLEM_FOUND, aBundle->getName() % res.detail);
	LogManager::getInstance()->message(message, LogMessage::SEV_WARNING, STRING(SETTINGS_DOWNLOAD_SCAN));

	const auto action = SETTING(SCAN_ACTION);
	if (action == ACTION_WARN) {
		return {};
	}

	if (action == ACTION_QUARANTINE) {
		string error;
		auto newPath = quarantine(target, error);
		if (newPath) {
			message += " - " + STRING_F(SCAN_QUARANTINED_TO, *newPath);
		} else {
			// Block-only fallback: the files stay where they are, and the error says so
			message += " - " + STRING_F(SCAN_QUARANTINE_FAILED, error);
			LogManager::getInstance()->message(message, LogMessage::SEV_ERROR, STRING(SETTINGS_DOWNLOAD_SCAN));
		}
	}

	return aResultGetter.getRejection(res.getRejectId(), message);
}

optional<string> ScanManager::quarantine(const string& aPath, string& error_) const noexcept {
	auto quarantineDir = PathUtil::validateDirectoryPath(SETTING(SCAN_QUARANTINE_PATH));
	if (quarantineDir.empty()) {
		error_ = STRING(SCAN_QUARANTINE_UNSET);
		return nullopt;
	}

	const auto isDir = PathUtil::isDirectoryPath(aPath);
	const auto name = isDir ? PathUtil::getLastDir(aPath) : PathUtil::getFileName(aPath);

	// Never overwrite an earlier quarantined download of the same name
	string target = quarantineDir + name;
	for (int i = 1; PathUtil::fileExists(target) || PathUtil::fileExists(target + PATH_SEPARATOR_STR); ++i) {
		if (i > 100) {
			error_ = STRING_F(SCAN_QUARANTINE_FULL, name);
			return nullopt;
		}

		target = quarantineDir + name + " (" + Util::toString(i) + ")";
	}

	try {
		File::ensureDirectory(quarantineDir);
		if (isDir) {
			File::moveDirectory(aPath, target + PATH_SEPARATOR_STR);
			// The now-empty source directory is left for the queue's own cleanup
			return target + PATH_SEPARATOR_STR;
		}

		File::renameFile(aPath, target);
		return target;
	} catch (const FileException& e) {
		error_ = e.getError();
	}

	return nullopt;
}

} // namespace dcpp
