/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_SPEAKER_H
#define DCPLUSPLUS_DCPP_SPEAKER_H

#include <utility>
#include <vector>

#include <airdcpp/core/thread/CriticalSection.h>
#include <airdcpp/core/header/debug.h>

namespace dcpp {

using std::vector;

template<typename Listener>
class Speaker {
	typedef vector<Listener*> ListenerList;

public:
	Speaker() noexcept { }
	virtual ~Speaker() { 
		dcassert(listeners.empty());
	}

	template<typename... ArgT>
	void fire(ArgT&&... args) noexcept {
		// Snapshot the listeners under the lock (fixes the reentrant shared-state race),
		// then release the lock BEFORE invoking callbacks. A listener may delete this
		// Speaker (e.g. an HttpConnection deleted from its own Complete callback), so the
		// lock must not be held across callbacks or we would unlock a destroyed mutex.
		ListenerList tmpListeners;
		{
			Lock l(listenerCS);
			tmpListeners = listeners;
		}
		for(auto listener: tmpListeners) {
			listener->on(std::forward<ArgT>(args)...);
		}
	}

	// Fire listeners in a reversed order
	// (e.g. during a shutdown sequence the listeners that were added last should be uninitialized first)
	template<typename... ArgT>
	void fireReversed(ArgT&&... args) noexcept {
		ListenerList tmpListeners;
		{
			Lock l(listenerCS);
			tmpListeners = listeners;
		}
		for (auto listener : tmpListeners | views::reverse) {
			listener->on(std::forward<ArgT>(args)...);
		}
	}

	void addListener(Listener* aListener) noexcept {
		Lock l(listenerCS);
		if(ranges::find(listeners, aListener) == listeners.end())
			listeners.push_back(aListener);
	}

	// IMPORTANT, and the reason this is not a barrier:
	//
	// removeListener() returning does NOT mean no callback is in flight. fire() above
	// deliberately drops the lock before dispatching, so a listener removed here can still
	// be called by a fire() that already took its snapshot.
	//
	// The obvious fix -- an in-flight counter that removeListener() waits on -- CANNOT be
	// implemented here. fire() may destroy the Speaker itself: HttpConnection derives from
	// Speaker and does "delete this" from inside its own listener callbacks in about a
	// dozen places. Any counter stored as a member would therefore be decremented after
	// the object was freed, i.e. the barrier would be the very use-after-free it is meant
	// to prevent. (A side table keyed by Speaker* does not work either -- the address can
	// be recycled immediately after the delete.)
	//
	// So the invariant has to be enforced by OWNERS, not here. The pattern used across
	// this codebase for anything that is not a process-lifetime singleton:
	//   - detach while the owner still holds a reference (see PrivateChatManager::removeChat,
	//     ViewFileManager::removeFile, TrackableDownloadItem::detachFromDownloadManager),
	//   - and/or latch an atomic "closed"/"stopping" flag BEFORE detaching and check it at
	//     the top of every callback (see HubFrame::on(Close), PopupManager, CrashReportSender),
	//   - and for worker-driven objects, an in-flight counter on the OWNER that its
	//     shutdown() waits on (see ScanManager, CastManager).
	void removeListener(Listener* aListener) noexcept {
		Lock l(listenerCS);
		auto it = ranges::find(listeners, aListener);
		if(it != listeners.end())
			listeners.erase(it);
	}

	bool hasListener(Listener* aListener) const noexcept {
		Lock l(listenerCS);
		return ranges::find(listeners, aListener) != listeners.end();
	}

	void removeListeners() noexcept {
		Lock l(listenerCS);
		listeners.clear();
	}
	
protected:
	ListenerList listeners;
	mutable CriticalSection listenerCS;
};

} // namespace dcpp

#endif // !defined(SPEAKER_H)