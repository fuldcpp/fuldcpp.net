/*
	Copyright (C) 2004-2005 Cory Nelson

	This software is provided 'as-is', without any express or implied
	warranty.  In no event will the authors be held liable for any damages
	arising from the use of this software.

	Permission is granted to anyone to use this software for any purpose,
	including commercial applications, and to alter it and redistribute it
	freely, subject to the following restrictions:

	1. The origin of this software must not be misrepresented; you must not
		claim that you wrote the original software. If you use this software
		in a product, an acknowledgment in the product documentation would be
		appreciated but is not required.
	2. Altered source versions must be plainly marked as such, and must not be
		misrepresented as being the original software.
	3. This notice may not be removed or altered from any source distribution.
	
	SVN Info :
		$Author: crise $
		$Date: 2013-01-06 17:59:44 +0200 (pe, 06 tammi 2013) $
		$Revision: 1215 $
*/

/*
	- Updated for DC++ base code @ 2008, by Crise
	- Added basic zip creation support (minizip) @ 2010, by Crise
*/

#include "stdinc.h"
#include <airdcpp/core/io/compress/ZipFile.h>

#include <airdcpp/core/classes/ScopedFunctor.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/SystemUtil.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/util/Util.h>
#include <airdcpp/util/text/Text.h>

#include <minizip/zip.h>
#include <sys/stat.h>

#ifdef WIN32
#include <boost/algorithm/string/replace.hpp>
#endif

namespace dcpp {

using std::make_pair;

string ZipFileException::TranslateError(int e) {
	switch(e) {
		case UNZ_END_OF_LIST_OF_FILE:		return "end of file list reached";
		case UNZ_EOF:						return "end of file reached";
		case UNZ_PARAMERROR:				return "invalid parameter given";
		case UNZ_BADZIPFILE:				return "bad zip file";
		case UNZ_INTERNALERROR:				return "internal error";
		case UNZ_CRCERROR:					return "crc error, file is corrupt";
		case UNZ_ERRNO:						return strerror(errno);
		default:							return "unknown error (" + SystemUtil::translateError(e) + ")";
	}
}

ZipFile::ZipFile(const string &file) : fp(NULL) {
	this->Open(file);
}

ZipFile::~ZipFile() {
	this->Close();
}

#ifdef WIN32
// minizip reaches the archive through the ANSI CRT, so a UTF-8 path holding characters outside
// the active code page never survives the trip to unzOpen. Hand it the 8.3 short name instead,
// which is always representable. Volumes with 8.3 names disabled fall back to the raw path and
// fail exactly as before.
static string toZipPath(const string& file) noexcept {
	auto wide = Text::utf8ToWide(file);

	auto len = ::GetShortPathNameW(wide.c_str(), NULL, 0);
	if(len > 0) {
		wstring shortPath(len, 0);
		len = ::GetShortPathNameW(wide.c_str(), &shortPath[0], len);
		if(len > 0 && len < shortPath.size()) {
			shortPath.resize(len);
			return Text::wideToAcp(shortPath);
		}
	}

	return Text::wideToAcp(wide);
}

// The same problem when CREATING an archive, but GetShortPathName only resolves paths that
// already exist, and the archive does not yet. Shorten the (existing) parent directory and
// keep the file name, which for our callers (backups, crash bundles) is ASCII. A profile
// under a non-ASCII path was the failing case: "Failed to create the backup" with the
// archive never written.
//
// Same caveat as toZipPath: where the volume has 8.3 name creation disabled (the Windows
// default for non-system volumes) GetShortPathName returns the long name unchanged, so this
// still fails. Routing minizip through zipOpen2/unzOpen2 with a filefunc built on
// dcpp_fopen (which is _wfopen) would fix both directions on every volume; until then this
// only widens the set of paths that work.
static string toZipCreatePath(const string& file) noexcept {
	auto wide = Text::utf8ToWide(file);
	auto slash = wide.find_last_of(L"\\/");
	if(slash != wstring::npos && slash > 0) {
		auto dir = wide.substr(0, slash);
		auto name = wide.substr(slash);

		auto len = ::GetShortPathNameW(dir.c_str(), NULL, 0);
		if(len > 0) {
			wstring shortDir(len, 0);
			len = ::GetShortPathNameW(dir.c_str(), &shortDir[0], len);
			if(len > 0 && len < shortDir.size()) {
				shortDir.resize(len);
				return Text::wideToAcp(shortDir + name);
			}
		}
	}

	return Text::wideToAcp(wide);
}
#endif

void ZipFile::Open(const string &file) {
	this->Close();
#ifdef WIN32
	this->fp = unzOpen(toZipPath(file).c_str());
#else
	this->fp = unzOpen(file.c_str());
#endif
	if(this->fp == NULL) throw ZipFileException("unzOpen");
}

void ZipFile::Close() {
	if(this->IsOpen()) {
		int ret = unzClose(this->fp);
		if(ret != UNZ_OK) throw ZipFileException("unzClose", ret);
		this->fp=NULL;
	}
}

bool ZipFile::IsOpen() const {
	return (this->fp != NULL);
}

bool ZipFile::GoToFirstFile() {
	return (unzGoToFirstFile(this->fp) == UNZ_OK);
}

bool ZipFile::GoToNextFile() {
	return (unzGoToNextFile(this->fp) == UNZ_OK);
}

void ZipFile::OpenCurrentFile() {
	int ret = unzOpenCurrentFile(this->fp);
	if(ret != UNZ_OK) throw ZipFileException("unzOpenCurrentFile", ret);
}

void ZipFile::CloseCurrentFile() {
	int ret = unzCloseCurrentFile(this->fp);
	if(ret != UNZ_OK) throw ZipFileException("unzCloseCurrentFile", ret);
}

string ZipFile::GetCurrentFileName() {
	char buf[1024];
	unz_file_info info;

	int ret = unzGetCurrentFileInfo(this->fp, &info, buf, sizeof(buf), NULL, 0, NULL, 0);
	if(ret != UNZ_OK) throw ZipFileException("unzGetCurrentFileInfo", ret);

	// minizip only NUL-terminates the name buffer when it has spare room; if the
	// stored name is >= sizeof(buf) the buffer is filled without a terminator,
	// so guard against an out-of-bounds read by forcing termination here.
	buf[sizeof(buf) - 1] = '\0';

	return buf;
}

const ZipFile::FileInfo ZipFile::GetCurrentFileInfo() {
	char buf[1024];
	unz_file_info info;

	int ret = unzGetCurrentFileInfo(this->fp, &info, buf, sizeof(buf), NULL, 0, NULL, 0);
	if(ret != UNZ_OK) throw ZipFileException("unzGetCurrentFileInfo", ret);

	// Same unterminated-buffer guard as GetCurrentFileName above: minizip terminates the name only
	// when it has spare room, so a stored name of sizeof(buf) or more fills it with no terminator
	// and the FileInfo construction below reads past the end of the stack buffer.
	buf[sizeof(buf) - 1] = '\0';

	struct tm t;
	t.tm_year = info.tmu_date.tm_year - 1900;
	t.tm_isdst = -1;
	t.tm_mon = info.tmu_date.tm_mon;
	t.tm_mday = info.tmu_date.tm_mday;
	t.tm_hour = info.tmu_date.tm_hour;
	t.tm_min = info.tmu_date.tm_min;
	t.tm_sec = info.tmu_date.tm_sec;

	return FileInfo(buf, mktime(&t), info.uncompressed_size);
}

pair<uint8_t*,size_t> ZipFile::ReadCurrentFile() {
	// Hard cap on a single entry's declared uncompressed size to guard against
	// decompression-bomb / corrupt-header allocations (2 GiB).
	static const uint64_t MAX_UNCOMPRESSED_SIZE = 2ULL * 1024 * 1024 * 1024;

	unz_file_info info;
	uLong ret = unzGetCurrentFileInfo(this->fp, &info, NULL, 0, NULL, 0, NULL, 0);
	if(ret != UNZ_OK) throw ZipFileException("unzGetCurrentFileInfo", ret);

	const uint64_t declaredSize = static_cast<uint64_t>(info.uncompressed_size);
	if(declaredSize > MAX_UNCOMPRESSED_SIZE)
		throw ZipFileException("ReadCurrentFile", "uncompressed size exceeds maximum allowed size");

	// On 32-bit builds size_t may be narrower than the declared size; reject
	// anything that would not fit into the allocation/length type.
	if(declaredSize > static_cast<uint64_t>(SIZE_MAX))
		throw ZipFileException("ReadCurrentFile", "uncompressed size exceeds addressable range");

	const size_t bufSize = static_cast<size_t>(declaredSize);
	unique_ptr<uint8_t[]> buf(new uint8_t[bufSize]);

	ret = unzReadCurrentFile(fp, buf.get(), info.uncompressed_size);
	if(ret != info.uncompressed_size) throw ZipFileException("unzReadCurrentFile", ret);

	return { buf.release(), bufSize };
}

// Rejects archive entry names that would escape the destination directory (zip-slip).
//
// Enforced here rather than per caller: every caller passes a destination directory and expects
// the entry to land inside it, and the WIN32 separator rewrite below actively turns a POSIX
// "../" into working Windows traversal. ConfigBackupManager wrapped this API in its own check,
// which is what made the gap visible -- the plugin installer loops it over every entry with no
// check at all.
static bool isSafeRelativeEntry(const string& aName) noexcept {
	if (aName.empty()) {
		return false;
	}

	// Absolute path, or a drive-qualified one
	if (aName[0] == '/' || aName[0] == '\\') {
		return false;
	}

	if (aName.size() >= 2 && aName[1] == ':') {
		return false;
	}

	// Any ".." segment, whichever separator it uses
	for (string::size_type pos = 0;;) {
		const auto end = aName.find_first_of("/\\", pos);
		if (aName.substr(pos, end == string::npos ? string::npos : end - pos) == "..") {
			return false;
		}

		if (end == string::npos) {
			break;
		}

		pos = end + 1;
	}

	return true;
}

void ZipFile::ReadCurrentFile(const string& aPath) {
	try {
		string nameInZip = this->GetCurrentFileName();

#ifdef WIN32
		// Wrong path separators would hit assertions...
		boost::replace_all(nameInZip, "/", PATH_SEPARATOR_STR);
#endif

		if (!nameInZip.empty() && nameInZip[nameInZip.size()-1] != '/' &&  nameInZip[nameInZip.size()-1] != '\\') {
			// Only when the entry name is actually used to build the destination; a caller that
			// passes an explicit target file chooses the path itself.
			const auto appendName = PathUtil::isDirectoryPath(aPath);
			if (appendName && !isSafeRelativeEntry(nameInZip)) {
				throw ZipFileException("Unsafe entry name in archive: " + nameInZip);
			}

			pair<uint8_t*,size_t> file = this->ReadCurrentFile();
			// Owns the raw buffer ReadCurrentFile() hands back (it returns buf.release()), so a
			// throw from the write below no longer leaks the full uncompressed size.
			unique_ptr<uint8_t[]> buf(file.first);

			const string& fullPath = appendName ? aPath + nameInZip : aPath;
			File::ensureDirectory(fullPath);

			{
				File f(fullPath, File::WRITE, File::OPEN | File::CREATE | File::TRUNCATE, File::BUFFER_SEQUENTIAL);
				f.setEndPos(0);
				f.write(file.first, file.second);
			}
		}
	} catch (const Exception& e) {
		throw ZipFileException(e.getError());
	}
}

void ZipFile::ReadFiles(ZipFile::FileMap& files) {
	try {
		if(this->GoToFirstFile()) {
			do {
				this->OpenCurrentFile();
				const FileInfo& fi = this->GetCurrentFileInfo();
				if(!fi.name.empty() && fi.name[fi.name.size()-1] != '/' && fi.name[fi.name.size()-1] != '\\') {
					pair<uint8_t*,size_t> file = this->ReadCurrentFile();
					files[fi.name] = make_pair(fi, FileContentType(file.first));
				}
				this->CloseCurrentFile();
			} while(this->GoToNextFile());
		}
	} catch (const Exception& e) {
		throw ZipFileException(e.getError());
	}
}

// Zip file creation
void ZipFile::CreateZipFile(const string& dstPath, const StringPairList& files) {
	zipFile zFile;
	int err = ZIP_OK;

#ifdef WIN32
	zFile = zipOpen(toZipCreatePath(dstPath).c_str(), APPEND_STATUS_CREATE);
#else
	zFile = zipOpen(dstPath.c_str(), APPEND_STATUS_CREATE);
#endif
	if(!zFile)
		throw ZipFileException("zipOpen");

	// Close the archive on EVERY exit. Every error inside the loop throws ZipFileException, which
	// derives from Exception and not FileException -- so the catch below did not cover them, and the
	// one thing it did catch it rethrew from inside the handler. Either way the minizip FILE* was
	// leaked on a half-written .zip, and because MSVCRT's fopen does not pass FILE_SHARE_DELETE the
	// caller's own cleanup (ConfigBackupManager deletes the partial archive) then failed too,
	// stranding a corrupt backup that the rotation logic went on to count.
	bool zipClosed = false;
	ScopedFunctor([&] { if (!zipClosed) zipClose(zFile, NULL); });

	for(const auto& i: files) {
		auto& path = i.first;
		const char* nameInZip = i.second.c_str();

		while(nameInZip[0] == '/' || nameInZip[0] == '\\')
			nameInZip++;

		zip_fileinfo zi;
		memzero(&zi, sizeof(zip_fileinfo));

		if(!i.second.empty() && i.second[i.second.size()-1] == '/') {
			// Add directory entry (missing folder attributes)
			err = zipOpenNewFileInZip(zFile, nameInZip, &zi,
				NULL, 0, NULL, 0, NULL, Z_DEFLATED, Z_BEST_COMPRESSION);

			if(err != ZIP_OK)
				throw ZipFileException("zipOpenNewFileInZip", err);

			err = zipCloseFileInZip(zFile);
			if(err != ZIP_OK)
				throw ZipFileException("zipCloseFileInZip", err);
		} else {
			const size_t buf_size = 16384;
			// Owned: this was a raw new[] freed only on the success path.
			boost::scoped_array<char> buf(new char[buf_size]);

			try {
				File f(path, File::READ, File::OPEN | File::SHARED_WRITE);

				if(f.getSize() != -1) {
					time_t time = f.getLastModified();
					std::tm fileTm{};
#ifdef _WIN32
					auto fileTmOk = localtime_s(&fileTm, &time) == 0;
#else
					auto fileTmOk = localtime_r(&time, &fileTm) != nullptr;
#endif
					if(fileTmOk) {
					zi.tmz_date.tm_sec = fileTm.tm_sec;
					zi.tmz_date.tm_min = fileTm.tm_min;
					zi.tmz_date.tm_hour = fileTm.tm_hour;
					zi.tmz_date.tm_mday = fileTm.tm_mday;
					zi.tmz_date.tm_mon = fileTm.tm_mon;
					zi.tmz_date.tm_year = fileTm.tm_year;
					}

					err = zipOpenNewFileInZip(zFile, nameInZip, &zi,
						NULL, 0, NULL, 0, NULL, Z_DEFLATED, Z_BEST_COMPRESSION);

					if(err != ZIP_OK)
						throw ZipFileException("zipOpenNewFileInZip", err);

					size_t read = buf_size;
					while((read = f.read(buf.get(), read)) > 0) {
						err = zipWriteInFileInZip(zFile, buf.get(), read);
						if(err < ZIP_OK)
							throw ZipFileException("zipWriteInFileInZip", err);
						read = buf_size;
					}

					err = zipCloseFileInZip(zFile);
					if(err != ZIP_OK)
						throw ZipFileException("zipCloseFileInZip", err);
				}
			} catch(const FileException& e) {
				throw ZipFileException(e.getError());
			}

		}
	}

	err = zipClose(zFile, NULL);
	zipClosed = true;
	if(err != ZIP_OK)
		throw ZipFileException("zipClose", err);
}

// dstPath: path inside zip file (use forward slashes, not backslashes)
int ZipFile::CreateZipFileList(StringPairList& files_, const string& srcPath, const string& dstPath, const string& aPattern, bool aKeepEmpty) noexcept {
	int addedFiles = 0;

	FileFindIter end;
	for(FileFindIter i(srcPath, "*"); i != end; ++i) {
		string name = i->getFileName();
		if (i->isHidden() || i->isLink() || name.empty()) {
			continue;
		}

		if (!aPattern.empty()) {
			boost::regex reg(aPattern);
			if (!boost::regex_search(name.begin(), name.end(), reg)) {
				continue;
			}
		}

		if (i->isDirectory()) {
			string newSrcPath = srcPath + name + PATH_SEPARATOR;
			string newDstPath = dstPath + name + '/';

			StringPairList subFiles;
			addedFiles += ZipFile::CreateZipFileList(subFiles, newSrcPath, newDstPath); //don't pass the pattern to sub directories

			if (aKeepEmpty || !subFiles.empty()) {
				// Subdirectory
				files_.emplace_back(newSrcPath, newDstPath);

				// Subfiles
				files_.insert(files_.end(), subFiles.begin(), subFiles.end());
			}
		} else {
			files_.emplace_back(srcPath + name, dstPath + name);
			addedFiles++;
		}
	}

	return addedFiles;
}

} // namespace dcpp
