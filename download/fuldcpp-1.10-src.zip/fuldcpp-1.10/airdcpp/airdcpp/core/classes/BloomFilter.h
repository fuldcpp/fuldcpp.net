/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_BLOOM_FILTER_H
#define DCPLUSPLUS_DCPP_BLOOM_FILTER_H

#include <airdcpp/core/header/typedefs.h>

namespace dcpp {

template<size_t N>
class BloomFilter {
// Storage note: the bit table is held as atomic 64-bit words rather than a vector<bool>.
// Share refresh and cache loading both fill the bloom from parallel_for_each workers, and
// vector<bool> packs 64 bits into one word -- so two threads setting DIFFERENT bits
// performed a read-modify-write on the SAME word and one update was silently lost, leaving
// a shared file permanently invisible to remote searches until the next full refresh.
// (Only REFRESH_ALL builds a private bloom; every other refresh hands the workers the live
// one, which search threads are matching against at the same time.)
//
// fetch_or is lock-free and keeps the same memory footprint as vector<bool>, so neither the
// refresh path nor the search hot path pays for a mutex.
public:
	BloomFilter(size_t tableSize) : bitCount(tableSize ? tableSize : 1), table(wordCount(bitCount)) { }
	~BloomFilter() { }

	void add(const string& s) { xadd(s, N); }
	bool match(const string& s) const {
		if(s.length() >= N) {
			string::size_type l = s.length() - N;
			for(string::size_type i = 0; i <= l; ++i) {
				if(!testBit(getPos(s, i, N))) {
					return false;
				}
			}
		}
		return true;
	}
	void clear() {
		for (auto& w : table) {
			w.store(0, std::memory_order_relaxed);
		}
	}

	void merge(const BloomFilter<N>& aBloom) {
		// Same-sized filters only; the callers build both from the same share size.
		dcassert(table.size() == aBloom.table.size());
		const auto n = std::min(table.size(), aBloom.table.size());
		for (size_t i = 0; i < n; ++i) {
			const auto bits = aBloom.table[i].load(std::memory_order_relaxed);
			if (bits) {
				table[i].fetch_or(bits, std::memory_order_relaxed);
			}
		}
	}
#ifdef TESTER
	void print_table_status() {
		int tot = 0;
		for (size_t i = 0; i < bitCount; ++i) if (testBit(i)) ++tot;

		std::cout << "table status: " << tot << " of " << bitCount
			<< " filled, for an occupancy percentage of " << (100.*tot)/bitCount
			<< "%" << std::endl;
	}
#endif
private:
	using Word = uint64_t;
	static constexpr size_t BITS_PER_WORD = sizeof(Word) * 8;

	static size_t wordCount(size_t aBits) noexcept {
		return (aBits + BITS_PER_WORD - 1) / BITS_PER_WORD;
	}

	void setBit(size_t aPos) noexcept {
		table[aPos / BITS_PER_WORD].fetch_or(Word(1) << (aPos % BITS_PER_WORD), std::memory_order_relaxed);
	}

	bool testBit(size_t aPos) const noexcept {
		return (table[aPos / BITS_PER_WORD].load(std::memory_order_relaxed) & (Word(1) << (aPos % BITS_PER_WORD))) != 0;
	}

	void xadd(const string& s, size_t n) {
		if(s.length() >= n) {
			string::size_type l = s.length() - n;
			for(string::size_type i = 0; i <= l; ++i) {
				setBit(getPos(s, i, n));
			}
		}
	}

	/* This is roughly how boost::hash does it */
	size_t getPos(const string& s, size_t i, size_t l) const {
		size_t h = 0;
		const char* c = s.data() + i;
		const char* end = s.data() + i + l;
		for(; c < end; ++c) {
			h ^= *c + 0x9e3779b9 + (h<<6) + (h>>2);
		}
		return (h % bitCount);
	}

	size_t bitCount;
	std::vector<std::atomic<Word>> table;
};

} // namespace dcpp

#endif // !defined(BLOOM_FILTER_H)
