/* 
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/core/timer/TimerManager.h>

#include <boost/date_time/posix_time/ptime.hpp>

#ifndef _WIN32
#include <sys/time.h>
#endif


namespace dcpp {

using namespace boost::posix_time;

TimerManager::TimerManager() {
}

TimerManager::~TimerManager() {
	dcassert(listeners.size() == 0);
}

void TimerManager::shutdown() {
	{
		std::lock_guard<std::mutex> l(mtx);
		stopping = true;
	}

	cv.notify_all();
	join();
}

int TimerManager::run() {

	//https://bugs.launchpad.net/dcplusplus/+bug/713742
	
	// Scheduling is relative and driven by the monotonic tick, never by the wall clock.
	//
	// This used to wait on an ABSOLUTE wall-clock deadline (timed_lock(ptime)) and compare against
	// microsec_clock::universal_time(). A backward step -- an NTP correction, a VM resuming with a
	// stale RTC, the user fixing a wrong date -- left the deadline in the future by the size of the
	// step, so every tick stopped for that long: no transfer timeouts, no hub keepalives, no delayed
	// events. A one-second relative wait cannot be pushed around by the clock at all.
	auto nextMinTick = getTick() + 60 * 1000;

	for (;;) {
		{
			// Scoped so the listeners below run with the lock released.
			std::unique_lock<std::mutex> l(mtx);
			if (cv.wait_for(l, std::chrono::seconds(1), [this] { return stopping; })) {
				break;
			}
		}

		const auto t = getTick();
		fire(TimerManagerListener::Second(), t);

		if (nextMinTick <= t)
		{
			// Re-base rather than accumulate. `nextMinTick += 60*1000` left the deadline in the
			// past after any gap longer than a minute -- a laptop resuming from a ten-hour
			// hibernate fired Minute six hundred times, once per second, taking every listener
			// with it (an unconditional recents save, a full autosearch scan, and the plugin
			// timer hook for every loaded plugin). The Second schedule was already guarded this
			// way; Minute was not.
			nextMinTick = t + 60 * 1000;
			fire(TimerManagerListener::Minute(), t);
		}
	}

	dcdebug("TimerManager done\n");
	return 0;
}

uint64_t TimerManager::getTick() {
	// Steady, not wall clock. GET_TICK() feeds every "lastX + interval < now" comparison in the
	// client; derived from universal_time() a backward clock step across process start made the
	// subtraction negative, and the uint64_t result wrapped to ~1.8e19 -- firing every one of those
	// comparisons at once.
	using clock = std::chrono::steady_clock;
	static const auto start = clock::now();
	return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(clock::now() - start).count());
}

time_t TimerManager::getTime() {
	return (time_t)time(NULL); 
}

time_t TimerManager::getStartTime() noexcept {
	return getTime() - getUptime();
}

time_t TimerManager::getUptime() noexcept {
	return getTick() / 1000;
}

} // namespace dcpp