/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_GEO_MANAGER_H
#define DCPLUSPLUS_DCPP_GEO_MANAGER_H

#include <airdcpp/forward.h>
#include <airdcpp/core/geo/GeoIP.h>
#include <airdcpp/core/Singleton.h>

#include <memory>
#include <mutex>
#include <string>

namespace dcpp {

using std::string;
using std::unique_ptr;

/** Manages IP->country mappings. */
class GeoManager : public Singleton<GeoManager>
{
public:
	/** Prepare the databases and fill internal caches. */
	void init();
	/** Update a database and its internal caches. Call after a new one have been downloaded. */
	/** Unload databases and clear internal caches. */
	void close();

	/** Map an IP address to a country. The flags specify which database(s) to look into. */
	string getCountry(const string& ip) const;

	/** Build date of the open database ("%Y-%m-%d"); empty when no DB is loaded. */
	string getEpoch() const;
	/** libmaxminddb version. */
	static string getVersion();

	static string getDbPath();

private:
	friend class Singleton<GeoManager>;

	// only these 2 for now. in the future, more databases could be added (region / city info...).
	unique_ptr<GeoIP> geo;

	// Bumped by every close(). init() builds the database outside the lock, so it captures this
	// first and only publishes its result if no close() happened meanwhile -- otherwise a close()
	// that both started and finished during the build (it returns at once while "geo" is still
	// null) would be undone by the assignment, leaving the database open with the setting off.
	uint64_t closeGeneration = 0;

	// Serializes access to "geo": init()/update()/close() may run on a different
	// thread (settings change handler, GeoIP download completion) than the many
	// getCountry() callers, which would otherwise destroy the GeoIP mid-lookup.
	mutable std::mutex cs;

	GeoManager();
	virtual ~GeoManager() { }
};

} // namespace dcpp

#endif
