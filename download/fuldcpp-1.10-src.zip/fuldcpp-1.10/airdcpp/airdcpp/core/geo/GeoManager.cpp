/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/core/geo/GeoManager.h>

#include <airdcpp/util/AppUtil.h>
#include <airdcpp/core/geo/GeoIP.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/util/Util.h>

namespace dcpp {


GeoManager::GeoManager() {
	SettingsManager::getInstance()->registerChangeHandler({
		SettingsManager::GET_USER_COUNTRY
	}, [this](auto ...) {
		if (SETTING(GET_USER_COUNTRY)) {
			GeoManager::getInstance()->init();
		} else {
			GeoManager::getInstance()->close();
		}
	});
}

void GeoManager::init() {
	// Built OUTSIDE the lock, then swapped in. The constructor decompresses the database, opens
	// the mmap and can log -- and LogManager::message fires its listeners synchronously, so a
	// listener that called back into getCountry() would deadlock on this non-recursive mutex.
	// Holding it across construction also blocked every caller formatting an IP for the whole
	// decompress, which for a large or hostile database is not a short wait.
	uint64_t generation;
	{
		std::lock_guard<std::mutex> l(cs);
		generation = closeGeneration;
	}

	auto db = make_unique<GeoIP>(getDbPath());

	std::lock_guard<std::mutex> l(cs);
	if (closeGeneration != generation) {
		// A close() ran to completion while this was building -- the setting was turned off, or
		// shutdown started. It saw a null "geo" and returned immediately, so publishing now would
		// silently reopen the database behind it. Moving the build out of the lock lost the
		// ordering that blocking used to provide for free: whichever call started later won.
		return;
	}

	geo = std::move(db);
}

// GeoManager::update() removed: it had no callers, and the code it wrapped was wrong anyway.
// GeoIP::update() did close(); if (decompress()) open(); -- but decompress() returns false whenever
// the .gz is absent, and the real refresh path (UpdateManager::completeGeoDownload) deletes the .gz
// after a successful update. So it would have closed the mmap and never reopened it, leaving
// getCountry() empty until the next restart. That path already does the correct close() + init().

void GeoManager::close() {
	std::lock_guard<std::mutex> l(cs);
	closeGeneration++;
	geo.reset();
}

string GeoManager::getCountry(const string& ip) const {
	std::lock_guard<std::mutex> l(cs);
	if(!ip.empty() && geo.get()) {
		return geo->getCountry(ip);
	}

	return Util::emptyString;
}

string GeoManager::getEpoch() const {
	std::lock_guard<std::mutex> l(cs);
	return geo ? geo->getEpoch() : Util::emptyString;
}

string GeoManager::getVersion() {
	return GeoIP::getVersion();
}

string GeoManager::getDbPath() {
	return AppUtil::getPath(AppUtil::PATH_USER_LOCAL) + "country_ip_db.mmdb";
}

} // namespace dcpp
