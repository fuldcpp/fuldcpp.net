/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/core/geo/GeoIP.h>

#include <airdcpp/core/classes/Exception.h>
#include <airdcpp/core/io/File.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/core/localization/Localization.h>
#include <airdcpp/core/header/format.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/util/Util.h>
#include <airdcpp/core/io/compress/ZUtils.h>

#include <maxminddb.h>

namespace dcpp {

// Application locales mapped to supported GeoIP languages
const map<string, string> localeGeoMappings = {
	{ "de-DE", "de" },
	{ "en-US", "en" },
	{ "es-ES", "es" },
	{ "fr-FR", "fr" },
	//{ "ja" },
	{ "pt-BR", "pt-BR" },
	{ "ru-RU", "ru" } ,
	//{ "zh-CN" },
};

static string parseLanguage() noexcept {
	auto i = localeGeoMappings.find(Localization::getCurLanguageLocale());
	return i != localeGeoMappings.end() ? i->second : "en";
}

GeoIP::GeoIP(string&& aPath) : geo(nullptr), path(std::move(aPath)), language(parseLanguage()) {
	if (File::getSize(path) > 0 || decompress()) {
		open();
	}
}

GeoIP::~GeoIP() {
	close();
}

namespace {

static string parseData(MMDB_lookup_result_s res, ...) {
	MMDB_entry_data_s entry_data;
	va_list keys;
	va_start(keys, res);

	auto status = MMDB_vget_value(&res.entry, &entry_data, keys);
	va_end(keys);

	if (status != MMDB_SUCCESS)
		return Util::emptyString;

	if (!entry_data.has_data)
		return Util::emptyString;

	if (entry_data.type != MMDB_DATA_TYPE_UTF8_STRING) {
		dcdebug("Invalid data UTF8 GeoIP2 data %d:\n", entry_data.type);
		return Util::emptyString;
	}

	return string(entry_data.utf8_string, entry_data.data_size);
}

} // unnamed namespace

string GeoIP::getCountry(const string& ip) const {
	if (geo) {
		int gai_error, mmdb_error;
		MMDB_lookup_result_s res = MMDB_lookup_string(
			geo, 
			ip.c_str(), 
			&gai_error, 
			&mmdb_error
		);

		if (res.found_entry && mmdb_error == MMDB_SUCCESS && gai_error == 0) {
			const string& setting = SETTING(COUNTRY_FORMAT);

			ParamMap params;
			params["2code"] = [&] { return parseData(res, "country", "iso_code", NULL); };
			params["continent"] = [&] { return parseData(res, "continent", "code", NULL); };
			params["engname"] = [&] { return parseData(res, "country", "names", "en", NULL); };
			params["name"] = [&] { return parseData(res, "country", "names", language.c_str(), NULL); };
			params["officialname"] = [&] { return parseData(res, "country", "names", language.c_str(), NULL); };

			return Util::formatParams(setting, params);
		} else {
			if (gai_error != 0) {
#ifdef WIN32
				dcdebug("Error from getaddrinfo for %s - %ls\n",
#else
				dcdebug("Error from getaddrinfo for %s - %s\n",
#endif
					ip.c_str(), gai_strerror(gai_error));
			}

			if (mmdb_error != MMDB_SUCCESS) {
				dcdebug("Got an error from libmaxminddb (MMDB_lookup_string): %s\n",
					MMDB_strerror(mmdb_error));          	
			}
		}
	}

	return Util::emptyString;
}


string GeoIP::getEpoch() const {
	if (!geo)
		return Util::emptyString;

	time_t epoch = static_cast<time_t>(geo->metadata.build_epoch);
	return Util::formatTime("%Y-%m-%d", epoch);
}

string GeoIP::getVersion() {
	return MMDB_lib_version();
}

bool GeoIP::decompress() const {
	if(File::getSize(path + ".gz") <= 0) {
		return false;
	}

	try {
		GZ::decompress(path + ".gz", path);
	} catch (const Exception&) {
		// Remove what was written. GZ::decompress aborts mid-write once the expansion passes its
		// ceiling, and the constructor above tests File::getSize(path) > 0 BEFORE calling this --
		// so a partial database short-circuits that test on every later run, decompress() is never
		// retried, and MMDB_open quietly fails on the garbage for the rest of the installation's
		// life. UpdateManager::completeGeoDownload already cleans up the same way.
		//
		// The .gz goes too, and its failure matters more: checkGeoUpdate() reads a recent .gz as
		// "already up to date", so a corrupt one left behind blocks the re-download for the whole
		// expiration window while every startup re-runs the same doomed decompress. Removing it
		// after a merely transient write failure costs one re-download, the cheaper side of that
		// trade.
		File::deleteFile(path);
		File::deleteFile(path + ".gz");

		// Judged by what is left on disk, not by the return values: deleteFile also reports false
		// for a file that was never there, and the decompress can throw before creating the target.
		if (File::getSize(path) > 0 || File::getSize(path + ".gz") > 0) {
			LogManager::getInstance()->message(
				"Failed to remove the unusable GeoIP database files in " + PathUtil::getFilePath(path) +
				"; country lookups will stay unavailable until they are deleted by hand",
				LogMessage::SEV_WARNING, STRING(UPDATER));
		}

		return false;
	}

	return true;
}

void GeoIP::open() {
	geo = (MMDB_s*)malloc(sizeof(MMDB_s));
	if (!geo) {
		return;
	}

	// The path is passed as UTF-8, which is what MMDB_open documents and what it converts from on
	// Windows (MultiByteToWideChar with CP_UTF8). Text::fromUtf8 re-encoded it into the system ANSI
	// codepage first, so the library then decoded those bytes as UTF-8 -- a profile directory with
	// any non-ASCII character in it named a file that does not exist, the open failed, and country
	// lookups were silently unavailable for exactly those users. `path` is already UTF-8 everywhere
	// else in this class.
	auto res = MMDB_open(path.c_str(), MMDB_MODE_MMAP, geo);
	if (res != MMDB_SUCCESS) {
		dcdebug("Failed to open MMDB database %s\n", MMDB_strerror(res));
		if (geo) {
			free(geo);
			geo = nullptr;
		}
	}
}

void GeoIP::close() {
	MMDB_close(geo);
	free(geo);
	geo = nullptr;
}

} // namespace dcpp
