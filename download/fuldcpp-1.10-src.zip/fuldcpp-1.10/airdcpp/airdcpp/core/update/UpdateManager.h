/*
 * Copyright (C) 2012-2024 AirDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_UPDATE_MANAGER_H
#define DCPLUSPLUS_DCPP_UPDATE_MANAGER_H

#include <airdcpp/message/Message.h>
#include <airdcpp/core/Singleton.h>
#include <airdcpp/core/Speaker.h>
#include <airdcpp/core/thread/CriticalSection.h>
#include <airdcpp/core/timer/TimerManagerListener.h>
#include <airdcpp/core/update/UpdateManagerListener.h>

#include <airdcpp/core/version.h>

#include <atomic>

namespace dcpp {

struct HttpDownload;
class HttpOptions;
class UpdateDownloader;

class UpdateManager : public Singleton<UpdateManager>, public Speaker<UpdateManagerListener>, private TimerManagerListener
{

public:
	UpdateManager();
	~UpdateManager() override;

	struct {
		string geoip;
		string language;
		string ipcheck4;
		string ipcheck6;
	} links;

	static void log(const string& aMsg, LogMessage::Severity aSeverity) noexcept;
	static bool verifyVersionData(const string& data, const ByteVector& aSignature);

	// Transport options for every download in the update chain (manifest, its signature and the
	// updater payload). These must NOT use the HttpOptions defaults: allowUntrusted defaults to
	// true, which would let an on-path attacker terminate TLS with any certificate -- the RSA
	// signature still blocks a forged manifest, but not suppressing updates or replaying an old
	// signed one. Shared rather than set per call site, because this drifting out of sync between
	// the update path and the GeoIP path is exactly how it came to be missing here.
	static HttpOptions getUpdateHttpOptions(int64_t aMaxBodySize) noexcept;

	// Named so the slot helpers below can take one; the values are unchanged.
	enum ConnectionType {
		CONN_VERSION,
		CONN_GEO,
		CONN_LANGUAGE_FILE,
		CONN_LANGUAGE_CHECK,
		CONN_SIGNATURE,
		CONN_IP4,
		CONN_IP6,

		CONN_LAST
	};

	// Guards conns[] itself. A download's own data is only touched by its completion, but the
	// slots are assigned and cleared from unrelated threads.
	mutable CriticalSection csConns;
	unique_ptr<HttpDownload> conns[CONN_LAST];

	// Starts a download in aType unless one is already in flight there; false if it was skipped
	// for that reason. The callback type is spelled out rather than taken from HttpDownload, which
	// is only forward-declared here; it must stay in step with HttpDownload::CompletionF.
	bool startConnection(ConnectionType aType, const string& aUrl, std::function<void ()>&& aCallback, const HttpOptions& aOptions) noexcept;

	// Removes the download from aType and hands ownership to the caller.
	unique_ptr<HttpDownload> takeConnection(ConnectionType aType) noexcept;

	void checkVersion(bool aManualCheck);
	void checkLanguage();

	void checkIP(bool aManualCheck, bool v6);

	void checkGeoUpdate();
	void updateGeo(); // public so the settings page's Update Now button can force a download

	void init();

	void checkAdditionalUpdates(bool aManualCheck);
	string getVersionUrl() const;

	UpdateDownloader& getUpdater() const noexcept {
		return *updater.get();
	}

	// The updater exists only after init() has been called by the application host
	bool isUpdaterInitialized() const noexcept {
		return updater != nullptr;
	}
private:
	unique_ptr<UpdateDownloader> updater;

	void failVersionDownload(const string& aError, bool aManualCheck);

	static const char* versionUrl[VERSION_LAST];

	uint64_t lastIPUpdate;

	// Tick of the last version check (of any kind). The periodic check in the Minute
	// handler is scheduled from this, so a manual check or a channel change postpones
	// the next automatic one instead of stacking on top of it. Atomic because manual
	// checks run on their own thread while the timer thread reads it.
	std::atomic<uint64_t> lastVersionCheck;

	static uint8_t publicKey[270];

	ByteVector versionSig;

	void completeSignatureDownload(bool aManualCheck);
	void completeLanguageCheck();
	void completeGeoDownload();
	void completeVersionDownload(bool aManualCheck);
	void completeLanguageDownload();
	void completeIPCheck(bool aManualCheck, bool v6);

	void on(TimerManagerListener::Minute, uint64_t aTick) noexcept override;

	static string parseIP(const string& aText, bool v6);
};

} // namespace dcpp

#endif // UPDATE_MANAGER_H