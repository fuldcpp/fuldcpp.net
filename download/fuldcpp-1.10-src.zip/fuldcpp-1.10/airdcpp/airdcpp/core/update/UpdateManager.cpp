/*
 * Copyright (C) 2012-2024 AirDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/core/update/UpdateManager.h>
#include <airdcpp/core/update/UpdateDownloader.h>

#include <airdcpp/util/CryptoUtil.h>
#include <airdcpp/connectivity/ConnectivityManager.h>
#include <airdcpp/core/geo/GeoManager.h>
#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/hash/value/HashCalc.h>
#include <airdcpp/connection/http/HttpDownload.h>
#include <airdcpp/core/localization/Localization.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/util/LinkUtil.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/core/classes/ScopedFunctor.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/core/io/compress/ZUtils.h>
#include <airdcpp/core/io/xml/SimpleXML.h>
#include <airdcpp/util/text/Text.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/core/version.h>

#include <airdcpp/core/crypto/pubkey.h>

#define IP_DB_EXPIRATION_DAYS 16 // GeoLite2 databases are rebuilt about twice a month

namespace dcpp {

const char* UpdateManager::versionUrl[VERSION_LAST] = {
	"https://fuldcpp.net/update/version.xml",
	"https://fuldcpp.net/update/beta/version.xml",
	"https://fuldcpp.net/update/nightly/version.xml"
};

UpdateManager::UpdateManager() : lastIPUpdate(GET_TICK()), lastVersionCheck(GET_TICK()) {
	TimerManager::getInstance()->addListener(this);

	// GeoIP fallback only (the GEOIP_URL setting wins and defaults to the P3TERX mirror);
	// keep it off airdcpp.net so FulDC++ never contacts the upstream project.
	links.geoip = "https://github.com/P3TERX/GeoLite.mmdb/raw/download/GeoLite2-Country.mmdb";
	// Self-hosted HTTPS IP echo (dual-stack, bare address in the body, see the fuldc-ip
	// worker). The v4 check runs on a v4-only socket; the v6 check uses whatever family the
	// resolver picks, there being no v6-only socket option. checkIP() requires a CA-trusted
	// certificate for these, so the answer can't be forged by an on-path attacker. The signed
	// manifest may override both URLs (<Links><IPCheck>/<IPCheck6>).
	links.ipcheck4 = "https://ip.fuldcpp.net/";
	links.ipcheck6 = "https://ip.fuldcpp.net/";
	// Language-file update service is not self-hosted for FulDC++; leave empty so
	// checkLanguage() performs no network call (was languages.airdcpp.net upstream).
	links.language = "";

	SettingsManager::getInstance()->registerChangeHandler({
		SettingsManager::GET_USER_COUNTRY,
		SettingsManager::LANGUAGE_FILE,
		SettingsManager::GEOIP_URL
	}, [this](auto, auto aChangedSettings) {
		if (ranges::find(aChangedSettings, SettingsManager::LANGUAGE_FILE) != aChangedSettings.end()) {
			UpdateManager::getInstance()->checkLanguage();
		}

		if (ranges::find(aChangedSettings, SettingsManager::GET_USER_COUNTRY) != aChangedSettings.end() && SETTING(GET_USER_COUNTRY)) {
			UpdateManager::getInstance()->checkGeoUpdate();
		}

		// Changing the database URL kicks off an immediate re-download
		if (ranges::find(aChangedSettings, SettingsManager::GEOIP_URL) != aChangedSettings.end()) {
			UpdateManager::getInstance()->updateGeo();
		}
	});
}

UpdateManager::~UpdateManager() { 
	TimerManager::getInstance()->removeListener(this);
}

void UpdateManager::log(const string& aMsg, LogMessage::Severity aSeverity) noexcept {
	LogManager::getInstance()->message(aMsg, aSeverity, STRING(UPDATER));
}

void UpdateManager::on(TimerManagerListener::Minute, uint64_t aTick) noexcept {
	if (SETTING(UPDATE_IP_HOURLY) && lastIPUpdate + 60*60*1000 < aTick) {
		checkIP(false, false);

		// The hourly check used to be v4-only, so a changed v6 address was never re-detected
		// after startup. Gate v6 the same way checkAdditionalUpdates does rather than firing it
		// unconditionally; the v4 call above stays ungated to preserve existing behaviour.
		if (SETTING(IP_UPDATE6) && !SETTING(AUTO_DETECT_CONNECTION6) && SETTING(INCOMING_CONNECTIONS6) != SettingsManager::INCOMING_DISABLED) {
			checkIP(false, true);
		}

		lastIPUpdate = aTick;
	}

	// Periodic version check: without it a client that is left running for weeks would
	// never learn about a new release, as the only automatic check happens at startup.
	// The updater must be initialized first (init() is called by the application host).
	auto intervalHours = SETTING(UPDATE_CHECK_HOURS);
	if (intervalHours > 0 && isUpdaterInitialized() &&
		lastVersionCheck + static_cast<uint64_t>(intervalHours) * 60 * 60 * 1000 < aTick) {
		checkVersion(false);
	}
}

bool UpdateManager::verifyVersionData(const string& aVersionData, const ByteVector& aSignature) {
	auto digest = CryptoUtil::calculateSha1(aVersionData);
	if (!digest) {
		return false;
	}

	const uint8_t* key = UpdateManager::publicKey;
	auto keySize = sizeof(UpdateManager::publicKey);

	return CryptoUtil::verifyDigest(*digest, aSignature, key, keySize);
}

HttpOptions UpdateManager::getUpdateHttpOptions(int64_t aMaxBodySize) noexcept {
	HttpOptions options;
	options.setAllowUntrusted(false);
	// ...and it has to be https in the first place: the manifest may set links.language, and a
	// trusted-certificate requirement means nothing on a cleartext URL, because whether the socket
	// is encrypted at all comes from the scheme rather than from how a certificate is checked.
	options.setRequireTLS(true);
	options.setMaxBodySize(aMaxBodySize);
	return options;
}

// The manifest and its signature are well under a kilobyte each; the cap only exists so a
// hostile or misconfigured endpoint can't stream an unbounded body into memory.
static constexpr int64_t UPDATE_MANIFEST_MAX_BODY = 1LL * 1024 * 1024;

// A translation file is a few hundred KB; the version probe is a single number.
static constexpr int64_t LANGUAGE_FILE_MAX_BODY = 8LL * 1024 * 1024;
static constexpr int64_t LANGUAGE_CHECK_MAX_BODY = 64LL * 1024;

// The IP echo answers with one address; anything past a few hundred bytes is not our server.
static constexpr int64_t IP_CHECK_MAX_BODY = 4LL * 1024;

// The language download is the only update fetch whose second URL comes from a RESPONSE HEADER
// rather than the signed manifest, so the header value has to be tied back to the manifest host
// before it is used. Same scheme and same host, or we don't follow it.
static bool isSameOrigin(const string& aUrl, const string& aExpectedUrl) noexcept {
	string proto, host, port, path, query, fragment;
	LinkUtil::decodeUrl(aUrl, proto, host, port, path, query, fragment);

	string expProto, expHost, expPort, expPath, expQuery, expFragment;
	LinkUtil::decodeUrl(aExpectedUrl, expProto, expHost, expPort, expPath, expQuery, expFragment);

	// The port is compared too: without it the header could move the fetch to another service on
	// the same host.
	return !host.empty() && Util::stricmp(host, expHost) == 0 &&
		Util::stricmp(proto, expProto) == 0 && port == expPort;
}

/*
 * conns[] is written from several threads: the timer starts the version and GeoIP checks, the
 * settings dialog and connectivity detection start IP checks, and each completion runs on its own
 * download's socket thread. Nothing serialised them, and assigning over an occupied slot runs the
 * previous HttpDownload's destructor -- which deletes the HttpConnection -- while the socket thread
 * may still be inside it.
 *
 * The in-flight guard matters as much as the lock: a slot that still holds a download has a
 * transfer running, so a second request is dropped rather than replacing it. updateGeo() already
 * worked this way; the other starters did not.
 */
bool UpdateManager::startConnection(ConnectionType aType, const string& aUrl, std::function<void ()>&& aCallback, const HttpOptions& aOptions) noexcept {
	HttpDownload* started = nullptr;

	{
		Lock l(csConns);
		if (conns[aType]) {
			return false;
		}

		conns[aType] = make_unique<HttpDownload>(aUrl, std::move(aCallback), aOptions);
		started = conns[aType].get();
	}

	// Outside the lock: start() can connect and fail synchronously, completing on this thread. The
	// pointer stays valid because only the completion clears the slot, and it cannot have run yet.
	started->start();
	return true;
}

unique_ptr<HttpDownload> UpdateManager::takeConnection(ConnectionType aType) noexcept {
	Lock l(csConns);
	return std::move(conns[aType]);
}

void UpdateManager::completeSignatureDownload(bool aManualCheck) {
	// Taken out of the array under the lock and owned locally for the rest of this function.
	// The slot is written by whichever thread starts the next check and cleared here on the
	// socket thread, so holding a reference into the array had those two racing over the same
	// unique_ptr. Destroying it when this scope ends is the moment the ScopedFunctor used to.
	auto conn = takeConnection(CONN_SIGNATURE);
	if (!conn) { return; }

	if(conn->buf.empty()) {
		// Stop here. Fetching the manifest with no signature to check it against is guaranteed to
		// fail its !versionSig.empty() test, so this produced two error popups for one failure --
		// "downloading of the signature failed" then "version verification failed" -- plus a
		// pointless round trip and a second checkAdditionalUpdates pass.
		failVersionDownload(STRING_F(DOWNLOAD_SIGN_FAILED, conn->status), aManualCheck);
		return;
	}

	versionSig.assign(conn->buf.begin(), conn->buf.end());

	startConnection(CONN_VERSION,
		getVersionUrl(),
		[this, aManualCheck] { completeVersionDownload(aManualCheck); },
		getUpdateHttpOptions(UPDATE_MANIFEST_MAX_BODY)
	);
}

void UpdateManager::checkIP(bool aManual, bool v6) {
	HttpOptions options;
	options.setV4Only(!v6);
	// The address fetched here is announced to every hub and decides where peers connect,
	// so it gets the same trust requirement as the manifest and GeoIP downloads: a
	// CA-valid chain plus hostname match. With the default (untrusted allowed) the
	// https:// URL gave no protection at all against a forged answer.
	options.setAllowUntrusted(false);
	options.setRequireTLS(true);   // the manifest may override these URLs too
	options.setMaxBodySize(IP_CHECK_MAX_BODY);

	startConnection(v6 ? CONN_IP6 : CONN_IP4,
		v6 ? links.ipcheck6 : links.ipcheck4,
		[this, aManual, v6] { completeIPCheck(aManual, v6); },
		options
	);
}

string UpdateManager::parseIP(const string& aText, bool v6) {
	const string pattern = !v6 ? 
		"\\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b" : 
		// Eight full groups first: every other branch needs a "::" or an embedded dotted quad,
		// so the canonical form of an address with no zero run never matched.
		"(\\A([0-9a-f]{1,4}:){7}[0-9a-f]{1,4}\\Z)|"
		"(\\A([0-9a-f]{1,4}:){1,1}(:[0-9a-f]{1,4}){1,6}\\Z)|(\\A([0-9a-f]{1,4}:){1,2}(:[0-9a-f]{1,4}){1,5}\\Z)|(\\A([0-9a-f]{1,4}:){1,3}(:[0-9a-f]{1,4}){1,4}\\Z)|(\\A([0-9a-f]{1,4}:){1,4}(:[0-9a-f]{1,4}){1,3}\\Z)|(\\A([0-9a-f]{1,4}:){1,5}(:[0-9a-f]{1,4}){1,2}\\Z)|(\\A([0-9a-f]{1,4}:){1,6}(:[0-9a-f]{1,4}){1,1}\\Z)|(\\A(([0-9a-f]{1,4}:){1,7}|:):\\Z)|(\\A:(:[0-9a-f]{1,4}){1,7}\\Z)|(\\A((([0-9a-f]{1,4}:){6})(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3})\\Z)|(\\A(([0-9a-f]{1,4}:){5}[0-9a-f]{1,4}:(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3})\\Z)|(\\A([0-9a-f]{1,4}:){5}:[0-9a-f]{1,4}:(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}\\Z)|(\\A([0-9a-f]{1,4}:){1,1}(:[0-9a-f]{1,4}){1,4}:(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}\\Z)|(\\A([0-9a-f]{1,4}:){1,2}(:[0-9a-f]{1,4}){1,3}:(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}\\Z)|(\\A([0-9a-f]{1,4}:){1,3}(:[0-9a-f]{1,4}){1,2}:(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}\\Z)|(\\A([0-9a-f]{1,4}:){1,4}(:[0-9a-f]{1,4}){1,1}:(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}\\Z)|(\\A(([0-9a-f]{1,4}:){1,5}|:):(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}\\Z)|(\\A:(:[0-9a-f]{1,4}){1,5}:(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)(\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)){3}\\Z)";

	const boost::regex reg(pattern);
	boost::match_results<string::const_iterator> results;
	// RSX++ workaround for msvc std lib problems
	auto start = aText.begin();
	auto end = aText.end();

	if (boost::regex_search(start, end, results, reg, boost::match_default)) {
		if (!results.empty()) {
			return results.str(0);
		}
	}

	return Util::emptyString;
}

void UpdateManager::completeIPCheck(bool aManual, bool v6) {
	// Taken out of the array under the lock and owned locally for the rest of this function.
	// The slot is written by whichever thread starts the next check and cleared here on the
	// socket thread, so holding a reference into the array had those two racing over the same
	// unique_ptr. Destroying it when this scope ends is the moment the ScopedFunctor used to.
	auto conn = takeConnection(v6 ? CONN_IP6 : CONN_IP4);
	if (!conn) { return; }

	string ip;
	const auto& setting = v6 ? SettingsManager::EXTERNAL_IP6 : SettingsManager::EXTERNAL_IP;

	if (!conn->buf.empty()) {
		try {
			ip = parseIP(conn->buf, v6);
			if (!aManual && !ip.empty()) {
				// While auto-detection is running it owns the auto-settings overlay
				// (clearAutoSettings may have just emptied it, which would read as a false
				// "change" here); detection completion triggers its own refreshExternalIP.
				auto autoDetect = v6 ? SETTING(AUTO_DETECT_CONNECTION6) : SETTING(AUTO_DETECT_CONNECTION);
				auto cm = ConnectivityManager::getInstance();
				if (!autoDetect || !cm->isRunning()) {
					// Read and write through ConnectivityManager: with auto-detection on, every
					// consumer (CONNSETTING -> HubSettings::UserIp4/6) sees the auto-settings
					// overlay, so a raw SettingsManager write would land in a shadowed slot and
					// the hubs would keep announcing the stale address.
					auto oldIP = cm->get(setting);
					if (oldIP != ip) {
						cm->set(setting, ip);

						log("External IP address changed from " + (oldIP.empty() ? string("(none)") : oldIP) +
							" to " + ip + ", notifying connected hubs", LogMessage::SEV_INFO);

						// Fan out to every connected hub. Safe from this HTTP-completion thread:
						// onExternalIPChanged takes a read lock and marshals via callAsync.
						ClientManager::getInstance()->onExternalIPChanged(ip, v6);
					}
				}
			}
		} catch(...) { }
	}

	if (ip.empty()) {
		// A failed lookup means a possibly stale address announced to every hub, so say so:
		// DNS failures, quota or challenge pages and rejected certificates otherwise leave
		// no trace outside a manual check's message box.
		log("External IPv" + string(v6 ? "6" : "4") + " address check failed: " +
			(conn->buf.empty() ? conn->status : "unrecognised answer"), LogMessage::SEV_WARNING);
	}

	fire(UpdateManagerListener::SettingUpdated(), setting, ip);
}

void UpdateManager::checkGeoUpdate() {
	// Update when the database is non-existent or older than X days.
	// A recent copy of EITHER form is "fresh": the staged download can land as
	// .gz or, when the configured URL serves an uncompressed DB, as a raw .mmdb
	// (the gz-magic sniff in completeGeoDownload handles both). Checking only the
	// .gz would make a raw-.mmdb install re-download the full DB every check cycle.
	const auto cutoff = GET_TIME() - 3600 * 24 * IP_DB_EXPIRATION_DAYS;
	for (const auto& path : { GeoManager::getDbPath() + ".gz", GeoManager::getDbPath() }) {
		try {
			File f(path, File::READ, File::OPEN);
			if (f.getSize() > 0 && f.getLastModified() > cutoff) {
				return;
			}
		} catch (const FileException&) { }
	}
	updateGeo();
}

void UpdateManager::updateGeo() {
	// The in-flight check that used to be here is now startConnection's, so it is done under the
	// lock rather than racing with the socket thread that clears the slot.

	// The user setting wins over version.xml <GeoIP>. It has a non-empty default
	// (clearing the field restores it), so links.geoip is only a guard for the
	// case where the built-in default itself is ever emptied.
	auto url = SETTING(GEOIP_URL).empty() ? links.geoip : SETTING(GEOIP_URL);

	log(STRING(GEOIP_UPDATING), LogMessage::SEV_INFO);
	HttpOptions geoOpts;
	geoOpts.setMaxBodySize(64LL * 1024 * 1024);   // Country DB is ~10 MB; bound a hostile/misconfigured URL
	geoOpts.setAllowUntrusted(false);             // require a CA-valid cert so the DB can't be MITM'd
	startConnection(CONN_GEO,
		url,
		[this] { completeGeoDownload(); },
		geoOpts
	);
}

void UpdateManager::completeGeoDownload() {
	// Taken out of the array under the lock and owned locally for the rest of this function.
	// The slot is written by whichever thread starts the next check and cleared here on the
	// socket thread, so holding a reference into the array had those two racing over the same
	// unique_ptr. Destroying it when this scope ends is the moment the ScopedFunctor used to.
	auto conn = takeConnection(CONN_GEO);
	if (!conn) { return; }

	if(!conn->buf.empty()) {
		// Accept either a gzipped .mmdb.gz OR a raw .mmdb (sniff gzip magic 1F 8B).
		// The payload is staged and validated (MaxMind metadata marker) BEFORE the
		// live DB is touched: a 404 / HTML error body - even a gzip-compressed one
		// from a misconfigured mirror - must never replace the good .mmdb. The
		// staged file always ends up as a raw .mmdb.
		const bool isGz = conn->buf.size() >= 2 &&
			static_cast<uint8_t>(conn->buf[0]) == 0x1f &&
			static_cast<uint8_t>(conn->buf[1]) == 0x8b;

		static const std::string kMaxMindMarker = std::string("\xab\xcd\xef", 3) + "MaxMind.com";
		const auto tmpPath = GeoManager::getDbPath() + ".tmp";

		bool staged = false;
		try {
			if (isGz) {
				// Land the gz beside the staging file, gunzip it, then validate
				const auto gzTmpPath = GeoManager::getDbPath() + ".gz.tmp";
				File(gzTmpPath, File::WRITE, File::CREATE | File::TRUNCATE).write(conn->buf);
				try {
					GZ::decompress(gzTmpPath, tmpPath);
				} catch (const Exception&) {
					try { File::deleteFile(gzTmpPath); } catch (...) {}
					throw FileException("invalid gzip data");
				}
				try { File::deleteFile(gzTmpPath); } catch (...) {}
				// Only the tail is read. The marker begins the MaxMind metadata section, which the
				// file format puts at the END of the file and whose specification says to search
				// the last 128 KiB for it. Reading the whole database in to look at a fixed-size
				// window at its end meant allocating a second copy of it -- up to the 1 GiB
				// decompression cap -- on a socket thread, every time the database updated.
				static constexpr int64_t kMetadataSearchWindow = 128 * 1024;

				File staging(tmpPath, File::READ, File::OPEN);
				const auto stagedSize = staging.getSize();
				const auto windowSize = min(stagedSize, kMetadataSearchWindow);
				staging.setPos(stagedSize - windowSize);

				if (staging.read(static_cast<size_t>(windowSize)).find(kMaxMindMarker) == string::npos) {
					throw FileException("downloaded data is not a MaxMind database");
				}
			} else {
				if (conn->buf.find(kMaxMindMarker) == std::string::npos) {
					throw FileException("downloaded data is not a MaxMind database");
				}
				File(tmpPath, File::WRITE, File::CREATE | File::TRUNCATE).write(conn->buf);
			}
			staged = true;
		} catch (const FileException& e) {
			try { File::deleteFile(tmpPath); } catch (...) {}
			auto err = STRING(GEOIP_UPDATING_FAILED) + " (" + e.what() + ")";
			log(err, LogMessage::SEV_WARNING);
			fire(UpdateManagerListener::GeoFailed(), err);
		}

		if (staged) {
			// Now release the mmap (Windows would deny the overwrite otherwise) and
			// swap files. init() runs UNCONDITIONALLY after close() so the DB is
			// restored even if the rename fails (it reopens whatever is on disk).
			GeoManager::getInstance()->close();
			try {
				File::renameFile(tmpPath, GeoManager::getDbPath());
				try { File::deleteFile(GeoManager::getDbPath() + ".gz"); } catch (...) {}   // stale legacy gz form
			} catch (const FileException&) {
				try { File::deleteFile(tmpPath); } catch (...) {}
			}
			GeoManager::getInstance()->init();    // opens the .mmdb (or gunzips a legacy .gz)
			if (!GeoManager::getInstance()->getEpoch().empty()) {
				log(STRING(GEOIP_UPDATED), LogMessage::SEV_INFO);
				fire(UpdateManagerListener::GeoUpdated());
			} else {
				auto err = STRING(GEOIP_UPDATING_FAILED) + " (downloaded data is not a valid MaxMind database)";
				log(err, LogMessage::SEV_WARNING);
				fire(UpdateManagerListener::GeoFailed(), err);
			}
		}
	} else {
		auto err = STRING(GEOIP_UPDATING_FAILED) + " (" + conn->status + ")";
		log(err, LogMessage::SEV_WARNING);
		fire(UpdateManagerListener::GeoFailed(), err);
	}
}

void UpdateManager::completeLanguageDownload() {
	// Taken out of the array under the lock and owned locally for the rest of this function.
	// The slot is written by whichever thread starts the next check and cleared here on the
	// socket thread, so holding a reference into the array had those two racing over the same
	// unique_ptr. Destroying it when this scope ends is the moment the ScopedFunctor used to.
	auto conn = takeConnection(CONN_LANGUAGE_FILE);
	if (!conn) { return; }

	if(!conn->buf.empty()) {
		try {
			auto path = Localization::getCurLanguageFilePath();
			File::ensureDirectory(PathUtil::getFilePath(path));
			File(path, File::WRITE, File::CREATE | File::TRUNCATE).write(conn->buf);
			log(STRING_F(LANGUAGE_UPDATED, Localization::getCurLanguageName()), LogMessage::SEV_INFO);
			fire(UpdateManagerListener::LanguageFinished());

			return;
		} catch(const FileException& e) { 
			log(STRING_F(LANGUAGE_UPDATE_FAILED, Localization::getCurLanguageName() % e.getError()), LogMessage::SEV_WARNING);
		}
	}

	fire(UpdateManagerListener::LanguageFailed(), conn->status);
	log(STRING_F(LANGUAGE_UPDATE_FAILED, Localization::getCurLanguageName() % conn->status), LogMessage::SEV_WARNING);
}

void UpdateManager::completeVersionDownload(bool aManualCheck) {
	// Taken out of the array under the lock and owned locally for the rest of this function.
	// The slot is written by whichever thread starts the next check and cleared here on the
	// socket thread, so holding a reference into the array had those two racing over the same
	// unique_ptr. Destroying it when this scope ends is the moment the ScopedFunctor used to.
	auto conn = takeConnection(CONN_VERSION);
	if (!conn) { return; }

	if (conn->buf.empty()) {
		failVersionDownload(STRING_F(DOWNLOAD_VERSION_FAILED, conn->status), aManualCheck);
		return; 
	}

	auto verified = !versionSig.empty() && verifyVersionData(conn->buf, versionSig);
	if (!verified) {
		failVersionDownload(STRING(VERSION_VERIFY_FAILED), aManualCheck);
		return;
	}

	try {
		SimpleXML xml;
		xml.fromXML(conn->buf);
		xml.stepIn();

		// Check for updated HTTP links
		if (xml.findChild("Links")) {
			xml.stepIn();

			if (xml.findChild("Languages")) {
				links.language = xml.getChildData();
			}
			xml.resetCurrentChild();
			if (xml.findChild("GeoIP")) {
				links.geoip = xml.getChildData();
			}
			xml.resetCurrentChild();
			if (xml.findChild("IPCheck")) {
				links.ipcheck4 = xml.getChildData();
			}
			xml.resetCurrentChild();
			if (xml.findChild("IPCheck6")) {
				links.ipcheck6 = xml.getChildData();
			}
			xml.stepOut();
		}
		xml.resetCurrentChild();

		fire(UpdateManagerListener::VersionFileDownloaded(), xml);
		updater->onVersionDownloaded(xml, verified, aManualCheck);
	} catch (const Exception& e) {
		// Return: failVersionDownload ends in checkAdditionalUpdates itself, and falling through to
		// the call below ran it a second time. checkIP() has no in-flight guard (unlike updateGeo,
		// which returns early when its connection exists), so the second pass replaced the
		// HttpDownload the first had created microseconds earlier, while it was still connecting.
		failVersionDownload(STRING_F(VERSION_PARSING_FAILED, e.getError()), aManualCheck);
		return;
	}

	checkAdditionalUpdates(aManualCheck);
}

void UpdateManager::failVersionDownload(const string& aError, bool manualCheck) {
	auto msg = STRING_F(VERSION_CHECK_FAILED, aError);

	if (manualCheck) {
		log(msg, LogMessage::SEV_ERROR);
		fire(UpdateManagerListener::UpdateFailed(), msg);
	} else {
		log(msg, LogMessage::SEV_WARNING);
	}

	checkAdditionalUpdates(manualCheck);
}

void UpdateManager::checkAdditionalUpdates(bool manualCheck) {
	//v4
	if(!manualCheck && SETTING(IP_UPDATE) && !SETTING(AUTO_DETECT_CONNECTION) && SETTING(INCOMING_CONNECTIONS) != SettingsManager::INCOMING_DISABLED) {
		checkIP(false, false);
	}

	//v6
	if(!manualCheck && SETTING(IP_UPDATE6) && !SETTING(AUTO_DETECT_CONNECTION6) && SETTING(INCOMING_CONNECTIONS6) != SettingsManager::INCOMING_DISABLED) {
		checkIP(false, true);
	}

	checkLanguage();

	if(SETTING(GET_USER_COUNTRY)) {
		checkGeoUpdate();
	}
}

void UpdateManager::checkLanguage() {
	auto curLanguage = Localization::getCurrentLanguage();
	if (!curLanguage || curLanguage->isDefault() || links.language.empty()) {
		fire(UpdateManagerListener::LanguageFinished());
		return;
	}

	ParamMap params;
	params["locale"] = curLanguage->getLocale();

	// Same hardening as the manifest and signature fetches: an OS-trusted certificate chain plus a
	// bounded body. Without options the HttpOptions defaults apply, which are allowUntrusted = true
	// and maxBodySize = -1.
	startConnection(CONN_LANGUAGE_CHECK,
		Util::formatParams(links.language, params),
		[this] { completeLanguageCheck(); },
		getUpdateHttpOptions(LANGUAGE_CHECK_MAX_BODY)
	);
}

void UpdateManager::completeLanguageCheck() {
	// Taken out of the array under the lock and owned locally for the rest of this function.
	// The slot is written by whichever thread starts the next check and cleared here on the
	// socket thread, so holding a reference into the array had those two racing over the same
	// unique_ptr. Destroying it when this scope ends is the moment the ScopedFunctor used to.
	auto conn = takeConnection(CONN_LANGUAGE_CHECK);
	if (!conn) { return; }

	if(!conn->buf.empty()) {
		if (Util::toDouble(conn->buf) > Localization::getCurLanguageVersion()) {
			fire(UpdateManagerListener::LanguageDownloading());

			auto url = conn->headers.find("X-File-Location");
			if (url != conn->headers.end()) {
				// The body of this file is written verbatim over the active language file and its
				// contents become UI strings, so the header must point at the same origin the
				// manifest named - otherwise an on-path attacker who can answer the version probe
				// also chooses where we fetch from. links.language is compared unsubstituted on
				// purpose: %[locale] only ever appears in the path, so the origin is already exact.
				if (!isSameOrigin(url->second, links.language)) {
					fire(UpdateManagerListener::LanguageFailed(),
						"The language file location did not match the update host");
					return;
				}

				startConnection(CONN_LANGUAGE_FILE,
					url->second,
					[this] { completeLanguageDownload(); },
					getUpdateHttpOptions(LANGUAGE_FILE_MAX_BODY)
				);
			}
		} else {
			fire(UpdateManagerListener::LanguageFinished());
		}
	} else {
		fire(UpdateManagerListener::LanguageFailed(), conn->status);
	}
}

void UpdateManager::checkVersion(bool aManual) {
	// Postpone the next periodic check even when this one is skipped below: an update
	// download can take a while and re-entering every minute would achieve nothing.
	lastVersionCheck = GET_TICK();

	// Download the detached signature first; completeSignatureDownload() chains
	// to the version.xml download, which is verified against the embedded FulDC++
	// public key (pubkey.h) before it can trigger an update. Only guard against a
	// version check / update already in progress -- NOT the auxiliary services
	// (GeoIP/IP/language), which run continuously and would otherwise silently
	// block every version check (matches upstream UpdateManager::checkVersion).
	if (conns[CONN_SIGNATURE] || conns[CONN_VERSION] || updater->isUpdating()) {
		if (aManual) {
			fire(UpdateManagerListener::UpdateFailed(), STRING(ALREADY_UPDATING));
		}
		return;
	}

	versionSig.clear();

	startConnection(CONN_SIGNATURE,
		getVersionUrl() + ".sign",
		[this, aManual] { completeSignatureDownload(aManual); },
		getUpdateHttpOptions(UPDATE_MANIFEST_MAX_BODY)
	);
}

string UpdateManager::getVersionUrl() const {
	// The channel follows the build, not a user setting: a beta/nightly build checks its own
	// manifest, everything else checks stable. The old picker let a stable build select beta or
	// nightly, which did nothing useful because those manifests were copies of stable.
	return versionUrl[static_cast<int>(getVersionType())];
}

void UpdateManager::init() {
	updater = make_unique<UpdateDownloader>(this);

	checkVersion(false);
}

} // namespace dcpp
