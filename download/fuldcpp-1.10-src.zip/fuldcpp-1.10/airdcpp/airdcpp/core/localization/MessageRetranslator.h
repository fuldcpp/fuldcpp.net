/*
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_MESSAGE_RETRANSLATOR_H
#define DCPLUSPLUS_DCPP_MESSAGE_RETRANSLATOR_H

#include <airdcpp/core/header/typedefs.h>

namespace dcpp {

// Maps text that was formatted from the PREVIOUS language table back to its string and
// re-resolves it from the current one. Status and log lines are cached as finished text (a
// hub's "Connecting to ..." line, a private chat's "User went online [nick - hub]"), so after a
// runtime language switch the windows that replay their caches would keep showing the old
// language for everything that happened before the switch.
//
// Works purely from the two tables; the producers are untouched. Three shapes are recognised,
// in this order: the whole text is an old string; the whole text is an old string with %N%
// placeholders filled in (the arguments are captured and put back into the new string by
// placeholder number); or the text starts or ends with a multi-word old string followed or
// preceded by something else (the "User went online" + " [nick]" shape). Anything else is left
// alone, and so is a text whose translation did not change.
//
// The caches also hold text a hub sent verbatim, under the same message type as the client's
// own lines. The rules are deliberately conservative so that such a line is only rewritten
// when it IS one of the client's strings: a single word is never treated as a prefix or
// suffix, a placeholder pattern needs a good amount of fixed text, and an old text that
// several strings share is skipped unless they all translate the same way.
//
// Pure text mapping: the caller decides which caches to walk (LanguageUtil in the GUI). Web
// clients showing a cache are not told; they see the new text when they next load it.
class MessageRetranslator {
public:
	// aOldStrings: ResourceManager::snapshotStrings() taken BEFORE applyLanguage; the new
	// strings are read from ResourceManager when the object is built.
	explicit MessageRetranslator(const vector<string>& aOldStrings) noexcept;

	// Rewrites aText_ if it was produced from the old table; returns whether it changed.
	bool apply(string& aText_) const noexcept;
private:
	// "Connecting to %1% ..." -> segments { "Connecting to ", " ..." }, placeholders { 1 }:
	// segment k precedes placeholder k, the last segment follows the last placeholder.
	struct Pattern {
		int id;
		vector<string> segments;
		vector<int> placeholders;
		size_t literalLength;
	};

	struct Affix {
		string text;
		int id;
	};

	bool applyExact(string& aText_) const noexcept;
	bool applyPattern(string& aText_) const noexcept;
	bool applyAffix(string& aText_) const noexcept;

	static bool matchPattern(const string& aText, const Pattern& aPattern, vector<string>& captures_) noexcept;
	static bool parsePlaceholders(const string& aText, Pattern& pattern_) noexcept;
	const string& newString(int aId) const noexcept;

	vector<string> oldStrings;
	unordered_map<string, int> exact;
	vector<Pattern> patterns;	// most fixed text first
	vector<Affix> affixes;		// longest first
};

}

#endif
