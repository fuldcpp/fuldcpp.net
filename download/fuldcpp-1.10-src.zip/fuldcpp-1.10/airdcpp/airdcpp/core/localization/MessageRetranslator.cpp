/*
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/core/localization/MessageRetranslator.h>

#include <airdcpp/core/header/format.h>
#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/util/Util.h>

namespace dcpp {

// A prefix/suffix must be at least this long AND contain a space: single words ("Password",
// "Disconnected") turn up inside text a hub sent and are not evidence of anything.
static constexpr size_t MIN_AFFIX_LENGTH = 8;
// A placeholder pattern needs this much fixed text around its placeholders; "%1% users" would
// otherwise claim any hub line ending in " users".
static constexpr size_t MIN_PATTERN_LITERALS = 10;
// Longer than any status line the client produces; a raw hub line of this size is not one.
static constexpr size_t MAX_TEXT_LENGTH = 2048;

static bool isWordChar(char c) noexcept {
	// Non-ASCII bytes count as letters so a prefix never splits a UTF-8 sequence
	return std::isalnum(static_cast<unsigned char>(c)) || static_cast<unsigned char>(c) >= 0x80;
}

// Splits "a %1% b %2%" into segments { "a ", " b ", "" } and placeholders { 1, 2 }. Returns
// false when there is no placeholder at all.
bool MessageRetranslator::parsePlaceholders(const string& aText, Pattern& pattern_) noexcept {
	pattern_.segments.clear();
	pattern_.placeholders.clear();
	pattern_.literalLength = 0;

	string segment;
	for (size_t i = 0; i < aText.size(); ++i) {
		if (aText[i] == '%') {
			auto end = aText.find('%', i + 1);
			if (end != string::npos && end > i + 1 && std::all_of(aText.begin() + i + 1, aText.begin() + end, [](char c) { return std::isdigit(static_cast<unsigned char>(c)); })) {
				pattern_.segments.push_back(segment);
				pattern_.literalLength += segment.size();
				pattern_.placeholders.push_back(Util::toInt(aText.substr(i + 1, end - i - 1)));
				segment.clear();
				i = end;
				continue;
			}
		}
		segment += aText[i];
	}

	if (pattern_.placeholders.empty()) {
		return false;
	}

	pattern_.segments.push_back(segment);
	pattern_.literalLength += segment.size();
	return true;
}

MessageRetranslator::MessageRetranslator(const vector<string>& aOldStrings) noexcept : oldStrings(aOldStrings) {
	// Which ids share an old text, and whether they still agree after the switch
	unordered_map<string, vector<int>> byText;
	for (int i = 0; i < static_cast<int>(oldStrings.size()) && i < ResourceManager::LAST; ++i) {
		if (!oldStrings[i].empty()) {
			byText[oldStrings[i]].push_back(i);
		}
	}

	for (const auto& [old, ids] : byText) {
		const auto id = ids.front();
		if (old == newString(id)) {
			continue; // nothing to rewrite
		}

		if (ranges::any_of(ids, [&](int aOther) { return newString(aOther) != newString(id); })) {
			continue; // ambiguous: the same old text translates differently depending on the string
		}

		Pattern p;
		p.id = id;
		if (!parsePlaceholders(old, p)) {
			exact.emplace(old, id);
			if (old.size() >= MIN_AFFIX_LENGTH && old.find(' ') != string::npos) {
				affixes.push_back({ old, id });
			}
			continue;
		}

		if (p.literalLength >= MIN_PATTERN_LITERALS) {
			patterns.push_back(std::move(p));
		}
	}

	// Most fixed text first, so the most specific string is tried before a looser one
	stable_sort(affixes.begin(), affixes.end(), [](const Affix& a, const Affix& b) { return a.text.size() > b.text.size(); });
	stable_sort(patterns.begin(), patterns.end(), [](const Pattern& a, const Pattern& b) { return a.literalLength > b.literalLength; });
}

const string& MessageRetranslator::newString(int aId) const noexcept {
	return ResourceManager::getString(static_cast<ResourceManager::Strings>(aId));
}

bool MessageRetranslator::apply(string& aText_) const noexcept {
	if (aText_.empty() || aText_.size() > MAX_TEXT_LENGTH) {
		return false;
	}

	return applyExact(aText_) || applyPattern(aText_) || applyAffix(aText_);
}

bool MessageRetranslator::applyExact(string& aText_) const noexcept {
	auto i = exact.find(aText_);
	if (i == exact.end()) {
		return false;
	}

	aText_ = newString(i->second);
	return true;
}

// Leftmost-shortest matching of the segments in order: the first segment must start the text,
// each following segment is found after the previous capture, the last must end the text.
bool MessageRetranslator::matchPattern(const string& aText, const Pattern& aPattern, vector<string>& captures_) noexcept {
	captures_.clear();

	const auto& segments = aPattern.segments;
	if (aText.compare(0, segments.front().size(), segments.front()) != 0) {
		return false;
	}

	size_t pos = segments.front().size();
	for (size_t k = 1; k < segments.size(); ++k) {
		const auto& segment = segments[k];
		const bool last = k + 1 == segments.size();

		size_t at;
		if (last) {
			if (aText.size() < pos + segment.size()) {
				return false;
			}
			at = aText.size() - segment.size();
			if (aText.compare(at, segment.size(), segment) != 0) {
				return false;
			}
		} else {
			at = aText.find(segment, pos);
			if (at == string::npos) {
				return false;
			}
		}

		captures_.push_back(aText.substr(pos, at - pos));
		pos = at + segment.size();
	}

	return true;
}

bool MessageRetranslator::applyPattern(string& aText_) const noexcept {
	vector<string> captures;
	for (const auto& p : patterns) {
		if (!matchPattern(aText_, p, captures)) {
			continue;
		}

		// The captured arguments go back in by placeholder number: %2% may come before %1% in
		// one language and after it in another.
		int maxPlaceholder = 0;
		for (auto n : p.placeholders) maxPlaceholder = max(maxPlaceholder, n);
		vector<string> args(static_cast<size_t>(maxPlaceholder));
		for (size_t k = 0; k < p.placeholders.size() && k < captures.size(); ++k) {
			auto n = p.placeholders[k];
			if (n >= 1 && args[n - 1].empty()) {
				args[n - 1] = captures[k];
			}
		}

		// dcpp_fmt ignores surplus arguments and renders missing ones empty
		auto fmt = dcpp_fmt(newString(p.id));
		for (const auto& a : args) {
			fmt % a;
		}
		aText_ = fmt.str();
		return true;
	}

	return false;
}

bool MessageRetranslator::applyAffix(string& aText_) const noexcept {
	for (const auto& a : affixes) {
		if (aText_.size() <= a.text.size()) {
			continue;
		}

		if (aText_.compare(0, a.text.size(), a.text) == 0 && !isWordChar(aText_[a.text.size()])) {
			aText_ = newString(a.id) + aText_.substr(a.text.size());
			return true;
		}

		auto tailStart = aText_.size() - a.text.size();
		if (aText_.compare(tailStart, a.text.size(), a.text) == 0 && !isWordChar(aText_[tailStart - 1])) {
			aText_ = aText_.substr(0, tailStart) + newString(a.id);
			return true;
		}
	}

	return false;
}

}
