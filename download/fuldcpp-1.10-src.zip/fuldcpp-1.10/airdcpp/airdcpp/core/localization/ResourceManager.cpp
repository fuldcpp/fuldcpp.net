/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/core/localization/ResourceManager.h>

#include <airdcpp/core/classes/Exception.h>
#include <airdcpp/events/LogManager.h>

#include <airdcpp/core/localization/Localization.h>
#include <airdcpp/core/io/xml/SimpleXML.h>
#include <airdcpp/core/io/File.h>
#include <airdcpp/util/text/Text.h>

namespace dcpp {

#ifdef UNICODE
wstring ResourceManager::wstrings[ResourceManager::LAST];

void ResourceManager::createWide() {
	for (int i = 0; i < LAST; ++i) {
		wstrings[i] = Text::utf8ToWide(strings[i]);
	}
}
#endif

ResourceManager::ResourceManager() {
	// Pin the English defaults now: this constructor runs before any language file can be
	// loaded, so the capture cannot see a partially translated table.
	defaultStrings();
#ifdef UNICODE
	createWide();
#endif
}

const vector<string>& ResourceManager::defaultStrings() noexcept {
	// Captured on first use, which is the constructor above -- loadLanguage/resetToDefault
	// are the only writers of strings[] and both run later.
	static const vector<string> defaults(strings, strings + LAST);
	return defaults;
}

void ResourceManager::resetToDefault() noexcept {
	const auto& defaults = defaultStrings();
	std::copy(defaults.begin(), defaults.end(), strings);
	rtl = false;
#ifdef UNICODE
	createWide();
#endif
}

void ResourceManager::applyLanguage(const string& aFile) {
	if (aFile.empty()) {
		resetToDefault();
	} else {
		loadLanguage(aFile);
	}
}

void ResourceManager::loadLanguage(const string& aFile) {
	// Parsed into locals first and committed in one block at the end: a file that fails
	// half-way (truncated download, hand-edited XML) used to leave strings[] reset to English
	// with the entries read so far applied, and wstrings[] untouched -- a mixture of three
	// languages. Now the tables are either fully replaced or not touched at all, which is
	// what a runtime switch (Settings > General > Language) relies on.
	unordered_map<int, string> translated;
	bool fileRtl = false;

	try {
		File f(Localization::resolveLanguageFile(aFile), File::READ, File::OPEN, File::BUFFER_SEQUENTIAL, false);
		SimpleXML xml;
		xml.fromXML(f.read());

		unordered_map<string, int> h;

		for(int i = 0; i < LAST; ++i) {
			h[names[i]] = i;
		}

		string childName = "String";
		string attribName = "Name";
		if (xml.findChild("Language")) {
			fileRtl = xml.getBoolChildAttrib("RightToLeft");

			xml.stepIn();
			if (xml.findChild("Strings")) {
				xml.stepIn();
			}
		} else {
			xml.resetCurrentChild();
			if (xml.findChild("resources")) {
				xml.stepIn();
				childName = "string";
				attribName = "name";
			} else {
				throw Exception("Invalid format");
			}
		}

		while (xml.findChild(childName)) {
			const auto j = h.find(xml.getChildAttrib(attribName));
			if(j != h.end()) {
				translated[j->second] = xml.getChildData();
			}
		}
	} catch(const Exception& e) {
		// No translated strings in here
		LogManager::getInstance()->message("Failed to load the language file " + aFile + ": " + e.getError(), LogMessage::SEV_ERROR, "Localizations");
		return;
	}

	// Restore the compiled-in English strings before applying the file. The file only carries
	// the keys it translates, so without a reset a second language inherits every string the
	// new file omits from the PREVIOUS one. The setup wizard reaches that with one Back click:
	// pick a fully translated language, go back, pick a partly translated one, and the UI ends
	// up a mixture of the two.
	const auto& defaults = defaultStrings();
	std::copy(defaults.begin(), defaults.end(), strings);

	for (const auto& [index, text] : translated) {
		strings[index] = text;
	}

	rtl = fileRtl;
#ifdef UNICODE
	createWide();
#endif
}

} // namespace dcpp
