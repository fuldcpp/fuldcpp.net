/*
 * Copyright (C) 2011-2024 AirDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */


#include "stdinc.h"

#include <airdcpp/connectivity/ConnectivityManager.h>
#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/protocol/ProtocolCommandManager.h>
#include <airdcpp/events/LogManager.h>
#include <airdcpp/queue/partial_sharing/PartialSharingManager.h>
#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/plugins/PluginManager.h>
#include <airdcpp/search/SearchManager.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/connection/socket/Socket.h>
#include <airdcpp/connection/UDPServer.h>
#include <airdcpp/transfer/upload/upload_bundles/UploadBundleManager.h>


namespace dcpp {

void UDPServer::listen() {
	disconnect();

	try {
		socket.reset(new Socket(Socket::TYPE_UDP));
		socket->setLocalIp4(CONNSETTING(BIND_ADDRESS));
		socket->setLocalIp6(CONNSETTING(BIND_ADDRESS6));
		socket->setV4only(false);
		port = socket->listen(Util::toString(CONNSETTING(UDP_PORT)));
		start();
	} catch(...) {
		socket.reset();
		throw;
	}
}

void UDPServer::disconnect() {
	if(socket.get()) {
		stop = true;
		socket->disconnect();
		port.clear();

		join();

		socket.reset();

		stop = false;
	}
}

UDPServer::UDPServer() : stop(false), pp(true) { }
UDPServer::~UDPServer() { }


void UDPServer::addTask(Callback&& aTask) noexcept {
	pp.addTask(std::move(aTask));
}

constexpr auto BUFSIZE = 8192;
int UDPServer::run() {
	int len;
	string remoteAddr;
	vector<uint8_t> readBuffer(BUFSIZE);

	while(!stop) {
		try {
			if(!socket->wait(400, true, false).first) {
				continue;
			}

			// Read into a reusable stack-side buffer and queue only the bytes that actually arrived.
			// A fresh zero-initialised 8 KB vector per datagram, moved onto an unbounded queue, cost
			// ~8 KB of resident memory for a one-byte packet -- on a port advertised to every hub, with
			// no flood counter in front of it, unlike the TCP accept path.
			string remotePort;
			if((len = socket->read(readBuffer.data(), BUFSIZE, remoteAddr, remotePort)) > 0) {
				auto buf = vector<uint8_t>(readBuffer.begin(), readBuffer.begin() + len);
				pp.addTask([buf = std::move(buf), len, remoteAddr, remotePort, this] { handlePacket(buf, len, remoteAddr, remotePort); });
			}

			// Anything short of an exception is normal and must not tear the socket down. read()
			// returns 0 for a genuinely received ZERO-LENGTH datagram -- for a datagram socket that
			// is a real packet, not the end-of-stream it means for TCP -- and -1 when the wait()
			// above woke spuriously and recvfrom reports EWOULDBLOCK. Both used to fall through to
			// the disconnect/re-listen block below, so anyone who could reach this port could hold
			// the server in a rebind loop with a stream of empty datagrams, dropping every
			// in-flight search result. Only a SocketException gets there now.
			continue;
		} catch(const SocketException& e) {
			dcdebug("SearchManager::run Error: %s\n", e.getError().c_str());
		}

		bool failed = false;
		while(!stop) {
			try {
				socket->disconnect();
				port = socket->listen(Util::toString(CONNSETTING(UDP_PORT)));
				if(failed) {
					LogManager::getInstance()->message("Search enabled again", LogMessage::SEV_INFO, STRING(CONNECTIVITY));
					failed = false;
				}
				break;
			} catch(const SocketException& e) {
				dcdebug("SearchManager::run Stopped listening: %s\n", e.getError().c_str());

				if(!failed) {
					LogManager::getInstance()->message(STRING_F(SEARCH_DISABLED_X, e.getError()), LogMessage::SEV_ERROR, STRING(CONNECTIVITY));
					failed = true;
				}

				// Spin for 60 seconds
				for(auto i = 0; i < 60 && !stop; ++i) {
					Thread::sleep(1000);
				}
			}
		}
	}

	return 0;
}

namespace {

// Recognize packets that are certainly plaintext protocol commands
// (NMDC "$SR" or an ADC UDP command such as "URES") so that they are
// parsed as such without attempting SUDP decryption on them
bool isPlaintextUdpPacket(const string& aData) noexcept {
	if (aData.compare(0, 4, "$SR ") == 0) {
		return true;
	}

	if (aData.length() >= 5 && aData[0] == AdcCommand::TYPE_UDP && aData[4] == ' ') {
		auto isCommandChar = [](char c) { return (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'); };
		return isCommandChar(aData[1]) && isCommandChar(aData[2]) && isCommandChar(aData[3]);
	}

	return false;
}

}

void UDPServer::handlePacket(const ByteVector& aBuf, size_t aLen, const string& aRemoteIp, const string& aRemotePort) {
	string x(aBuf.begin(), aBuf.begin() + aLen);

	//check if this packet has been encrypted
	if (SETTING(ENABLE_SUDP) && aLen >= 32 && ((aLen & 15) == 0) && !isPlaintextUdpPacket(x)) {
		if (!SearchManager::getInstance()->decryptPacket(x, aLen, aBuf)) {
			// Not a recognizable plaintext packet and no search key can decrypt it;
			// don't attempt to parse the (most likely encrypted) data as a protocol command
			dcdebug("UDPServer: discarding an undecryptable packet from %s\n", aRemoteIp.c_str());
			return;
		}
	}

	if (x.empty())
		return;

	// Fire the plugin hook with the decrypted payload, before protocol dispatch.
	if(PluginManager::getInstance()->onUDP(false, aRemoteIp, aRemotePort, x))
		return;

	COMMAND_DEBUG(x, ProtocolCommandManager::TYPE_CLIENT_UDP, ProtocolCommandManager::INCOMING, aRemoteIp);

	if (x.compare(0, 1, "$") == 0) {
		// NMDC commands
		if (x.compare(1, 3, "SR ") == 0) {
			SearchManager::getInstance()->onSR(x, aRemoteIp);
		} else {
			dcdebug("Unknown NMDC command received via UDP: %s\n", x.c_str());
		}
		
		return;
	}

	// ADC commands

	// ADC commands must end with \n
	if (x[x.length() - 1] != 0x0a) {
		dcdebug("Invalid UDP data received: %s (no newline)\n", x.c_str());
		return;
	}

	if (!Text::validateUtf8(x)) {
		dcdebug("UTF-8 validation failed for received UDP data: %s\n", x.c_str());
		return;
	}

	// Dispatch without newline
	dispatch(x.substr(0, x.length() - 1), false, [&aRemoteIp](const AdcCommand& aCmd) {
		ProtocolCommandManager::getInstance()->fire(ProtocolCommandManagerListener::IncomingUDPCommand(), aCmd, aRemoteIp);
	}, aRemoteIp);
}

// Incoming search results are not authenticated to their SENDER, but they are now checked against
// the searches we actually issued.
//
// A result is still attributed purely to the CID inside the packet, and aRemoteIp is carried through
// to SearchResult without being compared against anything -- pinning it to the user's known address
// would drop legitimate results for NAT'd and multi-homed peers, so that remains deliberate.
//
// What used to make this exploitable was that the token was only required to begin with a hub unique
// id resolving to a connected client -- a small sequential integer, guessable in a handful of tries
// -- while the per-search half after the slash was never checked at all. SearchManager now keeps the
// tokens it has issued (see onSearchTokenSent/isKnownSearchToken) and onRES rejects anything else,
// so injecting results attributed to a real user requires guessing a token we actually sent rather
// than just a hub id.
void UDPServer::handle(AdcCommand::RES, AdcCommand& c, const string& aRemoteIp) noexcept {
	if (c.getParameters().empty())
		return;

	string cid = c.getParam(0);
	if (cid.size() != 39)
		return;

	UserPtr user = ClientManager::getInstance()->findUser(CID(cid));
	if (!user)
		return;

	// Remove the CID
	// This should be handled by AdcCommand really...
	c.getParameters().erase(c.getParameters().begin());

	SearchManager::getInstance()->onRES(c, user, aRemoteIp);
}

}