/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_HTTP_UPLOAD_H
#define DCPLUSPLUS_DCPP_HTTP_UPLOAD_H

#include <airdcpp/connection/http/HttpConnection.h>

namespace dcpp {

using std::string;

/*
 * Helper for a single bodied HTTP request (the POST counterpart of
 * HttpDownload). Calls a completion function when finished.
 *
 * The connection is created with isUnique=true, so it deletes itself on the
 * socket thread after firing Complete/Failed - the same ownership model
 * HttpDownload uses. This struct never deletes it. That is deliberate: deleting
 * it from whichever thread destroys this object would race the socket thread,
 * which may still be executing inside HttpConnection::on(...). Neither
 * removeListener nor putSocket closes that window - Speaker::fire releases its
 * lock before invoking callbacks, and putSocket only queues an async shutdown.
 *
 * Consequences the caller must respect:
 *
 *  1. The completion function must NOT destroy this object synchronously. It is
 *     invoked from inside HttpConnection::on(...), which reads its own members
 *     after firing. Marshal to another turn of the message loop first (e.g.
 *     MainFrame::callAsync) and destroy it from there.
 *
 *  2. abort() (and the destructor) detach from the connection so no further
 *     callback arrives, but do not stop bytes already handed to the socket. A
 *     genuine mid-flight cancel is not offered, because it cannot be done safely
 *     against this socket layer.
 *
 * There is no send-side progress reporting: BufferedSocketListener has no
 * BytesSent event and BufferedSocket::threadSendData loops internally, so only
 * "in flight" and "finished" are observable.
 */
struct HttpUpload : private HttpConnectionListener, private boost::noncopyable {
	HttpConnection* c = nullptr;

	string buf;                 // response body (bounded by HttpOptions::maxBodySize)
	string status;              // status/error text as reported by HttpConnection
	int statusCode = 0;         // parsed response code, 0 if never seen
	bool failed = false;        // true when Failed fired rather than Complete
	StringMap headers;

	using CompletionF = std::function<void ()>;
	CompletionF f;

	HttpUpload(const string& aUrl, string&& aBody, const string& aContentType,
		CompletionF&& aF, const HttpOptions& aOptions = HttpOptions());
	~HttpUpload() override;

	// Detach from the connection and tear it down. Idempotent; no completion
	// callback fires afterwards.
	void abort() noexcept;

	// HttpConnectionListener
	void on(HttpConnectionListener::Data, HttpConnection*, const uint8_t* buf_, size_t len) noexcept override;
	void on(HttpConnectionListener::Failed, HttpConnection*, const string& status_) noexcept override;
	void on(HttpConnectionListener::Complete, HttpConnection*, const string& status_) noexcept override;
};

} // namespace dcpp

#endif // !defined(DCPLUSPLUS_DCPP_HTTP_UPLOAD_H)
