/*
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/connection/http/HttpActivityMonitor.h>

#include <airdcpp/connection/http/HttpConnection.h>
#include <airdcpp/core/timer/TimerManager.h>
#include <airdcpp/util/Util.h>

namespace dcpp {

HttpActivityMonitor::~HttpActivityMonitor() {
	// A live transfer here means a connection outlived its owner (see the
	// header); not fatal, but worth catching in a debug build.
	dcassert(items.empty());

	// Detach from anything still alive. Without this an orphaned connection -
	// one whose HttpDownload was destroyed mid-transfer, leaving it to
	// self-delete on its terminal event - would fire into this freed object.
	std::set<HttpConnection*> remaining;
	{
		Lock l(cs);
		remaining.swap(attached);
		items.clear();
	}

	for (auto conn: remaining) {
		conn->removeListener(this);
	}
}

void HttpActivityMonitor::attach(HttpConnection* aConn) noexcept {
	{
		Lock l(cs);
		attached.insert(aConn);
	}

	// Added outside the lock, and last, so a connection that fires immediately
	// cannot re-enter the monitor while it is being registered.
	aConn->addListener(this);
}

HttpActivityMonitor::ActivityInfoList HttpActivityMonitor::getActivity() const noexcept {
	ActivityInfoList ret;

	Lock l(cs);
	ret.reserve(items.size());

	const auto tick = GET_TICK();
	for (const auto& [conn, item]: items) {
		const auto elapsed = tick > item.startTick ? tick - item.startTick : 0;
		ret.push_back({
			item.token,
			item.url,
			item.done,
			item.size,
			item.done * 1000 / static_cast<int64_t>(elapsed == 0 ? 1 : elapsed),
			elapsed,
		});
	}

	return ret;
}

void HttpActivityMonitor::onRequestStarted(HttpConnection* aConn) noexcept {
	string removedToken;
	string token;
	string url;

	{
		Lock l(cs);

		// A non-unique connection being reused for a new logical request while a
		// previous entry is still open shouldn't normally happen (terminal events
		// erase the entry first), but a leftover row must not leak if it does.
		if (auto i = items.find(aConn); i != items.end()) {
			removedToken = i->second.token;
			items.erase(i);
		}

		Item item;
		item.token = "http_" + Util::toString(++tokenCounter);
		item.url = aConn->getCurrentUrl();
		item.startTick = GET_TICK();

		token = item.token;
		url = item.url;
		items.emplace(aConn, std::move(item));
	}

	if (!removedToken.empty()) {
		fire(HttpActivityListener::Removed(), removedToken);
	}

	fire(HttpActivityListener::Added(), token, url);
}

void HttpActivityMonitor::onConnectionDestroyed(HttpConnection* aConn) noexcept {
	aConn->removeListener(this);

	string token;
	{
		Lock l(cs);
		attached.erase(aConn);
		if (auto i = items.find(aConn); i != items.end()) {
			token = i->second.token;
			items.erase(i);
		}
	}

	// An entry that survived until destruction means the transfer was aborted
	// mid-flight (owner reset, shutdown) - it will never complete or fail.
	if (!token.empty()) {
		fire(HttpActivityListener::Removed(), token);
	}
}

void HttpActivityMonitor::on(HttpConnectionListener::Data, HttpConnection* aConn, const uint8_t*, size_t aLen) noexcept {
	string token;
	int64_t done = 0;
	int64_t speed = 0;
	uint64_t elapsed = 0;

	{
		Lock l(cs);
		auto i = items.find(aConn);
		if (i == items.end()) {
			// POST bodies and other untracked traffic
			return;
		}

		auto& item = i->second;

		// The connection adds to its own done counter only after this callback
		// returns, so the running total has to be accumulated here.
		item.done += static_cast<int64_t>(aLen);
		// Kept here so getActivity() never touches the connection off-thread
		item.size = aConn->getSize();

		auto tick = GET_TICK();
		if (item.lastFireTick != 0 && tick - item.lastFireTick < PROGRESS_INTERVAL_MS) {
			return;
		}
		item.lastFireTick = tick;

		token = item.token;
		done = item.done;
		elapsed = tick > item.startTick ? tick - item.startTick : 0;
		speed = done * 1000 / static_cast<int64_t>(elapsed == 0 ? 1 : elapsed);
	}

	fire(HttpActivityListener::Progress(), token, done, aConn->getSize(), speed, elapsed);
}

void HttpActivityMonitor::on(HttpConnectionListener::Redirected, HttpConnection* aConn, const string& aNewUrl) noexcept {
	string token;
	{
		Lock l(cs);
		auto i = items.find(aConn);
		if (i == items.end()) {
			return;
		}

		i->second.url = aNewUrl;
		token = i->second.token;
	}

	fire(HttpActivityListener::UrlChanged(), token, aNewUrl);
}

void HttpActivityMonitor::on(HttpConnectionListener::Complete, HttpConnection* aConn, const string&) noexcept {
	string token;
	int64_t done = 0;
	{
		Lock l(cs);
		auto i = items.find(aConn);
		if (i == items.end()) {
			return;
		}

		token = i->second.token;
		done = i->second.done;
		items.erase(i);
	}

	fire(HttpActivityListener::Completed(), token, done);
}

void HttpActivityMonitor::on(HttpConnectionListener::Failed, HttpConnection* aConn, const string& aError) noexcept {
	string token;
	{
		Lock l(cs);
		auto i = items.find(aConn);
		if (i == items.end()) {
			return;
		}

		token = i->second.token;
		items.erase(i);
	}

	fire(HttpActivityListener::Failed(), token, aError);
}

} // namespace dcpp
