/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*
 * Request-head serialization and status-line parsing, split out of
 * HttpConnection so both are reachable without a socket, a settings singleton
 * or a live server - which is what makes them testable.
 */

#ifndef DCPLUSPLUS_DCPP_HTTP_REQUEST_H
#define DCPLUSPLUS_DCPP_HTTP_REQUEST_H

#include <airdcpp/core/header/typedefs.h>

#include <optional>
#include <string>

namespace dcpp {

namespace http {

using std::string;

struct RequestHead {
	string method;                  // "GET" | "POST"
	string target;                  // origin-form path, or absolute-form when proxied
	string host;                    // Host header value
	string userAgent;
	StringPairList extraHeaders;

	// Entity headers are emitted only when bodyLength is set. A GET must leave
	// it unset: emitting Content-Length: 0 on a bodyless request changes what
	// some servers do with it, and every existing caller here is a GET.
	string contentType;
	std::optional<int64_t> bodyLength;
};

/*
 * Serialize a complete request head, terminating blank line included.
 *
 * Field order is fixed and matters: it is the order HttpConnection emitted
 * before this function existed, so a GET produces a byte-identical request.
 * Do not reorder without re-capturing the golden test vector.
 */
string buildRequestHead(const RequestHead& aHead) noexcept;

/*
 * Status code from an HTTP status line ("HTTP/1.1 404 Not Found" -> 404).
 * Returns 0 when the line is not a well-formed status line.
 *
 * Exists because the legacy check was `aLine.find("200") != npos`, which also
 * matches a 200 appearing anywhere else on the line (e.g. a reason phrase or a
 * date) and cannot distinguish 201/202/204 from a failure.
 */
int parseStatusCode(const string& aStatusLine) noexcept;

} // namespace http

} // namespace dcpp

#endif // DCPLUSPLUS_DCPP_HTTP_REQUEST_H
