/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"

#include <airdcpp/connection/http/HttpRequest.h>

#include <airdcpp/util/Util.h>

namespace dcpp {

namespace http {

string buildRequestHead(const RequestHead& aHead) noexcept {
	string ret;
	// Enough for a request line plus the usual handful of headers; the reserve
	// is a hint, not a bound.
	ret.reserve(256 + aHead.target.size());

	const auto addHeader = [&ret](const string& aKey, const string& aValue) {
		ret += aKey;
		ret += ": ";
		ret += aValue;
		ret += "\r\n";
	};

	ret += aHead.method;
	ret += ' ';
	ret += aHead.target;
	ret += " HTTP/1.1\r\n";

	addHeader("User-Agent", aHead.userAgent);
	addHeader("Host", aHead.host);
	addHeader("Connection", "close"); // we'll only be doing one request

	for (const auto& [name, value] : aHead.extraHeaders) {
		addHeader(name, value);
	}

	// Only for requests that actually carry a body - see RequestHead::bodyLength.
	if (aHead.bodyLength) {
		addHeader("Content-Type", aHead.contentType.empty()
			? "application/octet-stream" : aHead.contentType);
		addHeader("Content-Length", Util::toString(*aHead.bodyLength));
	}

	addHeader("Cache-Control", "no-cache");
	ret += "\r\n";

	return ret;
}

int parseStatusCode(const string& aStatusLine) noexcept {
	// "HTTP/<v> <ddd> <reason>" - require the version prefix and exactly three
	// digits, so a reason phrase or header value containing digits can't be
	// mistaken for a status.
	if (aStatusLine.compare(0, 5, "HTTP/") != 0) return 0;

	const auto sp = aStatusLine.find(' ');
	if (sp == string::npos || aStatusLine.size() < sp + 4) return 0;

	for (size_t i = sp + 1; i < sp + 4; ++i) {
		if (!isdigit(static_cast<unsigned char>(aStatusLine[i]))) return 0;
	}

	// A 4th digit means it isn't a status code at all.
	if (aStatusLine.size() > sp + 4 && isdigit(static_cast<unsigned char>(aStatusLine[sp + 4]))) {
		return 0;
	}

	return Util::toInt(aStatusLine.substr(sp + 1, 3));
}

} // namespace http

} // namespace dcpp
