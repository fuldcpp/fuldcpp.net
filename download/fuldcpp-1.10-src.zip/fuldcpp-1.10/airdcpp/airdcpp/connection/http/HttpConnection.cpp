/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/connection/http/HttpConnection.h>

#include <airdcpp/connection/http/HttpActivityMonitor.h>
#include <airdcpp/connection/http/HttpRequest.h>
#include <airdcpp/connection/socket/BufferedSocket.h>
#include <airdcpp/core/crypto/CryptoManager.h>
#include <airdcpp/util/LinkUtil.h>
#include <airdcpp/util/NetworkUtil.h>
#include <airdcpp/core/header/format.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/util/SystemUtil.h>
#include <airdcpp/core/version.h>

#include <airdcpp/core/localization/ResourceManager.h>
#include <airdcpp/core/header/format.h>

#include <boost/algorithm/string/trim.hpp>

namespace dcpp {

// Redirect budget. See the CONN_MOVED branch.
static const int MAX_REDIRECTS = 5;

// Cap on the response header block. options.getMaxBodySize() only ever covered Content-Length and
// body bytes, both of which arrive AFTER the headers -- so a server that streamed distinct header
// lines and never sent the terminating blank line grew the header map until allocation failed,
// with the caller's carefully chosen body cap never engaging.
static const size_t MAX_HEADERS = 100;
static const size_t MAX_HEADER_BYTES = 64 * 1024;

// Header-name match, rather than "does this line contain the word somewhere".
static bool isHeaderNamed(const string& aLine, const string& aName) noexcept {
	auto separator = aLine.find_first_of(':');
	if (separator == string::npos || separator == 0) {
		return false;
	}

	return Util::stricmp(boost::algorithm::trim_copy(aLine.substr(0, separator)), aName) == 0;
}

static string headerValue(const string& aLine) noexcept {
	auto separator = aLine.find_first_of(':');
	if (separator == string::npos) {
		return Util::emptyString;
	}

	return boost::algorithm::trim_copy(aLine.substr(separator + 1));
}

HttpConnection::HttpConnection(bool aIsUnique, const HttpOptions& aOptions) :
port("80"),
isUnique(aIsUnique),
options(aOptions)
{
	// Registered first so the monitor sees terminal events before any consumer
	// callback can reuse this connection for the next request (hublist failover).
	if (auto monitor = HttpActivityMonitor::getInstance()) {
		monitor->attach(this);
	}
}

HttpConnection::~HttpConnection() {
	if (auto monitor = HttpActivityMonitor::getInstance()) {
		monitor->onConnectionDestroyed(this);
	}

	if (socket) {
		abortRequest(true);
	}
}

/**
 * Downloads a file and returns it as a string
 * @todo Report exceptions
 * @todo Abort download
 * @param aUrl Full URL of file
 * @return A string with the content, or empty if download failed
 */
void HttpConnection::downloadFile(const string& aFile) {
	// A new logical request, so the redirect budget starts over. The redirect path calls
	// followRedirect() instead, which deliberately keeps the count -- resetting it there would make
	// the limit meaningless, and this connection can be reused for several downloads in a row.
	redirectCount = 0;
	currentUrl = aFile;
	originalRequestSecure = Util::strnicmp(currentUrl, "https://", 8) == 0;

	// Announce before prepareRequest: a synchronous connect failure fires
	// Failed from inside it, and the row must exist by then (Added -> Failed).
	if (auto monitor = HttpActivityMonitor::getInstance()) {
		monitor->onRequestStarted(this);
	}

	prepareRequest(TYPE_GET);
}

void HttpConnection::followRedirect(const string& aFile) {
	currentUrl = aFile;
	prepareRequest(TYPE_GET);
}

/**
 * Initiates a basic urlencoded form submission
 * @param aFile Fully qualified file URL
 * @param aData StringMap with the args and values
 */
void HttpConnection::postData(const string& aUrl, const StringMap& aData) {
	currentUrl = aUrl;
	originalRequestSecure = Util::strnicmp(currentUrl, "https://", 8) == 0;
	requestBody.clear();

	// TODO: encodeURI is not the right escaper for form components - it leaves
	// '&' and '=' unescaped, so a value containing either corrupts the body.
	// Left as-is because this overload has no callers; use postBody() instead.
	for (const auto& [name, value] : aData)
		requestBody += "&" + LinkUtil::encodeURI(name) + "=" + LinkUtil::encodeURI(value);

	if (!requestBody.empty()) requestBody = requestBody.substr(1);
	contentType = "application/x-www-form-urlencoded";
	prepareRequest(TYPE_POST);
}

void HttpConnection::postBody(const string& aUrl, string&& aBody, const string& aContentType) {
	currentUrl = aUrl;
	originalRequestSecure = Util::strnicmp(currentUrl, "https://", 8) == 0;
	requestBody = std::move(aBody);
	contentType = aContentType;
	prepareRequest(TYPE_POST);
}

void HttpConnection::prepareRequest(RequestType type) {
	dcassert(Util::findSubString(currentUrl, "http://") == 0 || Util::findSubString(currentUrl, "https://") == 0);
	LinkUtil::sanitizeUrl(currentUrl);

	// Checked HERE, which is where every hop passes: the initial request and, via
	// followRedirect(), each redirect. The caller's own guard can only judge the URL it was
	// handed, so a permitted address answering "302 Location: http://127.0.0.1/" reached exactly
	// the destination that guard exists to refuse -- demonstrated end to end, not theoretical.
	// Opt-in, because ordinary client traffic (hubs, peers, the local web UI) is legitimately
	// on the LAN and must keep working.
	if (options.getPublicDestinationsOnly() && NetworkUtil::isBlockedDestinationUrl(currentUrl)) {
		// State set before the fire, as the failure paths below do: a listener may start the
		// next request from inside this callback.
		connState = CONN_FAILED;
		fire(HttpConnectionListener::Failed(), this, "Destination address is not allowed (" + currentUrl + ")");
		if (isUnique) delete this;
		return;
	}

	size = -1;
	done = 0;
	statusCode = 0;
	headerBytes = 0;
	// Cleared with headerBytes, and for the same reason. Nothing ever emptied this map: the count
	// it holds is what MAX_HEADERS tests, so across a redirect chain the cap measured the union of
	// every hop's header names and a legitimate multi-hop CDN download could trip it. try_emplace
	// also keeps the FIRST value, so getHeaders() returned the 301's headers rather than the final
	// response's -- which is what the file server forwards to the browser and where the update
	// check looks for X-File-Location.
	headers.clear();
	connState = CONN_UNKNOWN;
	connType = type;

	// method selection
	method = (connType == TYPE_POST) ? "POST" : "GET";

	// set download type
	if (currentUrl.size() >= 4 && Util::stricmp(currentUrl.substr(currentUrl.size() - 4).c_str(), ".bz2") == 0) {
		mimeType = "application/x-bzip2";
	}
	else mimeType.clear();

	string proto, fragment;
	if (SETTING(HTTP_PROXY).empty()) {
		LinkUtil::decodeUrl(currentUrl, proto, server, port, file, query, fragment);
		if (file.empty())
			file = "/";
	}
	else {
		LinkUtil::decodeUrl(SETTING(HTTP_PROXY), proto, server, port, file, query, fragment);
		file = currentUrl;
	}

	if (!query.empty())
		file += '?' + query;

	// Two callers' guarantees are checked here, both against currentUrl rather than `proto`, which
	// is the PROXY's scheme when one is configured.
	//
	// requireTLS: the resource itself must be fetched over TLS.
	//
	// allowUntrusted = false through a proxy: asking for a trusted certificate is asking for the
	// transfer to be authenticated, and across a plaintext proxy hop there is no certificate to
	// trust. That requirement was silently dropped, so the GeoIP database, the npm index and the
	// web-UI proxy were fetched with no verification at all the moment a proxy was configured, and
	// nothing said so. It shares requireTLS's message because it has the same cause and remedy.
	if (options.getRequireTLS() || (!options.getAllowUntrusted() && !SETTING(HTTP_PROXY).empty())) {
		// An HTTP proxy is not a tunnel here: the request goes to the proxy in the clear with an
		// absolute-URI GET, so there is no certificate and no encryption whatever the target URL
		// says. A caller that asked for TLS cannot be given it in that configuration, so say so
		// rather than reporting success over a plaintext hop.
		const auto viaProxy = !SETTING(HTTP_PROXY).empty();
		if (viaProxy || Util::strnicmp(currentUrl, "https://", 8) != 0) {
			// State before the fire: a listener may start the next request from inside the
			// callback, and assigning afterwards would clobber its fresh CONN_UNKNOWN.
			connState = CONN_FAILED;
			fire(HttpConnectionListener::Failed(), this, viaProxy ?
				"An encrypted address is required, and an HTTP proxy cannot provide one (" + currentUrl + ")" :
				"An encrypted address is required (" + currentUrl + ")");
			if (isUnique) delete this;
			return;
		}
	}

	if (port.empty())
		port = "80";

	if (!socket)
		socket = BufferedSocket::getSocket(0x0a, options.getV4Only());


	socket->addListener(this);
	try {
		SocketConnectOptions socketOptions(port, (proto == "https"));
		socket->connect(
			AddressInfo(server, AddressInfo::TYPE_URL),
			socketOptions,
			options.getAllowUntrusted(), // false => require an OS-trusted cert (GeoIP DB)
			false,
			// The marker makes verify_callback demand an OS-trusted chain + hostname
			// match for this connection only (hub trust rules are untouched by it)
			options.getAllowUntrusted() ? Util::emptyString : CryptoManager::CA_REQUIRED_MARKER
		);
	}
	catch (const Exception& e) {
		// State before the fire, for the reason spelled out on the status-line failure below: a
		// listener may start the next request from inside this callback, and a later assignment
		// would overwrite that request's fresh CONN_UNKNOWN.
		connState = CONN_FAILED;
		fire(HttpConnectionListener::Failed(), this, e.getError() + " (" + currentUrl + ")");
		if (isUnique) delete this;
	}
}

void HttpConnection::abortRequest(bool disconnect) {
	dcassert(socket);

	socket->removeListener(this);
	if (disconnect) socket->disconnect();

	BufferedSocket::putSocket(socket);
	socket = nullptr;
}

void HttpConnection::on(BufferedSocketListener::Connected) noexcept {
	dcassert(socket);

	string sRemoteServer = server;
	if(!SETTING(HTTP_PROXY).empty())
	{
		string tfile, tport, proto, queryTmp, fragment;
		LinkUtil::decodeUrl(file, proto, sRemoteServer, tport, tfile, queryTmp, fragment);
	}

	http::RequestHead head;
	// Previously hardcoded to "GET", which silently turned every POST into a
	// bodyless GET regardless of what prepareRequest() had selected.
	head.method = method;
	head.target = file;
	head.host = sRemoteServer;
	head.userAgent = "Fuldcpp/" + VERSIONSTRING + " " + SystemUtil::getOsVersion(true);
	head.extraHeaders = options.getHeaders();
	if (connType == TYPE_POST) {
		head.contentType = contentType;
		head.bodyLength = static_cast<int64_t>(requestBody.size());
	}

	socket->write(http::buildRequestHead(head));

	if (connType == TYPE_POST) {
		socket->write(requestBody);
		// BufferedSocket::write has copied the body into its own write buffer,
		// so releasing our copy here halves peak memory for a multi-MB body.
		// Safe because a POST is never redirected (see on(Line)) and there is
		// no internal retry that would need the body a second time.
		requestBody.clear();
		requestBody.shrink_to_fit();
	}
}

void HttpConnection::on(BufferedSocketListener::Line, const string& aLine) noexcept {
	if(connState == CONN_CHUNKED && aLine.size() > 1) {
		string::size_type i;
		string chunkSizeStr;
		if((i = aLine.find(';')) == string::npos) {
			chunkSizeStr = aLine.substr(0, aLine.length() - 1);
		} else chunkSizeStr = aLine.substr(0, i);

		// The WHOLE token has to be consumed, not just a prefix. strtoul returns 0 for input with no
		// leading hex digits, and 0 is the terminating-chunk marker -- so corrupt framing mid-stream
		// was delivered to the caller as a SUCCESSFUL, complete download of a truncated body, which
		// is then what went into the hublist cache or was written out as a GeoIP database. Checking
		// only that SOME digits were consumed still accepted "0zz" as a terminating chunk, so the
		// test is that the end pointer reached the terminator.
		char* chunkSizeEnd = nullptr;
		unsigned long chunkSize = strtoul(chunkSizeStr.c_str(), &chunkSizeEnd, 16);
		if(chunkSizeEnd == chunkSizeStr.c_str() || *chunkSizeEnd != '\0') {
			chunkSize = ULONG_MAX; // treat as the transfer-encoding error it is
		}

		// A length above INT64_MAX is a framing error, not a body. setDataMode clamps a negative to
		// the "read until close" sentinel, so this does not crash the way the Content-Length path
		// once did -- but without the check the transfer silently became an unbounded read instead
		// of the error it is.
		if(chunkSize > static_cast<unsigned long>(numeric_limits<int64_t>::max())) {
			chunkSize = ULONG_MAX;
		}

		if(chunkSize == 0 || chunkSize == ULONG_MAX) {
			abortRequest(true);

			if(chunkSize == 0) {
				fire(HttpConnectionListener::Complete(), this, currentUrl);
				connState = CONN_OK;
			} else {
				fire(HttpConnectionListener::Failed(), this, "Transfer-encoding error (" + currentUrl + ")");
				connState = CONN_FAILED;
			}

			if (isUnique) { delete this; return; }
		} else socket->setDataMode(chunkSize);
	} else if(connState == CONN_UNKNOWN) {
		statusCode = http::parseStatusCode(aLine);

		// GET keeps the legacy substring test verbatim - every existing caller
		// depends on its exact behaviour. Non-GET gets a real 2xx check, so a
		// collector answering 201/202 isn't reported as a failure.
		const bool ok = (connType == TYPE_GET)
			? (aLine.find("200") != string::npos)
			: (statusCode >= 200 && statusCode < 300);

		if(ok) {
			connState = CONN_OK;
		} else if(connType == TYPE_GET &&
				(aLine.find("301") != string::npos || aLine.find("302") != string::npos)) {
			// Redirects are followed for GET only: the CONN_MOVED handler below
			// re-issues via downloadFile(), which would turn a POST into a GET
			// and silently drop the body. Failing loudly is the correct
			// outcome - re-sending a payload to a host the caller never
			// approved is worse than not sending it at all.
			connState = CONN_MOVED;
		} else {
			abortRequest(true);
		
			auto error = aLine;
			if (error.length() > 1 && error.back() == '\r') {
				error.pop_back(); // These would cause issues in HTTP messages
			}

			// Set the state BEFORE firing. A listener is free to start the next request
			// from inside this callback -- HublistManager's failover does exactly that --
			// and that nested downloadFile() runs prepareRequest(), which sets
			// connState = CONN_UNKNOWN for the NEW request. Assigning CONN_FAILED after
			// the fire then overwrote the new request's fresh state, so its status line
			// skipped the CONN_UNKNOWN branch entirely: no 200 check, no 301/302 handling,
			// and a 404 / 500 / captive-portal body was parsed as a hublist and written to
			// the on-disk cache. The socket-failure path below already orders it this way.
			connState = CONN_FAILED;

			fire(HttpConnectionListener::Failed(), this, str(boost::format("%1% (%2%)") % error % currentUrl));
			if (isUnique) { delete this; return; }
		}
	} else if(connState == CONN_MOVED && isHeaderNamed(aLine, "Location")) {
		abortRequest(true);

		// Matched as a HEADER NAME and read after the colon. Testing for "Location" anywhere in the
		// line matched a Content-Location, or a cookie whose value contained the word, and the fixed
		// offset 10 dropped the first character when no space followed the colon -- the resulting
		// garbage was then glued onto the base URL and resolved as a host name.
		string location = headerValue(aLine);
		LinkUtil::sanitizeUrl(location);

		// make sure we can also handle redirects with relative paths
		bool wasRootRelative = false;
		if(location.find("://") == string::npos) {
			if(!location.empty() && location[0] == '/') {
				wasRootRelative = true;
				//302 doesn't contain the query, use temp one
				string proto, queryTmp, fragment;
				LinkUtil::decodeUrl(currentUrl, proto, server, port, file, queryTmp, fragment);
				string tmp = proto + "://" + server;
				if(port != "80" && port != "443")
					tmp += ':' + port;
				location = tmp + location;
			} else {
				string::size_type i = currentUrl.rfind('/');
				dcassert(i != string::npos);
				location = currentUrl.substr(0, i + 1) + location;
			}
		}

		// Bounded. The only protection was this exact self-redirect test, so an alternating A->B->A
		// chain was followed for ever -- each hop building a fresh socket and thread from inside the
		// previous socket's own thread, never completing and never failing, holding the caller's
		// download slot open the whole time.
		if(++redirectCount > MAX_REDIRECTS) {
			connState = CONN_FAILED;
			fire(HttpConnectionListener::Failed(), this, STRING_F(ENDLESS_REDIRECTION_LOOP, currentUrl));
			if (isUnique) delete this;
			return;
		}

		if(location == currentUrl) {
			connState = CONN_FAILED;
			fire(HttpConnectionListener::Failed(), this, STRING_F(ENDLESS_REDIRECTION_LOOP, currentUrl));
			if (isUnique) delete this;
			return;
		}

		// A request that STARTED encrypted must not be allowed to finish in the clear: following a
		// redirect down to http sends the rest of it, including anything in the URL, as plaintext,
		// with allowUntrusted and any certificate policy silently irrelevant because there is no
		// certificate left to check. Judged on the ORIGINAL request rather than this hop, so a URL
		// the caller gave us as http:// may still pass through https and back.
		//
		// No abortRequest() here: this branch already called it unconditionally at the top, and a
		// second call dereferences the socket it just released -- that is a segfault, demonstrated
		// in the webclient's test/qa suite, not a theoretical concern. The two early returns above
		// get this right.
		//
		// Skipped when an HTTP proxy is configured, because the socket went to the proxy in the
		// clear anyway, so "this request is encrypted" was never true and refusing would protect
		// nothing while breaking proxied URLs that worked before.
		if (originalRequestSecure && SETTING(HTTP_PROXY).empty() &&
			Util::strnicmp(location, "https://", 8) != 0) {
			connState = CONN_FAILED;
			fire(HttpConnectionListener::Failed(), this, "Refusing to follow a redirect from HTTPS to an unencrypted address (" + currentUrl + ")");
			if (isUnique) delete this;
			return;
		}

		// The original query is carried over ONLY for a root-relative redirect, which is the case the
		// comment above describes, and only when the new location has none of its own. Appending it
		// unconditionally produced "/other?y=2?key=X" for an absolute redirect -- a malformed target
		// that servers answer with 400 -- and sent the original query, which for RSS and hublist URLs
		// routinely carries an API key, to a different host entirely.
		if (wasRootRelative && !query.empty() && location.find('?') == string::npos)
			location += "?" + query;
		fire(HttpConnectionListener::Redirected(), this, location);

		followRedirect(location);
	} else if(aLine[0] == 0x0d) {
		// End of the header block.

		// A 301/302 whose headers ended without a Location is not a redirect anyone can follow.
		// Falling through here left connState at CONN_MOVED and then delivered the redirect page
		// itself as a successful Complete, so the caller parsed the "this has moved" HTML as a
		// hublist, a version manifest or a GeoIP database.
		if (connState == CONN_MOVED) {
			abortRequest(true);
			connState = CONN_FAILED;
			fire(HttpConnectionListener::Failed(), this, "Redirect without a Location header (" + currentUrl + ")");
			if (isUnique) delete this;
			return;
		}

		// A response with no body has to complete HERE, because nothing else will complete it.
		// Complete is fired for a non-chunked body only by ModeChange, which BufferedSocket fires
		// from inside its read loop -- and that loop body runs only once at least one byte of body
		// has arrived. Content-Length: 0 therefore produced no completion at all: the peer closed,
		// and the close arrived as Failed. Every zero-length 200 was reported as a failure, and a
		// caller that retries on failure retried it forever.
		//
		// The crash collector documents this from the other side, in a comment telling anyone
		// working on it never to answer 204 or send an empty body, because this client would treat
		// a successful upload as failed and upload it again. That workaround is what a server we
		// control can do; a server we do not control just looks broken.
		//
		// 204 and 304 have no body by definition and send no Content-Length, so they are named
		// rather than waited on. They are reachable only for non-GET requests -- the GET path's
		// legacy substring status test rejects them earlier, and it is deliberately left alone.
		if (size == 0 || statusCode == 204 || statusCode == 304) {
			abortRequest(true);
			// State before the fire, as everywhere else here: a listener may start the next
			// request from inside the callback.
			connState = CONN_OK;
			fire(HttpConnectionListener::Complete(), this, currentUrl);
			if (isUnique) delete this;
			return;
		}

		if(size != -1) {
			socket->setDataMode(size);
		} else connState = CONN_CHUNKED;
	} else if (aLine.length() > 2) {
		// Header
		auto separator = aLine.find_first_of(':');
		if (separator <= 1) {
			return;
		}

		auto name = boost::algorithm::trim_copy(aLine.substr(0, separator));
		auto value = boost::algorithm::trim_copy(aLine.substr(separator + 1));

		headerBytes += aLine.length();
		if (headers.size() >= MAX_HEADERS || headerBytes > MAX_HEADER_BYTES) {
			abortRequest(true);
			connState = CONN_FAILED;
			fire(HttpConnectionListener::Failed(), this, "Too many response headers (" + currentUrl + ")");
			if (isUnique) delete this;
			return;
		}

		if (name == "Content-Length") {
			// toInt64, not toInt: atoi also truncates any legitimate body over 2 GiB.
			size = Util::toInt64(value);

			// Anything negative other than the -1 "unknown length" sentinel must be
			// rejected here. A server answering "Content-Length: -2" otherwise reached
			// setDataMode(-2), and BufferedSocket then passed that negative length to
			// fire(Data) where the listener's size_t parameter turned it into ~2^64:
			// buf.append(ptr, huge) throws length_error out of a noexcept callback, so
			// std::terminate. Neither guard in on(Data) catches it -- both compare the
			// same sign-confused values -- and this path is reachable over plain http
			// by the updater, GeoIP, hublist and plugin-catalog fetches.
			if (size < 0) {
				abortRequest(true);
				connState = CONN_FAILED;
				fire(HttpConnectionListener::Failed(), this, "Invalid Content-Length in response (" + currentUrl + ")");
				if (isUnique) delete this;
				return;
			}

			// Reject oversized bodies up front (before reading them) when a cap is set
			const int64_t maxBody = options.getMaxBodySize();
			if (maxBody >= 0 && size > maxBody) {
				abortRequest(true);
				connState = CONN_FAILED;
				fire(HttpConnectionListener::Failed(), this, "Response body exceeds size cap (" + currentUrl + ")");
				if (isUnique) delete this;
				return;
			}
		} else if (mimeType.empty()) {
			if (name == "Content-Encoding") {
				if (value == "x-bzip2")
					mimeType = "application/x-bzip2";
			} else if (name == "Content-Type") {
				mimeType = value;
			}
		}

		headers.try_emplace(name, value);
	}
}

void HttpConnection::on(BufferedSocketListener::Failed, const string& aLine) noexcept {
	abortRequest(false);

	connState = CONN_FAILED;
	fire(HttpConnectionListener::Failed(), this, str(boost::format("%1% (%2%)") % aLine % currentUrl));
	if (isUnique) delete this;
}

void HttpConnection::on(BufferedSocketListener::ModeChange) noexcept {
	if(connState != CONN_CHUNKED) {
		abortRequest(true);

		fire(HttpConnectionListener::Complete(), this, currentUrl);
		if (isUnique) { delete this; return; }
	}
}
void HttpConnection::on(BufferedSocketListener::Data, uint8_t* aBuf, size_t aLen) noexcept {
	if(size != -1 && static_cast<size_t>(size - done)  < aLen) {
		abortRequest(true);

		connState = CONN_FAILED;
		fire(HttpConnectionListener::Failed(), this, "Too much data in response body (" + currentUrl + ")");
		if (isUnique) delete this;
		return;
	}

	// The Content-Length guard above only bounds responses that declare a length;
	// this also stops chunked / unknown-length bodies from growing without limit.
	const int64_t maxBody = options.getMaxBodySize();
	if (maxBody >= 0 && done + static_cast<int64_t>(aLen) > maxBody) {
		abortRequest(true);

		connState = CONN_FAILED;
		fire(HttpConnectionListener::Failed(), this, "Response body exceeds size cap (" + currentUrl + ")");
		if (isUnique) delete this;
		return;
	}

	fire(HttpConnectionListener::Data(), this, aBuf, aLen);
	done += aLen;
}

} // namespace dcpp
