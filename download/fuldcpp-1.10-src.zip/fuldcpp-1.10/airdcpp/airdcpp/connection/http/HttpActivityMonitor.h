/*
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_HTTP_ACTIVITY_MONITOR_H
#define DCPLUSPLUS_DCPP_HTTP_ACTIVITY_MONITOR_H

#include <airdcpp/connection/http/HttpActivityListener.h>
#include <airdcpp/connection/http/HttpConnectionListener.h>

#include <airdcpp/core/Singleton.h>
#include <airdcpp/core/Speaker.h>
#include <airdcpp/core/thread/CriticalSection.h>
#include <airdcpp/core/header/typedefs.h>

#include <map>
#include <set>

namespace dcpp {

/*
 * Central notifier for the client's own HTTP GET downloads, so the GUI can show
 * them as transfer rows. Every HttpConnection registers the monitor as its
 * first listener at construction; the monitor translates the per-connection
 * HttpConnectionListener events into value-only HttpActivityListener events
 * keyed by a string token, tracking only connections that entered through
 * downloadFile() (POST bodies and uploads stay invisible by design).
 *
 * Shutdown order: connections are expected to be gone before
 * HttpActivityMonitor::deleteInstance(), because all HTTP consumers (RSS,
 * hublists, updater, GeoIP, web server) are destroyed earlier in
 * dcpp::shutdown(). That is not something this class can rely on, though:
 * ~HttpDownload only detaches itself and leaves a unique HttpConnection to
 * self-delete on its terminal event, so an owner destroyed mid-transfer leaves
 * an orphan connection holding the monitor in its listener list. The monitor
 * therefore tracks every connection that registered with it and detaches from
 * whatever is left in its destructor, rather than trusting the ordering.
 *
 * Threading: any method may be called from any thread. The item map is
 * guarded by a CriticalSection; values are copied out and events are fired
 * OUTSIDE the lock. Being the connection's first listener also guarantees
 * that on a failure the terminal event for the old request is fired before a
 * consumer's failover callback (HublistManager) can start the next request
 * on the same connection.
 */
class HttpActivityMonitor : public Singleton<HttpActivityMonitor>,
	public Speaker<HttpActivityListener>,
	public HttpConnectionListener
{
public:
	// Value snapshot of one in-flight transfer. Front-ends that attach after
	// transfers have already started (a web client connecting mid-session) would
	// otherwise only ever learn about them from future events.
	struct ActivityInfo {
		string token;
		string url;
		int64_t done = 0;
		int64_t size = -1;      // -1 while the total is unknown
		int64_t speed = 0;      // bytes/s, averaged over the transfer
		uint64_t elapsedMs = 0;
	};
	using ActivityInfoList = vector<ActivityInfo>;

	// Snapshot of everything currently in flight, safe to call from any thread.
	ActivityInfoList getActivity() const noexcept;

	// Subscribes to aConn's events. Every connection registers itself here at
	// construction, whether or not it ever starts a tracked request, so the
	// monitor can detach from the stragglers when it goes away.
	void attach(HttpConnection* aConn) noexcept;

	// Called by HttpConnection::downloadFile() when a new GET request starts.
	void onRequestStarted(HttpConnection* aConn) noexcept;
	// Called first thing in ~HttpConnection(); detaches the monitor and, if the
	// transfer was still in flight, announces its removal.
	void onConnectionDestroyed(HttpConnection* aConn) noexcept;

	// HttpConnectionListener
	void on(HttpConnectionListener::Data, HttpConnection*, const uint8_t*, size_t) noexcept override;
	void on(HttpConnectionListener::Failed, HttpConnection*, const string&) noexcept override;
	void on(HttpConnectionListener::Complete, HttpConnection*, const string&) noexcept override;
	void on(HttpConnectionListener::Redirected, HttpConnection*, const string&) noexcept override;

private:
	friend class Singleton<HttpActivityMonitor>;
	HttpActivityMonitor() = default;
	~HttpActivityMonitor();

	struct Item {
		string token;
		string url;
		int64_t done = 0;
		// Mirrored from the connection as data arrives, so a snapshot never has to
		// dereference an HttpConnection owned by another thread.
		int64_t size = -1;
		uint64_t startTick = 0;
		uint64_t lastFireTick = 0;
	};

	// Minimum interval between Progress events per transfer, so a fast download
	// doesn't flood the GUI task queue.
	static const uint64_t PROGRESS_INTERVAL_MS = 500;

	mutable CriticalSection cs;
	std::map<const HttpConnection*, Item> items;
	// Every connection currently subscribed to, tracked transfer or not
	std::set<HttpConnection*> attached;
	uint32_t tokenCounter = 0;
};

} // namespace dcpp

#endif // !defined(DCPLUSPLUS_DCPP_HTTP_ACTIVITY_MONITOR_H)
