/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_HTTP_CONNECTION_H
#define DCPLUSPLUS_DCPP_HTTP_CONNECTION_H

#include <airdcpp/connection/socket/BufferedSocketListener.h>
#include <airdcpp/connection/http/HttpConnectionListener.h>

#include <airdcpp/core/types/GetSet.h>
#include <airdcpp/core/Speaker.h>
#include <airdcpp/core/header/typedefs.h>

namespace dcpp {

using std::string;

class HttpOptions {
public:
	IGETSET(bool, isUnique, IsUnique, false);
	IGETSET(bool, v4Only, V4Only, false);
	// When true (the default, preserving legacy behavior) the TLS peer certificate
	// is accepted even if it does not chain to a trusted CA. Set to false for
	// security-relevant downloads (GeoIP DBs) so an on-path attacker can't MITM a
	// forged payload past https:// - those require an OS-trusted certificate chain
	// plus a hostname match (see CA_REQUIRED_MARKER in CryptoManager::verify_callback).
	IGETSET(bool, allowUntrusted, AllowUntrusted, true);
	// Hard cap on the response body in bytes; -1 = unlimited. Aborts the download
	// if Content-Length exceeds it, or mid-stream for chunked/unknown-length
	// responses, so a hostile/misconfigured URL can't OOM us with an unbounded body.
	IGETSET(int64_t, maxBodySize, MaxBodySize, -1);
	// Refuse a URL that is not https at all. allowUntrusted only governs how a certificate is
	// checked; it says nothing when there is no certificate, because whether the socket is
	// encrypted comes solely from the scheme. Set this wherever "require a trusted certificate"
	// was meant to mean "this transfer must be protected".
	IGETSET(bool, requireTLS, RequireTLS, false);
	// Refuse a destination that is loopback/private/link-local, on every hop. Set this for a
	// transfer the CLIENT performs on a remote caller's behalf (the web server's extension
	// download and its address proxy), where the URL is chosen by whoever called in and the
	// reachable-from-here addresses are exactly the ones they must not get at.
	IGETSET(bool, publicDestinationsOnly, PublicDestinationsOnly, false);
	GETSET(StringPairList, headers, Headers);
};


/*
 * NOTE FOR LISTENERS: never delete the HttpConnection from inside a
 * Complete/Failed/Data callback, and never let another thread delete it while
 * one is running. Every fire() site below reads `isUnique` (and sometimes
 * assigns connState) *after* the callback returns, so freeing it there is a
 * use-after-free and, for a unique connection, a double delete. Detach with
 * removeListener() and let a unique connection retire itself; see HttpUpload.
 */
class HttpConnection : private BufferedSocketListener, public Speaker<HttpConnectionListener>, public boost::noncopyable
{
public:
	HttpConnection(bool aIsUnique = false, const HttpOptions& aOptions = HttpOptions());
	virtual ~HttpConnection();

	void downloadFile(const string& aUrl);
	void postData(const string& aUrl, const StringMap& aData);

	// Send aBody verbatim under the given Content-Type. aBody may contain NUL
	// bytes and any other binary content: it is written length-prefixed all the
	// way down to BufferedSocket::write(const char*, size_t).
	//
	// The body is moved in and released as soon as it has been handed to the
	// socket - a multi-MB body is otherwise resident twice (here and in the
	// socket's write buffer) for the duration of the send.
	void postBody(const string& aUrl, string&& aBody, const string& aContentType);

	const string& getCurrentUrl() const { return currentUrl; }
	const string& getMimeType() const { return mimeType; }

	int64_t getSize() const { return size; }
	int64_t getDone() const { return done; }

	// Parsed response status code, 0 until the status line has been seen.
	// Lets a caller tell a permanent rejection from a transient failure
	// instead of pattern-matching the error string.
	int getStatusCode() const noexcept { return statusCode; }

	const StringMap getHeaders() const noexcept { return headers; }
private:
	enum RequestType { TYPE_GET, TYPE_POST, TYPE_UNKNOWN };
	enum ConnectionStates { CONN_UNKNOWN, CONN_OK, CONN_FAILED, CONN_MOVED, CONN_CHUNKED };

	string currentUrl;
	string method;
	string file;
	string server;
	string port;
	string query;

	string requestBody;
	string contentType;

	string mimeType;
	int64_t size = -1;
	int64_t done = 0;
	int statusCode = 0;

	// Redirect hops taken on this connection, and the size of the response header block. Both are
	// bounded in HttpConnection.cpp; neither used to be.
	int redirectCount = 0;

	// Whether the request the CALLER made was https, as opposed to this particular hop. A URL
	// given to us as http:// may legitimately pass through https and back again, and refusing that
	// would break hublists, feeds and proxied URLs nobody asked to protect. What must not happen is
	// a request that started encrypted ending up in the clear. Set by the three entry points, and
	// deliberately not by followRedirect().
	bool originalRequestSecure = false;
	size_t headerBytes = 0;

	ConnectionStates connState = CONN_UNKNOWN;
	RequestType connType = TYPE_UNKNOWN;

	BufferedSocket* socket = nullptr;

	// Like downloadFile, but keeps the redirect count so a chain cannot run for ever.
	void followRedirect(const string& aUrl);

	void prepareRequest(RequestType type);
	void abortRequest(bool disconnect);

	// BufferedSocketListener
	void on(BufferedSocketListener::Connected) noexcept override;
	void on(BufferedSocketListener::Line, const string&) noexcept override;
	void on(BufferedSocketListener::Data, uint8_t*, size_t) noexcept override;
	void on(BufferedSocketListener::ModeChange) noexcept override;
	void on(BufferedSocketListener::Failed, const string&) noexcept override;

	const bool isUnique;
	const HttpOptions options;

	StringMap headers;
};

} // namespace dcpp

#endif // !defined(HTTP_CONNECTION_H)
