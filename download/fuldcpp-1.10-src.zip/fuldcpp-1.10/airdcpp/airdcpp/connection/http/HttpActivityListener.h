/*
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_HTTP_ACTIVITY_LISTENER_H
#define DCPLUSPLUS_DCPP_HTTP_ACTIVITY_LISTENER_H

#include <airdcpp/forward.h>

namespace dcpp {

/*
 * GUI-facing view of the client's own HTTP GET traffic (GeoIP databases,
 * version checks, hublists, RSS feeds), fired by HttpActivityMonitor.
 *
 * Events carry plain values only - never an HttpConnection* - because a unique
 * connection deletes itself right after its terminal callback, so by the time a
 * listener (or a task queued from one) runs, the connection may be gone.
 *
 * Events fire on arbitrary threads: Added on the caller of downloadFile(),
 * everything else on the socket thread. Listeners must marshal to their own
 * thread and must not call back into the HTTP stack synchronously.
 */
class HttpActivityListener {
public:
	virtual ~HttpActivityListener() { }
	template<int I>	struct X { enum { TYPE = I }; };

	typedef X<0> Added;
	typedef X<1> UrlChanged;
	typedef X<2> Progress;
	typedef X<3> Completed;
	typedef X<4> Failed;
	typedef X<5> Removed;

	// A GET request was issued; a transfer row may be created for the token.
	virtual void on(Added, const string& /*aToken*/, const string& /*aUrl*/) noexcept { }
	// A redirect was followed; same token, new URL.
	virtual void on(UrlChanged, const string& /*aToken*/, const string& /*aUrl*/) noexcept { }
	// aSize is -1 when the total is unknown (chunked/no Content-Length);
	// aSpeed is the average over the whole transfer, in bytes/s.
	virtual void on(Progress, const string& /*aToken*/, int64_t /*aDone*/, int64_t /*aSize*/, int64_t /*aSpeed*/, uint64_t /*aElapsedMs*/) noexcept { }
	virtual void on(Completed, const string& /*aToken*/, int64_t /*aDone*/) noexcept { }
	virtual void on(Failed, const string& /*aToken*/, const string& /*aError*/) noexcept { }
	// The connection was destroyed mid-transfer (owner reset, shutdown);
	// the row should be removed rather than kept in a terminal state.
	virtual void on(Removed, const string& /*aToken*/) noexcept { }
};

} // namespace dcpp

#endif // !defined(DCPLUSPLUS_DCPP_HTTP_ACTIVITY_LISTENER_H)
