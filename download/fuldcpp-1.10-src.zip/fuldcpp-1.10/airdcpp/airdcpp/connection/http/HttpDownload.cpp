/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/connection/http/HttpDownload.h>

namespace dcpp {

HttpDownload::HttpDownload(const string& address, CompletionF&& f, const HttpOptions& aOptions) :
	c(new HttpConnection(true, aOptions)), f(std::move(f)), address(address)
{
	c->addListener(this);
}

void HttpDownload::start() noexcept {
	c->downloadFile(address);
}

HttpDownload::~HttpDownload() {
	// NOTE: do NOT delete c here. The HttpConnection is created with isUnique=true and
	// self-deletes after firing Complete/Failed (HttpConnection.cpp). Deleting it here
	// double-frees it (the completion callback can destroy this HttpDownload from within
	// HttpConnection::on, which would then dereference the freed connection).
	if (c) {
		c->removeListener(this);
	}
}

void HttpDownload::on(HttpConnectionListener::Data, HttpConnection*, const uint8_t* buf_, size_t len) noexcept {
	buf.append(reinterpret_cast<const char*>(buf_), len);
}

void HttpDownload::on(HttpConnectionListener::Failed, HttpConnection* aConn, const string& status_) noexcept {
	buf.clear();
	status = status_;

	// The connection deletes itself the moment this returns, and ~Speaker asserts
	// that its listener list is empty - so detach here instead of relying on the
	// completion function destroying us synchronously (it may bail out early).
	aConn->removeListener(this);
	c = nullptr;

	// Last statement: f() may destroy this object.
	f();
}

void HttpDownload::on(HttpConnectionListener::Complete, HttpConnection* aConn, const string& status_) noexcept {
	status = status_;
	headers = aConn->getHeaders();

	// As above: detach before the connection self-deletes, or ~Speaker asserts.
	aConn->removeListener(this);
	c = nullptr;

	// Last statement: f() may destroy this object.
	f();
}

} // namespace dcpp
