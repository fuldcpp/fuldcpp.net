/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"
#include <airdcpp/connection/http/HttpUpload.h>

namespace dcpp {

HttpUpload::HttpUpload(const string& aUrl, string&& aBody, const string& aContentType,
	CompletionF&& aF, const HttpOptions& aOptions) :
	// isUnique=true, exactly as HttpDownload does: the connection self-deletes on
	// the socket thread after firing Complete/Failed. We must NOT own it. Owning
	// it would mean deleting it from whichever thread destroys us, while the
	// socket thread may still be inside HttpConnection::on(...) - a use-after-free
	// that no amount of listener removal closes, because Speaker::fire releases
	// its lock before invoking callbacks and putSocket() never joins the thread.
	c(new HttpConnection(true, aOptions)), f(std::move(aF))
{
	c->addListener(this);
	c->postBody(aUrl, std::move(aBody), aContentType);
}

HttpUpload::~HttpUpload() {
	abort();
}

void HttpUpload::abort() noexcept {
	// Once the connection has completed it has already deleted itself, so the
	// pointer must not be touched again - `c` is cleared in the callbacks below.
	if (!c) return;

	c->removeListener(this);
	c = nullptr;
	// Deliberately not deleted: see the constructor. An abandoned request is
	// cleaned up by the connection itself when its socket completes or fails, and
	// at shutdown the process exits before that matters.
}

void HttpUpload::on(HttpConnectionListener::Data, HttpConnection*, const uint8_t* buf_, size_t len) noexcept {
	buf.append(reinterpret_cast<const char*>(buf_), len);
}

void HttpUpload::on(HttpConnectionListener::Failed, HttpConnection* aConn, const string& status_) noexcept {
	buf.clear();
	status = status_;
	statusCode = aConn ? aConn->getStatusCode() : 0;
	failed = true;

	// The connection deletes itself the moment this returns, and ~Speaker asserts
	// that its listener list is empty - so we must detach HERE, not in our own
	// destructor, which runs later (the completion is marshalled to another
	// thread). Removing from inside fire() is safe: Speaker snapshots the list and
	// releases its lock before invoking callbacks.
	if (aConn) aConn->removeListener(this);
	c = nullptr;

	// Must not destroy this object - see the note in HttpUpload.h.
	f();
}

void HttpUpload::on(HttpConnectionListener::Complete, HttpConnection* aConn, const string& status_) noexcept {
	status = status_;
	statusCode = aConn ? aConn->getStatusCode() : 0;
	failed = false;
	if (aConn) headers = aConn->getHeaders();

	// As above: detach before the connection self-deletes, or ~Speaker asserts.
	if (aConn) aConn->removeListener(this);
	c = nullptr;
	f();
}

} // namespace dcpp
