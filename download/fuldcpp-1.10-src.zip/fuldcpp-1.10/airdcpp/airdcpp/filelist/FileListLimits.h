/*
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_FILE_LIST_LIMITS_H
#define DCPLUSPLUS_DCPP_FILE_LIST_LIMITS_H

#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/util/Util.h>

#include <algorithm>
#include <limits>

namespace dcpp {

/* Single source of truth for the ceiling on a DECOMPRESSED file list.
 *
 * A peer's files.xml.bz2 is parsed through a FilteredInputStream<UnBZFilter>, a pure streaming
 * filter with no ratio or output limit of its own: a few MB of one repeated line on the wire
 * expands to gigabytes of XML, and every <File/> in it becomes a heap-allocated entry plus a TTH
 * lookup into the share. Some ceiling is therefore required -- but a real share with millions of
 * files legitimately produces more than a GiB of XML (which is how the hard-coded 1 GiB constant
 * this replaces ended up rejecting a genuine list), so the ceiling is a setting rather than a
 * constant.
 *
 * Both users of the limit -- DirectoryListing::loadXML and the BZUtil::decodeBZ2 call that serves
 * the extracted files.xml to legacy clients -- resolve it here, so the unit conversion and the
 * clamp cannot drift apart.
 */
class FileListLimits {
public:
	// Effective ceiling in bytes. 0 = unlimited, which is what both SimpleXMLReader::parse and
	// BZUtil::decodeBZ2 take as "no limit".
	static size_t maxBytes() noexcept {
		const auto mib = SETTING(MAX_FILELIST_SIZE);
		if (mib <= 0) {
			return 0;
		}

		const auto bytes = Util::convertSize(static_cast<int64_t>(mib), Util::MB);

		// Clamp to what size_t can represent rather than to a value of our own choosing: on a
		// 32-bit build 4096 MiB and up would truncate, and a truncation to zero reads back as
		// "unlimited" -- the one direction this must never fail in. Anything a 64-bit size_t can
		// hold is passed through, so the default means the same thing on every build.
		if (static_cast<uint64_t>(bytes) > std::numeric_limits<size_t>::max()) {
			return std::numeric_limits<size_t>::max();
		}

		return static_cast<size_t>(bytes);
	}
};

} // namespace dcpp

#endif // DCPLUSPLUS_DCPP_FILE_LIST_LIMITS_H
