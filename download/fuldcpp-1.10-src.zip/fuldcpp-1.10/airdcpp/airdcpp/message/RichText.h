/*
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef DCPLUSPLUS_DCPP_RICH_TEXT_H
#define DCPLUSPLUS_DCPP_RICH_TEXT_H

#include <airdcpp/forward.h>

#include <airdcpp/core/header/typedefs.h>

namespace dcpp {

/* Parser for the ADC RTF0 extension (CommonMark 0.31 plus GFM strikethrough and
 * tables, minus raw HTML and minus non-magnet image targets).
 *
 * The parser flattens markdown into *rendered plain text* plus a list of styling
 * spans. Nothing downstream ever sees markup: the chat renderer only applies
 * character and paragraph formats over ranges, and logging, chat triggers, the
 * highlight scanner and the web UI all get readable text. That is deliberate --
 * the alternative (inserting markup into the control and cutting it back out)
 * is what makes the BBCode path in RichTextBox::FormatBBCodes so delicate.
 *
 * Markdown links do not leave through spans. They leave as MessageHighlight
 * entries whose range covers the visible label and whose text is the
 * destination, which reuses the whole existing link stack: magnet display text,
 * dupe colouring, click-to-download and the right-click menu.
 */

struct RichTextSpan {
	enum Kind : uint8_t {
		// Inline. These may nest in the source; the parser resolves them into
		// non-overlapping runs, so a renderer can apply them in order.
		EMPH,
		STRONG,
		STRIKE,
		CODE_SPAN,
		LINK,

		// Block. Emitted outermost-first over the range they cover.
		PARAGRAPH,
		HEADING,
		BLOCKQUOTE,
		LIST_ITEM,
		CODE_BLOCK,
		TABLE,
		TABLE_HEADER_CELL,
		THEMATIC_BREAK,

		// Synthesized runs the parser wrote into the text itself: list bullets,
		// blockquote markers, the table rule, the thematic-break glyphs. Split
		// out so a renderer can dim them rather than styling them as content.
		BLOCK_MARKER,
	};

	// Offsets are UTF-8 byte offsets into RichTextDocument::text, always on a
	// codepoint boundary. A Windows renderer must convert to UTF-16 units, the
	// way RichTextBox::FormatHighlights already does for highlights.
	size_t start = 0;
	size_t end = 0;
	Kind kind = PARAGRAPH;

	// HEADING: level 1-6. BLOCKQUOTE / LIST_ITEM: nesting depth, 1-based.
	uint8_t level = 0;

	bool operator<(const RichTextSpan& rhs) const noexcept {
		return start != rhs.start ? start < rhs.start : end > rhs.end;
	}
};

using RichTextSpanList = vector<RichTextSpan>;

struct RichTextDocument {
	// Rendered plain text. This becomes ChatMessage::text, so it is the single
	// offset space that spans, highlights and every consumer agree on.
	string text;
	RichTextSpanList spans;

	// A limit was hit; text is a valid prefix rather than the whole message.
	bool truncated = false;

	// The document is more than one plain paragraph, so a renderer should start
	// it on its own line instead of running it on after "<nick> ".
	bool blockLevel = false;

	// At least one construct produced actual formatting. RTF0 says a client
	// SHOULD NOT set RT on a message that carries none.
	bool formatted = false;
};

using RichTextDocumentPtr = shared_ptr<const RichTextDocument>;

class RichTextParser {
public:
	struct Limits {
		size_t maxInputBytes = 16 * 1024;
		size_t maxOutputBytes = 64 * 1024;
		size_t maxBlockDepth = 32;
		size_t maxSpans = 4096;
		// Table cells are buffered until the table closes, so they do not grow the
		// output the other limits watch. md4c also pads every body row out to the
		// header's column count, which turns a couple of bytes per row into a whole
		// row of cells - a 16 KB message can otherwise buffer millions of them.
		size_t maxTableCells = 4096;
	};

	struct Result {
		RichTextDocument doc;

		// One entry per markdown link or image with a permitted destination.
		// Ranges refer to doc.text and are already sorted by start offset.
		MessageHighlightList links;
	};

	/* Parse ADC-unescaped UTF-8 markdown.
	 *
	 * Never throws and never lets an exception cross md4c's C frames: this runs
	 * on the hub socket thread inside a noexcept constructor, where one crafted
	 * message would otherwise take the client down for everyone in the hub (see
	 * the note above MessageHighlight::parseReleaseHighlights).
	 *
	 * nullopt means the caller must show the original text literally.
	 *
	 * Two overloads rather than "const Limits& = Limits()": a default argument that
	 * value-initialises a nested class needs that class's default member initializers,
	 * which are not available until the enclosing class is complete. MSVC accepts it
	 * anyway; GCC and Clang reject it, as the standard requires. */
	static optional<Result> parse(const string& aMarkdown, const Limits& aLimits) noexcept;
	static optional<Result> parse(const string& aMarkdown) noexcept;

	/* Bounds for SETTING(RICH_TEXT_MAX_SIZE) (KiB). Shared with the settings page's
	 * spinner range so the UI can never advertise values the clamp below rewrites. */
	static constexpr int MAX_INPUT_KIB_MIN = 1;
	static constexpr int MAX_INPUT_KIB_MAX = 256;

	/* Limits with maxInputBytes driven by SETTING(RICH_TEXT_MAX_SIZE) (KiB), hard-clamped
	 * to the bounds above so a corrupt or hostile settings file cannot open a parse-cost
	 * hole. maxOutputBytes scales at 4x input (floored at its default) so raising the
	 * input limit does not silently fail on output; the structural limits stay at their
	 * defaults. Requires a live SettingsManager - the parse(aMarkdown) overload keeps
	 * working without one (fixed defaults, e.g. in the test binary). */
	static Limits limitsFromSettings() noexcept;

	/* Whether a link destination may become actionable.
	 *
	 * RTF0 permits exactly http, https, adc, adcs, dchub and magnet. Everything
	 * else renders as the literal text it is. This deliberately does not reuse
	 * the GUI's UrlPolicy: that accepts ftp, mailto and bare hosts, and it
	 * promotes bare hosts to http://, which the spec forbids ("MUST NOT
	 * normalise or rewrite an unrecognised scheme into a recognised one"). */
	static bool isPermittedLinkTarget(const string& aTarget) noexcept;

	/* Escape a string so CommonMark renders it literally, for use as a link label. */
	static string escapeLabel(const string& aText) noexcept;

	/* Whether a local file is worth marking as inline media when attaching it.
	 *
	 * Sending side only. A receiver MUST NOT infer media from a name or an extension -
	 * only the sender's explicit '!' marks it - so this must never be consulted while
	 * rendering. The list is what GDI+ actually decodes, so a marked file is one the
	 * renderer has a chance of displaying. */
	static bool isInlineMediaFile(const string& aPath) noexcept;
};

} // namespace dcpp

#endif // !defined(DCPLUSPLUS_DCPP_RICH_TEXT_H)
