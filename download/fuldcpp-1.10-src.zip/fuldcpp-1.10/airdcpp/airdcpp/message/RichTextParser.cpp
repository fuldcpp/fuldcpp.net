/*
 * Copyright (C) 2026 FulDC++ Project
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"

#include <airdcpp/message/RichText.h>

#include <airdcpp/core/classes/Magnet.h>
#include <airdcpp/message/MessageHighlight.h>
#include <airdcpp/settings/SettingsManager.h>
#include <airdcpp/util/PathUtil.h>
#include <airdcpp/util/Util.h>
#include <airdcpp/util/text/Text.h>

#include <md4c.h>

#include <algorithm>
#include <cctype>

namespace dcpp {

namespace {

// Rendered stand-ins for constructs whose markers cannot survive as markup.
const char* const BULLETS[] = { "\xE2\x80\xA2 ", "\xE2\x97\xA6 ", "\xE2\x96\xAA " }; // • ◦ ▪
const string QUOTE_MARKER = "> ";
const string TABLE_SEPARATOR = " \xE2\x94\x82 ";                                    // │
const string TABLE_RULE_JOINT = "\xE2\x94\x80\xE2\x94\xBC\xE2\x94\x80";             // ─┼─
const string TABLE_RULE_UNIT = "\xE2\x94\x80";                                      // ─
const size_t THEMATIC_BREAK_WIDTH = 48;

bool isContinuationByte(char c) noexcept {
	return (static_cast<unsigned char>(c) & 0xC0) == 0x80;
}

// Codepoint count, used to align table columns. Not display width -- a wide CJK
// glyph still counts as one -- but byte length would be far worse.
size_t codepointLength(const string& aText) noexcept {
	size_t ret = 0;
	for (const auto c: aText) {
		if (!isContinuationByte(c)) {
			ret++;
		}
	}
	return ret;
}

string lowerAscii(const string& aText) noexcept {
	string ret = aText;
	std::transform(ret.begin(), ret.end(), ret.begin(), [](char c) {
		return static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
	});
	return ret;
}

void appendCodepoint(string& out_, uint32_t aCodepoint) noexcept {
	if (aCodepoint == 0 || aCodepoint > 0x10FFFF || (aCodepoint >= 0xD800 && aCodepoint <= 0xDFFF)) {
		aCodepoint = 0xFFFD;
	}

	if (aCodepoint < 0x80) {
		out_ += static_cast<char>(aCodepoint);
	} else if (aCodepoint < 0x800) {
		out_ += static_cast<char>(0xC0 | (aCodepoint >> 6));
		out_ += static_cast<char>(0x80 | (aCodepoint & 0x3F));
	} else if (aCodepoint < 0x10000) {
		out_ += static_cast<char>(0xE0 | (aCodepoint >> 12));
		out_ += static_cast<char>(0x80 | ((aCodepoint >> 6) & 0x3F));
		out_ += static_cast<char>(0x80 | (aCodepoint & 0x3F));
	} else {
		out_ += static_cast<char>(0xF0 | (aCodepoint >> 18));
		out_ += static_cast<char>(0x80 | ((aCodepoint >> 12) & 0x3F));
		out_ += static_cast<char>(0x80 | ((aCodepoint >> 6) & 0x3F));
		out_ += static_cast<char>(0x80 | (aCodepoint & 0x3F));
	}
}

/* Character references.
 *
 * md4c hands entities through untouched and leaves resolution to the renderer;
 * its own HTML renderer links a generated 2000-entry HTML5 table that is not
 * part of the parser library we link. Numeric references are resolved in full,
 * plus the named ones that actually occur in chat. An unresolved reference is
 * emitted verbatim, which is also what CommonMark does with an invalid one. */
bool decodeEntity(const string& aEntity, string& out_) noexcept {
	if (aEntity.size() < 3 || aEntity.front() != '&' || aEntity.back() != ';') {
		return false;
	}

	const auto body = aEntity.substr(1, aEntity.size() - 2);
	if (body.size() > 1 && body[0] == '#') {
		const auto hex = body[1] == 'x' || body[1] == 'X';
		const auto digits = body.substr(hex ? 2 : 1);
		if (digits.empty() || digits.size() > 8) {
			return false;
		}

		uint32_t value = 0;
		for (const auto c: digits) {
			const auto uc = static_cast<unsigned char>(c);
			int digit;
			if (uc >= '0' && uc <= '9') {
				digit = uc - '0';
			} else if (hex && uc >= 'a' && uc <= 'f') {
				digit = uc - 'a' + 10;
			} else if (hex && uc >= 'A' && uc <= 'F') {
				digit = uc - 'A' + 10;
			} else {
				return false;
			}
			value = value * (hex ? 16 : 10) + static_cast<uint32_t>(digit);
		}

		appendCodepoint(out_, value);
		return true;
	}

	static const struct { const char* name; uint32_t codepoint; } named[] = {
		{ "amp", '&' }, { "lt", '<' }, { "gt", '>' }, { "quot", '"' }, { "apos", '\'' },
		{ "nbsp", 0x00A0 }, { "copy", 0x00A9 }, { "reg", 0x00AE }, { "trade", 0x2122 },
		{ "hellip", 0x2026 }, { "mdash", 0x2014 }, { "ndash", 0x2013 },
		{ "lsquo", 0x2018 }, { "rsquo", 0x2019 }, { "ldquo", 0x201C }, { "rdquo", 0x201D },
		{ "deg", 0x00B0 }, { "plusmn", 0x00B1 }, { "times", 0x00D7 }, { "divide", 0x00F7 },
		{ "euro", 0x20AC }, { "pound", 0x00A3 }, { "yen", 0x00A5 }, { "cent", 0x00A2 },
		{ "bull", 0x2022 }, { "dagger", 0x2020 }, { "sect", 0x00A7 }, { "para", 0x00B6 },
	};

	for (const auto& entry: named) {
		if (body == entry.name) {
			appendCodepoint(out_, entry.codepoint);
			return true;
		}
	}

	return false;
}

bool hasAuthority(const string& aUrl, size_t aColon) noexcept {
	// scheme://host -- the host must not be empty. RTF0: "A URL whose scheme
	// requires an authority component and whose host is empty" is not a link.
	if (aUrl.size() < aColon + 4 || aUrl.compare(aColon + 1, 2, "//") != 0) {
		return false;
	}

	const auto hostStart = aColon + 3;
	const auto hostEnd = aUrl.find_first_of("/?#", hostStart);
	const auto host = aUrl.substr(hostStart, hostEnd == string::npos ? string::npos : hostEnd - hostStart);
	return !host.empty();
}

struct Renderer {
	explicit Renderer(const RichTextParser::Limits& aLimits) noexcept : limits(aLimits) {}

	const RichTextParser::Limits& limits;
	RichTextParser::Result result;

	string out;
	RichTextSpanList spans;

	size_t depth = 0;
	size_t topLevelBlocks = 0;
	bool nonParagraphBlock = false;
	bool truncated = false;

	struct OpenSpan {
		size_t start;
		RichTextSpan::Kind kind;
		uint8_t level;
	};
	vector<OpenSpan> openSpans;

	struct ListState {
		bool ordered = false;
		unsigned next = 1;
		bool tight = true;
	};
	vector<ListState> lists;
	size_t quoteDepth = 0;
	bool pendingItemMarker = false;

	// A list item has just written its bullet, so the paragraph that may follow must
	// not open a new line. In a *tight* list md4c emits no MD_BLOCK_P at all, which is
	// why the bullet is written from MD_BLOCK_LI rather than from the paragraph.
	bool atItemStart = false;

	struct LinkState {
		bool permitted = false;
		bool image = false;
		string href;
		size_t labelStart = 0;
	};
	vector<LinkState> linkStack;

	// Table cells are buffered so columns can be padded once the widths are
	// known; spans inside a cell are collected relative to the cell and
	// translated when the table is flushed.
	struct Cell {
		string text;
		RichTextSpanList spans;
		// Links found in this cell, with cell-relative ranges. Translated on flush the
		// same way the spans are - a link's range lives in MessageHighlight rather than
		// in a span, so it needs re-anchoring separately.
		struct PendingLink {
			size_t start, end;
			LinkState link;
		};
		vector<PendingLink> links;
		bool header = false;
	};
	bool inTable = false;
	// Cells buffered so far, across every table in the message
	size_t tableCells = 0;
	size_t tableStart = 0;
	vector<vector<Cell>> tableRows;
	Cell* activeCell = nullptr;

	string* sink = nullptr;
	RichTextSpanList* spanSink = nullptr;

	void bindMainSink() noexcept {
		sink = &out;
		spanSink = &spans;
	}

	bool overflowed() const noexcept {
		// tableCells counts too: while a cell sink is bound, out doesn't grow, so
		// without it a table could buffer without ever tripping a limit.
		return out.size() >= limits.maxOutputBytes || spans.size() >= limits.maxSpans ||
			tableCells >= limits.maxTableCells;
	}

	void append(const char* aText, size_t aSize) {
		if (overflowed()) {
			truncated = true;
			return;
		}

		auto size = aSize;
		if (sink == &out && out.size() + size > limits.maxOutputBytes) {
			size = limits.maxOutputBytes - out.size();
			// Do not split a codepoint.
			while (size > 0 && isContinuationByte(aText[size])) {
				size--;
			}
			truncated = true;
		}

		sink->append(aText, size);
	}

	void append(const string& aText) {
		append(aText.data(), aText.size());
	}

	size_t offset() const noexcept {
		return sink->size();
	}

	void addSpan(size_t aStart, size_t aEnd, RichTextSpan::Kind aKind, uint8_t aLevel = 0) {
		if (aEnd <= aStart || spanSink->size() >= limits.maxSpans) {
			if (spanSink->size() >= limits.maxSpans) {
				truncated = true;
			}
			return;
		}

		spanSink->push_back(RichTextSpan{ aStart, aEnd, aKind, aLevel });
		if (aKind != RichTextSpan::PARAGRAPH) {
			result.doc.formatted = true;
		}
	}

	// The prefix every continuation line inside the current blocks must repeat.
	string linePrefix() const {
		string ret;
		for (size_t i = 0; i < quoteDepth; ++i) {
			ret += QUOTE_MARKER;
		}
		ret.append(lists.size() * 2, ' ');
		return ret;
	}

	void writePrefix() {
		const auto prefix = linePrefix();
		if (prefix.empty()) {
			return;
		}

		const auto start = offset();
		append(prefix);
		addSpan(start, offset(), RichTextSpan::BLOCK_MARKER);
	}

	// Start a new line inside the current block context.
	void newline() {
		append("\n", 1);
		writePrefix();
	}

	// Ensure we are at the start of a fresh line before opening a new block. Any block
	// that does this has left the bullet's line, so the item-start suppression lapses.
	void blockBreak() {
		atItemStart = false;

		if (sink->empty()) {
			writePrefix();
			return;
		}

		if (sink->back() != '\n') {
			append("\n", 1);
		}
		writePrefix();
	}

	void writeItemMarker() {
		if (!pendingItemMarker || lists.empty()) {
			return;
		}
		pendingItemMarker = false;

		auto& list = lists.back();
		const auto start = offset();
		if (list.ordered) {
			// RTF0: "A receiver MUST take the first item's number as the number
			// to count from" -- hence next, seeded from MD_BLOCK_OL_DETAIL.
			append(Util::toString(list.next) + ". ");
			list.next++;
		} else {
			const auto index = std::min<size_t>(lists.size(), sizeof(BULLETS) / sizeof(BULLETS[0])) - 1;
			append(string(BULLETS[index]));
		}

		addSpan(start, offset(), RichTextSpan::BLOCK_MARKER);
	}

	void flushTable() {
		if (tableRows.empty()) {
			return;
		}

		size_t columns = 0;
		for (const auto& row: tableRows) {
			columns = std::max(columns, row.size());
		}

		vector<size_t> widths(columns, 0);
		for (const auto& row: tableRows) {
			for (size_t i = 0; i < row.size(); ++i) {
				widths[i] = std::max(widths[i], codepointLength(row[i].text));
			}
		}

		bool ruleWritten = false;
		for (const auto& row: tableRows) {
			blockBreak();

			for (size_t i = 0; i < columns; ++i) {
				if (i > 0) {
					const auto sepStart = offset();
					append(TABLE_SEPARATOR);
					addSpan(sepStart, offset(), RichTextSpan::BLOCK_MARKER);
				}

				const auto cellStart = offset();
				if (i < row.size()) {
					append(row[i].text);
					// Re-anchor the cell's own spans now that its text has a home.
					for (const auto& span: row[i].spans) {
						addSpan(cellStart + span.start, cellStart + span.end, span.kind, span.level);
					}
					// Same for its links, which carry their range in the highlight.
					for (const auto& pending: row[i].links) {
						emitLink(pending.link, cellStart + pending.start, cellStart + pending.end);
					}
					if (row[i].header) {
						addSpan(cellStart, offset(), RichTextSpan::TABLE_HEADER_CELL);
					}
				}

				const auto written = codepointLength(sink->substr(cellStart));
				if (written < widths[i] && i + 1 < columns) {
					append(string(widths[i] - written, ' '));
				}
			}

			if (!ruleWritten && !row.empty() && row.front().header) {
				ruleWritten = true;
				blockBreak();
				const auto ruleStart = offset();
				for (size_t i = 0; i < columns; ++i) {
					if (i > 0) {
						append(TABLE_RULE_JOINT);
					}
					for (size_t j = 0; j < widths[i]; ++j) {
						append(TABLE_RULE_UNIT);
					}
				}
				addSpan(ruleStart, offset(), RichTextSpan::BLOCK_MARKER);
			}
		}

		addSpan(tableStart, offset(), RichTextSpan::TABLE);
		tableRows.clear();
	}

	int enterBlock(MD_BLOCKTYPE aType, void* aDetail) {
		if (++depth > limits.maxBlockDepth) {
			return 1;
		}
		if (depth == 2) {
			topLevelBlocks++;
		}

		switch (aType) {
			case MD_BLOCK_DOC:
				bindMainSink();
				break;

			case MD_BLOCK_QUOTE:
				nonParagraphBlock = true;
				quoteDepth++;
				openSpans.push_back({ offset(), RichTextSpan::BLOCKQUOTE, static_cast<uint8_t>(quoteDepth) });
				break;

			case MD_BLOCK_UL:
			case MD_BLOCK_OL: {
				nonParagraphBlock = true;
				ListState state;
				state.ordered = aType == MD_BLOCK_OL;
				if (state.ordered && aDetail) {
					const auto detail = static_cast<MD_BLOCK_OL_DETAIL*>(aDetail);
					state.next = detail->start;
					state.tight = detail->is_tight != 0;
				} else if (aDetail) {
					state.tight = static_cast<MD_BLOCK_UL_DETAIL*>(aDetail)->is_tight != 0;
				}
				lists.push_back(state);
				break;
			}

			case MD_BLOCK_LI:
				blockBreak();
				openSpans.push_back({ offset(), RichTextSpan::LIST_ITEM, static_cast<uint8_t>(lists.size()) });
				pendingItemMarker = true;
				writeItemMarker();
				atItemStart = true;
				break;

			case MD_BLOCK_H: {
				nonParagraphBlock = true;
				blockBreak();
				const auto level = aDetail ? static_cast<MD_BLOCK_H_DETAIL*>(aDetail)->level : 1;
				openSpans.push_back({ offset(), RichTextSpan::HEADING, static_cast<uint8_t>(level) });
				break;
			}

			case MD_BLOCK_CODE:
				nonParagraphBlock = true;
				blockBreak();
				openSpans.push_back({ offset(), RichTextSpan::CODE_BLOCK, 0 });
				break;

			case MD_BLOCK_HR: {
				nonParagraphBlock = true;
				blockBreak();
				const auto start = offset();
				for (size_t i = 0; i < THEMATIC_BREAK_WIDTH; ++i) {
					append(TABLE_RULE_UNIT);
				}
				addSpan(start, offset(), RichTextSpan::THEMATIC_BREAK);
				break;
			}

			case MD_BLOCK_P:
				// The bullet is already on this line in a loose list; only a paragraph
				// that does not follow one starts a line of its own.
				if (atItemStart) {
					atItemStart = false;
				} else {
					blockBreak();
				}
				openSpans.push_back({ offset(), RichTextSpan::PARAGRAPH, 0 });
				break;

			case MD_BLOCK_TABLE:
				nonParagraphBlock = true;
				inTable = true;
				tableStart = offset();
				tableRows.clear();
				break;

			case MD_BLOCK_TR:
				if (inTable) {
					tableRows.emplace_back();
				}
				break;

			case MD_BLOCK_TH:
			case MD_BLOCK_TD:
				if (inTable && !tableRows.empty()) {
					if (tableCells >= limits.maxTableCells) {
						truncated = true;
						break;
					}
					++tableCells;
					tableRows.back().emplace_back();
					activeCell = &tableRows.back().back();
					activeCell->header = aType == MD_BLOCK_TH;
					sink = &activeCell->text;
					spanSink = &activeCell->spans;
				}
				break;

			default:
				break;
		}

		return 0;
	}

	int leaveBlock(MD_BLOCKTYPE aType, void* /*aDetail*/) {
		if (depth > 0) {
			depth--;
		}

		switch (aType) {
			case MD_BLOCK_QUOTE:
				closeSpan(RichTextSpan::BLOCKQUOTE);
				if (quoteDepth > 0) {
					quoteDepth--;
				}
				break;

			case MD_BLOCK_UL:
			case MD_BLOCK_OL:
				if (!lists.empty()) {
					lists.pop_back();
				}
				break;

			case MD_BLOCK_LI:
				// An empty item still consumed its marker.
				pendingItemMarker = false;
				// The suppression only ever applies to this item's own first
				// paragraph. Leaving it set runs the next block - a blockquote
				// after the list, say - onto the last bullet's line.
				atItemStart = false;
				closeSpan(RichTextSpan::LIST_ITEM);
				break;

			case MD_BLOCK_H:
				closeSpan(RichTextSpan::HEADING);
				break;

			case MD_BLOCK_CODE:
				closeSpan(RichTextSpan::CODE_BLOCK);
				break;

			case MD_BLOCK_P:
				closeSpan(RichTextSpan::PARAGRAPH);
				// A loose list separates its items with a blank line.
				if (!lists.empty() && !lists.back().tight) {
					append("\n", 1);
				}
				break;

			case MD_BLOCK_TH:
			case MD_BLOCK_TD:
				activeCell = nullptr;
				bindMainSink();
				break;

			case MD_BLOCK_TABLE:
				inTable = false;
				flushTable();
				break;

			default:
				break;
		}

		return 0;
	}

	void closeSpan(RichTextSpan::Kind aKind) {
		for (auto i = openSpans.rbegin(); i != openSpans.rend(); ++i) {
			if (i->kind == aKind) {
				addSpan(i->start, offset(), aKind, i->level);
				openSpans.erase(std::next(i).base());
				return;
			}
		}
	}

	int enterSpan(MD_SPANTYPE aType, void* aDetail) {
		switch (aType) {
			case MD_SPAN_EM:
				openSpans.push_back({ offset(), RichTextSpan::EMPH, 0 });
				break;
			case MD_SPAN_STRONG:
				openSpans.push_back({ offset(), RichTextSpan::STRONG, 0 });
				break;
			case MD_SPAN_DEL:
				openSpans.push_back({ offset(), RichTextSpan::STRIKE, 0 });
				break;
			case MD_SPAN_CODE:
				openSpans.push_back({ offset(), RichTextSpan::CODE_SPAN, 0 });
				break;

			case MD_SPAN_A:
			case MD_SPAN_IMG: {
				LinkState link;
				link.image = aType == MD_SPAN_IMG;
				if (aDetail) {
					// MD_SPAN_A_DETAIL and MD_SPAN_IMG_DETAIL both begin with href/src
					// followed by title, so the href field is at the same offset.
					const auto detail = static_cast<MD_SPAN_A_DETAIL*>(aDetail);
					if (detail->href.text && detail->href.size > 0) {
						link.href.assign(detail->href.text, detail->href.size);
					}
				}

				link.permitted = RichTextParser::isPermittedLinkTarget(link.href);
				if (link.image) {
					// RTF0: an image whose destination is not a magnet URI MUST NOT be
					// fetched and SHOULD be rendered as its own description, so a
					// non-magnet image degrades to its alt text rather than a link.
					link.permitted = link.permitted && lowerAscii(link.href).compare(0, 7, "magnet:") == 0;
				}

				link.labelStart = offset();
				linkStack.push_back(std::move(link));
				break;
			}

			default:
				break;
		}

		return 0;
	}

	int leaveSpan(MD_SPANTYPE aType, void* /*aDetail*/) {
		switch (aType) {
			case MD_SPAN_EM: closeSpan(RichTextSpan::EMPH); break;
			case MD_SPAN_STRONG: closeSpan(RichTextSpan::STRONG); break;
			case MD_SPAN_DEL: closeSpan(RichTextSpan::STRIKE); break;
			case MD_SPAN_CODE: closeSpan(RichTextSpan::CODE_SPAN); break;

			case MD_SPAN_A:
			case MD_SPAN_IMG: {
				if (linkStack.empty()) {
					return 1;
				}

				const auto link = linkStack.back();
				linkStack.pop_back();

				if (link.permitted && offset() > link.labelStart) {
					if (sink == &out) {
						emitLink(link, link.labelStart, offset());
					} else if (activeCell) {
						// Inside a table cell the offsets are relative to the cell's own
						// buffer, which has no home yet. Keep them until flushTable knows
						// where the cell landed.
						activeCell->links.push_back({ link.labelStart, offset(), link });
					}
				}
				break;
			}

			default:
				break;
		}

		return 0;
	}

	// aStart/aEnd are offsets into the finished text. They are the live offsets for a link
	// in the main flow, and the translated ones for a link recovered from a table cell.
	void emitLink(const LinkState& aLink, size_t aStart, size_t aEnd) {
		auto highlight = make_shared<MessageHighlight>(aStart, aEnd, aLink.href,
			MessageHighlight::HighlightType::TYPE_LINK_URL, "rich_link");

		if (lowerAscii(aLink.href).compare(0, 7, "magnet:") == 0) {
			auto magnet = Magnet::parseMagnet(aLink.href, nullptr);
			if (!magnet) {
				return; // "A magnet URI without a usable xt is not a link at all"
			}

			// dn is sender-chosen: display only, final component only, never a path.
			(*magnet).fname = PathUtil::getFileName((*magnet).fname);
			highlight->setMagnet(magnet);
			highlight->setTag(MessageHighlight::TAG_MAGNET);

			// Only an explicit '!' marks media, and only a magnet can carry it - both
			// already enforced above, since a non-magnet image never reaches here.
			highlight->setInlineMedia(aLink.image);
		}

		// The range already holds the author's label; without this the link stack would
		// substitute the destination for it. A magnet is the exception: it has its own
		// display rule ("name (size)"), and the size is the thing a reader needs in order
		// to decide whether to fetch the file, so leave that one alone.
		if (!highlight->getMagnet()) {
			highlight->setDisplayText(out.substr(aStart, aEnd - aStart));
		}

		addSpan(aStart, aEnd, RichTextSpan::LINK);
		result.links.push_back(std::move(highlight));
		result.doc.formatted = true;
	}

	int text(MD_TEXTTYPE aType, const MD_CHAR* aText, MD_SIZE aSize) {
		switch (aType) {
			case MD_TEXT_NULLCHAR:
				append("\xEF\xBF\xBD", 3); // U+FFFD
				break;

			case MD_TEXT_BR:
			case MD_TEXT_SOFTBR:
				if (sink == &out) {
					newline();
				} else {
					append(" ", 1); // a break inside a table cell would break alignment
				}
				break;

			case MD_TEXT_ENTITY: {
				string decoded;
				if (decodeEntity(string(aText, aSize), decoded)) {
					append(decoded);
				} else {
					append(aText, aSize);
				}
				break;
			}

			case MD_TEXT_CODE:
			case MD_TEXT_HTML:
			case MD_TEXT_NORMAL:
			default:
				// With MD_FLAG_NOHTML md4c stops recognising HTML, so anything that
				// looks like a tag arrives here as ordinary text and stays literal.
				if (aSize == 1 && aText[0] == '\n' && sink == &out) {
					newline();
				} else {
					append(aText, aSize);
				}
				break;
		}

		return 0;
	}
};

int onEnterBlock(MD_BLOCKTYPE aType, void* aDetail, void* aUserData) {
	try {
		return static_cast<Renderer*>(aUserData)->enterBlock(aType, aDetail);
	} catch (...) {
		return -1;
	}
}

int onLeaveBlock(MD_BLOCKTYPE aType, void* aDetail, void* aUserData) {
	try {
		return static_cast<Renderer*>(aUserData)->leaveBlock(aType, aDetail);
	} catch (...) {
		return -1;
	}
}

int onEnterSpan(MD_SPANTYPE aType, void* aDetail, void* aUserData) {
	try {
		return static_cast<Renderer*>(aUserData)->enterSpan(aType, aDetail);
	} catch (...) {
		return -1;
	}
}

int onLeaveSpan(MD_SPANTYPE aType, void* aDetail, void* aUserData) {
	try {
		return static_cast<Renderer*>(aUserData)->leaveSpan(aType, aDetail);
	} catch (...) {
		return -1;
	}
}

int onText(MD_TEXTTYPE aType, const MD_CHAR* aText, MD_SIZE aSize, void* aUserData) {
	try {
		return static_cast<Renderer*>(aUserData)->text(aType, aText, aSize);
	} catch (...) {
		return -1;
	}
}

} // namespace

bool RichTextParser::isPermittedLinkTarget(const string& aTarget) noexcept {
	if (aTarget.empty() || aTarget.size() > 4096) {
		return false;
	}

	for (const auto c: aTarget) {
		const auto uc = static_cast<unsigned char>(c);
		if (uc <= 0x20 || uc == 0x7F || c == '\\' || c == '"' || c == '<' || c == '>') {
			return false;
		}
	}

	const auto colon = aTarget.find(':');
	if (colon == string::npos || colon == 0 || !std::isalpha(static_cast<unsigned char>(aTarget[0]))) {
		return false;
	}

	for (size_t i = 1; i < colon; ++i) {
		const auto uc = static_cast<unsigned char>(aTarget[i]);
		if (!std::isalnum(uc) && uc != '+' && uc != '-' && uc != '.') {
			return false;
		}
	}

	const auto scheme = lowerAscii(aTarget.substr(0, colon));
	if (scheme == "magnet") {
		return true;
	}

	// Exactly the schemes RTF0 permits. No ftp, no mailto, no bare hosts, and no
	// nmdc:// alias -- the spec lists dchub and this must not be widened.
	if (scheme != "http" && scheme != "https" && scheme != "adc" && scheme != "adcs" && scheme != "dchub") {
		return false;
	}

	return hasAuthority(aTarget, colon);
}

bool RichTextParser::isInlineMediaFile(const string& aPath) noexcept {
	// What GDI+ decodes, so a file marked here is one the renderer can actually show.
	// Deliberately not WebP or AVIF: GDI+ handles neither, and marking a file we could
	// never display would promise the recipient something we cannot keep.
	static const char* const extensions[] = {
		".bmp", ".gif", ".ico", ".jpg", ".jpeg", ".png", ".tif", ".tiff"
	};

	const auto ext = lowerAscii(PathUtil::getFileExt(aPath));
	return ranges::any_of(extensions, [&ext](const char* aExt) { return ext == aExt; });
}

string RichTextParser::escapeLabel(const string& aText) noexcept {
	// Only what can actually change how a *label* parses. RTF0: "SHOULD escape nothing
	// else. Every unnecessary backslash is visible noise" - and the noise lands on
	// exactly the clients that cannot render RTF0, since they show the raw characters.
	//
	// So no '-', '#', '+' or '.': those open a list, heading or numbered item, and only
	// do so at the start of a line, which a label never is. A label sits between '[' and
	// ']' on one line, so the whole risk is the brackets, the escape character itself,
	// a code span, and the two emphasis markers.
	string ret;
	ret.reserve(aText.size());
	for (const auto c: aText) {
		if (strchr("\\`*_[]", c) != nullptr) {
			ret += '\\';
		}
		ret += c;
	}
	return ret;
}

optional<RichTextParser::Result> RichTextParser::parse(const string& aMarkdown) noexcept {
	return parse(aMarkdown, Limits());
}

RichTextParser::Limits RichTextParser::limitsFromSettings() noexcept {
	Limits l;
	l.maxInputBytes = static_cast<size_t>(std::clamp(SETTING(RICH_TEXT_MAX_SIZE), MAX_INPUT_KIB_MIN, MAX_INPUT_KIB_MAX)) * 1024;
	l.maxOutputBytes = std::max(l.maxOutputBytes, 4 * l.maxInputBytes);
	return l;
}

optional<RichTextParser::Result> RichTextParser::parse(const string& aMarkdown, const Limits& aLimits) noexcept {
	try {
		if (aMarkdown.empty() || aMarkdown.size() > aLimits.maxInputBytes) {
			return nullopt;
		}

		Renderer renderer(aLimits);
		renderer.bindMainSink();

		const MD_PARSER parser = {
			0,
			MD_FLAG_NOHTML | MD_FLAG_TABLES | MD_FLAG_STRIKETHROUGH,
			&onEnterBlock,
			&onLeaveBlock,
			&onEnterSpan,
			&onLeaveSpan,
			&onText,
			nullptr,
			nullptr
		};

		if (md_parse(aMarkdown.data(), static_cast<MD_SIZE>(aMarkdown.size()), &parser, &renderer) != 0) {
			return nullopt;
		}

		auto& doc = renderer.result.doc;
		doc.text = std::move(renderer.out);
		doc.spans = std::move(renderer.spans);
		doc.truncated = renderer.truncated;
		doc.blockLevel = renderer.topLevelBlocks > 1 || renderer.nonParagraphBlock;

		// Trailing blank lines from loose lists and block breaks are noise in chat.
		while (!doc.text.empty() && (doc.text.back() == '\n' || doc.text.back() == ' ')) {
			doc.text.pop_back();
		}
		if (doc.text.empty()) {
			return nullopt;
		}

		// Clamp any span the trim just orphaned, then order outermost-first so a
		// renderer can apply blocks before the inline runs that sit inside them.
		for (auto& span: doc.spans) {
			span.start = std::min(span.start, doc.text.size());
			span.end = std::min(span.end, doc.text.size());
		}
		std::erase_if(doc.spans, [](const RichTextSpan& aSpan) { return aSpan.end <= aSpan.start; });
		std::stable_sort(doc.spans.begin(), doc.spans.end());

		std::erase_if(renderer.result.links, [&](const MessageHighlightPtr& aLink) {
			return aLink->getEnd() > doc.text.size();
		});
		std::stable_sort(renderer.result.links.begin(), renderer.result.links.end(),
			[](const MessageHighlightPtr& a, const MessageHighlightPtr& b) {
				return a->getStart() < b->getStart();
			});

		return renderer.result;
	} catch (...) {
		// Reached from the hub socket thread through a noexcept constructor: a
		// throw here would take the client down for every recipient in the hub.
		return nullopt;
	}
}

} // namespace dcpp
