/*
 * Copyright (C) 2001-2024 Jacek Sieka, arnetheduck on gmail point com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "stdinc.h"

#include <airdcpp/message/Message.h>
#include <airdcpp/message/RichText.h>
#include <airdcpp/core/classes/Magnet.h>
#include <airdcpp/hub/ClientManager.h>
#include <airdcpp/share/temp_share/TempShareManager.h>
#include <airdcpp/user/OnlineUser.h>
#include <airdcpp/core/timer/TimerManager.h>

namespace dcpp {

atomic<uint64_t> messageIdCounter { 1 };

ChatMessage::ChatMessage(const string& aOriginalText, const OnlineUserPtr& aFrom, const OnlineUserPtr& aTo, const OnlineUserPtr& aReplyTo, bool aRich) noexcept :
	from(aFrom), to(aTo), replyTo(aReplyTo), time(GET_TIME()), id(messageIdCounter++) {

	if (aRich) {
		// RTF0 markdown must reach the parser byte for byte, so cleanText's paste guard
		// is skipped: it inserts "- " before any line starting with '[' or '<', which
		// would silently rewrite a link reference definition into a list item.
		// limitsFromSettings rather than the fixed defaults: communities that raise
		// RICH_TEXT_MAX_SIZE stay symmetric (send and receive honor the same limit),
		// and its hard clamp keeps a hostile sender bounded regardless.
		if (auto parsed = RichTextParser::parse(Message::unifyLineEndings(aOriginalText), RichTextParser::limitsFromSettings()); parsed) {
			originalText = aOriginalText;
			text = (*parsed).doc.text;
			richDocument = make_shared<const RichTextDocument>(std::move((*parsed).doc));
			rich = true;

			// Seeded before parseHighlights so the rich links win: insert_sorted drops
			// anything overlapping, which is the existing "earlier formatters override
			// later ones" priority.
			for (const auto& link: (*parsed).links) {
				// The parser deliberately knows nothing about users, so a magnet it
				// produced carries no recipient and cannot tell whether the sender is
				// temp-sharing that file. Attach it here, where the recipient is known:
				// this decides both the tag and Magnet::getDupeType, which consults the
				// same user - without it a temp-shared file offered through a rich link
				// looked like a file we do not have. The magnet is reused rather than
				// re-parsed so the parser's filename sanitising is not lost.
				if (const auto& parsedMagnet = link->getMagnet(); parsedMagnet) {
					// Null for a hub message, exactly as the plain-link path passes it
					const auto recipient = aTo ? aTo->getUser() : nullptr;

					auto magnet = *parsedMagnet;
					magnet.to = recipient;
					link->setMagnet(magnet);
					link->setTag(TempShareManager::getInstance()->isTempShared(recipient, magnet.getTTH()) ?
						MessageHighlight::TAG_TEMP_SHARE : MessageHighlight::TAG_MAGNET);
				}

				highlights.insert_sorted(link);
			}
		}
	}

	if (!rich) {
		text = cleanText(aOriginalText);
	}

	read = aFrom && aFrom->getUser() == ClientManager::getInstance()->getMe();
}

LogMessage::LogMessage(const string& aOriginalText, LogMessage::Severity aSeverity, Type aType, const string& aLabel, int aInitFlags) noexcept :
	read(aInitFlags & INIT_DISABLE_TIMESTAMP), id(messageIdCounter++), text(Message::unifyLineEndings(aOriginalText)),
	label(aLabel), time(aInitFlags & INIT_DISABLE_TIMESTAMP ? 0 : GET_TIME()),
	severity(aSeverity), type(aType) {

	if (!(aInitFlags & INIT_DISABLE_HIGHLIGHTS)) {
		highlights = MessageHighlight::parseHighlights(text, Util::emptyString, nullptr);
	}
}

LogMessage::LogMessage(const LogMessage& aFrom, const string& aText) noexcept :
	read(aFrom.read), id(aFrom.id), text(Message::unifyLineEndings(aText)),
	label(aFrom.label), time(aFrom.time), severity(aFrom.severity), type(aFrom.type) {

	highlights = MessageHighlight::parseHighlights(text, Util::emptyString, nullptr);
}

LogMessagePtr LogMessage::withText(const LogMessagePtr& aFrom, const string& aText) noexcept {
	return LogMessagePtr(new LogMessage(*aFrom, aText));
}

string LogMessage::format() const noexcept {
	return time == 0 ? text : "*** " + text;
}

string ChatMessage::formatAuthor() const noexcept {
	string tmp;

	const string& nick = from->getIdentity().getNick();
	// let's *not* obey the spec here and add a space after the star. :P
	tmp += (thirdPerson ? "* " + nick : '<' + nick + ">");

	return tmp;
}

string ChatMessage::cleanText(const string& aText) noexcept {
	auto tmp = Message::unifyLineEndings(aText);

	// Check all '<' and '[' after newlines as they're probably pastes...
	size_t i = 0;
	while ((i = tmp.find('\n', i)) != string::npos) {
		if (i + 1 < tmp.length()) {
			if (tmp[i + 1] == '[' || tmp[i + 1] == '<') {
				tmp.insert(i + 1, "- ");
				i += 2;
			}
		}
		i++;
	}

	return tmp;
}

string ChatMessage::format() const noexcept {
	return formatAuthor() + " " + text;
}

void ChatMessage::parseMention(const Identity& aMe) noexcept {
	if (from->getIdentity().getSID() == aMe.getSID() || !from->getIdentity().isUser()) {
		return;
	}

	if (text.find(aMe.getNick()) != string::npos) {
		mentionedNick = aMe.getNick();
	}
}

void ChatMessage::parseHighlights(const Identity& aMe, const MessageHighlightList& aHookHighlights) noexcept {
	// Insert hook highlights
	for (const auto& hl: aHookHighlights) {
		highlights.insert_sorted(hl);
	}

	// Insert our highlights (that won't overlap)
	const auto defaultHighlights = MessageHighlight::parseHighlights(text, aMe.getNick(), to ? to->getUser() : nullptr);
	for (const auto& hl: defaultHighlights) {
		highlights.insert_sorted(hl);
	}
}

string Message::unifyLineEndings(const string& aText) {
	auto text = aText;

	string::size_type j = 0;
	while ((j = text.find("\r", j)) != string::npos)
		text.erase(j, 1);

	return text;
}

Message Message::fromText(const string& aMessage, int aInitFlags) noexcept {
	auto logMessage = std::make_shared<LogMessage>(aMessage, LogMessage::SEV_INFO, LogMessage::Type::SYSTEM, Util::emptyString, aInitFlags);
	return Message(logMessage);
}

} // namespace dcpp
