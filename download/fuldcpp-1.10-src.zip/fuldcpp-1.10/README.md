# FulDC++ for Windows

FulDC++ is a Windows file sharing client for the [ADC](https://en.wikipedia.org/wiki/Advanced_Direct_Connect)
and [NMDC](https://en.wikipedia.org/wiki/Direct_Connect_(protocol)) protocols, forked from
[AirDC++](https://github.com/airdcpp/airdcpp-windows) and developed actively — including the Windows GUI,
which upstream maintains on a bug-fixes-only basis.

Downloads, news and support: [fuldcpp.net](https://fuldcpp.net/)

## Supported operating systems

Windows 10/11

## Current development status

| Component  | Status |
| ------------- | ------------- |
| Core  | Active  |
| Web API  | Active  |
| Web UI  | Active  |
| Windows GUI  | Active  |

Contributions are welcome.

## Compiling

### Required tools

- [Visual Studio 2022](https://visualstudio.microsoft.com/)
- [Python](https://www.python.org/)
- [vcpkg](https://vcpkg.io/en/) with `VCPKG_ROOT` env variable pointing to the vcpkg installation directory
- [CMake](https://cmake.org/)

## Building from command line

Run the following commands in the repository root:

`cmake --preset=<preset-name>`

`cmake --build --preset=<preset-name>`

Replace `<preset-name>` with one of the presets listed under `cmake --list-presets`

The GUI executable is written to `compiled/<preset>/windows/FulDC.exe` (`FulDCd.exe` for debug presets).

## Opening in Visual Studio

You can simply use the `Open a local folder` option in Visual Studio. 

Alternatively you may also generate the Visual Studio project files with the following command:

`cmake "-DCMAKE_VS_GLOBALS=UseMultiToolTask=true;EnforceProcessCountAcrossBuilds=true" -B msvc -G "Visual Studio 17 2022" --preset=<preset-name>_`

## Credits

FulDC++ builds on [AirDC++](https://github.com/airdcpp/airdcpp-windows) by the AirDC++ Project, which in
turn builds on [DC++](https://dcplusplus.sourceforge.net/). The `airdcpp/` and `airdcpp-webapi/`
directories are vendored from their upstream repositories. Licensed under the GPL — see the file headers
for the full copyright notices.
